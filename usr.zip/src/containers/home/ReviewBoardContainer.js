import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import PropTypes from 'prop-types';
// components import
import { ReviewBoard } from '../../components/main';
// utils import
import { NewMainString } from '../../utils/common/strings';
// styles import
import { Font } from '../../utils/style';
const { responseFont } = Font;

function ReviewBoardContainer({ appReview, style }) {
  return (
    <View style={[styles.container, style]}>
      <View style={styles.title}>
        <Text
          style={styles.titleText}
        >{`${NewMainString.reviewBoardTitle}`}</Text>
      </View>
      <ReviewBoard appReview={appReview} autoplayTimeout={5} />
    </View>
  );
}

ReviewBoardContainer.defaultProps = {
  appReview: [],
  style: {},
};

ReviewBoardContainer.propTypes = {
  appReview: PropTypes.array.isRequired,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 56,
  },
  title: {
    marginBottom: 16,
  },
  titleText: {
    ...responseFont(16).bold,
  },
});

export default React.memo(ReviewBoardContainer);
