import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import PropTypes from 'prop-types';
// components import
import { AddressInfoButton, ServiceButtonGroup } from '../../components/main';
// utils import
import { mainServiceStyleList } from '../../static/settings';
import { NewMainString } from '../../utils/common/strings';
import { navPushAddressChangeScreen } from '../../utils/common/nav';
// styles import
import { Font } from '../../utils/style';
const { responseFont, washswatColor } = Font;

function MainServiceContainer({
  componentId,
  MainScreenState,
  mainServiceInfoList,
  deliveryDay,
  onPressService,
  globalData,
  style,
}) {
  const [title, setTitle] = useState({ main: '', sub: '' });
  const mainServiceList = mainServiceInfoList.map((item, i) =>
    Object.assign({}, item, mainServiceStyleList[i]),
  );

  useEffect(() => {
    if (globalData)
      setTitle(getTitleMessage(deliveryDay, globalData.isService));
  }, [globalData, deliveryDay]);

  const onPressAddress = () => {
    const passProps = { express: false, weekly: false };
    navPushAddressChangeScreen({ componentId, passProps });
  };

  const getTitleMessage = (deliveryDay, isService) => {
    return {
      main:
        isService && deliveryDay && deliveryDay.length > 0
          ? NewMainString.mainTitle1
          : NewMainString.noServiceAreaTitle_,
      sub:
        isService && deliveryDay && deliveryDay.length > 0
          ? `${deliveryDay}${NewMainString.mainTitle2}`
          : NewMainString.noServiceAreaTitle_2,
    };
  };

  return (
    <View style={[styles.container, style]}>
      <View style={styles.infoContainer}>
        <View style={styles.title}>
          <View>
            <Text style={styles.titleText}>{title.main}</Text>
            <Text style={styles.titleText}>{title.sub}</Text>
          </View>
        </View>
        <AddressInfoButton
          style={styles.addressContainer}
          addressText={MainScreenState.fullAddress}
          onPressAddress={onPressAddress}
        />
      </View>
      <View style={styles.mainServiceGroup}>
        <ServiceButtonGroup
          serviceList={mainServiceList}
          onPressService={onPressService}
        />
      </View>
    </View>
  );
}

MainServiceContainer.defaultProps = {
  componentId: '0',
  MainScreenState: {},
  mainServiceInfoList: [],
  deliveryDay: '',
  onPressService: () => {},
  globalData: {},
  style: {},
};

MainServiceContainer.propTypes = {
  componentId: PropTypes.string.isRequired,
  MainScreenState: PropTypes.object.isRequired,
  mainServiceInfoList: PropTypes.array.isRequired,
  deliveryDay: PropTypes.string.isRequired,
  onPressService: PropTypes.func.isRequired,
  globalData: PropTypes.object.isRequired,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  container: {
    height: 310,
  },
  infoContainer: {
    marginTop: 28,
  },
  title: {
    height: 62,
    marginBottom: 24,
  },
  titleText: {
    color: washswatColor.black_10,
    ...responseFont(24).bold,
  },
  addressContainer: {
    height: 37,
    marginBottom: 24,
  },
  mainServiceGroup: {
    alignItems: 'center',
  },
});

export default React.memo(MainServiceContainer);
