import React from 'react';
import { StyleSheet, View } from 'react-native';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';
// modules import
import * as MainScreenModule from '../../reducers/MainScreenModule';
// components import
import { BigContents } from '../../components/main';
// utils import
import { navPushWebViewScreen } from '../../utils/common/nav';

function ContentsWrapper({ componentId, children, contentsStyle, style }) {
  const dispatch = useDispatch();
  const MainScreenState = useSelector(state => state.MainScreenModule);

  const offScrollTopEvent = () =>
    dispatch(MainScreenModule.offScrollTopEvent());
  const onScrollTopVisible = () =>
    dispatch(MainScreenModule.onScrollTopVisible());
  const offScrollTopVisible = () =>
    dispatch(MainScreenModule.offScrollTopVisible());
  const getContents = () => dispatch(MainScreenModule.getContentsAPI());

  const onPressContents = serviceInfo => {
    const passProps = {
      option: {
        title: serviceInfo.title,
        url: serviceInfo.url,
      },
    };
    navPushWebViewScreen({ componentId, passProps });
  };

  return (
    <View style={[styles.container, style]}>
      <BigContents
        contentsStyle={contentsStyle}
        MainScreenState={MainScreenState}
        offScrollTopEvent={offScrollTopEvent}
        onScrollTopVisible={onScrollTopVisible}
        offScrollTopVisible={offScrollTopVisible}
        getContents={getContents}
        onPressContents={onPressContents}
        headerComponents={children}
      />
    </View>
  );
}

ContentsWrapper.defaultProps = {
  componentId: '0',
  contentsStyle: {},
  style: {},
  children: null,
};

ContentsWrapper.propTypes = {
  componentId: PropTypes.string.isRequired,
  contentsStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  children: PropTypes.oneOfType([PropTypes.array, PropTypes.element]),
};

const styles = StyleSheet.create({
  container: {},
});

export default ContentsWrapper;
