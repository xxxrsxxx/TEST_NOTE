import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import PropTypes from 'prop-types';
// components import
import { ServiceButtonGroup } from '../../components/main';
// utils import
import { subServiceStyleList } from '../../static/settings';
import { NewMainString } from '../../utils/common/strings';
// styles import
import { Font } from '../../utils/style';
const { responseFont } = Font;

function SubServiceContainer({ subServiceInfoList, onPressService, style }) {
  const subServiceList = subServiceInfoList.map((item, i) =>
    Object.assign({}, item, subServiceStyleList[i]),
  );

  return (
    <View style={[styles.container, style]}>
      <View style={styles.title}>
        <Text style={styles.titleText}>{NewMainString.subTitle}</Text>
      </View>
      <View style={styles.mainServiceGroup}>
        <ServiceButtonGroup
          serviceList={subServiceList}
          onPressService={onPressService}
        />
      </View>
    </View>
  );
}

SubServiceContainer.defaultProps = {
  subServiceInfoList: [],
  onPressService: () => {},
  style: {},
};

SubServiceContainer.propTypes = {
  subServiceInfoList: PropTypes.array.isRequired,
  onPressService: PropTypes.func.isRequired,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 32, // 디자인상에는 56이나 ServiceButton에 marginBottom 24가 있어서 32만 입력
  },
  title: {
    marginBottom: 16,
  },
  titleText: {
    ...responseFont(16).bold,
  },
  mainServiceGroup: {
    alignItems: 'center',
  },
});

export default SubServiceContainer;
