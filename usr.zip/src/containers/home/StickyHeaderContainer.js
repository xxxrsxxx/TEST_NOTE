import React from 'react';
import { StyleSheet, View } from 'react-native';
import PropTypes from 'prop-types';
import { ChannelIO } from 'react-native-channel-plugin';
// components import
import { BellButton } from '../../components/main';

function StickyHeaderContainer({ style, badge }) {
  const showMessenger = () => {
    ChannelIO.showMessenger();
  };

  return (
    <View style={[styles.container, style]}>
      <BellButton
        style={styles.bellBtn}
        badge={badge}
        onPress={showMessenger}
      />
    </View>
  );
}

StickyHeaderContainer.defaultProps = {
  style: {},
  badge: 0,
};

StickyHeaderContainer.propTypes = {
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  badge: PropTypes.number.isRequired,
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 44,
    alignItems: 'flex-end',
  },
  bellBtn: {
    marginTop: 12,
    marginRight: 16,
  },
});

export default StickyHeaderContainer;
