import React, { useEffect, useState, useRef } from 'react';
import {
  StyleSheet,
  TouchableOpacity,
  View,
  Text,
  ScrollView,
  TextInput,
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../../reducers/MyPageModule';

import { Font } from '../../../utils/style';
const { responseFont } = Font;

const ActionInterface = [
  {
    _id: 0,
    type: 'storage',
    name: 'getStorage',
    action: 'storageLog',
  },
  {
    _id: 1,
    type: 'user',
    name: 'status.user',
    action: 'userInfo',
  },
  {
    _id: 2,
    type: 'user',
    name: 'executeLogout',
    action: 'logout',
  },
];

function DebugFixedContainer(props) {
  const { MyPageAction } = props;

  const eventHandler = async (e, o) => {
    const { action } = o;

    switch (action) {
      case 'storageLog':
        $_debug.storageLog('GET');
        break;
      case 'userInfo':
        console.log(
          '%c ====================$_statusModule.state====================',
          log.style,
          '\n return',
          $_status.state.user,
        );

        break;
      case 'logout':
        MyPageAction.logOut();
        break;
      default:
    }
  };

  const closeHandler = () => {
    $_status.actions.statusHandler('debug:false');
  };

  const commonEventElements = () => {
    return ActionInterface.map(o => {
      return (
        <TouchableOpacity
          style={styles.commonBtn}
          key={`dc${o._id}`}
          onPress={e => {
            eventHandler(e, o);
          }}
        >
          <Text style={[styles.whiteFont]}>{o.name}</Text>
        </TouchableOpacity>
      );
    });
  };

  $_useCycleHandler.unMounted(() => {
    $_status.actions.statusHandler('debug:false');
  });

  return (
    <>
      <View style={styles.container}>
        <View style={styles.top}>
          <Text style={styles.whiteFont}>디버그 모드</Text>
          <TouchableOpacity onPress={closeHandler}>
            <Text style={styles.whiteFont}>닫기</Text>
          </TouchableOpacity>
        </View>
        <ScrollView>
          <View>
            <Text style={styles.subTitle}>공통 메서드</Text>
            <View style={styles.commonTop}>{commonEventElements()}</View>
          </View>
          <View>
            <Text style={styles.subTitle}>페이지 메서드</Text>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(DebugFixedContainer);

const log = {
  style: [
    'background: black',
    'border: 1px solid #3E0E02',
    'color: white',
    'display: block',
    'line-height: 40px',
    'text-align: center',
    'font-weight: bold',
    'font-size: 20px',
  ].join(';'),
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: '40%',
    backgroundColor: '#000000a3',
  },
  top: {
    paddingTop: 60,
    paddingBottom: 50,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  commonTop: { flexDirection: 'row' },
  commonBtn: { marginTop: 10, marginRight: 10 },
  subTitle: { marginTop: 30, ...responseFont(16).bold, color: 'red' },
  whiteFont: {
    ...responseFont(14).bold,
    color: '#fff',
  },
});
