import React, { Component } from 'react';

import {
  Image,
  PixelRatio,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import ViewShot from 'react-native-view-shot';

import Marker from '../../components/common/style/Marker';

import { ImageMarkerGuide } from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  preview: {
    flex: 1,
    alignItems: 'center',
  },
  capture: {
    flex: 0,
    backgroundColor: washswatColor.black,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 68,
    width: 78,
    height: 78,
    borderRadius: 39,
    alignSelf: 'center',
    flexDirection: 'row',
  },
  bottom: {
    height: 180,
    ...Platform.select({
      android: {
        backgroundColor: washswatColor.white,
        // height: 100,
      },
    }),
  },
  toggleImage: {
    // flex: 1,
    width: 16,
    height: 16,
    marginTop: 43,
    marginBottom: 21,
    marginLeft: 18,
  },
  nextButtonText: {
    // flex: 1,
    color: washswatColor.blue,
    marginTop: 40,
    marginBottom: 21,
    marginRight: 18,
    textAlign: 'center',
    height: 19,
    width: 40,
    lineHeight: 22,
  },
  albumImage: {
    flex: 0,
    alignItems: 'center',
    justifyContent: 'center',
    width: 16,
    height: 16,
    alignSelf: 'center',
  },
  guideText: {
    ...responseFont(14).bold,
    color: washswatColor.grey_03,
    // marginTop: 90,
    textAlign: 'center', // <-- the magic
  },
  imageLayer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    backgroundColor: washswatColor.grey_04,
  },
  markerLayer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
});

class ImageMarkerContainer extends Component {
  state = {
    markerList: [],
    isPending: false,
    cameraStatus: '',
  };

  handlePressGoBack = () => {
    Navigation.dismissModal(this.props.componentId);
  };

  _screenCapture = async () => {
    return this.refs.captureViewRef
      .capture()
      .then(uri => {
        return uri;
      })
      .catch(e => {});
  };

  handlePressNext = async () => {
    const { imageUrl, finishedAction } = this.props;
    let fileUri = imageUrl;
    if (this.state.markerList.length > 0) {
      fileUri = await this._screenCapture();
    }
    finishedAction(fileUri);
    this.handlePressGoBack();
  };

  handlePressImage = event => {
    const copyMarkerList = _.cloneDeep(this.state.markerList);
    const location = {
      x: event.nativeEvent.locationX,
      y: event.nativeEvent.locationY,
    };
    copyMarkerList.push({
      location,
      isStatusDelete: false,
    });
    this.setState({
      markerList: copyMarkerList,
    });
  };

  handlePressMarker = index => {
    const copyMarkerList = _.cloneDeep(this.state.markerList);
    copyMarkerList[index].isStatusDelete = !this.state.markerList[index]
      .isStatusDelete;
    this.setState({
      markerList: copyMarkerList,
    });
  };

  handlePressDeleteMarker = index => {
    const copyMarkerList = _.cloneDeep(this.state.markerList);
    copyMarkerList.splice(index, 1);
    this.setState({
      markerList: copyMarkerList,
    });
  };

  _renderImage = imageUrl => {
    let guideText = ImageMarkerGuide.addMarker;
    if (this.state.markerList.length > 0) {
      guideText = ImageMarkerGuide.deleteMarker;
    }
    return (
      <>
        <ViewShot
          style={styles.preview}
          options={{ format: 'jpg', quality: 0.9 }}
          ref="captureViewRef"
        >
          <Image style={styles.imageLayer} source={{ uri: imageUrl }} />
          {/* 마커 레이어 */}
          <TouchableOpacity
            style={styles.markerLayer}
            activeOpacity={1}
            onPress={this.handlePressImage}
          >
            {this.state.markerList.map((item, index) => {
              return (
                <Marker
                  key={index}
                  location={item.location}
                  isStatusDelete={true}
                  onPressMarker={() => this.handlePressMarker(index)}
                  onPressDeleteMarker={() =>
                    this.handlePressDeleteMarker(index)
                  }
                />
              );
            })}
          </TouchableOpacity>
        </ViewShot>
        <View
          style={[
            styles.bottom,
            { justifyContent: 'center', alignItems: 'center', width: `100%` },
          ]}
        >
          <Text
            style={[
              responseFont(16).bold,
              {
                color: washswatColor.black,
                lineHeight: 21,
                textAlign: 'center',
              },
            ]}
          >
            {ImageMarkerGuide.title}
          </Text>
          <Text
            style={[
              responseFont(14).bold,
              { color: washswatColor.darkGrey, lineHeight: 21, marginTop: 12 },
            ]}
          >
            {ImageMarkerGuide.subtitle}
          </Text>
          {/*<Text style={styles.guideText}>{guideText}</Text>*/}
        </View>
      </>
    );
  };

  render() {
    const { imageUrl } = this.props;
    return (
      <>
        {imageUrl ? (
          <View style={{ flex: 1 }}>
            <View
              style={{
                flexDirection: 'row',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                height: PixelRatio.roundToNearestPixel(
                  61 + getStatusBarHeight(true),
                ),
              }}
            >
              <TouchableOpacity onPress={this.handlePressGoBack}>
                <Image
                  style={styles.toggleImage}
                  source={require('image/common/no.png')}
                />
              </TouchableOpacity>
              <TouchableOpacity onPress={this.handlePressNext}>
                <Text style={[responseFont(16).bold, styles.nextButtonText]}>
                  {ImageMarkerGuide.next}
                </Text>
              </TouchableOpacity>
            </View>
            {this._renderImage(imageUrl)}
          </View>
        ) : (
          <View />
        )}
      </>
    );
  }
}

export default ImageMarkerContainer;
