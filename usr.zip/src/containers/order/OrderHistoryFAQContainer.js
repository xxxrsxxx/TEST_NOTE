import React, { useEffect, useState } from 'react';

import { Image, Text, View } from 'react-native';
import Accordion from 'react-native-collapsible/Accordion';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';
import * as MainScreenModule from '../../reducers/MainScreenModule';

import AnnouncementContentView from '../../components/cs/AnnouncementContentView';

import { FAQText } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const OrderHistoryFAQContainer = props => {
  const [activeSections, setActiveSections] = useState([]);
  const [sections, setSections] = useState([]);
  const { MainScreenState, OrderHistoryState } = props;
  const { orderItemList } = OrderHistoryState;
  const { FAQs } = MainScreenState;
  if (!orderItemList || !FAQs) {
    return null;
  }

  useEffect(() => {
    if (orderItemList && orderItemList.length > 0) {
      const { status } = orderItemList[0];
      setSections(FAQs[status]);
    }
  }, []);

  const renderHeader = section => {
    const { status, question } = section;
    const title = FAQText.titles[status] ? FAQText.titles[status] : FAQText.etc;
    return (
      <View
        style={{
          backgroundColor: washswatColor.white,
          paddingLeft: 24,
          paddingRight: 24,
        }}
      >
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingTop: 24,
            paddingBottom: 24,
          }}
        >
          <View style={{ flex: 1 }}>
            <Text
              style={{
                ...responseFont(14).regular,
                color: washswatColor.grey_13,
              }}
            >{`[ ${title} ]`}</Text>
            <Text
              style={{
                ...responseFont(14).regular,
                color: washswatColor.black,
                marginTop: 8,
              }}
            >
              {question}
            </Text>
          </View>
          <Image
            source={require('../../../assets/image/v5/order-history/arrow_down.png')}
            style={{ width: 12, height: 6.5, marginLeft: 9 }}
          />
        </View>
        <View style={{ height: 1, backgroundColor: washswatColor.grey_12 }} />
      </View>
    );
  };

  const renderContent = section => {
    const { content = '...' } = section;
    if (!content) {
      return;
    }
    return <AnnouncementContentView content={content} />;
  };

  const updateSections = activeSections => {
    setActiveSections(activeSections);
  };

  return (
    <View
      style={{
        paddingTop: 40,
        paddingBottom: 43,
        backgroundColor: washswatColor.white,
      }}
    >
      <Text
        style={{
          ...responseFont(18).bold,
          color: washswatColor.black,
          marginLeft: 24,
        }}
      >
        {FAQText.faq}
      </Text>
      <Accordion
        sections={sections}
        renderHeader={renderHeader}
        renderContent={renderContent}
        onChange={updateSections}
        activeSections={activeSections}
      />
    </View>
  );
};

const mapStateToProps = ({ OrderHistoryModule, MainScreenModule }) => ({
  OrderHistoryState: OrderHistoryModule,
  MainScreenState: MainScreenModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
  MainScreenAction: bindActionCreators(MainScreenModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderHistoryFAQContainer);
