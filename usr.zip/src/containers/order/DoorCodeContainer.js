import React, { Component } from 'react';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';
import * as DoorModule from '../../reducers/DoorModule';

import { CollapsibleComponent } from '../../components/common/collapse/CollapsibleComponent';

import { DoorPassText } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import { Font } from '../../utils/style';

import * as PageName from '../../vo/PageName';

const { washswatColor } = Font;

class DoorCodeContainer extends Component {
  onPressButton = () => {
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'TextInputScreen',
      passProps: {
        pageName: PageName.DOOR_CODE,
        finishedAction: inputValue => {
          const { DoorAction, orderId } = this.props;
          DoorAction.updateDoorCodeAPI({ orderId, doorCode: inputValue });
        },
      },
    });
  };

  render() {
    const { OrderHistoryState } = this.props;
    const { orderItem } = OrderHistoryState;
    const { userInfo } = orderItem;
    const { doorCode } = userInfo;
    let content = `[언제나 열려있음] ${DoorPassText.content}`;
    if (doorCode) {
      content = `[${doorCode}] ${DoorPassText.content}`;
    }
    return (
      <CollapsibleComponent
        title={DoorPassText.title}
        content={content}
        buttonText={DoorPassText.button}
        buttonTitleColor={washswatColor.black}
        onPressButton={this.onPressButton}
        bgColor={washswatColor.white}
        buttonBgColor={washswatColor.grey_07}
        borderRadius={10}
      />
    );
  }
}

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
  DoorAction: bindActionCreators(DoorModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(DoorCodeContainer);
