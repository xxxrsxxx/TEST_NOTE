import React, { Component } from 'react';
import {
  FlatList,
  Image,
  Keyboard,
  PixelRatio,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Linking,
  Alert,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import BottomSheet from 'react-native-bottomsheet';
import ShimmerPlaceHolder from 'react-native-shimmer-placeholder';
import ImagePicker from 'react-native-image-crop-picker';
import { RNS3 } from 'react-native-aws3';
import Modal from 'react-native-modalbox';
import ImageEditor from '@react-native-community/image-editor';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderChatModule from '../../reducers/OrderChatModule';
import * as BottomTabModule from '../../reducers/BottomTabModule';

import LoadingBar from '../../components/common/button/LoadingBar';
import KeyboardSpacerIOS from '../../components/common/keyboard/KeyboardSpacerIOS';

import * as KeyUtils from '../../utils/type/key';
import * as ServerUtils from '../../utils/type/server';
import * as CommonUtils from '../../utils/common';
import { ErrorMessage, Favorite, OrderChat } from '../../utils/common/strings';
import WashAlert from '../../utils/alert';
import { Font, Styles } from '../../utils/style';

import { _, moment } from '../../plugins';

const { responseFont, washswatColor } = Font;
const { androidStatusBar } = Styles;

const BORDER_RADIOS = 20;

const styles = StyleSheet.create({
  input: {
    padding: 10,
    borderWidth: 0.5,
    borderRadius: 4,
    backgroundColor: '#fff',
    color: 'black',
    width: '90%',
  },
  bottomInputFrame: {
    flexDirection: 'column',
  },
  bottonInputTextFrame: {
    borderTopWidth: PixelRatio.roundToNearestPixel(1),
    borderColor: washswatColor.grey_05,
    backgroundColor: washswatColor.white,
    flexDirection: 'row',
    alignItems: 'flex-end',
  },

  inputText: {
    // height:
    paddingTop: PixelRatio.roundToNearestPixel(10),
    paddingBottom: PixelRatio.roundToNearestPixel(10),
    maxHeight: PixelRatio.roundToNearestPixel(160),
    paddingLeft: PixelRatio.roundToNearestPixel(10),
    paddingRight: PixelRatio.roundToNearestPixel(30),
    color: washswatColor.black,
  },
  flatList: {
    // backgroundColor : washswatColor.red,
    paddingTop: PixelRatio.roundToNearestPixel(7),
    borderRadius: PixelRatio.roundToNearestPixel(BORDER_RADIOS),
    marginBottom: PixelRatio.roundToNearestPixel(15),
    // paddingLeft : PixelRatio.roundToNearestPixel(30) ,
    // paddingRight  : PixelRatio.roundToNearestPixel(30) ,
  },
  textInput: {
    flex: 1,
    // backgroundColor:'red',
    // width: '100%',
    marginTop: PixelRatio.roundToNearestPixel(6),
    marginBottom: PixelRatio.roundToNearestPixel(6),
    marginRight: PixelRatio.roundToNearestPixel(12),
    borderWidth: 1,
    borderColor: washswatColor.grey_09,
    borderRadius: PixelRatio.roundToNearestPixel(BORDER_RADIOS),
  },

  sendButtonImage: {
    width: PixelRatio.roundToNearestPixel(30),
    height: PixelRatio.roundToNearestPixel(30),
  },

  sendBtn: {
    paddingEnd: PixelRatio.roundToNearestPixel(15),
    zIndex: 1000,
    position: 'absolute',
    right: 0,
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingRight: PixelRatio.roundToNearestPixel(7) + 1, // inputText's paddingRight + borderWidth
  },
  userChat: {
    backgroundColor: washswatColor.black,
    color: washswatColor.white,
    padding: 18,
    maxWidth: 280,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    ...responseFont(15).regular,
  },
  swatChat: {
    backgroundColor: washswatColor.white,
    color: washswatColor.black,
    padding: 18,
    maxWidth: 280,
    minWidth: 280,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    ...responseFont(15).regular,
  },
  userChatContainer: {
    alignItems: 'flex-end',
  },
  swatChatContainer: {
    alignItems: 'flex-start',
  },
  chatButtonWrap: {
    padding: 15,
    alignItems: 'center',
    borderRadius: 6,
    backgroundColor: washswatColor.white,
  },
  chatButtonWrap0: {
    marginTop: 30,
  },
  chatButton: {
    color: washswatColor.black,
    ...responseFont(16).regular,
    textAlign: 'center',
  },
  form: {
    flex: 1,
    justifyContent: 'space-between',
    height: '100%',
    backgroundColor: washswatColor.grey_16,
    paddingTop: 30,
  },
  picture: {
    paddingLeft: PixelRatio.roundToNearestPixel(15),
    paddingRight: PixelRatio.roundToNearestPixel(15),
  },
  pictureIcon: {
    fontSize: PixelRatio.roundToNearestPixel(30),
  },

  imageItem: {
    marginRight: PixelRatio.roundToNearestPixel(5),
  },
  imageItemPicture: {
    width: PixelRatio.roundToNearestPixel(60),
    height: PixelRatio.roundToNearestPixel(60),
    borderRadius: PixelRatio.roundToNearestPixel(BORDER_RADIOS / 1.5),
  },
  removeImageItem: {
    padding: PixelRatio.roundToNearestPixel(4),
    position: 'absolute',
    right: 0,
    top: 0,
  },
  removeImageItemIcon: {
    width: PixelRatio.roundToNearestPixel(18),
    height: PixelRatio.roundToNearestPixel(18),
  },
  line: {
    width: 21,
    height: 2,
    backgroundColor: washswatColor.grey_11,
  },
  line1: {
    transform: [{ rotate: '45deg' }],
  },
  titleView: {
    flexDirection: 'row',
    height: 56,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 30,
    paddingRight: 24.5,
  },
  title: {
    ...responseFont(16).bold,
    color: washswatColor.grey_09,
  },
  line2: {
    transform: [{ rotate: '135deg' }],
    marginTop: -2,
  },
  cardComponent: {
    height: 54,
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 24,
  },
  check: {
    width: 16,
    height: 16,
  },
  cardCheckedContent: {
    flex: 1,
    ...responseFont(16).regular,
    color: '#2D4AFF',
  },
  cardUncheckedcontent: {
    flex: 1,
    ...responseFont(16).regular,
  },
  modal: {
    height: 375,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    justifyContent: 'center',
  },
});

class OrderChatContainer extends Component {
  state = {
    images: [],
    isKeyboard: false,
    inputHeight: 0,
  };

  UNSAFE_componentWillMount() {
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this._keyboardDidShow,
    );
    this.keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      this._keyboardDidHide,
    );
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    const {
      OrderChatState,
      OrderChatAction,
      OrderHistoryAction,
      componentId,
      callbackOrderHistoryEmpty,
      BottomTabAction,
    } = this.props;
    const { orderId } = OrderChatState;
    if (orderId) {
      // 화면 전환하고, 페이지 리셋
      CommonUtils.navShowModal({
        name: 'OrderCompleteScreen',
        passProps: { orderId },
      });
      Navigation.pop(componentId);
      if (callbackOrderHistoryEmpty) {
        callbackOrderHistoryEmpty();
      } else {
        BottomTabAction.setCurrentTab('OrderHistoryScreen');
        // CommonUtils.navPush({
        //   componentId,
        //   name: 'OrderHistoryScreen',
        // });
      }
      OrderChatAction.reset();
    }
  }

  componentDidMount() {
    const { init } = this.props.OrderChatAction;

    init();
  }

  initAction = requiredImages => {
    const { inputAction } = this.props.OrderChatAction;
    const { images } = this.state;

    if (images.length > 0) {
      let prevent = false;
      _.map(images, ({ uri, url }) => {
        if (uri && !url) {
          /** 이미지 업로드중 **/
          prevent = true;
        }
      });

      if (prevent) {
        WashAlert.showAlert(ErrorMessage.stillUploading, Favorite.ok);
        return;
      }
      inputAction(images);
      this.setState({ images: [] });
    } else {
      if (requiredImages) {
        /** 이미지 필수 **/
        WashAlert.showAlert(Favorite.requiredImages, Favorite.ok);
      } else {
        inputAction();
      }
    }
  };

  cancelAction = () => {
    WashAlert.showAlert(Favorite.blank, Favorite.ok);
  };

  pullImage = index => {
    const { images } = this.state;
    _.pullAt(images, index);
    this.setState({ images });
  };

  showImageMarkerContainer = image => {
    if (image && image.path) {
      CommonUtils.navShowModal({
        name: 'ImageMarkerContainer',
        passProps: {
          imageUrl: image.path,
          componentId: this.props.componentId,
          finishedAction: fileUri => {
            image.path = fileUri;
            this.uploadImage([image]);
          },
        },
      });
    }
  };

  showImagePicker = () => {
    const options = [
      OrderChat.openCamera,
      OrderChat.openGallary,
      OrderChat.modalCancel,
    ];
    BottomSheet.showBottomSheetWithOptions(
      {
        options,
        // options: ['기본요금', '스페셜요금', '프리미엄요금', '취소'],
        title: '선택',
        dark: true,
        cancelButtonIndex: 2,
      },
      async value => {
        const str = options[value];
        let image;
        try {
          if (str === OrderChat.openCamera) {
            image = await ImagePicker.openCamera({
              width: 300,
              height: 400,
              cropping: false,
            });
          } else if (str === OrderChat.openGallary) {
            image = await ImagePicker.openPicker({
              width: 300,
              height: 400,
              cropping: false,
            });
          }
          if (image) {
            this.showImageMarkerContainer(image);
          }
        } catch (e) {
          console.log(e.message);
          if (
            e &&
            e.message &&
            (e.message.indexOf('permission') > -1 ||
              e.message.indexOf('Permission') > -1)
          ) {
            this.showPermissionMessage();
          }
        }
      },
    );
  };

  showPermissionMessage = () => {
    let message =
      Platform.OS === 'android'
        ? OrderChat.permission_android
        : OrderChat.permission_ios;
    Alert.alert(
      OrderChat.permissionTitle,
      message,
      [{ text: Favorite.ok, onPress: () => Linking.openSettings() }],
      { cancelable: false },
    );
  };

  uploadImage = async list => {
    const { dataList } = this.props.OrderChatState;
    const uid = _.find(dataList, { key: 'uid' }).value;
    const images = [];
    _.map(list, ({ path }) => {
      images.push(path);
      this.state.images.push({ uri: path });
    });
    this.forceUpdate();
    const options = {
      bucket: 'washswat-hang-image',
      region: 'ap-northeast-1',
      accessKey: KeyUtils.AWS_S3_ACCESS_KEY,
      secretKey: KeyUtils.AWS_S3_SECRET_ACCESS_KEY,
      successActionStatus: 201,
    };
    try {
      for (let i = 0; i < images.length; i++) {
        const path = images[i];
        try {
          let uri = await imageBuilding(path);
          const file = {
            uri,
            name: `rn-${uid}-${i}-${moment().format('YYYYDDMM_HH_mm_sss')}.jpg`,
            type: 'image/jpeg',
          };

          let res = await RNS3.put(file, options);
          const { status } = res;
          if (status === 201) {
            const url = `https://s3-ap-northeast-1.amazonaws.com/${options.bucket}/${file.name}`;
            const index = _.findIndex(this.state.images, { uri: path });
            if (index > -1) {
              this.state.images[index].url = url;
            }
          }
        } catch (e) {}
      }
    } catch (e) {
      WashAlert.showAlert(ErrorMessage.awsS3UploadAPI, Favorite.ok);
    }
    this.forceUpdate();
  };

  _keyboardDidShow = () => {
    this.scrollY.scrollToEnd({ animated: true });
  };
  _keyboardDidHide = () => {
    if (Platform.OS === 'android') {
      this.setState({
        inputHeight: -androidStatusBar,
      });
    }
  };
  render() {
    const { OrderChatState, OrderChatAction } = this.props;
    const { chatList, dataList, isPending, dataSetForModal } = OrderChatState;
    const { images } = this.state;
    const {
      onChangeInputText,
      inputAction,
      nextButtonAction,
      orderAction,
      pressNotice,
    } = OrderChatAction;
    /** Modal 관련 **/
    const { handleModalData, showModal, dismissModal } = OrderChatAction;
    return (
      <View style={styles.form}>
        {/* {isPending ? <LoadingBar /> : null} */}
        <ScrollView
          scrollEventThrottle={16}
          ref={ref => (this.scrollY = ref)}
          onContentSizeChange={(contentWidth, contentHeight) => {
            this.scrollY.scrollToEnd({ animated: true });
          }}
        >
          <View
            style={{
              paddingBottom: 18,
              paddingTop: 80,
              paddingHorizontal: 12,
              alignContent: 'space-between',
            }}
          >
            <View style={{ flex: 1 }}>
              {_.map(chatList, (block, i) => {
                return (
                  <View
                    key={`vv#_${i}`}
                    style={{ paddingTop: block.text ? 10 : 0 }}
                  >
                    <ChatRow
                      block={block}
                      dataList={dataList}
                      rowIndex={i}
                      orderAction={orderAction}
                      nextButtonAction={nextButtonAction}
                      chatList={chatList}
                      pressNotice={pressNotice}
                      showModal={showModal}
                    />
                  </View>
                );
              })}
            </View>
          </View>

          {chatList.length > 0 && chatList[chatList.length - 1].keyboard && (
            <View style={styles.bottonInputTextFrame}>
              {chatList[chatList.length - 1].keyboard.camera && (
                <TouchableOpacity
                  onPress={() => this.showImagePicker()}
                  style={styles.picture}
                >
                  <Text
                    style={[
                      styles.pictureIcon,
                      {
                        marginBottom: PixelRatio.roundToNearestPixel(
                          images.length > 0 ? 12 : 10,
                        ),
                      },
                    ]}
                  >
                    📷
                  </Text>
                </TouchableOpacity>
              )}
              <View
                style={[
                  styles.textInput,
                  {
                    marginLeft: chatList[chatList.length - 1].keyboard.camera
                      ? 0
                      : styles.textInput.marginRight,
                  },
                ]}
              >
                {images.length > 0 && (
                  <FlatList
                    data={_.cloneDeep(images)}
                    horizontal={true}
                    style={styles.flatList}
                    renderItem={({ item, index }) => (
                      <ImageItem
                        item={item}
                        index={index}
                        pullImage={this.pullImage}
                      />
                    )}
                    keyExtractor={item => item.uri}
                  />
                )}
                <View style={styles.bottomInputFrame}>
                  <TouchableOpacity
                    style={[
                      styles.sendBtn,
                      {
                        bottom: PixelRatio.roundToNearestPixel(
                          images.length > 0 ? 7 : 2,
                        ),
                      },
                    ]}
                    onPress={() => {
                      if (
                        chatList[chatList.length - 1].keyboard.text.match(
                          /^\s*$/,
                        )
                      ) {
                        this.cancelAction();
                      } else {
                        this.initAction(
                          chatList[chatList.length - 1].keyboard.requiredImages,
                        );
                      }
                    }}
                    activeOpacity={1}
                  >
                    <Image
                      style={styles.sendButtonImage}
                      source={require('image/orderchat/send.png')}
                    />
                  </TouchableOpacity>
                  <TextInput
                    multiline
                    keyboardType={'default'}
                    value={chatList[chatList.length - 1].keyboard.text}
                    placeholder={
                      chatList[chatList.length - 1].keyboard.placeholder
                    }
                    placeholderTextColor={washswatColor.grey_03}
                    onChangeText={text => onChangeInputText(text)}
                    style={[responseFont(15).regular, styles.inputText]}
                    autoFocus
                    autoCorrect={false}
                  />
                </View>
              </View>
            </View>
          )}
        </ScrollView>

        <KeyboardSpacerIOS />
        <ChatModal
          dataSetForModal={dataSetForModal}
          handleModalData={handleModalData}
          dismissModal={dismissModal}
        />
      </View>
    );
  }
}

const ChatModal = props => {
  const { dataSetForModal, dismissModal, handleModalData } = props;
  if (!dataSetForModal || _.size(dataSetForModal) === 0) {
    return null;
  }
  const { button, blockId } = dataSetForModal;
  const { modal, data } = button;
  const { type, title, list } = modal;

  const views = [];
  /**
   * List 형태.
   */
  if (type == 'list') {
    for (let row of list) {
      const { value, input } = row;
      let content, marker;
      if (input) {
        /** input 창 필요 **/
        let customText = _.find(list, { value: data.value })
          ? null
          : data.value;
        content = (
          <View style={styles.bottonInputTextFrame}>
            <View style={styles.textInput}>
              <View style={styles.bottomInputFrame}>
                <TextInput
                  style={[responseFont(15).regular, styles.inputText]}
                  value={customText}
                  placeholder={OrderChat.inputPlaceHolder}
                  onSubmitEditing={Keyboard.dismiss}
                  onChangeText={text => {
                    data.value = text;
                    handleModalData(blockId, button);
                  }}
                ></TextInput>
                <TouchableOpacity
                  style={[styles.sendBtn, { bottom: 4, right: -8 }]}
                  activeOpacity={1}
                  onPress={() => {
                    dismissModal();
                  }}
                >
                  <Image
                    style={styles.sendButtonImage}
                    source={require('../../../assets/image/orderchat/send.png')}
                  />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        );

        views.push(
          <View key={`md_${value}_${blockId}`} style={styles.cardComponent}>
            {content}
          </View>,
        );
      } else {
        let checked = data.value && value === data.value;
        content = (
          <Text
            style={
              checked ? styles.cardCheckedContent : styles.cardUncheckedcontent
            }
          >
            {value}
          </Text>
        );
        if (checked) {
          marker = (
            <Image
              source={require('../../../assets/image/v5/ic_checkmark.png')}
              style={styles.check}
            />
          );
        }
        views.push(
          <TouchableOpacity
            key={`md_${value}_${blockId}`}
            style={styles.cardComponent}
            onPress={() => {
              data.value = value;
              handleModalData(blockId, button);
            }}
          >
            {content}
            {marker}
          </TouchableOpacity>,
        );
      }
    }
  }

  return (
    <Modal
      isOpen={views.length}
      onClosed={dismissModal}
      style={styles.modal}
      position={'bottom'}
    >
      <View style={styles.titleView}>
        <Text style={[responseFont(18).bold, styles.title]}>{title}</Text>
      </View>
      <View style={{ marginVertical: 40 }}>{views}</View>
    </Modal>
  );
};

const ImageItem = props => {
  const {
    item: { uri, url },
    index,
    pullImage,
  } = props;
  return (
    <View style={styles.imageItem}>
      {url ? (
        <Image
          style={[
            styles.imageItemPicture,
            { marginLeft: index === 0 ? styles.imageItem.marginRight : 0 },
          ]}
          source={{ uri: url }}
        />
      ) : (
        <ShimmerPlaceHolder
          autoRun={true}
          style={[
            styles.imageItemPicture,
            { marginLeft: index === 0 ? styles.imageItem.marginRight : 0 },
          ]}
        />
      )}
      <TouchableOpacity
        style={styles.removeImageItem}
        onPress={() => pullImage(index)}
      >
        <Image
          style={styles.removeImageItemIcon}
          source={require('image/orderchat/cancel.png')}
        />
      </TouchableOpacity>
    </View>
  );
};

const ChatRow = props => {
  const {
    block,
    nextButtonAction,
    orderAction,
    dataList,
    rowIndex,
    chatList,
    pressNotice,
    showModal,
  } = props;
  const { blockId, owner, text, buttons, keyboard, notice } = block;

  /** Image Chat Layout */
  const row = [];
  const finded = _.find(dataList, { wiredComponentIndex: rowIndex });

  if (finded && finded.images && finded.images.length > 0) {
    const imageRow = [];
    const imageChatLayout = [];

    _.map(finded.images, (putImage, i) => {
      imageRow.push(
        <Image
          source={{ uri: putImage.url }}
          style={{
            width: 58,
            height: 58,
            marginRight: 3,
            borderRadius: PixelRatio.roundToNearestPixel(BORDER_RADIOS / 1.5),
            marginBottom: 5,
          }}
          key={`V##V$_$$${imageRow.length}${new Date().getTime()}`}
        />,
      );
    });

    imageChatLayout.push(
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }} key={0}>
        {imageRow}
      </View>,
    );
    row.push(imageChatLayout);
  }
  if (text) {
    const content = contentBuilder(text, block);
    row.push(
      <View key={`VV$_$$${row.length}${new Date().getTime()}`}>
        <TextWithRegex text={`${content}`} owner={owner} />
      </View>,
    );
    if (notice) {
      const { text, action, description } = notice;
      row.push(
        <TouchableOpacity
          key={`VV$_$$${new Date().getTime()}`}
          style={{ paddingTop: 18 }}
          onPress={() => {
            pressNotice(action);
          }}
        >
          <Text
            style={[
              responseFont(14).regular,
              { color: washswatColor.blue, lineHeight: 18 },
            ]}
          >
            {text}
          </Text>
          {description ? (
            <TextWithRegex text={`${description}`} owner={owner} />
          ) : null}
        </TouchableOpacity>,
      );
    }
    // chatList[chatList.length -1 ].blockId === blockId
    if (buttons && chatList[chatList.length - 1].blockId === blockId) {
      const buttonRow = [];
      _.map(buttons, (button, i) => {
        const { modal, data, text } = button;

        buttonRow.push(
          <View key={`V##V$_$$${buttonRow.length}${new Date().getTime()}`}>
            <TouchableOpacity
              style={[
                styles.chatButtonWrap,
                {
                  marginTop: i === 0 ? 18 : 0,
                  marginBottom: i === buttons.length - 1 ? 0 : 9,
                  backgroundColor: getButtonColor(button),
                },
              ]}
              onPress={() => {
                if (modal) {
                  /**
                   * Modal이 있다. 요거를 띄우자
                   */
                  showModal(blockId, button);
                } else {
                  nextButtonAction(button, blockId);
                }
              }}
            >
              <Text
                style={[
                  styles.chatButton,
                  button.lastAction ? { color: washswatColor.white } : {},
                ]}
              >
                {text}
              </Text>
            </TouchableOpacity>
          </View>,
        );
      });
      row.push(buttonRow);
    }
    return (
      <View
        style={
          owner === 'user' ? styles.userChatContainer : styles.swatChatContainer
        }
      >
        <View style={owner === 'user' ? styles.userChat : styles.swatChat}>
          {row}
        </View>
      </View>
    );
  } else {
    return null;
  }
};

const imageBuilding = async uri => {
  try {
    let { width, height } = await new Promise((resolve, reject) => {
      Image.getSize(
        uri,
        (width, height) => {
          resolve({ width, height });
        },
        fail => {
          reject(fail);
        },
      );
    });

    const cropData = {
      offset: { x: 0, y: 0 },
      size: { width: parseInt(width * 0.6), height: parseInt(height * 0.6) },
      displaySize: {
        width: parseInt(width * 0.6),
        height: parseInt(height * 0.6),
      },
      resizeMode: 'cover',
    };
    console.log('imageBuilding - ok');
    let url = ImageEditor.cropImage(uri, cropData);
    console.log('imageBuilding - croped', url);
    return url;
  } catch (e) {
    console.log('imageBuilding - error', e);
    throw e;
  }
};

/**
 * @description
 * Content에 변수가 있는지 확인하고, 있다면 data에서 빼서 바꿔준다
 * @param content
 * @param block
 * @return content {string}
 */
const contentBuilder = (content, block) => {
  let regex = /\${(.+?)}/g;
  if (regex.test(content)) {
    // console.log(block);
    // console.log(content);

    const list = content.match(regex);
    let Keys = content.split(regex);

    const dataList = [];
    if (Keys.length) {
      /** 바꿔야할 변수들이다. data에서 찾는다 **/
      if (block) {
        if (block.data && block.data.key) {
          dataList.push(block.data);
        }
        if (block.buttons && block.buttons.length) {
          for (let button of block.buttons) {
            if (button && button.data && button.data.key) {
              dataList.push(button.data);
            }
          }
        }
      }
    }
    // console.log(dataList);
    for (let key of Keys) {
      if (key && _.find(list, o => o.indexOf(key) > -1)) {
        const data = _.find(dataList, { key });
        if (data) {
          const { value } = data;
          /** 변수를 value로 교체 **/
          let keyRegex = new RegExp('\\$\\{' + key + '\\}', 'g');
          content = content.replace(keyRegex, value || '');
        }
      }
    }
  }
  return content;
};

const getButtonColor = button => {
  if (button.text === '직접입력' || button.text === '취소') {
    return 'transparent';
  } else if (button.lastAction) {
    return washswatColor.blue;
  } else {
    return washswatColor.grey_16;
  }
};

const textWrapper = (Component, text, key) => {
  return <Component key={key} text={text} />;
};

const TextWithRegex = ({ text, owner }) => {
  const list = [
    {
      version: 1,
      regex: /\*\*(.+?)\*\*/g,
      component: BoldText,
    },
    {
      version: 2,
      regex: /<BoldText>(.+?)<\/BoldText>/g,
      component: BoldText,
    },
    {
      version: 1,
      regex: /rr(.+?)rr/g,
      component: SmallRed,
    },
    {
      version: 2,
      regex: /<SmallRed>(.+?)<\/SmallRed>/g,
      component: SmallRed,
    },

    {
      version: 2,
      regex: /<BlueBold>(.+?)<\/BlueBold>/g,
      component: BlueBold,
    },

    {
      version: 1,
      regex: /sb(.+?)sb/g,
      component: SmallBlack,
    },
    {
      version: 2,
      regex: /<SmallBlack>(.+?)<\/SmallBlack>/g,
      component: SmallBlack,
    },

    {
      version: 1,
      regex: /sg(.+?)sg/g,
      component: SmallGray,
    },
    {
      version: 2,
      regex: /<SmallGray>(.+?)<\/SmallGray>/g,
      component: SmallGray,
    },
    {
      version: 1,
      regex: /gg(.+?)gg/g,
      component: SmallGray2,
    },
    {
      version: 2,
      regex: /<SmallGray2>(.+?)<\/SmallGray2>/g,
      component: SmallGray2,
    },
    {
      version: 1,
      regex: /pp(.+?)pp/g,
      component: GoToPolicy,
    },

    {
      version: 2,
      regex: /<GoToPolicy>(.+?)<\/GoToPolicy>/g,
      component: GoToPolicy,
    },
  ];

  const views = text.split('\n');
  views.map((text, viewIndex) => {
    list.map(({ regex, component }) => {
      if (regex.test(text)) {
        const matched = text.match(regex);
        let wordList = text.split(regex);
        wordList.map((word, wordIndex) => {
          if (word) {
            const match = _.find(matched, o => o.indexOf(word) > -1);
            if (match) {
              wordList[wordIndex] = textWrapper(
                component,
                word,
                `el__${viewIndex}_${wordIndex}`,
              );
            }
          }
        });
        wordList = _.filter(wordList, word => word);
        views[viewIndex] = wordList;
      }
    });
  });

  const viewList = [];
  for (let i = 0; i < views.length; i++) {
    const row = views[i];
    if (row === '') {
      viewList.push(<View key={`vrt-${i}`} style={{ padding: 8 }}></View>);
    } else if (typeof row === 'string') {
      viewList.push(
        textWrapper(owner === 'user' ? UserText : SwatText, row, `vrt-${i}`),
      );
    } else if (typeof row === 'object') {
      for (let j = 0; j < row.length; j++) {
        const child = row[j];
        if (typeof child === 'string') {
          viewList.push(
            textWrapper(
              owner === 'user' ? UserText : SwatText,
              row,
              `vrt-${i}`,
            ),
          );
        } else {
          viewList.push(child);
        }
      }
    }
  }
  return viewList;
};
const BlueBold = ({ text }) => (
  <Text
    style={[
      responseFont(16).bold,
      { color: washswatColor.blue, lineHeight: 21 },
    ]}
  >
    {text}
  </Text>
);

const BoldText = ({ text }) => (
  <Text style={{ fontWeight: 'bold' }}>{text}</Text>
);
const SmallRed = ({ text }) => (
  <Text style={[responseFont(12).regular, { color: 'red' }]}>{text}</Text>
);
const SmallBlack = ({ text }) => (
  <Text
    style={[
      responseFont(14).regular,
      { color: washswatColor.black, lineHeight: 21 },
    ]}
  >
    {text}
  </Text>
);

const SmallGray2 = ({ text }) => (
  <Text
    style={[
      responseFont(14).regular,
      { color: washswatColor.darkGrey, lineHeight: 21 },
    ]}
  >
    {text}
  </Text>
);
const SmallGray = ({ text }) => (
  <Text
    style={[
      responseFont(13).regular,
      { color: washswatColor.darkGrey, lineHeight: 20 },
    ]}
  >
    {text}
  </Text>
);

const GoToPolicy = ({ text }) => (
  <Text
    onPress={() =>
      CommonUtils.navShowModalWebView({ url: ServerUtils.URL_POLICY })
    }
    style={{ color: washswatColor.blue }}
  >
    {text}
  </Text>
);
const SwatText = ({ text }) => (
  <Text
    style={[
      responseFont(16).bold,
      { color: washswatColor.black, lineHeight: 21 },
    ]}
  >
    {text}
  </Text>
);
const UserText = ({ text }) => (
  <Text
    style={[
      responseFont(16).regular,
      { color: washswatColor.white, lineHeight: 21 },
    ]}
  >
    {text}
  </Text>
);

const mapStateToProps = ({ OrderChatModule }) => ({
  OrderChatState: OrderChatModule,
});

const mapDispatchToProps = dispatch => ({
  OrderChatAction: bindActionCreators(OrderChatModule, dispatch),
  BottomTabAction: bindActionCreators(BottomTabModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderChatContainer);
