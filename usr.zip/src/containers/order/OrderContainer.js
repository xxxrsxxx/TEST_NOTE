import React, { Component } from 'react';

import { StyleSheet, View } from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MainScreenModule from '../../reducers/MainScreenModule';

import { BorderRadiusButton } from '../../components/common/button/BorderRadiusButton';
import OrderTopComponent from '../../components/order/OrderTopComponent';

import { OrderText, MainScreenString } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import * as Keys from '../../utils/type/key';
import { getCircleText } from '../../utils/common/order';
import { Font, Styles } from '../../utils/style';

import { _, moment } from '../../plugins';

moment.locale('ko');

const { washswatColor, verticalScale } = Font;
const { commonStyles } = Styles;

class OrderContainer extends Component {
  state = {
    userName: '',
    height: {},
  };

  componentDidMount() {
    this.getUserName();
  }

  onPressDateTime = () => {
    CommonUtils.navShowModalPageSheet({
      name: 'OrderPickupScreen',
    });
  };

  // 해당 동작 이후 timeout시간동안 추가동작 없으면 마지막 동작 한번만을 인지하여 실행, 해당 timeout안에 다시 클릭시에 timeout을 리셋
  preventMultiClick = _.debounce(() => this.onPressOrder(), 500);

  onPressOrder = () => {
    const { MainScreenAction } = this.props;
    MainScreenAction.goOrderChatScreen(this.props.componentId);
  };

  getUserName = async () => {
    const userName = await CommonUtils.getValue(Keys.USER_NAME);
    this.setState({
      userName: userName.length > 10 ? `${userName.slice(0, 10)}...` : userName,
    });
  };

  async componentDidUpdate(prevProps) {
    if (this.props.userName && this.props.userName !== this.state.userName) {
      this.setState({
        userName: this.props.userName,
      });
    }
    if (this.props.pickup !== prevProps.pickup) {
      const { MainScreenAction, pickup } = this.props;
      MainScreenAction.setDeliveryDateTimeAPI({ pickup });
    }
  }

  getLayoutHeight = (e, name) => {
    let { height } = e.nativeEvent.layout;
    this.setState({
      height: {
        ...this.state.height,
        [name]: height,
      },
    });
  };

  getDawnDeliveryDescription = () => {
    const { MainScreenState } = this.props;
    const { pickup, delivery } = MainScreenState;
    if (pickup && delivery) {
      const hourMinute = moment(pickup.pickupTime)
        .subtract(10, 'minutes')
        .format('h시 m분');
      // 오늘 밤 11시 50분 전 주문하면 3월 5일 (목) 아침 7시 전 도착
      return `오늘 밤 ${hourMinute} 전 주문하면\n${moment(
        delivery.endTime,
      ).format('M월 D일 (ddd) 아침 h시')} 전 도착`;
      // return `오늘 밤 ${hourMinute} 전 주문하면\n${monthDay} (${dayOfWeek}) 아침 7시 전 도착`;
    }
    return '';
  };

  render() {
    const { MainScreenState } = this.props;
    const { pickup, delivery } = MainScreenState;

    return (
      <View
        style={{ flex: 1 }}
        onLayout={e => this.getLayoutHeight(e, 'layout')}
      >
        <View style={[styles.orderView, commonStyles.cardBackground]}>
          <OrderTopComponent
            title={`${MainScreenString.welcomeText} ${this.state.userName}${MainScreenString.userTitle}`}
            circleText={getCircleText({ pickup })}
            circleColors={['rgba(98, 255, 177, 0.42)', 'rgba(39, 158, 217, 1)']}
            bottomText={
              pickup !== null
                ? moment(pickup.pickupTime).hour() === 0
                  ? this.getDawnDeliveryDescription()
                  : MainScreenString.mainDescription
                : MainScreenString.disableMainDescription
            }
            onPressDateTime={pickup !== null && this.onPressDateTime}
            getOrderTopHeight={e => this.getLayoutHeight(e, 'orderTop')}
            circleIsPress={true}
          />
          <View
            style={{
              marginTop: 20,
              paddingBottom: verticalScale(40),
              marginLeft: 24,
              marginRight: 24,
            }}
            onLayout={e => this.getLayoutHeight(e, 'button')}
          >
            <BorderRadiusButton
              title={OrderText.order}
              onPress={this.preventMultiClick}
              buttonBgColor={
                pickup !== null ? washswatColor.black : washswatColor.grey_09
              }
            />
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  orderView: {
    backgroundColor: washswatColor.white,
    paddingLeft: 24,
    paddingTop: 30,
    paddingRight: 24,
    flex: 1,
    justifyContent: 'space-between',
  },
});

const mapStateToProps = ({ MainScreenModule }) => ({
  MainScreenState: MainScreenModule,
});

const mapDispatchToProps = dispatch => ({
  MainScreenAction: bindActionCreators(MainScreenModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderContainer);
