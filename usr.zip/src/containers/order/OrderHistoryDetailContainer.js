import React, { useState } from 'react';
import { View } from 'react-native';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import Collapsible from 'react-native-collapsible';
import OrderHistoryDetailCollapse from '../../components/order-history/OrderHistoryDetailCollapse';
import OrderHistoryDetailComponent from '../../components/order-history/OrderHistoryDetailComponent';
import OrderHistoryDetailImageComponent from '../../components/order-history/OrderHistoryDetailImageComponent';
// module import
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';

const OrderHistoryDetailContainer = (props) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const { OrderHistoryState, componentId } = props;
  const { orderItem } = OrderHistoryState;

  const onToggle = () => {
    setIsCollapsed(!isCollapsed);
  }

  return (
    <View>
      <OrderHistoryDetailComponent
        onToggle={onToggle}
        orderId={orderItem.orderId}
        isCollapsed={isCollapsed}
      />

      <Collapsible collapsed={isCollapsed}>
        <View style={{ marginHorizontal: 24, marginTop: 8, marginBottom: 32 }}>

          {/* 상세설명 */}
          <OrderHistoryDetailCollapse OrderHistoryState={OrderHistoryState} />

          <OrderHistoryDetailImageComponent
            componentId={componentId}
            careOptions={orderItem?.preOptions?.care && orderItem.preOptions.care.options}
            orderItem={orderItem}
          />

        </View>
      </Collapsible>
    </View>
  )
};

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OrderHistoryDetailContainer);
