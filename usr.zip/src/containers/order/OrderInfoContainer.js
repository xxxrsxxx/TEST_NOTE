import React, { Component } from 'react';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';

import { CollapsibleComponent } from '../../components/common/collapse/CollapsibleComponent';

import { OrderInfoText } from '../../utils/common/strings';
import * as OrderUtils from '../../utils/common/order';
import { Font } from '../../utils/style';

const { washswatColor } = Font;

class OrderInfoContainer extends Component {
  state = {
    isCollapsed: true,
  };

  getOrderInfo = () => {
    const { OrderHistoryState } = this.props;
    const { orderItem } = OrderHistoryState;
    const {
      orderId,
      status,
      pickup,
      pickupTime,
      deliveryTime,
      mission,
      preOptions,
      alert,
      userInfo,
    } = orderItem;
    const { address, addressOthers } = userInfo;
    const pickupDate = OrderUtils.getDateOfMission({
      startTime: mission.pickup.pickupTime,
      endTime: mission.pickup.endTime,
    });
    const deliveryDate = OrderUtils.getDateOfMission({
      startTime: mission.delivery.deliveryTime,
      endTime: mission.delivery.endTime,
    });
    let pickupAddress = `${address} ${addressOthers}`;
    let deliveryAddress = `${address} ${addressOthers}`;
    if (preOptions) {
      if (preOptions.pickupAddr) {
        const { address, addressOthers } = preOptions.pickupAddr;
        pickupAddress = `${address} ${addressOthers}`;
      }
      if (preOptions.deliveryAddr) {
        const { address, addressOthers } = preOptions.deliveryAddr;
        deliveryAddress = `${address} ${addressOthers}`;
      }
    }
    let requestMessage = '';
    if (preOptions && preOptions.care && preOptions.care.options) {
      requestMessage += `${OrderInfoText.requestMatter}\n`;
      preOptions.care.options.map((option, index) => {
        if (index !== 0) {
          requestMessage += '\n';
        }
        requestMessage += option.message;
      });
    }
    return `${OrderInfoText.pickup}\n${pickupDate}\n${pickupAddress}\n\n${OrderInfoText.delivery}\n${deliveryDate}\n${deliveryAddress}\n\n${requestMessage}`;
  };

  render() {
    const { screen } = this.props;
    return (
      <CollapsibleComponent
        title={OrderInfoText.title}
        collapsed={this.state.isCollapsed}
        onPressCollapse={() =>
          this.setState({ isCollapsed: !this.state.isCollapsed })
        }
        content={this.getOrderInfo()}
        bgColor={
          screen === 'OrderCompleteScreen'
            ? washswatColor.white
            : washswatColor.grey_07
        }
        borderRadius={10}
      />
    );
  }
}

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderInfoContainer);
