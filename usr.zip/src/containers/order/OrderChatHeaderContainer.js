import React, { Component } from 'react';
import {
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
  Keyboard,
  Platform,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderChatModule from '../../reducers/OrderChatModule';

import {
  OrderChatBackPressPopupString,
  BottomTabString,
} from '../../utils/common/strings';

import { navShowModalWebView } from '../../utils/common';
import { URL_USER_GUIDE } from '../../utils/type/server';

import { Font, Styles } from '../../utils/style';
const { washswatColor, responseFont } = Font;
const { GET_STATUSBAR_HEIGHT } = Styles;
import { BasicHeader } from '../../components/common/layout';

class OrderChatHeaderContainer extends Component {
  onPressBack = () => {
    const { backPressPopupOpen } = this.props.OrderChatState;
    const { backPressToggle } = this.props.OrderChatAction;
    Keyboard.dismiss();
    if (backPressPopupOpen) {
      Navigation.pop(this.props.componentId);
    } else {
      backPressToggle(true);
    }
  };
  render() {
    const { isPending } = this.props.OrderChatState;
    return (
      <View style={styles.container}>
        <BasicHeader title={BottomTabString.order} onPress={this.onPressBack} />
        {!isPending && (
          <View style={styles.guideBook}>
            <TouchableOpacity
              style={styles.chatWrap}
              onPress={() =>
                navShowModalWebView({
                  url: URL_USER_GUIDE,
                })
              }
            >
              <Text
                style={styles.chatButton}
              >{`📖 ${OrderChatBackPressPopupString.guideText}`}</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  }
}
const offsetTop = () => {
  let container = 0,
    guide = GET_STATUSBAR_HEIGHT;
  if (Platform.OS === 'android') {
    container = GET_STATUSBAR_HEIGHT;
    guide = 0;
  }
  return { container, guide };
};
const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: offsetTop().container,
    left: 0,
    width: '100%',
    zIndex: 90,
    backgroundColor: '#fff',
  },
  guideBook: {
    position: 'absolute',
    top: offsetTop().guide,
    bottom: 0,
    right: 10,
    zIndex: 20,
    justifyContent: 'center',
  },
  chatWrap: {
    paddingLeft: 7,
    paddingRight: 7,
    marginBottom: 6,
    height: 27,
    justifyContent: 'center',
    backgroundColor: washswatColor.blueOpacity12,
    borderRadius: 30,
    ...Platform.select({
      android: {
        paddingTop: 3,
        paddingBottom: 3,
      },
    }),
  },
  chatButton: {
    color: washswatColor.blue,
    ...responseFont(12).regular,
  },
});
const mapStateToProps = ({ OrderChatModule }) => ({
  OrderChatState: OrderChatModule,
});
const mapDispatchToProps = dispatch => ({
  OrderChatAction: bindActionCreators(OrderChatModule, dispatch),
});
export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderChatHeaderContainer);
