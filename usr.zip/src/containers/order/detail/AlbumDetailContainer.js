import React, { Component } from 'react';

import { Dimensions, Text, View, StyleSheet, Image } from 'react-native';
import ImageZoom from 'react-native-image-pan-zoom';
import Swiper from 'react-native-swiper';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as AlbumModule from '../../../reducers/AlbumModule';

import { AlbumText, Favorite } from '../../../utils/common/strings';
import * as CommonUtils from '../../../utils/common';
import { Font } from '../../../utils/style';

const { washswatColor, responseFont } = Font;

const window = Dimensions.get('window');

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  wrapper: {},
  image: {
    width: '100%',
    height: (window.width / 4) * 3,
    backgroundColor: washswatColor.grey_12,
  },
  bottom: {
    flex: 1,
    width: '100%',
    height: 180,
    paddingLeft: 24,
    paddingTop: 18,
    backgroundColor: washswatColor.white,
    position: 'absolute',
    bottom: 0,
  },
});

class AlbumDetailContainer extends Component {
  render() {
    const { AlbumState } = this.props;
    const { selectedItem } = AlbumState;
    const {
      type,
      name,
      price,
      content,
      url,
      barcodeId,
      brand,
      option,
      careArray,
      emoji,
    } = selectedItem;
    return (
      <View style={styles.root}>
        <Swiper style={styles.wrapper} showsPagination={false}>
          <ImageZoom
            cropWidth={window.width}
            cropHeight={(window.height / 4) * 3}
            imageWidth={window.width}
            imageHeight={(window.width / 4) * 3}
          >
            <Image source={{ uri: url }} style={styles.image} />
          </ImageZoom>
        </Swiper>
        <View style={styles.bottom}>
          <Text
            style={{ ...responseFont(14).bold, color: washswatColor.black }}
          >
            {barcodeId ? `[${barcodeId}] ${name}` : name}
          </Text>
          {price ? (
            <Text
              style={{
                ...responseFont(14).regular,
                color: washswatColor.grey_13,
                marginTop: 8,
              }}
            >
              {`${AlbumText.basicFee}: ${CommonUtils.numberWithCommas(price)}${
                Favorite.won
              }`}
            </Text>
          ) : null}
          {content ? (
            <Text
              style={{
                ...responseFont(14).regular,
                color: washswatColor.grey_13,
                marginTop: 8,
              }}
            >
              {content}
            </Text>
          ) : null}
          {careArray
            ? careArray.map((care, index) => {
                const { title, price } = care;
                return (
                  <View key={`${title}-${index}`}>
                    {price !== undefined ? (
                      <Text
                        style={{
                          ...responseFont(14).regular,
                          color: washswatColor.grey_13,
                          marginTop: 8,
                        }}
                      >
                        {`${
                          AlbumText.addFee
                        }: ${title}(+${CommonUtils.numberWithCommas(price)}${
                          Favorite.won
                        })`}
                      </Text>
                    ) : null}
                  </View>
                );
              })
            : null}
        </View>
      </View>
    );
  }
}

const mapStateToProps = ({ AlbumModule }) => ({
  AlbumState: AlbumModule,
});

const mapDispatchToProps = dispatch => ({
  AlbumAction: bindActionCreators(AlbumModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(AlbumDetailContainer);
