import React, { Component } from 'react';

import { Text, TouchableOpacity, View, StyleSheet, Image } from 'react-native';
import Collapsible from 'react-native-collapsible';

import { WashPlanAfterOrderText } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  root: {
    borderRadius: 10,
    backgroundColor: washswatColor.white,
  },
  button: {
    height: 54,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 21,
    paddingRight: 24,
  },
  buttonText: {
    ...responseFont(16).bold,
    color: washswatColor.black,
    lineHeight: 21,
  },
  arrow: {
    width: 12,
    height: 6.5,
  },
  collapsibleRoot: {
    paddingLeft: 20,
    paddingTop: 13,
    paddingRight: 30,
    paddingBottom: 29,
  },
  round: {
    width: 21,
    height: 21,
    borderRadius: 10.5,
    backgroundColor: washswatColor.blue_03,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

class WashPlanAfterOrder extends Component {
  state = {
    collapsed: false,
  };

  onButton = () => {
    this.setState(prevState => {
      return {
        collapsed: !prevState.collapsed,
      };
    });
  };

  scheduleView = () => {
    const schedules = WashPlanAfterOrderText.schedules;
    return schedules.map((schedule, index) => {
      const { title, content } = schedule;
      const length = schedules.length;
      return (
        <View key={index} style={{ flexDirection: 'row', paddingRight: 30 }}>
          <View style={{ width: 21, alignItems: 'center' }}>
            <View style={styles.round}>
              <Text
                style={{
                  ...responseFont(12).bold,
                  color: washswatColor.blue_04,
                }}
              >
                {index + 1}
              </Text>
            </View>
            {index !== length - 1 ? (
              <View
                style={{
                  width: 1.5,
                  flex: 1,
                  backgroundColor: washswatColor.blue_03,
                }}
              />
            ) : null}
          </View>
          <View
            style={{
              marginLeft: 13,
              marginBottom: index !== length - 1 ? 24 : 0,
            }}
          >
            <Text
              style={{
                ...responseFont(16).bold,
                color: washswatColor.black,
                lineHeight: 21,
              }}
            >
              {title}
            </Text>
            <Text
              style={{
                ...responseFont(14).regular,
                color: washswatColor.darkGrey,
                marginTop: 6,
                lineHeight: 21,
              }}
            >
              {content}
            </Text>
          </View>
        </View>
      );
    });
  };

  render() {
    const { collapsed } = this.state;
    const arrowImgSource = collapsed
      ? require('../../../assets/image/v5/arrow_bottom.png')
      : require('../../../assets/image/v5/arrow_top.png');

    const ArrowImage = props => {
      const { collapsed } = props;
      if (collapsed !== undefined) {
        return <Image source={arrowImgSource} style={styles.arrow} />;
      }
      return <View />;
    };

    return (
      <View style={styles.root}>
        <TouchableOpacity onPress={this.onButton} style={styles.button}>
          <Text style={styles.buttonText}>{WashPlanAfterOrderText.title}</Text>
          <ArrowImage collapsed={collapsed} />
        </TouchableOpacity>
        <Collapsible collapsed={collapsed}>
          <View style={styles.collapsibleRoot}>{this.scheduleView()}</View>
        </Collapsible>
      </View>
    );
  }
}

export default WashPlanAfterOrder;
