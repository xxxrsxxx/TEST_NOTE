import React from 'react';

import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as albumActions from '../../reducers/AlbumModule';

import OrderItemTagText from '../../components/common/text/OrderItemTagText';

import * as CommonUtils from '../../utils/common';
import {
  Favorite,
  OrderHistoryStatusItemText,
  StainCareText,
} from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { moment } from '../../plugins';

const { responseFont, washswatColor } = Font;

const styles = StyleSheet.create({
  divideLine: {
    height: 1,
    backgroundColor: washswatColor.grey_12,
  },
});

const OrderHistoryStatusItemContainer = props => {
  const {
    componentId,
    status,
    statusName,
    endTime,
    items,
    undecidedTime,
    isDeliveryFail,
    hideDate,
  } = props;

  const StatusView = () => {
    if (!endTime) {
      return null;
    }
    // 5/6 (수) 새벽 7시 전 수거 예정
    let dateString;
    let dateStringColor = washswatColor.blue_01;
    if (
      (status === 'ing' || status === 'delivery') &&
      (isDeliveryFail || undecidedTime)
    ) {
      dateString = OrderHistoryStatusItemText.undecidedTime;
      dateStringColor = washswatColor.red;
    } else {
      const endTimeFormat = moment(endTime).format('M/D (ddd) a h');
      switch (status) {
        case 'pickup':
          dateString =
            endTimeFormat + OrderHistoryStatusItemText.pickupSchedule;
          break;
        case 'over':
        case 'complete':
          dateString =
            moment(endTime).format('M/D (ddd) ') +
            OrderHistoryStatusItemText.overSchedule;
          dateStringColor = washswatColor.grey_13;
          break;
        default:
          dateString =
            endTimeFormat + OrderHistoryStatusItemText.arriveSchedule;
          break;
      }
    }
    return (
      <>
        <View
          style={{
            flexDirection: 'row',
            paddingLeft: 24,
            paddingTop: 15,
            paddingRight: 24,
            paddingBottom: 15,
            justifyContent: 'space-between',
          }}
        >
          <Text
            style={{ ...responseFont(14).bold, color: washswatColor.black }}
          >
            {statusName}
          </Text>
          {hideDate ? null : (
            <Text
              style={{ ...responseFont(14).regular, color: dateStringColor }}
            >
              {dateString}
            </Text>
          )}
        </View>
        <View style={styles.divideLine} />
      </>
    );
  };

  const ItemView = () => {
    const onPressItem = (item, index) => () => {
      if (!item) {
        return;
      }
      CommonUtils.navPush({
        componentId,
        name: 'AlbumSwiperScreen',
        passProps: {
          albumItem: item,
        },
      });
    };

    return items.map((item, index) => {
      // extra가 undefined 일때, 0을 부여해주는 es6의 default parameter 문법
      const {
        emoji,
        info: infoArray,
        name,
        subName,
        price,
        option,
        extra = 0,
      } = item;
      const foundImage =
        infoArray && infoArray.find(info => info.type === 'view');
      const foundStain =
        infoArray && infoArray.find(info => info.type.includes('stain'));
      if (!foundStain) console.log('item', item);
      const tagViews = [];
      if (option) {
        tagViews.push(
          <View key={`${name}-${index}`}>
            <OrderItemTagText
              text={option}
              textColor={washswatColor.orange}
              backgroundColor={washswatColor.orangeOpacity16}
            />
          </View>,
        );
      }
      tagViews.push(
        infoArray &&
          infoArray.map((info, index) => {
            const { type, title } = info;
            if (type === 'view' || !title) {
              return null;
            }
            return (
              <View
                key={`${name}-${index}`}
                style={{ marginLeft: tagViews.length === 0 ? 0 : 4 }}
              >
                <OrderItemTagText
                  text={title}
                  textColor={washswatColor.red_01}
                  backgroundColor={washswatColor.grey_15}
                />
              </View>
            );
          }),
      );

      const notFoundImage = () => {
        switch (status) {
          case 'pickup':
            return (
              <View style={{ flexDirection: 'row', flex: 1 }}>
                <Text style={{ ...responseFont(36).bold, marginTop: 5 }}>
                  🚪
                </Text>
                <Text
                  style={{
                    ...responseFont(24).bold,
                    alignSelf: 'flex-end',
                    marginBottom: 10,
                  }}
                >
                  🧺
                </Text>
              </View>
            );
          case 'wait':
            return (
              <Text
                style={{ ...responseFont(24).bold, color: washswatColor.white }}
              >
                🧺
              </Text>
            );
          default:
            return (
              <Text
                style={{ ...responseFont(24).bold, color: washswatColor.white }}
              >
                {emoji}
              </Text>
            );
        }
      };

      const onVideo = () => {
        if (foundStain?.video?.length) {
          CommonUtils.navShowModalWebView({ url: foundStain.video[0] });
        }
      };

      return (
        <View key={`ItemContainer_${index}`}>
          <TouchableOpacity
            key={`ItemView-${index}`}
            onPress={onPressItem(foundImage && item, index)}
            style={{
              flexDirection: 'row',
              paddingLeft: 24,
              paddingTop: 12,
              paddingRight: 24,
              paddingBottom: 12,
            }}
            disabled={status === 'pickup' || status === 'wait' || !foundImage}
          >
            <View
              style={{
                width: 72,
                height: 72,
                backgroundColor: washswatColor.grey_07,
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              {foundImage && foundImage.image && foundImage.image.length > 0 ? (
                <Image
                  source={{ uri: foundImage.image[0] }}
                  style={{
                    width: '100%',
                    height: '100%',
                    transform: [{ rotate: '180deg' }],
                  }}
                />
              ) : (
                <View>{notFoundImage()}</View>
              )}
            </View>
            <View style={{ flex: 1, marginLeft: 16 }}>
              <View
                style={{
                  flexDirection: 'row',
                  flex: 1,
                  justifyContent: 'space-between',
                }}
              >
                <View>
                  {name ? (
                    <Text
                      style={{
                        ...responseFont(14).regular,
                        color: washswatColor.black,
                        marginBottom: 4,
                      }}
                    >
                      {name}
                    </Text>
                  ) : null}
                  {price !== undefined ? (
                    <Text
                      style={{
                        ...responseFont(14).regular,
                        color: washswatColor.grey_13,
                      }}
                    >
                      {`${CommonUtils.numberWithCommas(price + extra)}${
                        Favorite.won
                      }`}
                    </Text>
                  ) : null}
                  {subName ? (
                    <Text
                      style={{
                        ...responseFont(14).regular,
                        color: washswatColor.grey_13,
                      }}
                    >
                      {subName}
                    </Text>
                  ) : null}
                </View>
                {status &&
                (status === 'ing' ||
                  status === 'delivery' ||
                  status === 'over') &&
                foundImage ? (
                  <Image
                    source={require('../../../assets/image/v5/order-history/dots_vertical.png')}
                    style={{ width: 3, height: 15 }}
                  />
                ) : null}
              </View>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
                {tagViews}
              </View>
            </View>
          </TouchableOpacity>
          {foundStain?.video ||
          foundStain?.resultCode === 'SUCCESS' ||
          foundStain?.resultCode === 'FAIL' ? (
            <View
              style={{
                marginTop: 12,
                marginBottom: 12,
                flexDirection: 'row',
                paddingLeft: 32,
                paddingRight: 24,
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <View style={{ flexDirection: 'row' }}>
                <Image
                  style={{ width: 8, height: 8 }}
                  source={require('../../../assets/image/v5/order-history/cramp.png')}
                />
                {foundStain?.resultCode ? (
                  <Text
                    style={{
                      ...responseFont(14).regular,
                      color:
                        foundStain?.resultCode === 'SUCCESS'
                          ? washswatColor.blue_01
                          : washswatColor.red_01,
                      marginLeft: 8,
                    }}
                  >
                    {foundStain?.resultCode === 'SUCCESS'
                      ? StainCareText.success
                      : StainCareText.fail}
                    {/*<Text style={{ color: washswatColor.black }}>{` : ${CommonUtils.numberWithCommas(1500)}${StainCareText.refundExpect}`}</Text>*/}
                  </Text>
                ) : null}
              </View>
              {foundStain?.video ? (
                <TouchableOpacity
                  onPress={onVideo}
                  style={{
                    width: 80,
                    height: 32,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: washswatColor.grey_15,
                    backgroundColor: washswatColor.white,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}
                >
                  <Text
                    style={{
                      ...responseFont(14).regular,
                      color: washswatColor.black,
                    }}
                  >
                    {StainCareText.showVideo}
                  </Text>
                </TouchableOpacity>
              ) : null}
            </View>
          ) : null}
        </View>
      );
    });
  };

  return (
    <>
      <StatusView />
      <View style={{ paddingTop: 12, paddingBottom: 12 }}>
        <ItemView />
      </View>
    </>
  );
};

const mapStateToProps = ({ AlbumModule }) => ({
  AlbumState: AlbumModule,
});

const mapDispatchToProps = dispatch => ({
  AlbumActions: bindActionCreators(albumActions, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderHistoryStatusItemContainer);
