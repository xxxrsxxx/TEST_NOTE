import React from 'react';

import {
  StyleSheet,
  TouchableOpacity,
  View,
  Text,
  Image,
  Dimensions,
  PixelRatio,
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import Modal from 'react-native-modalbox';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';

import OrderHistoryModalBottomButtons from '../../components/order-history/OrderHistoryModalBottomButtons';

import * as CommonUtils from '../../utils/common';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

const { height } = Dimensions.get('window');

const OrderHistoryModalContainer = props => {
  const {
    isModalOn,
    onModalToggle,
    OrderHistoryState,
    OrderHistoryAction,
    componentId,
  } = props;

  const {
    isPayPending,
    billKey,
    available,
    selectedPaymentType,
    modalCardStructure,
  } = OrderHistoryState;
  const {
    setCardChecked,
    setComponentId,
    pressPay,
    setBillKey,
    setPayPending,
  } = OrderHistoryAction;

  const registedDefaultCard =
    available && available.cardList
      ? available.cardList.filter(card => card.isDefault === 1)
      : [];

  // available.cardList.sort((a, b) => a.isDefault - b.isDefault)
  const registedCardList =
    registedDefaultCard.length > 0 &&
    available.cardList
      .sort((a, b) => b.isDefault - a.isDefault)
      .map((card, i) => {
        return (
          <TouchableOpacity
            key={`${card.billKey}-${i}`}
            style={styles.cardComponent}
            onPress={() => {
              setCardChecked('bill');
              setBillKey(card.billKey);
            }}
          >
            <Text
              style={
                selectedPaymentType === 'bill' && billKey === card.billKey
                  ? styles.checkedCardContent
                  : styles.uncheckedCardContent
              }
            >
              {card.card}
            </Text>
            {selectedPaymentType === 'bill' && billKey === card.billKey && (
              <Image
                source={require('../../../assets/image/v5/ic_checkmark.png')}
                style={styles.check}
              />
            )}
          </TouchableOpacity>
        );
      });

  //
  const renderModalCard = modalCardStructure.cards.map((card, i) => (
    <TouchableOpacity
      key={`${card.key}-${i}`}
      style={styles.cardComponent}
      onPress={() => setCardChecked(card.key)}
    >
      <Text
        style={
          selectedPaymentType === card.key
            ? styles.checkedCardContent
            : styles.uncheckedCardContent
        }
      >
        {/* 카드등록이고 등록된 카드리스트가 존재할 경우에는 '새로운 신용/체크카드 등록' 으로 보여주기 */}
        {card.key === 'regist' &&
        available &&
        available.cardList &&
        available.cardList.length > 0
          ? card.registedTitle
          : // 총알이고 이미 보유하고있는 총알이 존재할 경우에는 잔여 총알 값으로 보여주기
          card.key === 'coin' && available && available.availableCoin
          ? `세특총알 ${CommonUtils.numberWithCommas(available.availableCoin)}`
          : card.title}
      </Text>
      {selectedPaymentType === card.key && (
        <Image
          source={require('../../../assets/image/v5/ic_checkmark.png')}
          style={styles.check}
        />
      )}
    </TouchableOpacity>
  ));

  return (
    <Modal
      isOpen={isModalOn ? true : false}
      style={{
        height:
          height / 2.15 +
          (available &&
            available.cardList &&
            available.cardList.length * PixelRatio.roundToNearestPixel(54)),
        position: 'absolute',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        justifyContent: 'center',
        backgroundColor: washswatColor.white,
        elevation: 20,
      }}
      position={'bottom'}
      onClosed={() => {
        onModalToggle(false);
        setPayPending(false);
        setCardChecked();
      }}
    >
      <View style={{ marginVertical: 20 }}>
        {/* key값이 기본 props로 들어오는 구조면 괜찮을듯 - component화 */}
        {available &&
          available.cardList &&
          available.cardList.length > 0 &&
          registedCardList}
        {renderModalCard}
        <OrderHistoryModalBottomButtons
          available={available}
          pressPay={pressPay}
          componentId={componentId}
          setComponentId={setComponentId}
          onModalToggle={onModalToggle}
          selectedPaymentType={selectedPaymentType}
          isPayPending={isPayPending}
          setPayPending={setPayPending}
        />
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  title: {
    ...responseFont(16).bold,
    color: washswatColor.black,
  },
  cardComponent: {
    height: 54,
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 24,
  },
  checkedCardContent: {
    ...responseFont(16).regular,
    flex: 1,
    color: '#2d4aff',
  },
  uncheckedCardContent: {
    ...responseFont(16).regular,
    flex: 1,
  },
  check: {
    width: 16,
    height: 16,
  },
});

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderHistoryModalContainer);
