import React from 'react';

import { RefreshControl, ScrollView, View } from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';

import OrderHistoryListContainer from './OrderHistoryListContainer';
import OrderHistoryFAQContainer from './OrderHistoryFAQContainer';

import { Font } from '../../utils/style';

const { washswatColor } = Font;

const OrderHistoryProgressContainer = props => {
  const { OrderHistoryState, OrderHistoryAction, componentId } = props;
  const { refreshingInProgress } = OrderHistoryState;
  const { onRefreshInProgress } = OrderHistoryAction;

  return (
    <ScrollView
      refreshControl={
        <RefreshControl
          refreshing={refreshingInProgress}
          onRefresh={onRefreshInProgress}
        />
      }
    >
      <OrderHistoryListContainer componentId={componentId} />
      <View style={{ height: 8, backgroundColor: washswatColor.grey_12 }} />
      <OrderHistoryFAQContainer />
    </ScrollView>
  );
};

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderHistoryProgressContainer);
