import React from 'react';

import {
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MainScreenModule from '../../reducers/MainScreenModule';
import * as orderHistoryActions from '../../reducers/OrderHistoryModule';

import { OrderHistoryText } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import * as KeyUtils from '../../utils/type/key';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: washswatColor.white,
  },
  order: {
    backgroundColor: washswatColor.black,
    paddingLeft: 16,
    paddingTop: 8,
    paddingRight: 16,
    paddingBottom: 8,
    borderRadius: 8,
    marginTop: 32,
  },
});

const OrderHistoryEmptyContainer = props => {
  const {
    componentId,
    MainScreenState,
    OrderHistoryState,
    OrderHistoryAction,
  } = props;
  const { pickup } = MainScreenState;
  const { tab, refreshingInProgress } = OrderHistoryState;
  const {
    onRefreshInProgress,
    setOrderInProgress,
    setTab,
  } = OrderHistoryAction;

  const onPressOrder = () => {
    if (!componentId) {
      return;
    }
    CommonUtils.navPush({
      componentId,
      name: 'OrderChatScreen',
      passProps: {
        callbackOrderHistoryEmpty: () => {
          setOrderInProgress();
          setTab(KeyUtils.PROGRESS);
        },
      },
    });
  };

  return (
    <ScrollView
      refreshControl={
        <RefreshControl
          refreshing={refreshingInProgress}
          onRefresh={onRefreshInProgress}
        />
      }
      contentContainerStyle={{ ...styles.root }}
    >
      <Text
        style={{
          ...responseFont(16).regular,
          color: washswatColor.grey_13,
          textAlign: 'center',
        }}
      >
        {tab === KeyUtils.PROGRESS
          ? OrderHistoryText.emptyProgressOrder
          : OrderHistoryText.emptyLastOrder}
      </Text>
      {tab === KeyUtils.PROGRESS ? (
        <TouchableOpacity
          onPress={pickup !== null && onPressOrder}
          style={styles.order}
        >
          <Text
            style={{ ...responseFont(14).regular, color: washswatColor.white }}
          >
            {OrderHistoryText.order}
          </Text>
        </TouchableOpacity>
      ) : null}
    </ScrollView>
  );
};

const mapStateToProps = ({ OrderHistoryModule, MainScreenModule }) => ({
  OrderHistoryState: OrderHistoryModule,
  MainScreenState: MainScreenModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(orderHistoryActions, dispatch),
  MainScreenAction: bindActionCreators(MainScreenModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderHistoryEmptyContainer);
