import React from 'react';

import { View } from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';

import OrderHistoryCommonPaymentComponent from '../../components/order-history/OrderHistoryCommonPaymentComponent';
import OrderHistorySalePaymentComponent from '../../components/order-history/OrderHistorySalePaymentComponent';
import OrderHistoryTotalPaymentComponent from '../../components/order-history/OrderHistoryTotalPaymentComponent';

import { Font } from '../../utils/style';

const { washswatColor } = Font;

const OrderHistoryDetailPaymentContainer = (props) => {

  const { OrderHistoryState, OrderHistoryAction, componentId, available, userType } = props;
  const { orderItem } = OrderHistoryState;
  const { goToPreCouponMain, goToCouponMain, goToPointMain, setReceipt } = OrderHistoryAction;

  const ShortGreyBoundary = () => (
    <View style={{ backgroundColor: washswatColor.grey_12, height: 1 }} />
  );

  return (
    <View style={{ marginVertical: 16, marginHorizontal: 24 }}>
      {/* commonpayment 부분 */}
      <OrderHistoryCommonPaymentComponent orderItem={orderItem}/>

      <ShortGreyBoundary />

      <OrderHistorySalePaymentComponent
        componentId={componentId}
        orderItem={orderItem}
        available={available}
        userType={userType}
        goToPreCouponMain={goToPreCouponMain}
        goToCouponMain={goToCouponMain}
        goToPointMain={goToPointMain}
      />

      <ShortGreyBoundary />

      <OrderHistoryTotalPaymentComponent
        componentId={componentId}
        orderItem={orderItem}
        available={available}
        setReceipt={setReceipt}
      />
    </View>
  )
};

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OrderHistoryDetailPaymentContainer);
