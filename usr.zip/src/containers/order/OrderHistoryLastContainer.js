import React from 'react';

import {
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as orderHistoryActions from '../../reducers/OrderHistoryModule';

import OrderHistoryListContainer from './OrderHistoryListContainer';

import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  moreShow: {
    width: 80,
    height: 32,
    borderRadius: 8,
    backgroundColor: washswatColor.grey_12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 56,
    marginBottom: 152,
  },
});

const OrderHistoryLastContainer = props => {
  const { OrderHistoryState, OrderHistoryAction, componentId } = props;
  const {
    refreshingInProgress,
    originalLastOrders,
    lastOrders,
  } = OrderHistoryState;
  const { onRefreshInProgress, setOrderListData } = OrderHistoryAction;

  const onPressMoreShow = () => {
    if (!lastOrders || !originalLastOrders) {
      return;
    }
    const length = lastOrders.length;
    if (length < originalLastOrders.length) {
      const concatList = lastOrders.concat(
        originalLastOrders.slice(length, length + 5),
      );
      setOrderListData({ lastOrders: concatList });
    }
  };

  return (
    <ScrollView
      refreshControl={
        <RefreshControl
          refreshing={refreshingInProgress}
          onRefresh={onRefreshInProgress}
        />
      }
    >
      <OrderHistoryListContainer componentId={componentId} />
      {lastOrders.length < originalLastOrders.length ? (
        <View style={{ alignItems: 'center' }}>
          <TouchableOpacity onPress={onPressMoreShow} style={styles.moreShow}>
            <Text
              style={{
                ...responseFont(14).regular,
                color: washswatColor.blue_01,
              }}
            >
              더보기
            </Text>
          </TouchableOpacity>
        </View>
      ) : null}
    </ScrollView>
  );
};

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(orderHistoryActions, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderHistoryLastContainer);
