import React, { Component } from 'react';

import { StyleSheet, Text, View } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';

import { BorderRadiusButton } from '../../components/common/button/BorderRadiusButton';

import { Favorite, OrderHistoryPaymentText } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import * as KeyUtils from '../../utils/type/key';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { washswatColor, responseFont } = Font;

const HorizontalLine = props => {
  const { height, backgroundColor } = props;
  return <View style={{ height, backgroundColor }} />;
};

const styles = StyleSheet.create({
  root: {
    backgroundColor: washswatColor.grey_07,
    borderRadius: 30,
    paddingTop: 15,
    paddingBottom: 15,
  },
  arrowTop: {
    borderBottomWidth: 10,
    borderLeftWidth: 3,
    borderLeftColor: 'transparent',
    borderRightWidth: 3,
    borderRightColor: 'transparent',
    marginRight: '10%',
  },
});

const PaymentRow = ({
  title,
  titleColor,
  price,
  priceColor,
  percent,
  percentColor,
  explain,
}) => {
  return (
    <View style={{ paddingLeft: 30, paddingTop: 16, paddingRight: 30 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text
          style={{
            ...responseFont(14).regular,
            color: titleColor ? titleColor : washswatColor.black,
          }}
        >
          {title}
        </Text>
        {price ? (
          <Text
            style={{
              ...responseFont(14).regular,
              color: priceColor ? priceColor : washswatColor.black,
            }}
          >
            {`${CommonUtils.numberWithCommas(price)}${Favorite.won}`}
          </Text>
        ) : percent ? (
          <Text
            style={{
              ...responseFont(14).regular,
              color: percentColor ? percentColor : washswatColor.black,
            }}
          >
            {String(percent)}
          </Text>
        ) : null}
      </View>
      {explain && (
        <Text
          style={{
            ...responseFont(12).regular,
            color: washswatColor.grey,
          }}
        >
          {explain}
        </Text>
      )}
    </View>
  );
};

const PaymentMethodView = ({ payType, histories }) => {
  if (!(payType && histories)) {
    return <View />;
  }
  if (payType === 'later') {
    return <View />;
  }
  const views = [];
  let originalPaymentArray = [];
  const payMethods = [
    {
      type: 'inicisBank',
      payName: OrderHistoryPaymentText.payAccount,
      refundName: OrderHistoryPaymentText.refundAccount,
    },
    {
      type: 'bill',
      payName: OrderHistoryPaymentText.payBill,
      refundName: OrderHistoryPaymentText.refundBill,
    },
    {
      type: 'card',
      payName: OrderHistoryPaymentText.payBill,
      refundName: OrderHistoryPaymentText.refundBill,
    },
    {
      type: 'coin',
      payName: OrderHistoryPaymentText.payCoin,
      refundName: OrderHistoryPaymentText.refundCoin,
    },
    {
      type: 'point',
      payName: '',
      refundName: OrderHistoryPaymentText.refundPoint,
    },
    {
      type: 'naverpay',
      payName: OrderHistoryPaymentText.payNaverPay,
      refundName: OrderHistoryPaymentText.refundNaverPay,
    },
  ];

  let payTypeCount = 0;
  histories.map((history, index) => {
    const { payType, refundType, price, type, match } = history;
    let name = '';
    let priceColor = '';
    if (payType && payType !== 'later' && type === 'payment') {
      payTypeCount++;
    }
    if (refundType && type && type === 'refund') {
      payTypeCount--;
    }
    if (payType && payType !== 'later' && payType !== 'point') {
      originalPaymentArray.push(history);
      const payMethod = _.find(payMethods, ['type', payType]);
      name = payMethod ? payMethod.payName : '';
      if (payTypeCount > 1) {
        name += '(추가금)';
      }
      priceColor = washswatColor.black;
    }
    if (type === 'refund') {
      const refundMethod = _.find(payMethods, ['type', refundType]);
      name = refundMethod ? refundMethod.refundName : '';
      priceColor = washswatColor.red;
    }

    if (name && priceColor) {
      views.push(
        <View
          key={index}
          style={{ paddingLeft: 30, paddingTop: 16, paddingRight: 30 }}
        >
          <View
            style={{ flexDirection: 'row', justifyContent: 'space-between' }}
          >
            <Text
              style={{
                ...responseFont(14).regular,
                color: washswatColor.black,
              }}
            >
              {name}
            </Text>
            <Text
              style={{
                ...responseFont(14).regular,
                color: washswatColor.black,
              }}
            >
              {`${type === 'refund' ? '-' : ''}${CommonUtils.numberWithCommas(
                price,
              )}${Favorite.won}`}
            </Text>
          </View>
        </View>,
      );
    }
  });
  return views;
};

class OrderHistoryPaymentContainer extends Component {
  getButtonTitle = ({ payType, alert, smile }) => {
    let buttonTitle = '';
    if (payType === 'later') {
      buttonTitle = OrderHistoryPaymentText.actionPayment;
    } else {
      if (alert && alert.length > 0 && alert[0].button) {
        // if (alert[0].button.action && alert[0].button.action === 'refund') {
        //   if (smile && smile.status && smile.status === '미처리') { // 환불금 발생시 status: '미처리' or '완료'
        //     return OrderHistoryPaymentText.refundReceiveCompletion;
        //   }
        // }
        const { action, name, needPayPrice, needRefundPrice } = alert[0].button;
        switch (action) {
          case 'payment':
            buttonTitle = name;
            break;
          case 'refund':
            buttonTitle = name;
            break;
          default:
            break;
        }
      } else {
        buttonTitle = OrderHistoryPaymentText.actionSendReceipt;
      }
    }
    return buttonTitle;
  };

  onPressButton = ({ payType, history, alert }) => {
    if (payType === 'later') {
      this.onPressPayment();
    } else {
      if (alert && alert.length > 0 && alert[0].button) {
        const { action, name, needPayPrice, needRefundPrice } = alert[0].button;
        switch (action) {
          case 'payment':
            this.onPressPayment();
            break;
          case 'refund':
            this.onPressRefund(needRefundPrice);
            break;
          default:
            break;
        }
      } else {
        this.showReceiptListModal(history);
      }
    }
  };

  onPressPayment = () => {
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'OrderHistoryPayment',
      // name: 'PaymentScreen'
    });
  };

  onPressRefund = needRefundPrice => {
    const { OrderHistoryAction, OrderHistoryState } = this.props;
    const { orderItem } = OrderHistoryState;
    const { orderId } = orderItem;
    OrderHistoryAction.setRefundPrice({
      refundPrice: needRefundPrice,
      orderId,
    });
  };

  showReceiptListModal = history => {
    let receiptList = [];
    _.map(history || [], row => {
      const { tId, payType, price, regdate, refundType, type } = row;
      const canShowReceiptPayMethod = ['bill', 'card', 'naverpay'];
      if (
        tId &&
        (canShowReceiptPayMethod.indexOf(payType) > -1 ||
          canShowReceiptPayMethod.indexOf(refundType) > -1)
      ) {
        receiptList.push({ tId, payType, price, regdate, refundType, type });
      }
    });
    if (receiptList.length === 1) {
      // 하나만 있을때
      this.sendReceiptBottomSheet(receiptList[0]);
    } else {
      // 여러개 있거나 0개 일경우
      const { OrderHistoryAction } = this.props;
      OrderHistoryAction.setReceiptList({ receiptList });
      // this.setState({ receiptList });
    }
  };

  sendReceiptBottomSheet = row => {
    const { componentId, OrderHistoryAction, OrderHistoryState } = this.props;
    const { orderItem } = OrderHistoryState;
    const { _id } = orderItem;
    OrderHistoryAction.sendReceit({ row, objectId: _id, componentId });
  };

  isShowPaymentAndReceiptButton = ({ payType, histories }) => {
    const isAddPayment = histories.filter(e => e.payType === 'later');
    if (isAddPayment.length > 0) {
      return true;
    }
    let payTypeString = '';
    histories.map(history => {
      const { payType } = history;
      if (payType) {
        payTypeString = payType;
      }
    });
    return (
      payTypeString === 'bill' ||
      payTypeString === 'card' ||
      payTypeString === 'naverpay'
    );
  };

  onPressMembershipBenefit = () => {
    CommonUtils.navShowModal({
      name: 'JoinMember',
      passProps: {
        finishedAction: () => {
          /** 여기 들어온 경우는 멤버십 가입한 경우. 쿠폰함으로 보낸다 /**/
          CommonUtils.navPush({
            componentId: this.props.componentId,
            name: 'CouponMain',
          });
        },
      },
    });
  };

  state = {
    animatedColors: ['#ABFFD3', '#0098CB'],
    // animatedColors: ['#ABFFD3', '#93F1D2', '#80E5D1', '#69D7D0', '#52C9CF', '#3BBBCE', '#27AFCD', '#12A3CC', '#0098CB']
    connectMemberBenefit: 0,
  };

  // animatedInterval;

  async componentDidMount() {
    const { OrderHistoryState, OrderHistoryAction } = this.props;
    const { orderItem } = OrderHistoryState;
    const { orderId } = orderItem;
    if (orderId) {
      OrderHistoryAction.getDiscountPriceForBasicUser(orderId);
    }
    const connectMemberBenefit = await CommonUtils.getValue(
      KeyUtils.CONNECT_MEMBER_BENEFIT,
    );
    this.setState({ connectMemberBenefit });
    // this.animatedInterval = setInterval(() => {
    //   const { animatedColors } = this.state;
    //   const deletedColors = animatedColors.splice(0, 2);
    //   animatedColors.unshift(deletedColors[1]);
    //   animatedColors.push(deletedColors[1]);
    //   this.setState((prevState) => {
    //     return {
    //       animatedColors: prevState.animatedColors
    //     }
    //   });
    // }, 300);
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    const { OrderHistoryState, OrderHistoryAction } = this.props;
    const { discountPriceForBasicUser, orderItem } = OrderHistoryState;
    const { orderId } = orderItem;
    if (
      discountPriceForBasicUser !==
      prevProps.OrderHistoryState.discountPriceForBasicUser
    ) {
      if (orderId) {
        OrderHistoryAction.getDiscountPriceForBasicUser(orderId);
      }
    }
  }

  componentWillUnmount() {
    // clearInterval(this.animatedInterval);
  }

  render() {
    const { connectMemberBenefit } = this.state;
    const { OrderHistoryState } = this.props;
    const {
      orderItem,
      receiptList,
      discountPriceForBasicUser,
    } = OrderHistoryState;
    const { pickup, payment, alert, smile } = orderItem;
    const {
      item,
      totalPrice,
      couponDiscount,
      usePoint,
      finalPrice,
      payType,
      itemExtra,
      deliveryFee,
      discountRate,
    } = pickup;
    const membershipDiscount = connectMemberBenefit ? discountRate : 0;
    const { history } = payment;
    const totalNeedPayPrice = alert.map(list => {
      let totalPrice = 0;
      const { needPayPrice } = list.button;
      totalPrice = totalPrice + needPayPrice;
      return totalPrice;
    });
    const totalNeedRefundPrice = alert.map(list => {
      let totalRefundPrice = 0;
      const { needRefundPrice } = list.button;
      totalRefundPrice = totalRefundPrice + needRefundPrice;
      return totalRefundPrice;
    });
    let isSmileStatus = false;
    // if (smile && smile.status && smile.status === '미처리') { // 환불금 발생시 status: '미처리' or '완료'
    //   isSmileStatus = true;
    // }

    return (
      <View style={styles.root}>
        <Text
          style={{
            ...responseFont(16).bold,
            color: washswatColor.black,
            marginLeft: 30,
            marginRight: 30,
          }}
        >
          {OrderHistoryPaymentText.title}
        </Text>
        <View style={{ height: 6 }} />
        <PaymentRow
          title={OrderHistoryPaymentText.washAmount}
          price={totalPrice - itemExtra}
        />
        {itemExtra && itemExtra > 0 ? (
          <PaymentRow
            title={OrderHistoryPaymentText.itemExtra}
            price={itemExtra}
            explain={OrderHistoryPaymentText.itemExtraExplain}
          />
        ) : null}
        <View style={{ marginLeft: 18, marginTop: 20, marginRight: 18 }}>
          <HorizontalLine height={1} backgroundColor={washswatColor.grey_09} />
        </View>
        <PaymentRow
          title={OrderHistoryPaymentText.totalPrice}
          price={totalPrice}
        />
        {couponDiscount && couponDiscount > 0 ? (
          <PaymentRow
            title={OrderHistoryPaymentText.couponDiscount}
            price={`-${couponDiscount}`}
            priceColor={washswatColor.red}
          />
        ) : null}
        {usePoint && usePoint > 0 ? (
          <PaymentRow
            title={OrderHistoryPaymentText.usePoint}
            price={`-${usePoint}`}
            priceColor={washswatColor.red}
          />
        ) : null}
        {membershipDiscount ? (
          <PaymentRow
            title={OrderHistoryPaymentText.membershipDiscount}
            percent={`${membershipDiscount}%`}
          />
        ) : null}
        {deliveryFee && deliveryFee > 0 ? (
          <PaymentRow
            title={OrderHistoryPaymentText.deliveryFee}
            price={deliveryFee}
          />
        ) : null}
        <View
          style={{
            marginLeft: 18,
            marginTop: 20,
            marginRight: 18,
            marginBottom: 20,
          }}
        >
          <HorizontalLine height={1} backgroundColor={washswatColor.grey_09} />
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginLeft: 30,
            marginRight: 30,
          }}
        >
          <Text
            style={{
              ...responseFont(14).regular,
              color: washswatColor.black,
            }}
          >
            {OrderHistoryPaymentText.finalPaymentAmount}
          </Text>
          <Text
            style={{
              ...responseFont(16).bold,
              color: washswatColor.black,
            }}
          >
            {`${CommonUtils.numberWithCommas(
              totalPrice - (couponDiscount + usePoint),
            )}${Favorite.won}`}
          </Text>
        </View>
        {discountPriceForBasicUser ? (
          <View style={{ alignItems: 'flex-end', paddingRight: 30 }}>
            <View
              style={[
                styles.arrowTop,
                { borderBottomColor: this.state.animatedColors[1] },
              ]}
            ></View>
            <LinearGradient
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              colors={this.state.animatedColors}
              style={{
                height: 22,
                paddingLeft: 8,
                paddingRight: 8,
                justifyContent: 'center',
                borderRadius: 10,
              }}
            >
              <Text
                style={{
                  ...responseFont(12).bold,
                  color: washswatColor.white,
                }}
              >{`지금 멤버십 가입하면 ${CommonUtils.numberWithCommas(
                discountPriceForBasicUser,
              )}원 절약!`}</Text>
            </LinearGradient>
          </View>
        ) : null}
        <PaymentMethodView payType={payType} histories={history} />
        {totalNeedPayPrice > 0 ? (
          <>
            <View style={{ marginLeft: 18, marginTop: 30, marginRight: 18 }}>
              <HorizontalLine
                height={1}
                backgroundColor={washswatColor.grey_09}
              />
            </View>
            <PaymentRow
              title={OrderHistoryPaymentText.addPrice}
              price={totalNeedPayPrice}
            />
          </>
        ) : (
          <></>
        )}

        {totalNeedRefundPrice > 0 ? (
          <>
            <View style={{ marginLeft: 18, marginTop: 30, marginRight: 18 }}>
              <HorizontalLine
                height={1}
                backgroundColor={washswatColor.grey_09}
              />
            </View>
            <PaymentRow
              title={OrderHistoryPaymentText.refundPrice}
              price={totalNeedRefundPrice}
            />
          </>
        ) : (
          <></>
        )}

        {this.isShowPaymentAndReceiptButton({ payType, histories: history }) ? (
          <View style={{ marginLeft: 15, marginTop: 31, marginRight: 15 }}>
            <BorderRadiusButton
              title={this.getButtonTitle({ payType, alert, smile })}
              titleFont={responseFont(16).bold}
              titleColor={
                isSmileStatus ? washswatColor.white : washswatColor.blue
              }
              borderRadius={15}
              buttonBgColor={
                isSmileStatus ? washswatColor.grey_09 : washswatColor.white
              }
              disabled={totalPrice === 0 || isSmileStatus}
              onPress={() => this.onPressButton({ payType, history, alert })}
            />
          </View>
        ) : (
          <View />
        )}
        {discountPriceForBasicUser ? (
          <View style={{ marginLeft: 15, marginTop: 9, marginRight: 15 }}>
            <BorderRadiusButton
              title={OrderHistoryPaymentText.membershipBenefit}
              titleFont={responseFont(16).bold}
              titleColor={washswatColor.blue}
              borderRadius={15}
              buttonBgColor={washswatColor.white}
              onPress={this.onPressMembershipBenefit}
            />
          </View>
        ) : null}
      </View>
    );
  }
}

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderHistoryPaymentContainer);
