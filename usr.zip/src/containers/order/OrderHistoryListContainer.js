import React, { useEffect } from 'react';

import {
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as orderHistoryActions from '../../reducers/OrderHistoryModule';
import * as orderActions from '../../reducers/OrderModule';

import OrderHistoryStatusItemContainer from './OrderHistoryStatusItemContainer';

import OrderIdComponent from '../../components/order-history/OrderIdComponent';

import {
  OrderHistoryDetailString,
  OrderHistoryProgressText,
  OrderHistoryText,
} from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import * as OrderUtils from '../../utils/common/order';
import * as OrderHistoryUtils from '../../utils/common/order/history';
import * as KeyUtils from '../../utils/type/key';
import { Font } from '../../utils/style';

import { _, moment } from '../../plugins';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  buttonRoot: {
    flexDirection: 'row',
    paddingLeft: 24,
    paddingTop: 8,
    paddingRight: 24,
    paddingBottom: 24,
  },
  button: {
    height: 56,
    backgroundColor: washswatColor.white,
    borderWidth: 1,
    borderRadius: 16,
    borderColor: washswatColor.grey_15,
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
});

const OrderHistoryListContainer = props => {
  const {
    componentId,
    OrderHistoryState,
    OrderHistoryAction,
    OrderAction,
  } = props;
  const {
    GLOBAL_STATUS_LIST,
    tab,
    orderItemList,
    lastOrders,
  } = OrderHistoryState;
  const {
    setOrder,
    goToSetPickupTime,
    goToSetDeliveryTime,
  } = OrderHistoryAction;
  let flatListData = tab === KeyUtils.PROGRESS ? orderItemList : lastOrders;

  useEffect(() => {
    if (tab === KeyUtils.PROGRESS) {
      const foundOrder = flatListData.find((order, index) => {
        const { status } = order;
        return status === 'ing' || status === 'delivery';
      });
      const isDeliveryFail = OrderHistoryUtils.isDeliveryFail({
        order: foundOrder,
      });
      OrderHistoryAction.setToastDeliveryFail(isDeliveryFail);
    }
  }, []);

  const onPressOrderDetail = orderId => {
    if (!componentId) {
      return;
    }
    setOrder(
      flatListData.find(order => {
        return order.orderId === orderId ? order : null;
      }),
    );
    CommonUtils.navPush({
      componentId,
      name: 'OrderDetailScreen',
      passProps: {
        orderId,
      },
    });
  };

  const ButtonView = ({ item, goToSetPickupTime, goToSetDeliveryTime }) => {
    const { _id, status, orderId, feedback, pickup, history, mission } = item;
    if (!_id || !status || !orderId) {
      return;
    }

    if (status === 'pickup') {
      const onPressScheduleChange = () => {
        CommonUtils.navShowModalPageSheet({
          name: 'OrderPickupScreen',
          passProps: {
            timeSelectCallback: pickup => {
              setTimeout(() => {
                CommonUtils.navShowModalPageSheet({
                  name: 'OrderDeliveryScreen',
                  passProps: {
                    pickupTime: pickup,
                    timeSelectCallback: delivery => {
                      OrderAction.updateBoth({
                        pickup,
                        delivery,
                        objectId: _id,
                        callback: () => {
                          OrderHistoryAction.setOrderInProgress();
                        },
                      });
                    },
                  },
                });
              }, 1000);
            },
          },
        });
      };
      const onPressOrderCancel = () => {
        OrderUtils.cancelOrder({
          _id,
          OrderAction,
          componentId,
          OrderHistoryAction,
          OrderHistoryState,
          passScreen: 'OrderHistoryListContainer',
        });
      };
      const onPressRequestChange = () => {};
      return (
        <View style={styles.buttonRoot}>
          <TouchableOpacity
            onPress={onPressScheduleChange}
            style={styles.button}
          >
            <Text>{OrderHistoryProgressText.scheduleChange}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={onPressOrderCancel}
            style={{ ...styles.button, marginLeft: 7 }}
          >
            <Text>{OrderHistoryProgressText.orderCancel}</Text>
          </TouchableOpacity>
          {/*<TouchableOpacity onPress={onPressRequestChange} style={{ ...styles.button, marginLeft: 7 }}>*/}
          {/*  <Text>{OrderHistoryProgressText.requestModification}</Text>*/}
          {/*</TouchableOpacity>*/}
        </View>
      );
    } else {
      const onPressScheduleChange = componentId => {
        setOrder(
          flatListData.find(order => {
            return order.orderId === orderId ? order : null;
          }),
        );
        goToSetDeliveryTime(componentId);
      };
      const onPressPayment = () => {
        if (!componentId) {
          return;
        }
        setOrder(
          flatListData.find(order => {
            return order.orderId === orderId ? order : null;
          }),
        );
        CommonUtils.navPush({
          componentId,
          name: 'OrderDetailScreen',
          passProps: {
            orderId,
          },
        });
      };
      const onPressWriteReview = () => {
        CommonUtils.navShowModal({
          name: 'FeedbackAfterOrder',
          passProps: {
            order: item,
            text: 'good',
          },
        });
      };
      // const { payType } = pickup;
      // if (payType !== 'later' && feedback) {
      //   return null;
      // }

      if (feedback) {
        return null;
      } else {
        if (moment().diff(new Date(mission.delivery.deliveryTime), 'day') > 6) {
          return null;
        }
      }
      let paymentText = OrderHistoryText.payment;
      if (pickup) {
        const { payType } = pickup;
        if (payType && payType !== 'later') {
          paymentText = OrderHistoryText.paymentCompletion;
        }
      }
      const reviewHistory = history?.find(e => {
        const { type, action } = e;
        return type === 'meet' && action === 'delivery';
      });
      return (
        <View style={styles.buttonRoot}>
          {status !== 'over' ? (
            <TouchableOpacity
              style={{ ...styles.button, borderColor: '#eaeaea' }}
              onPress={onPressScheduleChange}
            >
              <Text>{OrderHistoryDetailString.scheduleChange}</Text>
            </TouchableOpacity>
          ) : null}
          {status !== 'over' ? (
            <TouchableOpacity
              disabled={status === 'wait'}
              onPress={onPressPayment}
              style={{ ...styles.button, marginLeft: 7 }}
            >
              <Text
                style={{
                  ...responseFont(14).regular,
                  color:
                    status === 'wait'
                      ? washswatColor.grey_13
                      : washswatColor.black,
                }}
              >
                {paymentText}
              </Text>
            </TouchableOpacity>
          ) : null}
          {status === 'over' &&
          reviewHistory?.type === 'meet' &&
          reviewHistory?.action === 'delivery' &&
          moment().format('YYYYMMDD') <
            moment(reviewHistory?.regdate)
              .add(7, 'days')
              .format('YYYYMMDD') ? (
            <TouchableOpacity
              onPress={onPressWriteReview}
              style={{ ...styles.button, marginLeft: 7 }}
            >
              <Text
                style={{
                  ...responseFont(14).regular,
                  color: washswatColor.black,
                }}
              >
                {OrderHistoryText.writeReview}
              </Text>
            </TouchableOpacity>
          ) : null}
        </View>
      );
    }
  };

  const renderItem = ({ order, index }) => {
    let views = [];
    const {
      history,
      _id,
      orderId,
      status,
      pickup,
      mission,
      delivery,
      package: packages,
    } = order;
    if (status === 'pickup') {
      const { endTime } = mission && mission.pickup;
      const items = [];
      items.push({
        emoji: '',
        subName: OrderHistoryProgressText.washBeforePickup,
      });
      views.push(
        <OrderHistoryStatusItemContainer
          key={`${status}-${index}`}
          status={status}
          statusName={OrderHistoryProgressText.pickupStatus}
          endTime={endTime}
          items={items}
        />,
      );
    } else if (status === 'wait') {
      if (!pickup) {
        return;
      }
      const endTime = mission?.delivery?.endTime;
      const { bagNumber: bagNumbers } = pickup;
      const items = [];
      bagNumbers.map((bagNumber, index) => {
        items.push({
          emoji: '🧺',
          name: `[${OrderHistoryProgressText.pickupBag}] ${bagNumber.id}`,
          subName: OrderHistoryProgressText.washBeforeWait,
        });
      });
      views.push(
        <OrderHistoryStatusItemContainer
          key={`${status}-${index}`}
          status={status}
          statusName={OrderHistoryProgressText.waitStatus}
          endTime={endTime}
          items={items}
        />,
      );
    } else if (status === 'ing' || status === 'delivery') {
      if (!pickup) {
        return null;
      }
      views = _.concat(
        buildItemViews({
          order,
          componentId: props.componentId,
          GLOBAL_STATUS_LIST,
        }),
        views,
      );
    }

    const deliveryViews = [];
    if (history && history.length > 0) {
      _.map(history, o => {
        const { type, action, regdate, swatId } = o;
        if (type === 'meet' && action === 'delivery') {
          const date = moment(regdate).format('M/D (ddd) HH:mm');
          const swatName = swatId.slice(0, swatId.indexOf('@'));
          deliveryViews.push({
            emoji: '🚚',
            name: `${date}\n${swatName} ${OrderHistoryProgressText.swat} ${OrderHistoryProgressText.overStatus}`,
          });
        }
      });
    }

    if (deliveryViews.length > 0) {
      views.push(
        <OrderHistoryStatusItemContainer
          key={`${status}__${_id}`}
          status={status}
          statusName={OrderHistoryProgressText.overStatus}
          items={deliveryViews}
          endTime={(delivery && delivery.regdate) || mission.delivery.endTime}
        />,
      );
    }
    return (
      <View>
        <OrderIdComponent
          orderId={`🗂 ${orderId}`}
          onPress={() => onPressOrderDetail(orderId)}
        />
        {views}
        <ButtonView
          item={order}
          goToSetPickupTime={goToSetPickupTime}
          goToSetDeliveryTime={goToSetDeliveryTime}
        />
      </View>
    );
  };

  return (
    <>
      <FlatList
        data={flatListData}
        renderItem={({ item: order, index }) => renderItem({ order, index })}
        keyExtractor={item => item.orderId}
        ItemSeparatorComponent={() => (
          <View style={{ height: 8, backgroundColor: washswatColor.grey_12 }} />
        )}
      />
    </>
  );
};

export const buildItemViews = ({ order, GLOBAL_STATUS_LIST, componentId }) => {
  const { pickup, mission, orderId, status, issue, history, delivery } = order;
  const views = [];
  const { item: items } = pickup;
  const { endTime } = mission.delivery;
  const itemGroup = [];
  _.map(items, o => {
    const { step } = o;
    const statusRow = _.find(GLOBAL_STATUS_LIST, { step });
    let orderStatus = 'ing';
    if (statusRow && statusRow.orderStatus) {
      orderStatus = statusRow.orderStatus;
    }
    const groupIndex = _.findIndex(itemGroup, { orderStatus });
    if (groupIndex > -1) {
      itemGroup[groupIndex].items.push(o);
    } else {
      itemGroup.push({
        orderStatus,
        items: [o],
      });
    }
  });
  const undecidedTime = _.find(
    issue || [],
    o => o && o.isIssue && o.code === 'undecidedTime',
  );
  const isDeliveryFail = OrderHistoryUtils.isDeliveryFail({ order });
  _.map(itemGroup, ({ orderStatus, items }, index) => {
    views.push(
      <OrderHistoryStatusItemContainer
        key={`${orderId}-${orderStatus}-${index}`}
        componentId={componentId}
        status={status}
        statusName={
          _.find(GLOBAL_STATUS_LIST, { orderStatus })
            ? _.find(GLOBAL_STATUS_LIST, { orderStatus }).name
            : ''
        }
        items={items}
        endTime={(delivery && delivery.regdate) || endTime}
        undecidedTime={
          undecidedTime ||
          moment() > moment(new Date(mission.delivery.endTime)).add(12, 'hour')
        }
        isDeliveryFail={isDeliveryFail}
        hideDate={index !== 0}
      />,
    );
  });
  return views;
};

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(orderHistoryActions, dispatch),
  OrderAction: bindActionCreators(orderActions, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderHistoryListContainer);
