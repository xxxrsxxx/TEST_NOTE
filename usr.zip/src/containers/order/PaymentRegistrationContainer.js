import React, { Component } from 'react';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';
import * as MyPageModule from '../../reducers/MyPageModule';

import { CollapsibleComponent } from '../../components/common/collapse/CollapsibleComponent';

import {
  EmojiText,
  Favorite,
  PaymentRegistrationText,
} from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import { Font } from '../../utils/style';

const { washswatColor } = Font;

class PaymentRegistrationContainer extends Component {
  state = {
    title: PaymentRegistrationText.title,
    collapsed: true,
  };

  async componentDidMount() {
    await this.props.MyPageAction.getCardAndCoin();
    this.setCollapse();
  }

  setCollapse = () => {
    const { OrderHistoryState } = this.props;
    const { orderItem } = OrderHistoryState;
    const {
      orderId,
      status,
      pickup,
      pickupTime,
      deliveryTime,
      mission,
      preOptions,
      alert,
      delivery,
      feedback,
    } = orderItem;
    const coin = this.getCoin();
    const card = this.getDelegateCard();
    if (preOptions && preOptions.payment && preOptions.payment.payType) {
      const payType = preOptions.payment.payType;
      if (payType === 'coin' || payType === 'bill') {
        this.setState({ collapsed: true });
        return;
      }
    }
    this.setState({ collapsed: false });
  };

  onPressPayment = ({ orderId, preOptions }) => {
    if (!orderId) {
      return;
    }
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'OrderPaymentScreen',
      passProps: {
        orderId,
      },
    });
    this.setState({ collapsed: true });
  };

  onPressCollapse = () => {
    const { collapsed } = this.state;
    this.setState({ collapsed: !collapsed });
  };

  getDelegateCard = () => {
    const { MyPageAction, MyPageState } = this.props;
    const { userCardList, userCoin, coinHistory } = MyPageState;
    for (let i = 0; i < userCardList.length; i++) {
      const cardObject = userCardList[i];
      if (cardObject.isDefault === 1) {
        const cardNumbers = cardObject.card.split(' ');
        return `${EmojiText.card} ${cardNumbers[0]}${Favorite.card} ${cardNumbers[1]}`;
      }
    }
  };

  getCoin = () => {
    const { MyPageAction, MyPageState } = this.props;
    const { userCardList, userCoin, coinHistory } = MyPageState;
    if (userCoin && userCoin > 0) {
      return `${EmojiText.card} ${
        Favorite.bullet
      } ${CommonUtils.numberWithCommas(userCoin)}`;
    }
  };

  getTitle = () => {
    const { OrderHistoryState } = this.props;
    const { orderItem } = OrderHistoryState;
    const { preOptions } = orderItem;

    const coin = this.getCoin();
    const card = this.getDelegateCard();

    if (preOptions && preOptions.payment && preOptions.payment.payType) {
      const payType = preOptions.payment.payType;
      switch (payType) {
        case 'coin':
          return coin;
        case 'bill':
          return card;
        default:
          return PaymentRegistrationText.title;
      }
    }
    return PaymentRegistrationText.title;
  };

  getContent = () => {
    const { OrderHistoryState } = this.props;
    const { orderItem } = OrderHistoryState;
    const {
      orderId,
      status,
      pickup,
      pickupTime,
      deliveryTime,
      mission,
      preOptions,
      alert,
      delivery,
      feedback,
    } = orderItem;
    if (preOptions && preOptions.payment && preOptions.payment.payType) {
      const payType = preOptions.payment.payType;
      if (payType === 'coin' || payType === 'bill') {
        return PaymentRegistrationText.contentRegistered;
      }
    }
    switch (status) {
      case 'pickup':
        return PaymentRegistrationText.contentReady;
      case 'wait':
        return PaymentRegistrationText.contentCheck;
      default:
        return PaymentRegistrationText.contentReady;
    }
  };

  getButtonText = () => {
    const { OrderHistoryState } = this.props;
    const { orderItem } = OrderHistoryState;
    const {
      orderId,
      status,
      pickup,
      pickupTime,
      deliveryTime,
      mission,
      preOptions,
      alert,
      delivery,
      feedback,
    } = orderItem;
    if (preOptions && preOptions.payment && preOptions.payment.payType) {
      const payType = preOptions.payment.payType;
      if (payType === 'coin' || payType === 'card') {
        switch (status) {
          case 'pickup':
          case 'wait':
            return PaymentRegistrationText.buttonChange;
          default:
            return PaymentRegistrationText.actionPay;
        }
      }
    }
    return PaymentRegistrationText.buttonRegistration;
  };

  getBgColor = () => {
    const { screen } = this.props;
    switch (screen) {
      case 'OrderHistoryDetailScreen':
        return washswatColor.grey_07;
      case 'OrderCompleteScreen':
        return washswatColor.white;
      default:
        return washswatColor.grey_07;
    }
  };

  getButtonBgColor = () => {
    const { screen } = this.props;
    switch (screen) {
      case 'OrderHistoryDetailScreen':
        return washswatColor.white;
      case 'OrderCompleteScreen':
        return washswatColor.grey_07;
      default:
        return washswatColor.white;
    }
  };

  render() {
    const { OrderHistoryState } = this.props;
    const { orderItem } = OrderHistoryState;
    const {
      orderId,
      status,
      pickup,
      pickupTime,
      deliveryTime,
      mission,
      preOptions,
      alert,
      delivery,
      feedback,
    } = orderItem;
    const { collapsed } = this.state;
    return (
      <CollapsibleComponent
        title={this.getTitle()}
        content={this.getContent()}
        buttonText={this.getButtonText()}
        onPressButton={() => this.onPressPayment({ orderId, preOptions })}
        bgColor={this.getBgColor()}
        buttonBgColor={this.getButtonBgColor()}
        onPressCollapse={this.onPressCollapse}
        collapsed={collapsed}
      />
    );
  }
}

const mapStateToProps = ({ OrderHistoryModule, MyPageModule }) => ({
  OrderHistoryState: OrderHistoryModule,
  MyPageState: MyPageModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(PaymentRegistrationContainer);
