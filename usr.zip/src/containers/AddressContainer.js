import React, { Component } from 'react';

import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Image,
  Dimensions,
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as changeAddressAction from '../reducers/ChangeAddressModule';

import * as CommonUtils from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import { Font } from '../utils/style';

const { washswatColor, responseFont, verticalScale } = Font;

const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  address: {
    paddingLeft: 18,
    paddingRight: 29,
    height: 48,
    backgroundColor: washswatColor.white,
    justifyContent: 'center',
    shadowColor: washswatColor.black,
    borderRadius: 30,
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.16,
    shadowRadius: 12,
    elevation: 12,
    position: 'absolute',
    alignSelf: 'center',
    marginTop: verticalScale(100),
    alignItems: 'center',
  },
  selector: {
    width: 0,
    height: 0,
    borderLeftColor: 'transparent',
    borderLeftWidth: 7,
    borderRightColor: 'transparent',
    borderRightWidth: 7,
    borderTopColor: '#fff',
    borderTopWidth: 14,
    position: 'absolute',
    bottom: -14,
  },
  guide: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    backgroundColor: washswatColor.whiteOpacity65,
    marginRight: 11,
    marginBottom: 15,
    paddingHorizontal: 9,
    paddingVertical: 3,
    borderRadius: 13,
  },
});

class AddressContainer extends Component {
  state = {};

  onPressAddress = () => {
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'AddressChange',
      passProps: { express: false, weekly: false },
    });
  };

  onPressGuide = () => {
    CommonUtils.navShowModalWebView({ url: ServerUtils.URL_USER_GUIDE });
  };

  render() {
    const { addressTitle, lat, lon, isService } = this.props.MainScreenState;
    return (
      <View style={{ flex: 1 }}>
        <Image
          source={{
            uri: `https://apis.openapi.sk.com/tmap/staticMap?appKey=bea19323-df5f-4a2b-9164-23c6e96ad7bf&longitude=${lon}&latitude=${lat}&coordType=WGS84GEO&zoom=15&format=PNG`,
            width: width,
            height: 331,
          }}
        />
        <TouchableOpacity onPress={this.onPressAddress} style={styles.address}>
          <View style={styles.selector}></View>
          <Text
            style={{ ...responseFont(14).regular, color: washswatColor.black }}
          >
            🏠 {addressTitle}
          </Text>

          <View
            style={{ width: 8, height: 13, position: 'absolute', right: 12 }}
          >
            <Image
              source={require('../../assets/image/v5/icons_8_forward.png')}
              style={{ width: '100%', height: '100%' }}
            />
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={this.onPressGuide} style={styles.guide}>
          <Text
            style={{ ...responseFont(12).regular, color: washswatColor.black }}
          >
            📖 세특이 처음이신가요?
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const mapStateToProps = ({ MainScreenModule }) => ({
  MainScreenState: MainScreenModule,
});
export default connect(mapStateToProps, dispatch => ({
  ChangeAddressAction: bindActionCreators(changeAddressAction, dispatch),
}))(AddressContainer);
