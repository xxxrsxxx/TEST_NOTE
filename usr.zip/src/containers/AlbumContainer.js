import React, { Component } from 'react';

import { View, FlatList, Image, Dimensions, TouchableOpacity, Platform } from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as AlbumModule from '../reducers/AlbumModule';

import * as CommonUtils from '../utils/common/index';
import * as KeyUtils from '../utils/type/key';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';

const window = Dimensions.get('window');

class AlbumContainer extends Component {

  onPressItem = (item) => () => {
    const { type, url } = item;
    const { AlbumAction, AlbumState } = this.props;
    const { orderId } = AlbumState;

    if (type !== 'dropbox') {
      AlbumAction.setSelectedItem(item);

    } else {
      const uid = CommonUtils.getValue(KeyUtils.USER_ID);
      const video = true;
      CommonUtils.navShowModalWebView({ url, video });
      AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_ORDER_DETAIL, {
        af_order_id: orderId,
        af_content_type: 'video'
      });
      AnalyticsManager.setAirbridgeTrackEvent(AnalyticsKey.NAME_ORDER_DETAIL, Platform.OS, uid);
    }
  };

  renderItem = ({ item }) => {
    const { type, name, url, barcodeId, brand, option } = item;
    const widthHeight = window.width / 3;
    return (
      <>
        <TouchableOpacity onPress={this.onPressItem(item)}>
          {type !== 'dropbox' ? (
            <Image
              source={{ uri: url }}
              style={{ width: widthHeight, height: widthHeight }}
            />
          ) : (
            <View style={{ justifyContent: 'center', alignItems: 'center' }}>
              <Image
                source={require('../../assets/image/v5/order-history/play_bg.png')}
                style={{ width: widthHeight, height: widthHeight }}
              />
              <Image
                source={require('../../assets/image/v5/order-history/play.png')}
                style={{ width: 42, height: 42, position: 'absolute' }}
              />
            </View>
          )}
        </TouchableOpacity>
      </>
    );
  };

  render() {
    const { AlbumState } = this.props;
    const { data } = AlbumState;
    if (data && data.length > 0) {
      return (
        <>
          <FlatList
            data={data}
            renderItem={this.renderItem}
            numColumns={3}
            keyExtractor={(item, index) => index.toString()}
          />
        </>
      );
    } else {
      return null;
    }
  }
}

const mapStateToProps = ({ AlbumModule }) => ({
  AlbumState: AlbumModule,
});

const mapDispatchToProps = dispatch => ({
  AlbumAction: bindActionCreators(AlbumModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(AlbumContainer);
