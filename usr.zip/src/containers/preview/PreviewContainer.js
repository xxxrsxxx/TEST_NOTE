import React, { useState, useEffect, PureComponent } from 'react';
import { Dimensions, StyleSheet, TouchableOpacity, View } from 'react-native';

import NewFirstPreview from '../../screens/initial/preview/NewFirstPreview';

import { getValueWithCallback } from '../../utils/common/index';
import * as Keys from '../../utils/type/key';

const { width, height } = Dimensions.get('window');

function PreviewContainer({ onNextState }) {
  const [step, setStep] = useState(0);
  const [isPreventPreview, setIsPreventPreview] = useState(true);
  let StepView = () => {
    return <NewFirstPreview showNextPreview={showNextPreview} />;
  };
  // state = {
  //   step: 0,
  //   isPreventPreview: true,
  // };
  useEffect(() => {
    const mount = () => {
      getValueWithCallback(Keys.IS_PREVIEW, (error, result) => {
        if (!error) {
          setIsPreventPreview(result ? true : false);
          // this.setState({
          //   isPreventPreview: result ? true : false, // default- result ? true : false, 확인 방법 false 로 변경
          // });
        }
      });
    };

    mount();
  }, []);

  const showNextPreview = async () => {
    // const { step } = this.state;
    // const { onNextState } = this.props;

    if (step === 0) {
      $_storage.set(Keys.IS_PREVIEW, 'over');
      setIsPreventPreview(true);
      onNextState();
      // this.setState({
      //   isPreventPreview: true,
      // });
      // MainScreenActions.getNewMainAPI({
      //   componentId,
      //   callPlace: 'MainScreen',
      // });
    }
  };

  // componentDidMount() {
  //   // deleteValue(Keys.IS_PREVIEW);
  //   this.getIsPreventPreviewKey();
  // }

  // getIsPreventPreviewKey = () => {
  //   getValueWithCallback(Keys.IS_PREVIEW, (error, result) => {
  //     if (!error) {
  //       this.setState({
  //         isPreventPreview: result ? true : false, // default- result ? true : false, 확인 방법 false 로 변경
  //       });
  //     }
  //   });
  // };

  useEffect(() => {
    StepView = () => {
      switch (step) {
        case 0:
          return <NewFirstPreview showNextPreview={showNextPreview} />;
          break;
        default:
          return <NewFirstPreview showNextPreview={showNextPreview} />;
          break;
      }
    };
  }, [step]);
  // const StepView = () => {
  //   switch (step) {
  //     case 0:
  //       return <NewFirstPreview showNextPreview={this.showNextPreview} />;
  //       break;
  //     default:
  //       return <NewFirstPreview showNextPreview={this.showNextPreview} />;
  //       break;
  //   }
  // };

  if (isPreventPreview) {
    return null;
  } else {
    return (
      <View style={styles.container}>
        <View style={[styles.inner]}>
          <TouchableOpacity style={{ flex: 1 }} onPress={showNextPreview}>
            <StepView />
          </TouchableOpacity>
        </View>
        <View style={styles.background} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1001,
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
  background: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#000',
    opacity: 0.75,
    zIndex: 10,
  },
  inner: {
    position: 'relative',
    flex: 1,
    width: '100%',
    zIndex: 12,
  },
});

export default PreviewContainer;
