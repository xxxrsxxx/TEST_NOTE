import React, { useContext } from 'react';
import { View, Text, StyleSheet } from 'react-native';
// module import
import * as CommonUtils from '../../../utils/common';
import { MyPageString } from '../../../utils/common/strings';
// context import
import MyPageContext from '../../../utils/context/myPage';
import { TouchableOpacityActiveOne } from '../../../components/common';
// font import
import { Font } from '../../../utils/style';
const { responseFont, washswatColor } = Font;

function MyPaymentContainer(props) {
  const { userType } = $_status.state.user;
  const context = useContext(MyPageContext);
  const myPayment = context.loadData.myPayment;

  const pressHandler = (e, item) => {
    const { screenName } = item;
    const { componentId, action, setCurrentTab } = props;
    if (!screenName) return;

    const memberShipHandler = () => {
      setCurrentTab('JoinMember');
    };

    const navOperation = props => {
      CommonUtils.navPush({
        componentId: componentId,
        name: screenName,
        passProps: { ...props },
      });
    };

    switch (screenName) {
      case 'JoinMember':
        memberShipHandler();
        break;
      default:
        navOperation();
    }
  };

  const myPaymentItem = (item, index) => {
    const comment =
      userType === 'member'
        ? MyPageString.memberUserFlag
        : MyPageString.basicUserFlag;
    return (
      <TouchableOpacityActiveOne
        key={index}
        style={{ marginTop: 18 }}
        onPress={e => pressHandler(e, item)}
      >
        <View style={[styles.layoutSpaceBetween, styles.listItem]}>
          <View>
            <Text style={styles.listTitle}>{item.listName}</Text>
          </View>
          {item.memberInfo && (
            <View style={styles.commentWrap}>
              <Text style={styles.comment}>{comment}</Text>
            </View>
          )}
        </View>
      </TouchableOpacityActiveOne>
    );
  };

  return (
    <View style={props.style}>
      <Text style={styles.title}>결제</Text>
      {$_.map(myPayment.items, (value, index) => myPaymentItem(value, index))}
    </View>
  );
}

const styles = StyleSheet.create({
  title: {
    ...responseFont(12).bold,
    color: washswatColor.black_50,
  },
  commentWrap: {
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
    borderRadius: 2,
    backgroundColor: washswatColor.blue,
  },
  comment: {
    ...responseFont(11).bold,
    color: washswatColor.white,
  },
  layoutSpaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  listTitle: {
    ...responseFont(15).regular,
  },
  listItem: { alignItems: 'center', height: 32 },
});

export default MyPaymentContainer;
