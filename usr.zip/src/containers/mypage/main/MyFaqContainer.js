import React, { useContext } from 'react';
import { View, Text, StyleSheet } from 'react-native';

// module import
import * as CommonUtils from '../../../utils/common';
// context import
import MyPageContext from '../../../utils/context/myPage';
// component import
import { TouchableOpacityActiveOne } from '../../../components/common';
// font import
import { Font } from '../../../utils/style';
const { responseFont, washswatColor } = Font;
import { ChannelIO } from 'react-native-channel-plugin';

function MyFaqContainer(props) {
  const context = useContext(MyPageContext);
  const myFaq = context.loadData.myFaq;

  const pressHandler = (e, item) => {
    const { screenName } = item;
    if (!screenName) return;

    const navOperation = () => {
      CommonUtils.navPush({
        componentId: props.componentId,
        name: screenName,
      });
    };

    switch (screenName) {
      case 'Chat':
        ChannelIO.showMessenger();
        break;
      default:
        navOperation();
    }
  };

  const myFaqItem = (item, index) => {
    return (
      <TouchableOpacityActiveOne
        key={index}
        onPress={e => pressHandler(e, item)}
        style={styles.listItem}
      >
        <Text style={styles.listTitle}>{item.listName}</Text>
      </TouchableOpacityActiveOne>
    );
  };

  return (
    <View style={props.style}>
      <Text style={styles.title}>고객센터</Text>
      {$_.map(myFaq.items, (value, index) => myFaqItem(value, index))}
    </View>
  );
}

const styles = StyleSheet.create({
  title: {
    ...responseFont(12).bold,
    color: washswatColor.black_50,
  },
  listTitle: {
    ...responseFont(15).regular,
  },
  listItem: { justifyContent: 'center', height: 32, marginTop: 18 },
});

export default MyFaqContainer;
