import React, { useContext } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

// module import
import * as CommonUtils from '../../../utils/common';
// context import
import MyPageContext from '../../../utils/context/myPage';
// component import
import { TouchableOpacityActiveOne } from '../../../components/common';
// font import
import {
  PaymentBuyBulletString,
  Favorite,
} from '../../../utils/common/strings';
import { Font } from '../../../utils/style';
import { useSelector } from 'react-redux';
const { responseFont } = Font;

function MyWashSwatContainer(props) {
  const { componentId, toggleConfirmDialog } = props;
  const { userCoin, userPoint } = useSelector(state => state.MyPageModule);
  const context = useContext(MyPageContext);
  const myWashSwat = context.loadData.myWashSwat;

  const showModal = (height, message, positiveAction, positiveText) => {
    // ( componentId , height , contentView, leftButtonText,  rightButtonText , onLeftButtonClicked , onRightButtonClicked , onClosed  )
    toggleConfirmDialog(
      componentId,
      300,
      <Text style={[{ ...responseFont(14).regular }, { textAlign: 'center' }]}>
        {' '}
        {message}{' '}
      </Text>,
      Favorite.close,
      positiveText,
      () => {
        toggleConfirmDialog();
      },
      () => {
        positiveAction();
        toggleConfirmDialog();
      },
      () => {
        toggleConfirmDialog();
      },
    );
  };

  const navHandler = (e, item) => {
    const { screenName } = item;
    if (!screenName) return;

    let target = screenName;
    if (screenName === 'BuyBulletScreen') {
      /** 이 경우는 총알이 있는지 확인 **/
      // userCoin
      if (userCoin) {
        // if (false) {
        target = 'BulletHistoryScreen';
      } else {
        let height = 300;

        let positiveAction = () => {
          CommonUtils.navPush({ componentId, name: 'BuyBulletScreen' });
        };
        showModal(
          height,
          PaymentBuyBulletString.confirm,
          positiveAction,
          PaymentBuyBulletString.confirmOK,
        );
        target = null;
      }
    }

    if (screenName === 'PointHistoryScreen' && !userPoint) {
      let positiveAction = () => {};
      showModal(300, PaymentBuyBulletString.confirmPoint, positiveAction);
      target = null;
    }

    if (target) {
      CommonUtils.navPush({
        componentId,
        name: target,
      });
    }
  };

  const myWashSwatItem = (item, index) => {
    const iconUrl = [
      require('../../../../assets/image/mypage/main/ic_coupon.png'),
      require('../../../../assets/image/mypage/main/ic_point.png'),
      require('../../../../assets/image/mypage/main/ic_prepaid.png'),
      require('../../../../assets/image/mypage/main/ic_referal.png'),
    ];
    return (
      <View key={index}>
        <TouchableOpacityActiveOne
          onPress={e => navHandler(e, item)}
          style={{
            alignItems: 'center',
            width: 56,
            height: 80,
          }}
        >
          <Image source={iconUrl[index]}></Image>
          <View>
            <Text style={styles.text}>{item.menuName}</Text>
          </View>
        </TouchableOpacityActiveOne>
      </View>
    );
  };
  return (
    <View style={[props.style, styles.layoutSpaceBetween]}>
      {$_.map(myWashSwat.items, (value, index) => myWashSwatItem(value, index))}
    </View>
  );
}

const styles = StyleSheet.create({
  layoutSpaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  textArea: {
    height: 24,
    justifyContent: 'center',
  },
  text: {
    ...responseFont(12).regular,
  },
});

export default MyWashSwatContainer;
