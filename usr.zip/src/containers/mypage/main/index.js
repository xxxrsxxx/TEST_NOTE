import MyProfileContainer from './MyProfileContainer';
import MyWashSwatContainer from './MyWashSwatContainer';
import MyPaymentContainer from './MyPaymentContainer';
import MyFaqContainer from './MyFaqContainer';

export {
  MyProfileContainer,
  MyWashSwatContainer,
  MyPaymentContainer,
  MyFaqContainer,
};
