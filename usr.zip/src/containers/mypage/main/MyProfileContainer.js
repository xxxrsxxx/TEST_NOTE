import React, { useEffect, useState } from 'react';
import { Text, View, Image, StyleSheet } from 'react-native';
// module import
import * as CommonUtils from '../../../utils/common';
// component import
import { TouchableOpacityActiveOne } from '../../../components/common';
// font import
import { SettingsString } from '../../../utils/common/strings';
import { Font } from '../../../utils/style';
const { responseFont, washswatColor } = Font;

function MyProfileContainer(props) {
  const { name, userType } = $_status.state.user;

  const [userInfo, setUserInfo] = useState({
    userName: name,
    userType,
  });

  useEffect(() => {
    setUserInfo({
      userName: name,
      userType,
    });
  }, [name, userType]);

  const onPressSetting = () => {
    CommonUtils.navPush({
      componentId: props.componentId,
      name: 'Settings',
    });
  };

  return (
    <View style={props.style}>
      <View style={styles.profileArea}>
        <Text
          style={styles.title}
        >{`${userInfo.userName}${SettingsString.sir}`}</Text>
      </View>
      <View>
        <TouchableOpacityActiveOne
          style={styles.settingArea}
          onPress={onPressSetting}
        >
          <Image
            width={16}
            height={16}
            source={require('../../../../assets/image/mypage/main/ic_vector.png')}
          />
          <Text style={styles.setting}>{SettingsString.setting}</Text>
        </TouchableOpacityActiveOne>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  profileArea: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    ...responseFont(20).bold,
  },
  settingArea: {
    width: 60,
    height: 32,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 6,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: washswatColor.f5,
  },
  setting: {
    marginLeft: 4,
    ...responseFont(12).regular,
    color: washswatColor.b19,
  },
});

export default MyProfileContainer;
