import React, { PureComponent } from 'react';

import {
  Text,
  View,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
  TouchableOpacity,
} from 'react-native';

import * as CommonUtils from '../../../utils/common';
import { PointHistoryScreenString } from '../../../utils/common/strings';
import { Font } from '../../../utils/style';

const { washswatColor, responseFont, verticalScale } = Font;

const { height } = Dimensions.get('window');

class HistoryContainer extends PureComponent {
  state = {
    isMore: false,
    currentIndex: 5,
  };

  onHandleIsMore = () => {
    const { isMore, currentIndex } = this.state;

    if (!isMore) {
      this.setState({
        isMore: true,
        currentIndex: currentIndex + 6,
      });
    }
  };

  handleInfiniteScroll = event => {
    const { historyData } = this.props;
    const { currentIndex } = this.state;
    const { contentOffset, layoutMeasurement, contentSize } = event.nativeEvent;
    if (historyData.length > currentIndex) {
      if (
        layoutMeasurement.height + contentOffset.y >=
        contentSize.height - 50
      ) {
        this.setState({
          currentIndex: currentIndex + 6,
        });
      }
    }
  };

  render() {
    const { historyData, coinHistory } = this.props;
    const { isMore, currentIndex, refreshing } = this.state;
    const setHistoryUI = historyData.filter((history, i) => i <= currentIndex);

    const pointHistoryUI = setHistoryUI.map((history, i) => (
      <View style={styles.historyList} key={i}>
        <View style={styles.leftBox}>
          <Text style={styles.title}>{history.reason}</Text>
          <Text style={styles.desc}>{history.regdate}</Text>
        </View>
        <View style={styles.rightBox}>
          <Text
            style={[
              styles.point,
              history.isPlus ? styles.plus_point : styles.minus_point,
            ]}
          >
            {!history.isPlus && '-'}
            {CommonUtils.numberWithCommas(history.point)}
            {coinHistory
              ? PointHistoryScreenString.coin_unit
              : PointHistoryScreenString.unit}
          </Text>
        </View>
      </View>
    ));

    return (
      <View style={styles.lower_container}>
        {pointHistoryUI.length > 6 && isMore ? (
          <ScrollView
            style={styles.historyBox}
            ref={ref => (this.scroll = ref)}
            showsVerticalScrollIndicator={false}
            onScrollEndDrag={this.handleInfiniteScroll}
          >
            {pointHistoryUI}
          </ScrollView>
        ) : (
          <View style={[styles.historyBox, styles.is_hidden]}>
            {historyData.length > 0 ? pointHistoryUI : <View />}
          </View>
        )}

        {!isMore && historyData.length > 6 ? (
          <View style={styles.more_button_box}>
            <TouchableOpacity
              style={styles.more_button}
              onPress={this.onHandleIsMore}
            >
              <Text style={styles.more_button_text}>
                {PointHistoryScreenString.more_text}{' '}
              </Text>
              <Image
                source={require('image/v5/down_arrow_small.png')}
                style={{ width: 10, height: 10 }}
              />
            </TouchableOpacity>
          </View>
        ) : (
          <View />
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  historyList: {
    paddingTop: verticalScale(13),
    paddingBottom: verticalScale(13),
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  leftBox: {},
  rightBox: {},
  title: {
    ...responseFont(14).regular,
  },
  desc: {
    ...responseFont(10).regular,
    color: washswatColor.grey_02,
    paddingTop: 5,
  },
  point: {
    ...responseFont(14).bold,
  },
  plus_point: {
    color: washswatColor.blue,
  },
  lower_container: {
    height: height - verticalScale(250) - 10,
  },
  minus_point: {
    color: washswatColor.black,
  },
  historyBox: {
    height: height - verticalScale(250) - 50,
    marginBottom: 150,
  },
  is_hidden: {
    overflow: 'hidden',
  },
  more_button_box: {
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  more_button: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: verticalScale(10),
    paddingHorizontal: verticalScale(10),
  },
  more_button_text: {
    ...responseFont(10).regular,
    color: washswatColor.grey_08,
  },
});

export default HistoryContainer;
