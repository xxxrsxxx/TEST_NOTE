import React, { useContext } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
// plugin module import
import { Clipboard } from '../../../plugins';
// context import
import InviteContext from '../../../utils/context/myPage/invite';
// util import
import * as Keys from '../../../utils/type/key';
import Invite from '../../../utils/modules';
import { InviteMessage } from '../../../utils/common/strings';
import AnalyticsManager from '../../../utils/tagging/analytics';
import * as AnalyticsKey from '../../../utils/tagging/analytics/key';
// component import
import { TouchableOpacityActiveOne } from '../../../components/common';
// font import
import { Font } from '../../../utils/style';
const { responseFont, washswatColor } = Font;

function IvShare(props) {
  const context = useContext(InviteContext);
  const { title, events } = context.loadData.inviteShare;
  const { myCode, name, uid } = $_status.state.user;

  const pressHandler = async obj => {
    const { type } = obj;

    const kakaoEvent = () => {
      Invite.sendKakao(name, myCode, Keys.KAKAO_INVITE_ID, (err, result) => {
        if (result && typeof result === 'string') {
          result = JSON.parse(result);
        }
        const { code } = result;
      });
    };

    const copyEvent = () => {
      let { text } = InviteMessage;
      text = text.replace(`{name}`, name);
      text = text.replace(`{myCode}`, myCode);
      Clipboard.setString(text);
      props.modal();
    };

    switch (type) {
      case 'kakao':
        kakaoEvent();
        break;
      case 'sms':
        break;
      case 'copy':
        copyEvent();
        break;
    }

    await AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_INVITE, {
      af_content_type: type,
      af_date: new Date(),
    });
    await AnalyticsManager.setAirbridgeTrackEvent(
      AnalyticsKey.NAME_INVITE,
      Platform.OS,
      uid,
    );
  };

  const codeArea = () => {
    return (
      <View style={styles.codeWrap}>
        <Text style={styles.title}>나의 초대 코드</Text>
        <Text style={styles.code}>{myCode}</Text>
      </View>
    );
  };

  const shareArea = () => {
    const items = () => {
      return $_.map(events, (value, index) => {
        return (
          <TouchableOpacityActiveOne
            style={styles.shareBtn}
            key={index}
            onPress={() => {
              pressHandler(value);
            }}
          >
            <Text style={styles.shareText}>{value.name}</Text>
          </TouchableOpacityActiveOne>
        );
      });
    };

    return <View style={styles.shareWrap}>{items()}</View>;
  };
  return (
    <View style={props.style}>
      {codeArea()}
      {shareArea()}
    </View>
  );
}

const styles = StyleSheet.create({
  codeWrap: {
    height: 82,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
    backgroundColor: '#F6F6F6',
  },
  title: { ...responseFont(12).regular },
  code: { marginTop: 16, ...responseFont(16).bold },
  shareWrap: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  shareBtn: {
    flex: 0.49,
    height: 54,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    backgroundColor: washswatColor.black,
  },
  shareText: {
    ...responseFont(14).bold,
    color: washswatColor.white,
  },
});
export default IvShare;
