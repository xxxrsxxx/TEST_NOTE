import React, { PureComponent, useContext } from 'react';
import { View, Text, StyleSheet } from 'react-native';
// component import
import InviteContext from '../../../utils/context/myPage/invite';

// font import
import { Font } from '../../../utils/style';
const { responseFont, washswatColor } = Font;

function IvInfo(props) {
  const context = useContext(InviteContext);
  const ivInfo = context.loadData.infoArea;

  return (
    <View style={props.style}>
      <Text style={styles.topTitle}>{ivInfo.title}</Text>
      <Text style={styles.topSubDsc}>{ivInfo.subDsc}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  topTitle: {
    ...responseFont(24).bold,
    color: washswatColor.black,
  },
  topSubDsc: {
    marginTop: 24,
    ...responseFont(14).regular,
    color: washswatColor.black,
  },
});
export default IvInfo;
