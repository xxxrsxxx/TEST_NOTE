import React, { useContext } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
// component import
import InviteContext from '../../../utils/context/myPage/invite';
// font import
import { Font } from '../../../utils/style';
const { responseFont, washswatColor } = Font;

function IvDscList(props) {
  const context = useContext(InviteContext);
  const ivDsc = context.loadData.inviteDscArea;
  const ivListItem = (value, index) => {
    const iconUrl = [
      require('../../../../assets/image/mypage/invite/ic_invitation.png'),
      require('../../../../assets/image/mypage/invite/ic_new.png'),
      require('../../../../assets/image/mypage/invite/ic_coupon.png'),
    ];
    const { title, subDsc } = value;

    return (
      <View style={styles.container} key={index}>
        <View style={styles.thumb}>
          <Image source={iconUrl[index]} />
        </View>
        <View style={styles.infoWrap}>
          <Text style={styles.infoTitle}>{title}</Text>
          <Text style={styles.infoSubDsc}>{subDsc}</Text>
        </View>
      </View>
    );
  };

  return (
    <View>
      {$_.map(ivDsc.items, (value, index) => ivListItem(value, index))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  thumb: {
    width: 64,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  infoWrap: {
    flex: 1,
    justifyContent: 'flex-start',
  },
  infoTitle: {
    marginBottom: 4,
    ...responseFont(14).bold,
    color: washswatColor.black,
  },
  infoSubDsc: {
    ...responseFont(12).regular,
    color: washswatColor.black,
  },
});

export default IvDscList;
