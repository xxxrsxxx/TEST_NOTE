import React from 'react';
import { View, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';

function WebViewContainer({ pendingHandler, ...props }) {
  const { option } = props;
  const handleSpinner = status => {
    pendingHandler(status);
  };

  return (
    <View style={{ flex: 1 }}>
      <View style={{ flex: 1 }}>
        <WebView
          source={{
            uri: option.url,
          }}
          javaScriptEnabled={true}
          originWhitelist={['*']}
          onLoadStart={() => handleSpinner(true)}
          onLoad={() => handleSpinner(false)}
          onError={() => {
            handleSpinner(false);
            WashAlert.showAlert(
              '서버와의 통신이 원활하지 않습니다. 다시 시도해주세요.',
              '확인',
            );
          }}
        />
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  ctaBar: {},
});

export default WebViewContainer;
