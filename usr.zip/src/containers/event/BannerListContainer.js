import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  Platform,
  TouchableOpacity,
} from 'react-native';
// modules import
import { moment, _ } from '../../plugins';
import * as CommonUtils from '../../utils/common';
//taggings import
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import AnalyticsManager from '../../utils/tagging/analytics';
// styles import
import { Font } from '../../utils/style';
import { Event } from '../../utils/common/strings';
const { responseFont, washswatColor } = Font;

let onLoadImg = 1;
function BannerListContainer({ EventScreenState, getLoadBnrApi }) {
  const [state, setState] = useState({
    bannerList: {
      page: 1,
      limit: 5,
      items: [],
    },
    pending: true,
  });
  const { bannerList } = EventScreenState;

  useEffect(() => {
    return () => {
      onLoadImg = 1; //이미지 로드 체크 전역 변수 초기화
    };
  }, []);

  const pressHandler = async (e, item, ended) => {
    const { url } = item;
    const uid = $_status.state.user.uid;
    if (ended || !url) return;
    CommonUtils.navShowModalWebView({ url });

    await AnalyticsManager.setAppsFlyerTrackEvent(
      AnalyticsKey.NAME_HOME_BANNER,
      { af_url: url },
    );
    await AnalyticsManager.setAirbridgeTrackEvent(
      AnalyticsKey.NAME_HOME_BANNER,
      Platform.OS,
      uid,
    );
  };

  const loadMore = e => {
    getLoadBnrApi();
  };

  const loadImgDebounce = () => {
    const listLength = bannerList.items.length;
    onLoadImg++;
    if (listLength === onLoadImg) $_status.actions.globalPendingHandler(false);
  };

  const listItem = e => {
    const { item, index } = e;
    const started = moment().isAfter(item.startdate);
    const ended = moment().isAfter(item.enddate);
    const required = started && item.imageUrl && item.url && item.title;
    // imageUrl null 일시 방어 로직 이미지 dummy 를 생성해야 재랜더링이 안됨.
    const source = item.imageUrl
      ? { uri: item.imageUrl }
      : require('../../../assets/image/common/transparent_dummy.png');
    if (!required) return null;

    return (
      <TouchableOpacity
        key={`event_bnr${item.idx}`}
        style={styles.bannerWrap}
        onPress={e => pressHandler(e, item, ended)}
      >
        <Image
          source={source}
          style={styles.listImage}
          onLoad={loadImgDebounce}
        />
        <View style={styles.listDscArea}>
          <Text style={styles.listTitle}>{item.title}</Text>
          <Text
            style={styles.listSubTitle}
            ellipsizeMode="tail"
            numberOfLines={1}
          >
            {item.subTitle}
          </Text>
          {ended && (
            <View style={styles.flagWrap}>
              <Text style={styles.flag}>{Event.finished}</Text>
            </View>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View>
      {bannerList.items.length > 0 && (
        <FlatList
          data={bannerList.items}
          renderItem={listItem}
          keyExtractor={(item, index) => index.toString()}
          onEndReached={loadMore}
          onEndReachedThreshold={0.01}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  bannerWrap: {
    position: 'relative',
    height: 156,
    marginTop: 16,
    marginHorizontal: 24,
    backgroundColor: '#F6F6F6',
    borderRadius: 8,
  },
  listImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    borderRadius: 8,
  },
  listDscArea: {
    position: 'absolute',
    top: 40,
    bottom: 21,
    left: 32,
    right: 16,
  },
  listTitle: {
    height: 54,
    ...responseFont(20).bold,
  },
  listSubTitle: {
    height: 16,
    color: washswatColor.black_40,
    ...responseFont(11).bold,
  },
  flagWrap: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    width: 30,
    height: 14,
    backgroundColor: washswatColor.black,
    ...responseFont(11).bold,
  },
  flag: {
    color: washswatColor.white,
  },
});

export default BannerListContainer;
