import React from 'react';

import {
  PixelRatio,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import CardRegist from '../../components/payment/CardRegist';
import SwatBullet from '../../components/payment/SwatBullet';
import RegistedCardList from '../../components/payment/RegistedCardList';
import RegistedBullet from '../../components/payment/RegistedBullet';
import { BasicHeader } from '../../components/common/layout';

import { Favorite, PaymentMethodString } from '../../utils/common/strings';
import WashAlert from '../../utils/alert';
import * as WashPayment from '../../utils/common/payment';
import * as CommonUtils from '../../utils/common';
import * as KeyUtils from '../../utils/type/key';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import AnalyticsManager from '../../utils/tagging/analytics';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

class PaymentMethod extends React.Component {
  componentDidMount() {
    this.props.MyPageAction.getCardAndCoin();
  }

  cardRegistPage = async () => {
    const _storage = await $_storage.get();
    const uid = _storage[KeyUtils.USER_ID];
    const name = _storage[KeyUtils.USER_NAME];
    const af_address = _storage[KeyUtils.USER_ADDRESS];
    const af_road_address = _storage[KeyUtils.USER_ROAD_ADDRESS];
    const af_detail_address = _storage[KeyUtils.USER_ADDRESS_OTHERS];
    const af_user_type = _storage[KeyUtils.USER_TYPE];

    const data = { callType: 'bill', uid, name };

    WashPayment.show(data, json => {
      const { code, message } = json;

      if (code === 200) {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        }
        this.props.MyPageAction.getCardAndCoin();
        AnalyticsManager.setAppsFlyerTrackEvent(
          AnalyticsKey.NAME_ADD_PAYMENT_INFO,
          {
            af_uid: uid,
            af_address,
            af_road_address,
            af_detail_address,
            af_user_type,
            af_path: 'payment_method',
            af_add_payment_method: 'card',
          },
        );
        AnalyticsManager.setAirbridgeTrackEvent(
          AnalyticsKey.NAME_ADD_PAYMENT_INFO,
          Platform.OS,
          uid,
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          /** 디폴트 메시지 **/
          WashAlert.showAlert(
            '카드등록 실패! 다시 한번 시도해주시겠어요?',
            Favorite.ok,
          );
        }
      }
    });
  };

  buyCoin = coin => {
    if (coin) {
      /** 코인구매 완료 **/
      this.props.MyPageAction.getCardAndCoin();
    } else {
      /** 코인구매 실패 **/
    }
  };

  coinCharge = () => {
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'BuyBulletScreen',
      // name: 'PaymentBuyBullet',
      // passProps: {
      //   finishedAction: this.buyCoin,
      //   pathOfPaymentMethod: 'payment_method' // 결제방법의 경로: '결제수단'
      // }
    });
  };

  onPressBack = () => {
    Navigation.pop(this.props.componentId);
  };

  deleteBillKey = billKey => {
    const { MyPageAction } = this.props;
    MyPageAction.deleteBillKey({ billKey });
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const { MyPageAction, componentId } = this.props;
    const { userCardList, userCoin, coinHistory } = this.props.MyPageState;
    const coins = (
      <RegistedBullet bullet={userCoin} componentId={componentId} />
    );
    const cardList = [];
    // const cards = userCardList.card.split(" ")
    userCardList.map((card, i) => {
      const cardsNumbers = card.card.split(' ');
      cardList.push(
        <RegistedCardList
          key={i}
          cardName={`${cardsNumbers[0]} ${cardsNumbers[1]}`}
          isDefault={card.isDefault}
          billKey={card.billKey}
          onPress={this.deleteBillKey}
          setDefault={MyPageAction.setDefault}
        />,
      );
    });
    const divideLine = (userCoin > 0 || cardList.length > 0) && (
      <View style={styles.divideLine} />
    );

    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.white }}>
        <View style={{ height: getStatusBarHeight(true) }} />
        <BasicHeader componentId={this.props.componentId} />
        <ScrollView>
          <Text style={[responseFont(27).bold, styles.titleText]}>
            {PaymentMethodString.paymentMethod}
          </Text>
          {/* <View style={styles.divideLine} /> */}
          {divideLine}
          {coins}
          {cardList}
          <View style={{ padding: PixelRatio.roundToNearestPixel(40) }} />
          <CardRegist moveToPage={this.cardRegistPage} />
          <View
            style={{
              height: PixelRatio.roundToNearestPixel(0.5),
              backgroundColor: washswatColor.grey_03,
              marginLeft: PixelRatio.roundToNearestPixel(30),
            }}
          />
          <SwatBullet onPress={this.coinCharge} />
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  titleText: {
    color: washswatColor.black,
    marginStart: PixelRatio.roundToNearestPixel(30),
    marginTop:
      Platform.OS === 'android'
        ? PixelRatio.roundToNearestPixel(110)
        : PixelRatio.roundToNearestPixel(80),
    marginEnd: PixelRatio.roundToNearestPixel(30),
  },
  divideLine: {
    height: PixelRatio.roundToNearestPixel(2),
    backgroundColor: washswatColor.black,
    marginStart: PixelRatio.roundToNearestPixel(30),
    marginTop: PixelRatio.roundToNearestPixel(60),
  },
});

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(PaymentMethod);
