import React from 'react';

import { Platform, StatusBar, StyleSheet, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { Navigation } from 'react-native-navigation';

import CloseButton from '../../components/common/button/CloseButton';
import LoadingBar from '../../components/common/button/LoadingBar';

import * as CommonUtils from '../../utils/common';
import * as ServerUtils from '../../utils/type/server';
import WashAlert from '../../utils/alert';
import { Favorite } from '../../utils/common/strings';
import { Font, Styles } from '../../utils/style';

const { washswatColor, responseFont } = Font;
const { androidStatusBar } = Styles;

export default class Account extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      url: null,
    };
    Navigation.events().bindComponent(this);
  }
  async componentDidMount() {
    const { orderId, finalPrice, usePoint, usedCouponList } = this.props;
    const _url = `${ServerUtils.PAY_ACTION}generate`;
    await $_axios
      .post(_url, {}, { orderId, finalPrice, usePoint, usedCouponList })
      .then(response => {
        const { code, url } = response.data;
        if (code == 200) {
          this.setState({ url });
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      })
      .catch(err => {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      });
  }

  onPressBack = () => {
    Navigation.dismissModal(this.props.componentId);
  };

  showSpinner = () => {};
  hideSpinner = () => {
    this.setState({ isLoading: false });
  };
  navigationButtonPressed({ buttonId }) {
    if (buttonId === 'cancelBtn') {
      Navigation.dismissModal(this.props.componentId);
    }
  }
  render() {
    const { isLoading, url } = this.state;
    return (
      <View style={{ flex: 1 }}>
        <StatusBar
          barStyle={
            Platform.OS === 'android' ? 'dark-content' : 'light-content'
          }
        />
        {isLoading ? <LoadingBar /> : null}
        {url ? (
          <WebView
            source={{ uri: url }}
            javaScriptEnabled={true}
            domStorageEnabled={true}
            onLoadStart={() => this.showSpinner()}
            onLoad={() => this.hideSpinner()}
          />
        ) : (
          <View
            style={{
              flex: 1,
              width: '100%',
              height: '100%',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Text
              style={{ ...responseFont(27).bold, color: washswatColor.black }}
            >
              잠시만요!
            </Text>
          </View>
        )}
        <View
          style={{
            position: 'absolute',
            marginTop: Platform.OS === 'android' ? -androidStatusBar : 0,
          }}
        >
          <CloseButton onPress={this.onPressBack} />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({});
