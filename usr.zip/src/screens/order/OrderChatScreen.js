import React, { Component } from 'react';

import {
  StyleSheet,
  Keyboard,
  View,
  Platform,
  Dimensions,
  BackHandler,
  Text,
} from 'react-native';
import { Navigation } from 'react-native-navigation';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderChatModule from '../../reducers/OrderChatModule';

import LoadingBar from '../../components/common/button/LoadingBar';
import OrderChatContainer from '../../containers/order/OrderChatContainer';
import OrderChatHeaderContainer from '../../containers/order/OrderChatHeaderContainer';

import BottomModalComponent from '../../components/common/modal/BottomModalComponent';

import { OrderChatBackPressPopupString } from '../../utils/common/strings';
import { Font, Styles } from '../../utils/style';

const { responseFont } = Font;
const { androidStatusBar } = Styles;

const { height } = Dimensions.get('window');

class OrderChatScreen extends Component {
  static options(passProps) {
    return {
      gestures: {},
    };
  }

  constructor(props) {
    super(props);
    Navigation.events().bindComponent(this);
  }

  componentDidAppear = () => {
    if (Platform.OS === 'android') {
      BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
    }
  };

  componentDidDisappear() {
    if (Platform.OS === 'android') {
      const { backPressToggle } = this.props.OrderChatAction;
      backPressToggle(false);
      BackHandler.removeEventListener(
        'hardwareBackPress',
        this.handleBackButton,
      );
    }
  }

  handleBackButton = () => {
    const { backPressPopupOpen } = this.props.OrderChatState;
    const { backPressToggle } = this.props.OrderChatAction;
    Keyboard.dismiss();
    if (backPressPopupOpen) {
      backPressToggle(false);
    } else {
      backPressToggle(true);
    }
    return true;
  };

  render() {
    const {
      OrderChatState,
      OrderChatAction,
      componentId,
      callbackOrderHistoryEmpty,
    } = this.props;
    const { backPressToggle } = OrderChatAction;
    const { backPressPopupOpen, isPending } = OrderChatState;

    return (
      <View style={styles.container}>
        {isPending ? <LoadingBar /> : null}
        <OrderChatContainer
          componentId={componentId}
          callbackOrderHistoryEmpty={callbackOrderHistoryEmpty}
        />
        <OrderChatHeaderContainer componentId={componentId} />

        <BottomModalComponent
          isOpen={backPressPopupOpen}
          contentView={
            <Text
              style={[
                { ...responseFont(16).regular },
                { textAlign: 'center', lineHeight: 19 },
              ]}
            >
              {OrderChatBackPressPopupString.title}
            </Text>
          }
          height={300}
          onClosed={() => backPressToggle(false)}
          rightButtonText={OrderChatBackPressPopupString.keepGoing}
          onRightButtonClicked={() => {
            backPressToggle(false);
          }}
          leftButtonText={OrderChatBackPressPopupString.cancel}
          onLeftButtonClicked={() => {
            backPressToggle(false);
            Navigation.pop(this.props.componentId);
          }}
        />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    ...Platform.select({
      android: {
        marginTop: -androidStatusBar,
        height: height + androidStatusBar,
      },
    }),
  },
});

const mapStateToProps = ({ OrderChatModule }) => ({
  OrderChatState: OrderChatModule,
});

const mapDispatchToProps = dispatch => ({
  OrderChatAction: bindActionCreators(OrderChatModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderChatScreen);
