import React, { useEffect, useState } from 'react';

import {
  Dimensions,
  Image,
  Platform,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import ImageZoom from 'react-native-image-pan-zoom';
import Swiper from 'react-native-swiper';

import { BasicHeader } from '../../../components/common/layout';

import { AlbumText, Favorite } from '../../../utils/common/strings';
import * as CommonUtils from '../../../utils/common';
import { Font } from '../../../utils/style';

const { washswatColor, responseFont } = Font;

const window = Dimensions.get('window');

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  wrapper: {
    backgroundColor: washswatColor.transparent,
  },
  image: {
    width: '100%',
    height: (window.width / 4) * 3,
    backgroundColor: washswatColor.transparent,
    transform: [{ rotate: '180deg' }],
  },
  bottom: {
    width: '100%',
    paddingLeft: 24,
    paddingTop: 18,
    marginBottom: 50,
    backgroundColor: washswatColor.transparent,
    position: 'absolute',
    bottom: 0,
    justifyContent: 'flex-end',
  },
});

const AlbumSwiperScreen = props => {
  const { albumItem, componentId } = props;
  const [pageIndex, setPageIndex] = useState(0);
  const [imageZooms, setImageZooms] = useState([]);

  const getItem = item => {
    const data = [];
    if (item) {
      const {
        info: infoArray,
        name,
        price,
        barcodeId,
        brand,
        option,
        emoji,
      } = item;
      if (infoArray && infoArray.length > 0) {
        const careArray = [];
        infoArray.map(infoObject => {
          const { type, title } = infoObject;
          if (type !== 'view' && title && infoObject.price !== undefined) {
            careArray.push({ title, price: infoObject.price });
          }
        });
        infoArray.map(infoObject => {
          const { type, image } = infoObject;
          if (type === 'view' && image && image.length > 0) {
            image.map(url => {
              data.push({
                type,
                name,
                price,
                url,
                barcodeId: barcodeId[0],
                brand,
                option,
                careArray,
              });
            });
          }
        });
      }
    }
    return data;
  };

  const dataArray = getItem(albumItem);

  useEffect(() => {
    const imageZooms =
      dataArray &&
      dataArray.map((data, index) => {
        const {
          type,
          name,
          price,
          url,
          barcodeId,
          brand,
          option,
          careArray,
          emoji,
        } = data;
        return (
          <View key={`imageZoom-${index}`} style={{ flex: 1 }}>
            <ImageZoom
              cropWidth={window.width}
              cropHeight={(window.height / 4) * 3}
              imageWidth={window.width}
              imageHeight={(window.width / 4) * 3}
            >
              <Image
                source={{ uri: url }}
                style={styles.image}
                resizeMode={'contain'}
              />
            </ImageZoom>
            <View style={styles.bottom}>
              <Text
                style={{
                  ...responseFont(14).bold,
                  color: washswatColor.black,
                }}
              >{`[${barcodeId}] ${name}`}</Text>
              <Text
                style={{
                  ...responseFont(14).regular,
                  color: washswatColor.grey_13,
                  marginTop: 8,
                }}
              >
                {`${AlbumText.basicFee}: ${CommonUtils.numberWithCommas(
                  price,
                )}${Favorite.won}`}
              </Text>
              {careArray
                ? careArray.map((care, index) => {
                    const { title, price } = care;
                    return (
                      <View key={`careArray-${index}`}>
                        {price !== undefined ? (
                          <Text
                            style={{
                              ...responseFont(14).regular,
                              color: washswatColor.grey_13,
                              marginTop: 8,
                            }}
                          >
                            {`${
                              AlbumText.addFee
                            }: ${title}(+${CommonUtils.numberWithCommas(
                              price,
                            )}${Favorite.won})`}
                          </Text>
                        ) : null}
                      </View>
                    );
                  })
                : null}
            </View>
          </View>
        );
      });
    setImageZooms(imageZooms);
  }, []);

  const onPressBack = () => {
    Navigation.pop(componentId);
  };

  const onIndexChanged = index => {
    setPageIndex(index);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: washswatColor.white }}>
      {Platform.OS === 'ios' ? (
        <BasicHeader componentId={componentId} />
      ) : (
        <BasicHeader
          componentId={componentId}
          customStyle={{ marginTop: -2 }}
        />
      )}
      <View
        style={{ height: 69, justifyContent: 'center', alignItems: 'center' }}
      >
        <Text
          style={{
            ...responseFont(16).bold,
            color: washswatColor.black,
            position: 'absolute',
          }}
        >
          {`${pageIndex + 1} / ${dataArray.length}`}
        </Text>
      </View>
      <Swiper
        style={styles.wrapper}
        showsPagination={false}
        index={0}
        onIndexChanged={onIndexChanged}
      >
        {imageZooms}
      </Swiper>
    </SafeAreaView>
  );
};

export default AlbumSwiperScreen;
