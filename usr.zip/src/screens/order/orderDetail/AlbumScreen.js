import React, { Component } from 'react';
import { SafeAreaView, View } from 'react-native';
import { Navigation } from 'react-native-navigation';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as AlbumModule from '../../../reducers/AlbumModule';

import AlbumDetailContainer from '../../../containers/order/detail/AlbumDetailContainer';
import { BasicHeader } from '../../../components/common/layout';

import { Font } from '../../../utils/style';

const { washswatColor } = Font;

class AlbumScreen extends Component {
  onPressBack = () => {
    const { AlbumState, AlbumAction } = this.props;
    const { selectedItem } = AlbumState;
    if (selectedItem) {
      AlbumAction.setSelectedItem(null);
    }
    Navigation.pop(this.props.componentId);
  };

  componentDidMount() {
    const { orderItem, AlbumAction, url } = this.props;
    AlbumAction.init(orderItem);

    if (orderItem) {
      AlbumAction.setData(orderItem, url);
    }
  }

  render() {
    const { AlbumState } = this.props;
    const { selectedItem } = AlbumState;

    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: washswatColor.white }}>
        <View style={{ position: 'absolute', zIndex: 1, elevation: 1 }}>
          <BasicHeader onPress={this.onPressBack} />
        </View>
        {selectedItem ? <AlbumDetailContainer /> : null}
      </SafeAreaView>
    );
  }
}

const mapStateToProps = ({ AlbumModule }) => ({
  AlbumState: AlbumModule,
});

const mapDispatchToProps = (dispatch) => ({
  AlbumAction: bindActionCreators(AlbumModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(AlbumScreen);
