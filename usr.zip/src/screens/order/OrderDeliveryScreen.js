import React from 'react';

import {
  BackHandler,
  Dimensions,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as StartOrderModule from '../../reducers/StartOrderModule';

import CloseButton from '../../components/common/button/CloseButton';
import OrderCenterModal from '../../components/order/OrderCenterModal';
import OrderBottomModal from '../../components/order/OrderBottomModal';
import LoadingBar from '../../components/common/button/LoadingBar';
import OrderTitle from '../../components/order/OrderTitle';
import OrderDateTime from '../../components/order/OrderDateTime';

import { StartOrderDelivery } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import { Font, Styles } from '../../utils/style';

import { _ } from '../../plugins';

const { washswatColor } = Font;
const { androidStatusBar } = Styles;

class OrderDeliveryScreen extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      getDeliveryIndex: null,
    };
  }

  componentDidMount() {
    // if (this.props.mainDataDeliveryTime) {
    //   this.setUpdateDateTime();
    // }
    this._setDeliveryDateTime();
    if (Platform.OS === 'android') {
      BackHandler.addEventListener(
        'hardwareBackPress',
        this._onPressHardwareBack,
      );
    }
  }

  setUpdateDateTime = () => {
    const { mainDataDeliveryTime, deliveryArray } = this.props;
    let indexResult = 0;
    const sliceDeliveryDate = mainDataDeliveryTime.split('T')[0];
    const index = _.findIndex(deliveryArray, date => {
      return date.day === sliceDeliveryDate;
    });
    indexResult = index > -1 ? index : 0;

    this.setState({
      getDeliveryIndex: indexResult,
    });
  };
  _setDeliveryDateTime = () => {
    const {
      OrderAction,
      pickupTime,
      timeSelectCallback,
      componentId,
      orderId,
      midnight,
      isUpdate,
      orderItem,
    } = this.props;
    OrderAction.setDeliveryDateTimeAPI({
      pickup: pickupTime,
      timeSelectCallback,
      componentId,
      orderId,
      midnight,
    });
  };

  componentWillUnmount() {
    if (Platform.OS === 'android') {
      BackHandler.removeEventListener(
        'hardwareBackPress',
        this._onPressHardwareBack,
      );
    }
  }

  _onPressBack = () => {
    Navigation.dismissModal(this.props.componentId);
  };

  _onPressHardwareBack = () => {
    const { deliveryIsOpenCenterModal, deliveryIsOpenBottomModal } = this.props;
    if (deliveryIsOpenCenterModal) {
      this._onPressCenterModalCancel();
      return true;
    }
    if (deliveryIsOpenBottomModal) {
      this._onPressBottomModalClose();
      return true;
    }
    Navigation.dismissModal(this.props.componentId);
    return true;
  };

  _onPressNext = () => {
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'OrderConfirmScreen',
    });
    this._onPressBottomModalClose();
  };

  _onPressBottomModalOpen = t => {
    const { OrderAction, pickup, delivery } = this.props;
    const isDisabled = OrderAction.isDisabledServiceItem();
    if (isDisabled) {
      OrderAction.setDeliveryIsOpenBottomModal(true);
    } else {
      this._onPressNext();
    }
  };

  _onPressBottomModalClose = () => {
    const { OrderAction } = this.props;
    OrderAction.setDeliveryIsOpenBottomModal(false);
  };

  _onClosedBottomModal = () => {
    this._onPressBottomModalClose();
  };

  _onPressCenterModalOpen = () => {
    const { OrderAction } = this.props;

    OrderAction.setDeliveryIsOpenCenterModal(true);
  };

  _onPressCenterModalOk = () => {
    const { OrderAction } = this.props;
    OrderAction.setDeliveryIsOpenCenterModal(false);
    OrderAction.setIsExpress(true);
  };

  _onPressCenterModalCancel = () => {
    const { OrderAction } = this.props;
    OrderAction.setDeliveryDateIndex(1);
    OrderAction.setDeliveryIsOpenCenterModal(false);
  };

  _setDateIndex = index => {
    const { OrderAction } = this.props;
    OrderAction.setDeliveryDateIndex(index);
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const {
      OrderAction,
      userType,
      isPending,
      deliveryArray,
      deliveryModal,
      deliveryDateIndex,
      deliveryIsOpenCenterModal,
      deliveryIsOpenBottomModal,
      isExpress,
      delivery,
      pickup,
      orderItem,
      isUpdate,
    } = this.props;

    const { dayOfWeek, startEndTime } = deliveryModal;
    const { width } = Dimensions.get('window');
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: washswatColor.white,
          marginTop: Platform.OS === 'android' ? -androidStatusBar : 0,
        }}
      >
        <StatusBar
          barStyle={
            Platform.OS === 'android' ? 'dark-content' : 'light-content'
          }
        />
        {isPending ? <LoadingBar /> : null}
        <ScrollView>
          <View style={{ paddingTop: 50 }} />
          <OrderTitle stage={''} title={StartOrderDelivery.title} />
          <OrderDateTime
            page={'delivery'}
            data={deliveryArray}
            width={width}
            dateIndex={deliveryDateIndex}
            setDateIndex={this._setDateIndex}
            onPressCenterModalOpen={this._onPressCenterModalOpen}
            onPressBottomModalOpen={this._onPressBottomModalOpen}
            action={OrderAction}
            userType={userType}
          />
        </ScrollView>

        {isExpress ? (
          <OrderBottomModal
            isOpen={deliveryIsOpenBottomModal}
            source={require('image/start/shirts_24h.png')}
            content={StartOrderDelivery.modalExpressContent}
            dayOfWeek={dayOfWeek}
            startEndTime={startEndTime}
            onPressButton={this._onPressNext}
            onClosed={this._onClosedBottomModal}
          />
        ) : (
          <OrderBottomModal
            isOpen={deliveryIsOpenBottomModal}
            source={require('image/start/repair_48h.png')}
            content={StartOrderDelivery.modalContent}
            dayOfWeek={dayOfWeek}
            startEndTime={startEndTime}
            onPressButton={this._onPressNext}
            onClosed={this._onClosedBottomModal}
          />
        )}
        <OrderCenterModal
          isOpen={deliveryIsOpenCenterModal}
          onPressOk={this._onPressCenterModalOk}
          onPressCancel={this._onPressCenterModalCancel}
        />
        <CloseButton onPress={this._onPressBack} />
      </View>
    );
  }
}

const styles = StyleSheet.create({});

export default connect(
  state => ({
    isPending: state.StartOrderModule.isPending,
    userType: state.StartOrderModule.userType,
    deliveryArray: state.StartOrderModule.deliveryArray,
    deliveryModal: state.StartOrderModule.deliveryModal,
    deliveryDateIndex: state.StartOrderModule.deliveryDateIndex,
    deliveryIsOpenCenterModal: state.StartOrderModule.deliveryIsOpenCenterModal,
    deliveryIsOpenBottomModal: state.StartOrderModule.deliveryIsOpenBottomModal,
    isExpress: state.StartOrderModule.isExpress,
    pickup: state.StartOrderModule.pickup,
    delivery: state.StartOrderModule.delivery,
    orderItem: state.OrderHistoryModule.orderItem,
  }),
  dispatch => ({ OrderAction: bindActionCreators(StartOrderModule, dispatch) }),
)(OrderDeliveryScreen);
