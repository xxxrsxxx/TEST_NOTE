import React, { PureComponent } from 'react';

import {
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as orderHistoryActions from '../../reducers/OrderHistoryModule';

import OrderHistoryProgressContainer from '../../containers/order/OrderHistoryProgressContainer';
import OrderHistoryLastContainer from '../../containers/order/OrderHistoryLastContainer';
import OrderHistoryEmptyContainer from '../../containers/order/OrderHistoryEmptyContainer';

import LoadingBar from '../../components/common/button/LoadingBar';
import OrderHistoryToast from '../../components/order-history/OrderHistoryToast';

import {
  OrderHistoryProgressText,
  OrderHistoryText,
} from '../../utils/common/strings';
import * as KeyUtils from '../../utils/type/key';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  tab: {
    flex: 1,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: washswatColor.grey_12,
  },
  selectedTab: {
    flex: 1,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: washswatColor.black,
  },
  tabText: {
    ...responseFont(16).regular,
    color: washswatColor.grey_14,
  },
  selectedTabText: {
    ...responseFont(16).bold,
    color: washswatColor.black,
  },
});

/**
 * @category Screen
 * @component
 * @description ### 좌측 상단 햄버거 메뉴 -> 주문목록 클릭 후 진입하는 Screen
 * @see https://www.notion.so/washswat/OrderHistoryScreen-c9543a52d045442980d1ed7cf9d3ad4a
 * @hideconstructor
 */
class OrderHistoryScreen extends PureComponent {
  constructor(props) {
    super(props);

    this.navigationEventListener = Navigation.events().bindComponent(this);
  }
  onPressProgress = () => {
    const { OrderHistoryAction } = this.props;
    OrderHistoryAction.setTab(KeyUtils.PROGRESS);
  };

  onPressLast = () => {
    const { OrderHistoryAction } = this.props;
    OrderHistoryAction.setTab(KeyUtils.LAST);
  };
  componentDidDisappear() {
    console.log('OrderHistoryScreen - Apper');
  }

  componentDidMount = async () => {
    const { OrderHistoryAction, callbackUsingGlobalPending } = this.props;
    OrderHistoryAction.setTab(KeyUtils.PROGRESS);
    await callbackUsingGlobalPending(OrderHistoryAction.getOrderHistory);
  };

  componentWillUnmount() {
    if (this.navigationEventListener) {
      this.navigationEventListener.remove();
    }
  }

  render() {
    const { OrderHistoryState, componentId, OrderHistoryAction } = this.props;
    const {
      orderItemList,
      lastOrders,
      isPending,
      tab,
      toastDeliveryFail,
    } = OrderHistoryState;

    const { setToastOn } = OrderHistoryAction;
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: washswatColor.white }}>
        {/* {isPending ? <LoadingBar /> : null} */}
        <View style={{ flexDirection: 'row' }}>
          <TouchableOpacity
            onPress={this.onPressProgress}
            style={
              tab === KeyUtils.PROGRESS ? [styles.selectedTab] : [styles.tab]
            }
          >
            <Text
              style={
                tab === KeyUtils.PROGRESS
                  ? styles.selectedTabText
                  : styles.tabText
              }
            >
              {OrderHistoryText.progressOrder}
            </Text>
            <View />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={this.onPressLast}
            style={tab === KeyUtils.LAST ? styles.selectedTab : styles.tab}
          >
            <Text
              style={
                tab === KeyUtils.LAST ? styles.selectedTabText : styles.tabText
              }
            >
              {OrderHistoryText.lastOrder}
            </Text>
          </TouchableOpacity>
        </View>
        <View style={{ flexGrow: 1 }}>
          {tab === KeyUtils.PROGRESS ? (
            <View style={{ flex: 1 }}>
              {orderItemList && orderItemList.length > 0 ? (
                <View>
                  <OrderHistoryProgressContainer componentId={componentId} />
                  {toastDeliveryFail ? (
                    <OrderHistoryToast
                      content={OrderHistoryProgressText.paymentFail}
                      userType={'normal'}
                      onToastToggle={() => setToastOn(false)}
                    />
                  ) : null}
                </View>
              ) : (
                <OrderHistoryEmptyContainer componentId={componentId} />
              )}
            </View>
          ) : null}
          {tab === KeyUtils.LAST ? (
            <View style={{ flex: 1 }}>
              {lastOrders && lastOrders.length > 0 ? (
                <OrderHistoryLastContainer componentId={componentId} />
              ) : (
                <OrderHistoryEmptyContainer componentId={componentId} />
              )}
            </View>
          ) : null}
        </View>
      </SafeAreaView>
    );
  }
}

const mapStateToProps = ({ OrderHistoryModule }) => ({
  OrderHistoryState: OrderHistoryModule,
});

const mapDispatchToProps = dispatch => ({
  OrderHistoryAction: bindActionCreators(orderHistoryActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderHistoryScreen);
