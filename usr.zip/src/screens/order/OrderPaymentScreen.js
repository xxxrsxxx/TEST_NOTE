import React from 'react';

import { PixelRatio, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as StartOrderModule from '../../reducers/StartOrderModule';
import * as MyPageModule from '../../reducers/MyPageModule';
import * as PaymentModule from '../../reducers/PaymentModule';

import OrderPaymentSelect from '../../components/order/OrderPaymentSelect';
import NBImageButton from '../../components/common/button/NBImageButton';
import OrderTitle from '../../components/order/OrderTitle';
import OrderCardListModal from '../../components/order/OrderCardListModal';

import {
  Favorite,
  StartOrderPayment,
  StartOrderShared,
} from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

class OrderPaymentScreen extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    // const { preOptions } = this.props;
    // const { payment } = preOptions;
    // const { payType } = payment;
    // if (!_.isEmpty(payType)) {
    //   this._onPressSelect(payType);
    // }
    // const { assets } = this.props;
    // const { billArray } = assets;
    // if (billArray.length === 1) {
    //   this._setDefaultCardAPI(billArray[0].billKey);
    // }
    const { OrderAction } = this.props;
    OrderAction.setAssetsAPI();
  }

  _onPressBack = () => {
    Navigation.pop(this.props.componentId);
  };

  _onPressSelect = (payType, info) => {
    const { OrderAction, PaymentAction, orderId } = this.props;
    PaymentAction.updatePaymentMethodAPI({ orderId, payType });
    OrderAction.setPayType(payType);
    OrderAction.setPaymentMethod(info);
    this._onPressBack();
  };

  _getPayViews = () => {
    let payViews = [];
    const { OrderAction, isExpress, assets } = this.props;
    const { coinObject, billArray } = assets;
    // 총알
    let coinTitle = StartOrderPayment.bulletCharge;
    let coinInfo = StartOrderPayment.bulletChargeExplain;
    let coin = 0;
    if (coinObject) {
      coin = coinObject.coin;
    }
    if (coin > 0) {
      coinTitle = StartOrderPayment.bullet;
      coinInfo = `${StartOrderPayment.balance} ${CommonUtils.numberWithCommas(
        coin,
      )}${Favorite.won}`;
    }
    payViews.push(
      <View key={'coin'}>
        <View style={styles.boundaryLine} />
        <OrderPaymentSelect
          title={coinTitle}
          percent={StartOrderPayment.bulletPercent}
          info={coinInfo}
          onPress={() => {
            coin >= 14900
              ? this._onPressSelect('coin', coinInfo)
              : this._onPressBullet();
          }}
          chargeAndChangeText={coin > 0 && StartOrderShared.charge}
          onPressChargeAndChange={this._onPressBullet}
        />
      </View>,
    );
    // 카드
    let cardTitle = StartOrderPayment.simplePayment;
    let cardInfo = StartOrderPayment.simplePaymentExplain;
    if (billArray.length > 0) {
      billArray.map((item, index) => {
        const { card, isDefault } = item;
        if (isDefault === 0) {
          return;
        }
        const cardSplits = card.split(' ');
        cardTitle = `${cardSplits[0]}${StartOrderPayment.card} ${cardSplits[1]}`;
        cardInfo = StartOrderPayment.cardExplain;
      });
    }
    payViews.push(
      <View key={'bill'}>
        <View style={styles.boundaryLine} />
        <OrderPaymentSelect
          title={cardTitle}
          info={cardInfo}
          onPress={() => {
            billArray.length > 0
              ? this._onPressSelect('bill', cardTitle)
              : this._onPressCardListModalOpen();
          }}
          chargeAndChangeText={billArray.length > 0 && StartOrderShared.change}
          onPressChargeAndChange={this._onPressCardListModalOpen}
        />
      </View>,
    );
    // 계좌이체
    // const accountTransfer = StartOrderPayment.accountTransfer;
    // const accountTransferSub = StartOrderPayment.accountTransferSub;
    // payViews.push(
    //   <View key={'account'}>
    //     <View style={styles.boundaryLine} />
    //     <OrderPaymentSelect
    //       title={accountTransfer}
    //       info={accountTransferSub}
    //       onPress={() => this._onPressSelect('later', accountTransfer)}
    //       isExpress={isExpress}
    //     />
    //   </View>
    // );
    // 1회성 결제
    // const singleCardPayment = StartOrderPayment.singleCardPayment;
    // const singleCardPaymentSub = StartOrderPayment.singleCardPaymentSub;
    // payViews.push(
    //   <View key={'singleCard'}>
    //     <View style={styles.boundaryLine} />
    //     <OrderPaymentSelect
    //       title={singleCardPayment}
    //       info={singleCardPaymentSub}
    //       onPress={() => this._onPressSelect('later', singleCardPayment)}
    //       isExpress={isExpress}
    //     />
    //     <View style={styles.boundaryLine} />
    //   </View>
    // );
    return payViews;
  };

  // 총알 충전하기
  _onPressBullet = () => {
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'BuyBulletScreen',
      passProps: {
        finishedAction: this._setCoin,
        pathOfPaymentMethod: 'order', // 결제방법의 경로: '주문하기'
      },
    });
  };

  _setCoin = addedCoin => {
    const { OrderAction, assets } = this.props;
    const { coinObject } = assets;
    const balance = coinObject.coin;
    const coin = balance + addedCoin;
    OrderAction.setCoin(coin);
  };

  _onPressCardListModalOpen = () => {
    const { OrderAction } = this.props;
    OrderAction.setIsOpenCardListModal(true);
  };

  _setDefaultCardAPI = billKey => {
    const { MyPageAction, OrderAction } = this.props;
    MyPageAction.setDefaultCardAPI({ billKey }, code => {
      if (code === 200) {
        OrderAction.setAssetsAPI();
      }
    });
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const { assets } = this.props;
    const { billArray } = assets;
    // if (billArray.length === 1) {
    //   this._setDefaultCardAPI(billArray[0].billKey);
    // }
    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.white }}>
        {/* {isPending ? <LoadingBar /> : null} */}
        <View style={{ height: getStatusBarHeight(true) }} />
        <NBImageButton
          onPress={this._onPressBack}
          source={require('image/common/back_button_black.png')}
        />
        <ScrollView>
          <OrderTitle title={StartOrderPayment.title} />
          {/* 사용 가능한 결제수단 */}
          <View>{this._getPayViews()}</View>
          {/* notice */}
          <View style={styles.notice}>
            <Text
              style={[responseFont(16).bold, { color: washswatColor.black }]}
            >
              {StartOrderPayment.notice}
            </Text>
            <Text
              style={[
                responseFont(15).regular,
                {
                  color: washswatColor.black,
                  lineHeight: PixelRatio.roundToNearestPixel(24),
                  marginTop: PixelRatio.roundToNearestPixel(24),
                },
              ]}
            >
              {StartOrderPayment.noticeContent}
            </Text>
          </View>
        </ScrollView>
        <OrderCardListModal />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  boundaryLine: {
    height: PixelRatio.roundToNearestPixel(1),
    backgroundColor: washswatColor.grey_05,
    marginStart: PixelRatio.roundToNearestPixel(30),
    marginEnd: PixelRatio.roundToNearestPixel(30),
  },
  boundaryLineBold: {
    height: PixelRatio.roundToNearestPixel(2),
    backgroundColor: washswatColor.black,
    marginLeft: PixelRatio.roundToNearestPixel(30),
  },
  notice: {
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(60),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(72),
  },
});

export default connect(
  state => ({
    isExpress: state.StartOrderModule.isExpress,
    preOptions: state.StartOrderModule.preOptions,
    assets: state.StartOrderModule.assets,
  }),
  dispatch => ({
    OrderAction: bindActionCreators(StartOrderModule, dispatch),
    MyPageAction: bindActionCreators(MyPageModule, dispatch),
    PaymentAction: bindActionCreators(PaymentModule, dispatch),
  }),
)(OrderPaymentScreen);
