import React, { Component } from 'react';

import {
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';
import * as OrderModule from '../../reducers/OrderModule';

import WashScheduleAfterOrder from '../../containers/order/WashPlanAfterOrder';
import OrderInfoContainer from '../../containers/order/OrderInfoContainer';
import PaymentRegistrationContainer from '../../containers/order/PaymentRegistrationContainer';
import DoorCodeContainer from '../../containers/order/DoorCodeContainer';

import { BorderRadiusButton } from '../../components/common/button/BorderRadiusButton';
import { XButton } from '../../components/common/button/XButton';
import LoadingBar from '../../components/common/button/LoadingBar';

import { Favorite, OrderCompleteText } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  root: {
    backgroundColor: washswatColor.grey_07,
    flex: 1,
  },
  xButton: {
    position: 'absolute',
    right: 0,
    marginTop: 48,
    marginRight: 18,
  },
});

class OrderCompleteScreen extends Component {
  constructor(props) {
    super(props);
    Navigation.events().bindComponent(this);
  }

  componentDidAppear() {
    const {
      orderId,
      OrderHistoryAction: { getOrderDetail },
    } = this.props;
    getOrderDetail(orderId);
  }

  render() {
    const {
      OrderAction,
      componentId,
      OrderHistoryAction,
      OrderHistoryState,
      orderId,
      OrderState,
    } = this.props;
    const { orderItem } = OrderHistoryState;
    const _id = orderItem ? orderItem._id : null;
    const preOptions =
      orderItem && orderItem.preOptions ? orderItem.preOptions : null;
    const { isPending } = OrderState;
    return (
      <View style={styles.root}>
        <StatusBar
          barStyle={
            Platform.OS === 'android' ? 'dark-content' : 'light-content'
          }
        />
        {isPending ? <LoadingBar /> : null}
        <ScrollView>
          <View>
            <View style={{ marginLeft: 40, marginTop: 71 }}>
              <Text style={{ ...responseFont(60).bold }}>
                {OrderCompleteText.emoji}
              </Text>
              <Text
                style={{ ...responseFont(24).bold, color: washswatColor.black }}
              >
                {OrderCompleteText.title}
              </Text>
            </View>
            {orderItem && orderItem.orderId ? (
              <View
                style={{
                  paddingLeft: 24,
                  paddingRight: 24,
                  paddingTop: 0,
                  paddingBottom: 65,
                }}
              >
                <View style={{ marginTop: 28 }}>
                  <WashScheduleAfterOrder />
                </View>
                <View style={{ marginTop: 12 }}>
                  <OrderInfoContainer screen={'OrderCompleteScreen'} />
                </View>
                {preOptions &&
                preOptions.payment &&
                !preOptions.payment.payType ? (
                  <View style={{ marginTop: 12 }}>
                    <PaymentRegistrationContainer
                      screen={'OrderCompleteScreen'}
                      componentId={this.props.componentId}
                    />
                  </View>
                ) : (
                  <View />
                )}
                <View style={{ marginTop: 12 }}>
                  <DoorCodeContainer
                    orderId={orderId}
                    componentId={this.props.componentId}
                  />
                </View>
                <View style={{ marginTop: 12 }}>
                  <BorderRadiusButton
                    title={Favorite.ok}
                    titleFont={responseFont(16).regular}
                    titleColor={washswatColor.white}
                    buttonBgColor={washswatColor.black}
                    onPress={() =>
                      Navigation.dismissModal(this.props.componentId)
                    }
                    borderRadius={10}
                  />
                </View>
              </View>
            ) : (
              <LoadingBar />
            )}
          </View>
        </ScrollView>
        <View style={styles.xButton}>
          <XButton
            onPress={() => Navigation.dismissModal(this.props.componentId)}
          />
        </View>
      </View>
    );
  }
}

const mapStateToProps = ({ OrderHistoryModule, OrderModule }) => ({
  OrderHistoryState: OrderHistoryModule,
  OrderState: OrderModule,
});

const mapDispatchToProps = (dispatch) => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
  OrderAction: bindActionCreators(OrderModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OrderCompleteScreen);
