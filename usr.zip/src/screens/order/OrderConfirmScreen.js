import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  PixelRatio,
  ScrollView,
  Platform,
  BackHandler,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as StartOrderModule from '../../reducers/StartOrderModule';

import NBImageButton from '../../components/common/button/NBImageButton';
import HorizontalProgressBar from '../../components/common/button/HorizontalProgressBar';
import OrderTitle from '../../components/order/OrderTitle';
import OrderToggleButton from '../../components/order/OrderToggleButton';
import OrderServiceItem from '../../components/order/OrderServiceItem';
import OrderHelpBottomModal from '../../components/order/OrderHelpBottomModal';
import OrderPaySelectView from '../../components/order/OrderPaySelectView';
import LoadingBar from '../../components/common/button/LoadingBar';

import { StartOrderConfirm, Favorite } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import * as KeyUtils from '../../utils/type/key';
import * as ServerUtils from '../../utils/type/server';
import WashAlert from '../../utils/alert';
import { Font } from '../../utils/style';

import { _, moment } from '../../plugins';

import * as PageName from '../../vo/PageName';

const { responseFont, washswatColor } = Font;

// 익일배달 불가
const cannotBeExpress = ['shoes', 'repair', 'etc'];

class OrderConfirmScreen extends React.Component {
  constructor(props) {
    super(props);
    this._setAssets();
    this.state = {
      isDisabledService: false,
    };
  }

  _setAssets = () => {
    const { OrderAction } = this.props;
    OrderAction.setAssetsAPI();
  };

  async componentDidMount() {
    const { OrderAction } = this.props;
    if (Platform.OS === 'android') {
      BackHandler.addEventListener(
        'hardwareBackPress',
        this._onPressHardwareBack,
      );
    }
    let doorCode = await CommonUtils.getValue(KeyUtils.DOOR_CODE);
    if (doorCode) {
      doorCode = doorCode === 'null' || doorCode === null ? '' : doorCode; // doorCode가 'null'로 들어올 경우 ''(공백)으로 수정
      this._setDoor(doorCode);
      const doorYes = StartOrderConfirm.doorYes; // 공동현관 출입가능
      if (doorCode === doorYes) {
        OrderAction.setIsDoor(true);
      }
    }
    const isDisabledService = OrderAction.isDisabledServiceItem();
    this.setState({ isDisabledService });
  }

  componentWillUnmount() {
    if (Platform.OS === 'android') {
      BackHandler.removeEventListener(
        'hardwareBackPress',
        this._onPressHardwareBack,
      );
    }
  }

  _onPressBack = () => {
    const { OrderAction } = this.props;
    OrderAction.initThreeStage();
    Navigation.pop(this.props.componentId);
  };

  _onPressHardwareBack = () => {
    const { OrderAction, isOpenHelpBottomModal } = this.props;
    if (isOpenHelpBottomModal) {
      this._onPressHelpBottomModal();
      return true;
    }
    OrderAction.initThreeStage();
    Navigation.pop(this.props.componentId);
    return true;
  };

  // 주문정보 확인
  _onPressOrderInfoConfirm = isOpenOrderInfo => {
    const { OrderAction } = this.props;
    OrderAction.setIsOpenOrderInfo(!isOpenOrderInfo);
  };

  // 공동현관 출입 유무
  _onPressDoor = isDoor => {
    const { OrderAction } = this.props;
    OrderAction.setIsDoor(isDoor);
    if (isDoor) {
      const doorYes = StartOrderConfirm.doorYes;
      this._setDoor(doorYes);
    } else {
      this._setDoor('');
    }
  };

  // 공동현관 출입방법 설정
  _setDoor = text => {
    const { OrderAction } = this.props;
    OrderAction.setDoor(text);
  };

  // 결제수단 선택
  _onPressPaymentSelect = () => {
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'OrderPaymentScreen',
    });
  };

  // 쿠폰 적용
  _onPressCoupon = () => {
    const { OrderAction, preOptions, assets } = this.props;
    const { couponArray } = assets;
    if (couponArray && couponArray.length > 0) {
      /** 쿠폰페이지 이동 **/
      const { coupon } = preOptions.payment.discount;
      CommonUtils.navPush({
        componentId: this.props.componentId,
        name: 'CouponMain',
        passProps: {
          finishedAction: OrderAction.setCouponInfo,
          seletedCoupon: coupon || [],
        },
      });
    } else {
      /** 쿠폰이 없어요! 팝업 **/
      WashAlert.showAlert(StartOrderConfirm.noCoupon, Favorite.ok);
    }
  };

  // 포인트 적용
  _onPressPoint = () => {
    const { OrderAction, userType, preOptions, assets } = this.props;
    const { pointObject } = assets;
    let { point } = pointObject;
    if (point) {
      if (userType === 'normal' && point > 10000) {
        point = 10000;
      }
      CommonUtils.navPush({
        componentId: this.props.componentId,
        name: 'TextInputScreen',
        passProps: {
          pageName: PageName.USE_POINT,
          maximum: point,
          keyboardType: 'number-pad',
          finishedAction: OrderAction.setPointInfo,
        },
      });
    } else {
      /** 포인트 없어요! 팝업 **/
      WashAlert.showAlert(StartOrderConfirm.noPoint, Favorite.ok);
    }
  };

  // 할인수단 선택
  _onPressDiscountSelect = () => {};

  // 주문하기
  _onPressOrder = () => {
    const { isDoor, door } = this.props;
    if (!isDoor && _.isEmpty(door)) {
      WashAlert.showAlertWithCallback(
        StartOrderConfirm.doorInputPlz,
        Favorite.ok,
        () => {
          this.refs.doorRef.focus();
        },
      );
      return;
    }
    const { OrderAction, componentId } = this.props;
    OrderAction.makeOrderAPI(Navigation, componentId);
  };

  _getConfirmString = () => {
    const {
      address,
      addressOthers,
      pickup,
      pickupModal,
      delivery,
      deliveryModal,
    } = this.props;
    const { pickupTime } = pickup;
    const { deliveryTime } = delivery;
    const pickupString = moment(pickupTime).format(
      `M${Favorite.month} D${Favorite.day}, ${pickupModal.startEndTime}`,
    );
    const deliveryString = moment(deliveryTime).format(
      `M${Favorite.month} D${Favorite.day}, ${deliveryModal.startEndTime}`,
    );
    return `pick up.\n${pickupString}\n\ndelivery.\n${deliveryString}\n\naddress.\n${address}\n${addressOthers}`;
  };

  _getServiceItemViews = () => {
    const { OrderAction, pickup, delivery, preOptions } = this.props;
    const { service } = preOptions; // 서비스 종류
    const { isDisabledService } = this.state;
    const returnViews = [];
    StartOrderConfirm.serviceItemArray.map((item, index) => {
      const { key, title, subTitle, content } = item;
      returnViews.push(
        <OrderServiceItem
          key={key}
          itemKey={key}
          onPress={() => {
            OrderAction.setServiceItemArray(key);
          }}
          onPressHelp={() => {
            OrderAction.setIsOpenHelpBottomModal(true);
          }}
          selected={_.find(service, { key }) ? true : false}
          disabled={
            isDisabledService &&
            _.find(cannotBeExpress, k => {
              return k === key;
            })
              ? true
              : false
          } // 수거시간 기준으로 +3일 또는 +3일에 배달시간이 6시 이후일 때 shoes, repair, etc 선택 제외
          title={title}
          subTitle={subTitle}
          content={content}
        />,
      );
    });
    return returnViews;
  };

  _onPressHelpBottomModal = () => {
    const { OrderAction } = this.props;
    OrderAction.setIsOpenHelpBottomModal(false);
  };

  _onClosedHelpBottomModal = () => {
    const { OrderAction } = this.props;
    OrderAction.setIsOpenHelpBottomModal(false);
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const {
      isPending,
      isOpenOrderInfo,
      isOpenHelpBottomModal,
      isDoor,
      door,
      preOptions,
      paymentInfo,
    } = this.props;
    const doorLeftBgColor = isDoor ? washswatColor.blue : washswatColor.white;
    const doorLeftTextColor = isDoor ? washswatColor.white : washswatColor.blue;
    const doorRightBgColor = isDoor ? washswatColor.white : washswatColor.blue;
    const doorRightTextColor = isDoor
      ? washswatColor.blue
      : washswatColor.white;
    // 결제수단
    const paymentMethod =
      paymentInfo.payment.info === '' ? '' : paymentInfo.payment.info;
    // 쿠폰
    const couponInfo =
      paymentInfo.coupon.info === '' ? '' : paymentInfo.coupon.info;
    // 포인트
    const pointInfo =
      paymentInfo.point.info === ''
        ? ''
        : `${CommonUtils.numberWithCommas(paymentInfo.point.info)}P`;
    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.white }}>
        {isPending ? <LoadingBar /> : null}
        <View style={{ height: getStatusBarHeight(true) }} />
        <HorizontalProgressBar progress={1} />
        <NBImageButton
          onPress={this._onPressBack}
          source={require('image/common/back_button_black.png')}
        />
        <ScrollView>
          <OrderTitle stage={'3/3'} title={StartOrderConfirm.title} />
          <View style={styles.boundaryLine} />
          {/* 주문정보 확인 */}
          <View>
            <TouchableOpacity
              onPress={() => this._onPressOrderInfoConfirm(isOpenOrderInfo)}
              style={styles.orderInfoConfirm}
            >
              <Text
                style={[responseFont(16).bold, { color: washswatColor.black }]}
              >
                {StartOrderConfirm.orderInfoConfirm}
              </Text>
              <Image
                style={{
                  width: PixelRatio.roundToNearestPixel(10),
                  height: PixelRatio.roundToNearestPixel(10),
                }}
                source={require('image/start/down_arrow_small.png')}
              />
            </TouchableOpacity>
            {/* 주문정보 확인 상세 */}
            {isOpenOrderInfo && (
              <View style={styles.orderInfo}>
                <Text
                  style={[
                    responseFont(15).regular,
                    {
                      color: washswatColor.black,
                      lineHeight: PixelRatio.roundToNearestPixel(24),
                      padding: PixelRatio.roundToNearestPixel(30),
                    },
                  ]}
                >
                  {/* pick up. 5월 1일, 오후 10시 - 자정 사이 delivery. 5월 2일, 오후 8시 - 자정 사이 address. 서울시 송파구 양재대로66길 36 금아빌딩 101호 */}
                  {this._getConfirmString()}
                </Text>
              </View>
            )}
          </View>
          <View style={styles.boundaryLine} />
          {/* 서비스 종류 선택 */}
          <View style={{ padding: PixelRatio.roundToNearestPixel(30) }}>
            <Text
              style={[responseFont(16).bold, { color: washswatColor.black }]}
            >
              {StartOrderConfirm.serviceItemTitle}
            </Text>
            <Text
              style={[responseFont(13).regular, { color: washswatColor.black }]}
            >
              {StartOrderConfirm.serviceItemSubTitle}
            </Text>
            <View
              style={{
                marginTop: PixelRatio.roundToNearestPixel(30),
                borderWidth: PixelRatio.roundToNearestPixel(1),
                borderColor: washswatColor.black,
              }}
            >
              {this._getServiceItemViews()}
            </View>
          </View>
          <View style={styles.boundaryLine} />
          {/* 공동현관 출입정보 */}
          <View
            style={{
              paddingStart: PixelRatio.roundToNearestPixel(30),
              paddingEnd: PixelRatio.roundToNearestPixel(30),
              paddingBottom: PixelRatio.roundToNearestPixel(30),
              marginTop: PixelRatio.roundToNearestPixel(9),
            }}
          >
            <Text
              style={[
                responseFont(16).bold,
                {
                  color: washswatColor.black,
                  paddingTop: PixelRatio.roundToNearestPixel(25),
                  paddingBottom: PixelRatio.roundToNearestPixel(25),
                },
              ]}
            >
              {StartOrderConfirm.doorTitle}
            </Text>
            <OrderToggleButton
              onPressLeft={() => this._onPressDoor(true)}
              leftBgColor={doorLeftBgColor}
              leftTextColor={doorLeftTextColor}
              leftString={StartOrderConfirm.doorYes}
              onPressRight={() => this._onPressDoor(false)}
              rightBgColor={doorRightBgColor}
              rightTextColor={doorRightTextColor}
              rightString={StartOrderConfirm.doorNo}
            />
            <View style={{ marginTop: PixelRatio.roundToNearestPixel(24) }}>
              {isDoor ? (
                <Text
                  style={[
                    responseFont(15).regular,
                    {
                      color: washswatColor.black,
                      lineHeight: PixelRatio.roundToNearestPixel(24),
                      padding: PixelRatio.roundToNearestPixel(15),
                      backgroundColor: washswatColor.grey_05,
                    },
                  ]}
                >
                  {StartOrderConfirm.doorContent}
                </Text>
              ) : (
                <TextInput
                  ref={'doorRef'}
                  onChangeText={text => this._setDoor(text)}
                  value={door}
                  style={[
                    responseFont(15).regular,
                    {
                      height: PixelRatio.roundToNearestPixel(50),
                      color: washswatColor.black,
                      borderWidth: PixelRatio.roundToNearestPixel(1),
                      borderColor: washswatColor.grey_03,
                      borderRadius: PixelRatio.roundToNearestPixel(3),
                      padding: PixelRatio.roundToNearestPixel(15),
                    },
                  ]}
                  placeholder={StartOrderConfirm.doorPlaceholder}
                  placeholderTextColor={washswatColor.grey_02}
                  selectionState={this.doorDSS}
                />
              )}
            </View>
          </View>
          <View style={styles.boundaryLine} />
          {/* 결제정보 */}
          <View>
            <Text
              style={[
                responseFont(16).bold,
                {
                  color: washswatColor.black,
                  paddingStart: PixelRatio.roundToNearestPixel(30),
                  paddingTop: PixelRatio.roundToNearestPixel(25),
                  paddingEnd: PixelRatio.roundToNearestPixel(30),
                  paddingBottom: PixelRatio.roundToNearestPixel(25),
                },
              ]}
            >
              {StartOrderConfirm.paymentInfo}
            </Text>
            {/* 결제수단 */}
            <View style={styles.boundaryLine} />
            <OrderPaySelectView
              title={StartOrderConfirm.paymentTitle}
              info={paymentMethod}
              onPress={this._onPressPaymentSelect}
            />
            {/* 쿠폰 적용 */}
            <View style={styles.boundaryLine} />
            <OrderPaySelectView
              title={StartOrderConfirm.couponTitle}
              info={couponInfo}
              onPress={this._onPressCoupon}
            />
            {/* 포인트 적용 */}
            <View style={styles.boundaryLine} />
            <OrderPaySelectView
              title={StartOrderConfirm.pointTitle}
              info={pointInfo}
              onPress={this._onPressPoint}
            />
          </View>
          {/* <OrderSelectView title={paymentTitle} subTitle={paymentSubTitle} buttonText={paymentButtonText} onPress={this._onPressPaymentSelect} /> */}
          <View style={styles.boundaryLine} />
          {/* 할인수단 선택 */}
          {/* <OrderSelectView
            title={discountTitle}
            subTitle={discountSubTitle}
            buttonText={StartOrderShared.selection}
            onPress={this._onPressDiscountSelect}
          /> */}
          <View style={styles.boundaryLine} />
          {/* 주의사항 */}
          <View
            style={{
              paddingStart: PixelRatio.roundToNearestPixel(30),
              paddingEnd: PixelRatio.roundToNearestPixel(30),
              marginTop: PixelRatio.roundToNearestPixel(42),
            }}
          >
            <Text
              style={[responseFont(16).bold, { color: washswatColor.black }]}
            >
              {StartOrderConfirm.precautions}
            </Text>
            <Text
              style={[
                responseFont(15).regular,
                {
                  color: washswatColor.black,
                  lineHeight: PixelRatio.roundToNearestPixel(24),
                  marginTop: PixelRatio.roundToNearestPixel(24),
                },
              ]}
            >
              <Text>{StartOrderConfirm.precautionsContent1}</Text>
              <Text>{StartOrderConfirm.precautionsContent2}</Text>
              <Text>{StartOrderConfirm.precautionsContent3}</Text>
              <Text>{StartOrderConfirm.precautionsContent4_1}</Text>
              <Text
                onPress={() =>
                  CommonUtils.navShowModalWebView({
                    url: ServerUtils.URL_SERVICE_POLICY,
                  })
                }
                style={{ color: washswatColor.blue }}
              >{` ${StartOrderConfirm.precautionsContent4_2}`}</Text>
              <Text>{StartOrderConfirm.precautionsContent4_3}</Text>
            </Text>
          </View>
          {/* 주문하기 */}
          <TouchableOpacity onPress={this._onPressOrder} style={styles.order}>
            <Text
              style={[responseFont(15).bold, { color: washswatColor.white }]}
            >
              {StartOrderConfirm.order}
            </Text>
          </TouchableOpacity>
        </ScrollView>
        <OrderHelpBottomModal
          isOpen={isOpenHelpBottomModal}
          source={require('image/start/wash_and_fold_help.png')}
          content={StartOrderConfirm.washAndFoldHelp.content}
          onPressButton={this._onPressHelpBottomModal}
          buttonText={StartOrderConfirm.washAndFoldHelp.close}
          onClosed={this._onClosedHelpBottomModal}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  orderInfoConfirm: {
    height: PixelRatio.roundToNearestPixel(70),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
  },
  orderInfo: {
    backgroundColor: washswatColor.grey_05,
    marginStart: PixelRatio.roundToNearestPixel(30),
    marginEnd: PixelRatio.roundToNearestPixel(30),
    marginBottom: PixelRatio.roundToNearestPixel(36),
  },
  boundaryLine: {
    height: PixelRatio.roundToNearestPixel(1),
    // backgroundColor: washswatColor.red,
    backgroundColor: washswatColor.grey_05,
    marginStart: PixelRatio.roundToNearestPixel(30),
    marginEnd: PixelRatio.roundToNearestPixel(30),
  },
  order: {
    height: PixelRatio.roundToNearestPixel(72),
    backgroundColor: washswatColor.black,
    marginStart: PixelRatio.roundToNearestPixel(42),
    marginTop: PixelRatio.roundToNearestPixel(72),
    marginEnd: PixelRatio.roundToNearestPixel(42),
    marginBottom: PixelRatio.roundToNearestPixel(87),
    borderRadius: PixelRatio.roundToNearestPixel(90),
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default connect(
  state => ({
    isPending: state.StartOrderModule.isPending,
    userType: state.StartOrderModule.userType,
    address: state.StartOrderModule.address,
    addressOthers: state.StartOrderModule.addressOthers,
    pickupArray: state.StartOrderModule.pickupArray,
    pickup: state.StartOrderModule.pickup,
    pickupModal: state.StartOrderModule.pickupModal,
    deliveryArray: state.StartOrderModule.deliveryArray,
    delivery: state.StartOrderModule.delivery,
    deliveryModal: state.StartOrderModule.deliveryModal,
    isExpress: state.StartOrderModule.isExpress,
    isOpenOrderInfo: state.StartOrderModule.isOpenOrderInfo,
    isOpenHelpBottomModal: state.StartOrderModule.isOpenHelpBottomModal,
    isDoor: state.StartOrderModule.isDoor,
    serviceItemArray: state.StartOrderModule.serviceItemArray,
    door: state.StartOrderModule.door,
    preOptions: state.StartOrderModule.preOptions,
    paymentInfo: state.StartOrderModule.paymentInfo,
    assets: state.StartOrderModule.assets,
  }),
  dispatch => ({ OrderAction: bindActionCreators(StartOrderModule, dispatch) }),
)(OrderConfirmScreen);
