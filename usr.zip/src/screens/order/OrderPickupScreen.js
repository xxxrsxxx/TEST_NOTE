import React from 'react';

import {
  BackHandler,
  Dimensions,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as StartOrderModule from '../../reducers/StartOrderModule';

import CloseButton from '../../components/common/button/CloseButton';
import OrderTitle from '../../components/order/OrderTitle';
import OrderDateTime from '../../components/order/OrderDateTime';
import OrderBottomModal from '../../components/order/OrderBottomModal';
import LoadingBar from '../../components/common/button/LoadingBar';

import { StartOrderPickup } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import { Font, Styles } from '../../utils/style';

const { washswatColor } = Font;
const { androidStatusBar } = Styles;

class OrderPickupScreen extends React.Component {
  constructor(props) {
    super(props);
    this._setPickupDateTime();
  }

  _setPickupDateTime = () => {
    const { OrderAction, componentId, timeSelectCallback } = this.props;
    OrderAction.setPickupDateTimeAPI({ componentId, timeSelectCallback });
  };

  componentDidMount() {
    if (Platform.OS === 'android') {
      BackHandler.addEventListener(
        'hardwareBackPress',
        this._onPressHardwareBack,
      );
    }
  }

  componentWillUnmount() {
    if (Platform.OS === 'android') {
      BackHandler.removeEventListener(
        'hardwareBackPress',
        this._onPressHardwareBack,
      );
    }
  }

  _onPressBack = () => {
    const { OrderAction } = this.props;
    OrderAction.initOrder();
    Navigation.dismissModal(this.props.componentId);
  };

  _onPressHardwareBack = () => {
    const { pickupIsOpenBottomModal, OrderAction } = this.props;
    if (pickupIsOpenBottomModal) {
      this._onPressBottomModalClose();
      this._onPressEventBottomModalClose();
      return true;
    }
    OrderAction.initOrder();
    Navigation.dismissModal(this.props.componentId);
    return true;
  };

  _onPressNext = () => {
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'OrderDeliveryScreen',
    });
    const { OrderAction } = this.props;
    OrderAction.setPickupIsOpenBottomModal(false);
    OrderAction.setPickupEventIsOpenBottomModal(false);
  };

  _onPressEventNext = () => {
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: 'OrderConfirmScreen',
    });
    const { OrderAction } = this.props;
    OrderAction.setPickupEventIsOpenBottomModal(false);
  };

  _onPressBottomModalOpen = () => {
    const { OrderAction } = this.props;
    OrderAction.setPickupIsOpenBottomModal(true);
  };

  _onPressBottomModalClose = () => {
    const { OrderAction } = this.props;
    OrderAction.setPickupIsOpenBottomModal(false);
  };

  _onPressEventBottomModalOpen = () => {
    const { OrderAction } = this.props;
    OrderAction.setPickupEventIsOpenBottomModal(true);
  };

  _onPressEventBottomModalClose = () => {
    const { OrderAction } = this.props;
    OrderAction.setPickupEventIsOpenBottomModal(false);
  };

  _onClosedBottomModal = () => {
    const { OrderAction } = this.props;
    OrderAction.setPickupIsOpenBottomModal(false);
    OrderAction.setPickupEventIsOpenBottomModal(false);
  };

  _setDateIndex = index => {
    const { OrderAction } = this.props;
    OrderAction.setPickupDateIndex(index);
  };

  _setEventBottomModal = () => {
    const {
      OrderAction,
      isPending,
      pickupArray,
      pickupEventArray,
      pickupModal,
      pickupEventIsOpenBottomModal,
      pickupDateIndex,
    } = this.props;
    // const { OrderAction, isPending, pickupArray, pickupModal, pickupEventIsOpenBottomModal, pickupDateIndex } = this.props;
    const { dayOfWeek, startEndTime } = pickupModal;
    // const pickupEventArray = [
    //   {
    //     pickup: {
    //       day: '2019-06-25',
    //       slots: [{ start: 20, end: 24 }]
    //     },
    //     delivery: {
    //       day: '2019-07-05',
    //       slots: [{ start: 20, end: 24 }]
    //     },
    //     info: {
    //       image: 'https://s3.ap-northeast-2.amazonaws.com/com.washswat.assets/growth/V5+pop+up.png',
    //       content: 'info > content'
    //     }
    //   }
    // ];
    if (pickupEventArray && pickupEventArray.length > 0) {
      const { info } = pickupEventArray[0];
      return (
        <OrderBottomModal
          isEvent={true}
          eventTitle={info.title}
          isOpen={pickupEventIsOpenBottomModal}
          // source={require('image/start/noti_delivery.png')}
          source={{ uri: info.image }}
          content={info.content}
          dayOfWeek={dayOfWeek}
          startEndTime={startEndTime}
          onPressButton={this._onPressEventNext}
          onClosed={this._onClosedBottomModal}
        />
      );
    }
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const {
      OrderAction,
      isPending,
      pickupArray,
      pickupEventArray,
      pickupModal,
      pickupIsOpenBottomModal,
      pickupDateIndex,
    } = this.props;
    // const { OrderAction, isPending, pickupArray, pickupModal, pickupIsOpenBottomModal, pickupDateIndex } = this.props;
    // const pickupEventArray = [
    //   {
    //     pickup: {
    //       day: '2019-06-25',
    //       slots: [{ start: 20, end: 24 }]
    //     },
    //     delivery: {
    //       day: '2019-07-05',
    //       slots: [{ start: 20, end: 24 }]
    //     },
    //     info: {
    //       image: 'https://s3.ap-northeast-2.amazonaws.com/com.washswat.assets/growth/V5+pop+up.png',
    //       content: 'info > content'
    //     }
    //   }
    // ];
    const { dayOfWeek, startEndTime } = pickupModal;
    const { width } = Dimensions.get('window');
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: washswatColor.white,
          marginTop: Platform.OS === 'android' ? -androidStatusBar : 0,
        }}
      >
        <StatusBar
          barStyle={
            Platform.OS === 'android' ? 'dark-content' : 'light-content'
          }
        />
        {isPending ? <LoadingBar /> : null}
        <View style={{ height: getStatusBarHeight(true) }} />
        <CloseButton onPress={this._onPressBack} />
        {/* <NBImageButton onPress={this._onPressBack} source={require('image/common/back_button_black.png')} /> */}
        <ScrollView>
          <OrderTitle title={StartOrderPickup.title} />
          {pickupArray.length > 0 && (
            <OrderDateTime
              page={'pickup'}
              data={pickupArray}
              eventData={pickupEventArray}
              width={width}
              dateIndex={pickupDateIndex}
              setDateIndex={this._setDateIndex}
              onPressBottomModalOpen={this._onPressBottomModalOpen}
              onPressEventBottomModalOpen={this._onPressEventBottomModalOpen}
              action={OrderAction}
            />
          )}
        </ScrollView>
        {this._setEventBottomModal()}
        <OrderBottomModal
          isOpen={pickupIsOpenBottomModal}
          source={require('image/start/pickup_at_door.png')}
          content={StartOrderPickup.modalContent}
          dayOfWeek={dayOfWeek}
          startEndTime={startEndTime}
          onPressButton={this._onPressNext}
          onClosed={this._onClosedBottomModal}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({});

export default connect(
  state => ({
    isPending: state.StartOrderModule.isPending,
    pickupArray: state.StartOrderModule.pickupArray,
    pickupEventArray: state.StartOrderModule.pickupEventArray,
    pickupModal: state.StartOrderModule.pickupModal,
    pickupIsOpenBottomModal: state.StartOrderModule.pickupIsOpenBottomModal,
    pickupEventIsOpenBottomModal:
      state.StartOrderModule.pickupEventIsOpenBottomModal,
    pickupDateIndex: state.StartOrderModule.pickupDateIndex,
  }),
  dispatch => ({ OrderAction: bindActionCreators(StartOrderModule, dispatch) }),
)(OrderPickupScreen);
