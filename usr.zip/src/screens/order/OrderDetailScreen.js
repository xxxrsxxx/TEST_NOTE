import React, { useEffect } from 'react';

import { Platform, SafeAreaView, ScrollView, Text, View } from 'react-native';
import { Navigation } from 'react-native-navigation';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';
import * as MyPageModule from '../../reducers/MyPageModule';

import OrderHistoryDetailContainer from '../../containers/order/OrderHistoryDetailContainer';
import OrderHistoryDetailPaymentContainer from '../../containers/order/OrderHistoryDetailPaymentContainer';
import OrderHistoryModalContainer from '../../containers/order/OrderHistoryModalContainer';
import { buildItemViews } from '../../containers/order/OrderHistoryListContainer';

import OrderHistoryMembershipComponent from '../../components/order-history/OrderHistoryMembershipComponent';
import OrderHistoryToast from '../../components/order-history/OrderHistoryToast';
import OrderHistoryButtons from '../../components/order-history/OrderHistoryButtons';
import { BasicHeader } from '../../components/common/layout';

import LoadingBar from '../../components/common/button/LoadingBar';

// style import
import { OrderHistoryDetailString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const OrderDetailScreen = (props) => {
  const {
    OrderHistoryState,
    OrderHistoryAction,
    PaymentState,
    componentId,
    orderId,
  } = props;

  const {
    isModalOn,
    isToastOn,
    orderItem,
    available,
    GLOBAL_STATUS_LIST,
    isPayPending,
  } = OrderHistoryState;
  const {
    setToastOn,
    setModalOn,
    joinMembership,
    goToSetPickupTime,
    goToSetDeliveryTime,
    pressPay,
    setCardChecked,
    setPayPending,
    setComponentId,
  } = OrderHistoryAction;
  const { isPending } = PaymentState;

  useEffect(() => {
    if (orderId) {
      OrderHistoryAction.getOrderHistoryDetail(orderId);
    }
  }, []);

  // 뒤로가기 버튼
  const onPressBack = () => {
    setToastOn(true);
    Navigation.pop(componentId);
  };

  const onToastClosed = () => {
    setToastOn(false);
  };

  const onModalToggle = (status) => {
    setModalOn(status);
  };

  const GreyBoundary = () => (
    <View style={{ backgroundColor: washswatColor.grey_12, height: 8 }} />
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: washswatColor.white }}>
      {isPending && <LoadingBar />}
      {Platform.OS === 'ios' ? (
        <BasicHeader
          onPress={onPressBack}
          title={OrderHistoryDetailString.orderDetail}
          inSafeAreaView={true}
        />
      ) : (
        <BasicHeader
          onPress={onPressBack}
          customStyle={{ marginTop: -2 }}
          title={OrderHistoryDetailString.orderDetail}
          inSafeAreaView={true}
        />
      )}

      <ScrollView style={{ marginBottom: 8 }}>
        {/*  주문일정표 component */}
        {orderItem && (
          <OrderHistoryDetailContainer
            OrderHistoryState={OrderHistoryState}
            componentId={componentId}
          />
        )}

        {/* membership 조건문 */}
        {orderItem &&
          orderItem.userInfo &&
          orderItem.userInfo.userType === 'normal' && (
            <View>
              <GreyBoundary />

              <OrderHistoryMembershipComponent
                joinMembership={joinMembership}
                componentId={componentId}
              />
            </View>
          )}

        {/* 요금표 component */}
        {orderItem && available && orderItem.status !== 'pickup' && (
          <View>
            <GreyBoundary />

            <OrderHistoryDetailPaymentContainer
              userType={orderItem.userInfo.userType}
              available={available}
              componentId={componentId}
            />
          </View>
        )}

        {/* over ||  complete */}
        {orderItem && ['over', 'complete'].indexOf(orderItem.status) > -1 && (
          <View>
            <GreyBoundary />
            <View
              style={{ height: 80, marginLeft: 24, justifyContent: 'center' }}
            >
              <Text
                style={[responseFont(16).bold, { color: washswatColor.black }]}
              >
                {OrderHistoryDetailString.myWashItem}
              </Text>
            </View>
            <View
              style={{ height: 1, backgroundColor: washswatColor.grey_12 }}
            />
            {buildItemViews({
              order: orderItem,
              componentId: props.componentId,
              GLOBAL_STATUS_LIST,
            })}
          </View>
        )}
      </ScrollView>

      {/* toast는 ing 상태이고 isToastOn 일때 나타나는게 기본, 그리고 결제 완료 후에는 안나타나도록 */}
      {isToastOn &&
        orderItem &&
        orderItem.status === 'ing' &&
        orderItem.pickup &&
        orderItem.pickup.payType === 'later' && (
          <OrderHistoryToast
            deliveryTime={orderItem.mission.delivery.deliveryTime}
            userType={orderItem.userInfo.userType}
            OrderHistoryDetailString={OrderHistoryDetailString}
            onToastToggle={onToastClosed}
          />
        )}

      {/* bottom buttons */}
      {orderItem &&
      orderItem.pickup &&
      orderItem.pickup.payType &&
      orderItem.pickup.payType === 'later' ? (
        <OrderHistoryButtons
          componentId={componentId}
          orderItem={orderItem}
          onModalToggle={onModalToggle}
          goToSetPickupTime={goToSetPickupTime}
          goToSetDeliveryTime={goToSetDeliveryTime}
          pressPay={pressPay}
          finalPrice={available?.order?.finalPrice}
          setCardChecked={setCardChecked}
          setPayPending={setPayPending}
          setComponentId={setComponentId}
          isPayPending={isPayPending}
        />
      ) : null}

      {/* modal */}
      {orderItem &&
        available &&
        orderItem.status !== 'pickup' &&
        orderItem.status !== 'wait' && (
          <OrderHistoryModalContainer
            isModalOn={isModalOn}
            onModalToggle={onModalToggle}
            componentId={componentId}
          />
        )}
    </SafeAreaView>
  );
};

const mapStateToProps = ({ OrderHistoryModule, PaymentModule }) => ({
  OrderHistoryState: OrderHistoryModule,
  PaymentState: PaymentModule,
});

const mapDispatchToProps = (dispatch) => ({
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderDetailScreen);
