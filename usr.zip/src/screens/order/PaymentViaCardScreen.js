import React, { Component } from 'react';

import { Linking, Platform, StatusBar, StyleSheet, View } from 'react-native';
import { Navigation } from 'react-native-navigation';
import { WebView } from 'react-native-webview';
import { sha256 } from 'react-native-sha256';

import queryString from 'query-string';
import urlencode from 'urlencode';

import LoadingBar from '../../components/common/button/LoadingBar';
import CloseButton from '../../components/common/button/CloseButton';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as PaymentViaCardModule from '../../reducers/PaymentViaCardModule';

import * as ServerUtils from '../../utils/type/server';
import { Styles } from '../../utils/style';

import { moment } from '../../plugins';
const { androidStatusBar } = Styles;

class PaymentViaCardScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      url: '',
      isLoading: true,
    };

    Navigation.events().bindComponent(this);
  }

  componentDidMount() {
    const {
      PaymentViaCardState,
      PaymentViaCardAction,
      componentId,
      data,
    } = this.props;
    let url;
    if (data && data.callType) {
      const {
        callType,
        uid,
        name,
        orderId,
        objectId,
        totalPrice,
        finalPrice,
        usePoint,
        phone,
        usedCouponList,
        coin,
        bonus,
        hash,
      } = data;

      const URL_PAYMENT_CARD_RESULT = 'payment/action/pay/card';
      let device = Platform.OS === 'ios' ? 'iOS' : 'Android';
      const EUC_KR = 'EUC-KR';
      if (callType === 'inicisCard') {
        url = ServerUtils.URL_INICIS_SMART_WCARD;
        let paramString = '';
        paramString += 'P_MID=washswat02';
        paramString += '&P_OID=' + objectId;
        paramString += '&P_AMT=' + finalPrice;
        paramString += '&P_MOBILE=' + phone;
        paramString +=
          '&P_NOTI=' +
          `device=${device}|version=RN|usePoint=${usePoint}|phone=${phone}`;
        if (usedCouponList && usedCouponList.length > 0) {
          const list = [];
          usedCouponList.map(o => {
            const { _id, couponId } = o;
            list.push({ _id, couponId });
          });
          paramString += `|usedCouponList=${JSON.stringify(list)}`;
        }
        paramString +=
          '&P_NEXT_URL=' + ServerUtils.DEFAULT_URL + URL_PAYMENT_CARD_RESULT;
        paramString += '&P_UNAME=' + urlencode(orderId, EUC_KR);
        // paramString += "&P_UNAME="+ orderId
        paramString += `&P_GOODS=WASHSWAT_${urlencode(orderId, EUC_KR)}`;
        // paramString += `&P_GOODS=WASHSWAT_${orderId}`
        paramString += `&P_RESERVED=${urlencode(
          'twotrs_isp=Y&block_isp=Y&twotrs_isp_noti=N&apprun_check=Y&app_scheme=washios://&extension_enable=Y&global_visa3d=Y&below1000=Y',
          EUC_KR,
        )}`;
        // paramString += "&P_RESERVED=twotrs_isp=Y&block_isp=Y&twotrs_isp_noti=N&apprun_check=Y&app_scheme=washios://&extension_enable=Y&global_visa3d=Y"
        url += '?' + queryString.stringify(queryString.parse(paramString));
        this.setState({ url });
      } else if (callType === 'bill') {
        const oid = `${moment().format('YYYYMMDDHH:mm')}${uid}`;
        let INISIC_MERCHANT_KEY = 'MVh0WDdqQ3V5R2tQd1JjNjc2bkZndz09';

        sha256(
          'washswat01' +
            oid +
            moment().format('YYYYMMDDHHmmss') +
            INISIC_MERCHANT_KEY,
        ).then(hash => {
          let urlString = '';
          urlString += '?mid=washswat01';
          urlString += '&price=0';
          urlString += '&orderid=' + oid;
          urlString +=
            '&returnurl=' +
            `${ServerUtils.DEFAULT_URL}payment/registCardResult`;
          urlString += '&timestamp=' + moment().format('YYYYMMDDHHmmss');
          urlString += '&period=' + moment().format('YYYYMMDD');
          urlString += '&p_noti=' + `uid=${uid}|version=RN`;
          urlString += '&hashdata=' + hash;
          urlString += '&buyername=' + name;
          urlString += '&goodname=' + '세특 카드 등록';
          url = `${ServerUtils.URL_INICIS_INIBILL_CARD}${urlString}`;
          this.setState({ url });
        });
      } else if (callType === 'coin') {
        url = ServerUtils.URL_INICIS_SMART_WCARD;
        let paramString = '';
        paramString +=
          'P_NEXT_URL=' + ServerUtils.DEFAULT_URL + URL_PAYMENT_CARD_RESULT;
        paramString += '&P_MID=washswat02';
        paramString +=
          '&P_OID=' + `coin-${uid}-${moment().format('YYYYMMDDHHmmss')}`;
        paramString += '&P_AMT=' + coin;
        paramString += '&P_MOBILE=' + phone;
        paramString +=
          '&P_NOTI=' +
          `version=RN|device=${device}|coin=${coin}|bonus=${bonus}|type=coin|uid=${uid}`;
        //인코딩 필요
        paramString += `&P_UNAME=${urlencode(name, EUC_KR)}`;
        paramString += `&P_GOODS=${urlencode('WASHSWAT')}`;
        paramString += `&P_RESERVED=${urlencode(
          'twotrs_isp=Y&block_isp=Y&twotrs_isp_noti=N&apprun_check=Y&app_scheme=washios://&extension_enable=Y',
          EUC_KR,
        )}`;
        url += '?' + paramString;
        this.setState({ url });
      } else if (callType === 'naverpay') {
        url = ServerUtils.URL_NAVERPAY;
        let paramString = '';

        paramString += 'hash=' + hash;
        paramString += '&device=' + Platform.OS;
        paramString += '&version=RN';
        paramString += '&name=' + name;
        url += '?' + queryString.stringify(queryString.parse(paramString));

        console.log('url', url);

        this.setState({ url });
      }
    }
  }

  onPressBack = () => {
    Navigation.dismissModal(this.props.componentId);
  };

  showSpinner = () => {};
  hideSpinner = () => {
    this.setState({ isLoading: false });
  };

  handleWebViewNavigationStateChange = newNavState => {
    const { url } = newNavState;
    if (url && url !== 'about:blank') {
      if (
        !url.startsWith('http') &&
        !url.startsWith('javascript:') &&
        !url.startsWith('file://')
      ) {
        Linking.canOpenURL(url)
          .then(supported => {
            if (!supported) {
              if (this.webview) {
                this.setState({ url: '' });
              }
            } else {
              this.setState({ url: '' });
              return Linking.openURL(url);
            }
          })
          .catch(err => {
            // ('An error occurred', err)
          });
      } else {
      }
    } else {
    }
  };

  onMessage = e => {
    const { data } = e.nativeEvent;
    const { finishedAction } = this.props;

    if (data && data.includes('{')) {
      setTimeout(() => {
        finishedAction(JSON.parse(data));
      }, 200);
      this.onPressBack();
    }
  };

  render() {
    const { isLoading, url } = this.state;
    const { data } = this.props;
    let source =
      data.callType === 'naverpay'
        ? { uri: url }
        : { uri: url, method: 'POST' };

    return (
      <View
        style={{
          flex: 1,
          marginTop: Platform.OS === 'android' ? -androidStatusBar : 0,
        }}
      >
        <StatusBar
          barStyle={
            Platform.OS === 'android' ? 'dark-content' : 'light-content'
          }
        />
        {isLoading ? <LoadingBar /> : null}
        <WebView
          ref={webview => {
            this.webview = webview;
          }}
          originWhitelist={['*']}
          source={source}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          onLoadStart={() => this.showSpinner()}
          onLoad={() => this.hideSpinner()}
          onMessage={this.onMessage.bind(this)}
          onNavigationStateChange={this.handleWebViewNavigationStateChange}
          /** isNotAppCard => Render Error */
          renderError={e => {
            if (e === 'NSURLErrorDomain') {
              // WashAlert.showAlertWithCallback(Favorite.fail, Favorite.ok, () => {
              //   this.onPressBack();
              // });
            }
          }}
        />
      </View>
    );
  }
}
const styles = StyleSheet.create({});

const mapStateToProps = ({ PaymentViaCardModule }) => ({
  PaymentViaCardState: PaymentViaCardModule,
});

const mapDispatchToProps = dispatch => ({
  PaymentViaCardAction: bindActionCreators(PaymentViaCardModule, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(PaymentViaCardScreen);
