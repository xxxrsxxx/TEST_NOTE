import React, { PureComponent } from 'react';

import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  Platform,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as myPageAction from '../../reducers/MyPageModule';

import { BasicHeader } from '../../components/common/layout';
import HistoryContainer from '../../containers/mypage/history/HistoryContainer';
import GrayBox from '../../components/common/style/GrayBox';

import * as CommonUtils from '../../utils/common/index';
import {
  PageTitles,
  MyPageString,
  PointHistoryScreenString,
} from '../../utils/common/strings';
import { Font, Styles } from '../../utils/style';

const { responseFont, washswatColor, verticalScale } = Font;
const { androidStatusBar } = Styles;

const { width } = Dimensions.get('window');

class BulletHistoryScreen extends PureComponent {
  componentDidMount() {
    const { MyPageAction } = this.props;
    MyPageAction.getPoint();
  }

  render() {
    const { componentId, userCoin, coinHistory } = this.props;
    const sortPointHistory = coinHistory.filter(
      (history) =>
        (history.isValid && history.type === 'bonus') ||
        history.type === 'coin',
    );

    return (
      <View
        style={{ marginTop: Platform.OS === 'android' ? -androidStatusBar : 0 }}
      >
        <BasicHeader componentId={componentId} title={PageTitles.coin} />

        <View style={styles.wrap}>
          <View style={styles.container}>
            <View style={styles.upper}>
              <GrayBox>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                  }}
                >
                  <Text style={styles.point}>🔫</Text>
                  <Text style={styles.point}>
                    {CommonUtils.numberWithCommas(userCoin)}
                    {PointHistoryScreenString.coin_unit}
                  </Text>
                </View>
              </GrayBox>
            </View>

            <View style={styles.lower}>
              <Text style={styles.history_title}>
                {PointHistoryScreenString.history}
              </Text>
              <HistoryContainer
                historyData={sortPointHistory}
                coinHistory={true}
              />
            </View>
          </View>
        </View>

        <View
          style={{
            position: 'absolute',
            bottom: 5,
            paddingLeft: 25,
            paddingRight: 25,
            width: `100%`,
          }}
        >
          <TouchableOpacity
            onPress={() => {
              CommonUtils.navPush({
                componentId,
                name: 'BuyBulletScreen',
              });
            }}
            style={{
              height: PixelRatio.roundToNearestPixel(55),
              backgroundColor: washswatColor.black,
              borderRadius: 5,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Text
              style={[responseFont(16).bold, { color: washswatColor.white }]}
            >
              {MyPageString.buyCoin}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  wrap: {
    width: width,
    alignItems: 'center',
    paddingTop: verticalScale(40),
  },
  container: {
    width: width - 48,
  },
  point: {
    paddingVertical: verticalScale(20),
    textAlign: 'center',
    ...responseFont(18).bold,
  },
  desc: {
    textAlign: 'center',
    ...responseFont(10).regular,
    color: washswatColor.grey_08,
  },
  lower: {
    marginTop: verticalScale(35),
  },
  history_title: {
    ...responseFont(12).bold,
    marginBottom: verticalScale(11),
  },
});
export default connect(
  (state) => ({
    coinHistory: state.MyPageModule.coinHistory,
    userCoin: state.MyPageModule.userCoin,
  }),
  (dispatch) => ({
    MyPageAction: bindActionCreators(myPageAction, dispatch),
  }),
)(BulletHistoryScreen);
