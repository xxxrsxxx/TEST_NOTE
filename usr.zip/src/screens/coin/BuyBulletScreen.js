import React, { PureComponent } from 'react';

import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  ScrollView,
  Platform,
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as buyBulletActions from '../../reducers/BuyBulletModule';
import * as startOrderActions from '../../reducers/StartOrderModule';

import { BasicHeader } from '../../components/common/layout';
import SelectBulletList from '../../components/coin/SelectBulletList';
import BottomModalComponent from '../../components/common/modal/BottomModalComponent';
import AddCardModalComponent from '../../components/coin/AddCardModalComponent';
import LoadingBar from '../../components/common/button/LoadingBar';

import { PaymentBuyBulletString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { verticalScale, responseFont } = Font;

const { width } = Dimensions.get('window');

class BuyBulletScreen extends PureComponent {
  componentDidMount() {
    this.getCardListInfo();
  }

  getCardListInfo = () => {
    const { StartOrderActions } = this.props;
    StartOrderActions.setAssetsAPI();
  };

  handleModalToggle = i => {
    const { billArray, BuyBulletActions } = this.props;
    if (billArray.length === 0) {
      BuyBulletActions.toggleOpenAddCardModal({
        isOpen: true,
        isActiveIndex: i,
      });
    } else {
      if (billArray[0].isDefault) {
        BuyBulletActions.toggleOpenPayCoinModal({
          isOpen: true,
          isActiveIndex: i,
        });
      } else {
        BuyBulletActions.selectPayCard();
      }
    }
  };

  handleBuyBullet = async () => {
    const { BuyBulletActions } = this.props;
    await BuyBulletActions.buyBullet('buyCoin');
  };

  handleCloseBottomModal = () => {
    const { BuyBulletActions } = this.props;
    BuyBulletActions.toggleOpenPayCoinModal({
      isOpen: false,
      isActiveIndex: null,
    });
  };

  render() {
    const {
      paymentArr,
      componentId,
      isOpenPayCoinModal,
      billArray,
      loading,
    } = this.props;
    const noticeList = PaymentBuyBulletString.noticeContents;

    const selectBulletListUI = paymentArr.map((bulletList, i) => (
      <SelectBulletList
        bulletList={bulletList}
        key={i}
        handleBuyBullet={() => this.handleModalToggle(i)}
      />
    ));
    const textStyleArray = [1, 3, 4, 5, 6];
    const bottomMargin = [1, 2, 4, 6, 7];
    const noticeListUI = noticeList.map((notice, i) => (
      <Text
        style={[
          styles.notice_list,
          textStyleArray.includes(i) && styles.indent_text,
          bottomMargin.includes(i) && styles.bottomMargin,
        ]}
        key={i}
      >
        {!textStyleArray.includes(i) && '·'} {notice}
      </Text>
    ));
    return (
      <View>
        {loading ? <LoadingBar /> : null}
        <ScrollView>
          <View style={styles.container}>
            <View style={{ width: width - 48 }}>
              <Text style={styles.title}>{PaymentBuyBulletString.title}</Text>
              <View>{selectBulletListUI}</View>

              <View style={styles.notice_box}>
                <Text style={styles.notice_title}>
                  {PaymentBuyBulletString.noticeTitle}
                </Text>
                {noticeListUI}
              </View>
            </View>
          </View>
        </ScrollView>
        <BasicHeader componentId={componentId} />
        <AddCardModalComponent
          billArray={billArray}
          componentId={componentId}
        />
        <BottomModalComponent
          isOpen={isOpenPayCoinModal}
          contentView={
            <View>
              <Text
                style={[
                  { ...responseFont(14).regular },
                  { textAlign: 'center' },
                ]}
              >
                {PaymentBuyBulletString.registerCardModalTitle}
              </Text>
            </View>
          }
          leftButtonText={PaymentBuyBulletString.registerCardModalNO}
          rightButtonText={PaymentBuyBulletString.registerCardModalOK}
          height={300}
          onClosed={this.handleCloseBottomModal}
          onLeftButtonClicked={this.handleCloseBottomModal}
          onRightButtonClicked={this.handleBuyBullet}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    width: width,
    alignItems: 'center',
    paddingTop:
      Platform.OS === 'android' ? verticalScale(100) : verticalScale(80),
  },
  title: {
    ...responseFont(24).bold,
    paddingBottom: verticalScale(40),
  },
  notice_box: {
    paddingTop: verticalScale(20),
    paddingBottom: verticalScale(20),
  },
  notice_title: {
    ...responseFont(13).bold,
    marginBottom: 15,
  },
  notice_list: {
    ...responseFont(10).regular,
    // marginBottom:1,
  },
  indent_text: {
    paddingLeft: 3,
  },
  bottomMargin: {
    marginBottom: 4,
  },
});

export default connect(
  state => ({
    paymentArr: state.BuyBulletModule.paymentArr,
    isOpenPayCoinModal: state.BuyBulletModule.isOpenPayCoinModal,
    billArray: state.StartOrderModule.assets.billArray,
    loading: state.BuyBulletModule.loading,
  }),
  dispatch => ({
    // CoinActions: bindActionCreators(coinActions, dispatch),
    BuyBulletActions: bindActionCreators(buyBulletActions, dispatch),
    StartOrderActions: bindActionCreators(startOrderActions, dispatch),
  }),
)(BuyBulletScreen);
