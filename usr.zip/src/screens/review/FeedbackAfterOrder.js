import React from 'react';

import {
  Image,
  Linking,
  PixelRatio,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import StarRating from 'react-native-star-rating';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as FeedbackModule from '../../reducers/FeedbackModule';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';

import FeedbackAfterOrderView from '../../components/review/FeedbackAfterOrderView';
import { AnswerChatView, ChatView } from '../../components/login/ChatComponent';
import NBImageButton from '../../components/common/button/NBImageButton';
import NBTextButton from '../../components/common/button/NBTextButton';
import LoadingBar from '../../components/common/button/LoadingBar';
import KeyboardSpacerIOS from '../../components/common/keyboard/KeyboardSpacerIOS';

import WashAlert from '../../utils/alert';
import * as KeyUtils from '../../utils/type/key';
import {
  FeedbackAfterOrderString,
  FeedbackBadExperienceSelectionString,
  FeedbackGoodExperienceSelectionString,
  Favorite,
} from '../../utils/common/strings';
import AnalyticsManager from '../../utils/tagging/analytics';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

import { _ } from '../../plugins';

class FeedbackAfterOrder extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      experience: props.experience,
      badToggle: false,
      preventDuplicateClick: false,
    };
  }

  toggleSendFeedback = () => {
    this.setState({
      badToggle: !this.state.badToggle,
    });
  };

  onPressBack = () => {
    const { componentId, FeedbackAction } = this.props;
    FeedbackAction.backPrsess();
    Navigation.dismissModal(componentId);
  };

  onPressGoStarRating = () => {
    const { FeedbackAction } = this.props;
    FeedbackAction.setShowFeedbackInput({ isShowFeedbackInput: false });
  };

  // 수거서비스
  onPressPickupStarRating(rating) {
    const { FeedbackAction } = this.props;
    FeedbackAction.setPickupStarRating({
      pickupPoint: Number(rating).toFixed(1),
      pickupPointTextColorFlag: true,
      pickupStarCount: rating,
    });
  }

  // 배달서비스
  onPressDeliveyStarRating(rating) {
    const { FeedbackAction } = this.props;
    FeedbackAction.setDeliveryStarRating({
      deliveryPoint: Number(rating).toFixed(1),
      deliveryPointTextColorFlag: true,
      deliveryStarCount: rating,
    });
  }

  // 세탁품질
  onPressWashStarRating(rating) {
    const { FeedbackAction } = this.props;
    FeedbackAction.setWashStarRating({
      washPoint: Number(rating).toFixed(1),
      washPointTextColorFlag: true,
      washStarCount: rating,
    });
  }

  setFeedback(feedback) {
    const { FeedbackAction } = this.props;
    FeedbackAction.setFeedback({ feedback });
  }

  setBadExperienceAnswerObject(index) {
    const { FeedbackState, FeedbackAction } = this.props;
    const cloneAnswerObj = _.cloneDeep(FeedbackState.badExperienceAnswerObject);

    const { textArr } = cloneAnswerObj;

    const newArr = [];
    textArr.map((obj, i) => {
      if (i === index) {
        obj.background = true;
        obj.onPress = false;
        newArr[0] = obj;
        return;
      }
    });

    cloneAnswerObj.textArr = newArr;

    FeedbackAction.setBadExperienceAnswerObject({
      badExperienceAnswerObject: cloneAnswerObj,
      isShowFeedbackInputOfBad: true,
    });
  }

  nextButtonPress = async () => {
    if (this.state.preventDuplicateClick) {
      return;
    }
    this.setState({ preventDuplicateClick: true });
    setTimeout(() => {
      this.setState({ preventDuplicateClick: false });
    }, 5000);
    const {
      text,
      order: { orderId },
    } = this.props;
    const { FeedbackState, FeedbackAction, OrderHistoryAction } = this.props;
    const {
      pickupStarCount,
      deliveryStarCount,
      washStarCount,
      feedback,
    } = FeedbackState;
    const starCountAverage = _.round(
      (pickupStarCount + deliveryStarCount + washStarCount) / 3,
    );
    const isActiveCompletionButton = feedback.length > 0;
    const {
      feedback_posivtive,
      feedback_negative,
      feedbackUpated_ios,
      feedbackUpated_android,
    } = FeedbackAfterOrderString;
    if (isActiveCompletionButton) {
      const _storage = $_storage.get();
      let feedbackIsRegist = _storage[KeyUtils.FEEDBACK_IS_REGIST];
      const uid = _storage[KeyUtils.USER_ID];

      if (starCountAverage > 3 && feedbackIsRegist !== 'true') {
        FeedbackAction.finished(orderId, () => {
          OrderHistoryAction.getOrderHistory();
          setTimeout(() => {
            this.onPressBack();
            FeedbackAction.anyAction({ isPending: false });
            WashAlert.showConfirm(
              Platform.OS === 'ios'
                ? feedbackUpated_ios
                : feedbackUpated_android,
              feedback_posivtive,
              feedback_negative,
              () => {
                $_storage.set(KeyUtils.FEEDBACK_IS_REGIST, 'true');
                if (Platform.OS === 'ios') {
                  Linking.openURL(
                    'itms-apps://itunes.apple.com/us/app/itunes-u/id1049236217?action=write-review',
                  );
                } else {
                  Linking.openURL('market://details?id=com.washswat.android');
                }
                AnalyticsManager.setAppsFlyerTrackEvent(
                  AnalyticsKey.NAME_REVIEW,
                  {
                    af_date: new Date(),
                    af_path: 'feedback',
                  },
                );
                AnalyticsManager.setAirbridgeTrackEvent(
                  AnalyticsKey.NAME_REVIEW,
                  Platform.OS,
                  uid,
                );
              },
            );
          }, 0);
        });
      } else {
        FeedbackAction.finished(orderId, () => {
          WashAlert.showAlertWithCallback(
            FeedbackAfterOrderString.feedbackUpated,
            Favorite.ok,
            () => {
              OrderHistoryAction.getOrderHistory();
              setTimeout(() => {
                this.onPressBack();
                FeedbackAction.anyAction({ isPending: false });
              }, 0);
            },
          );
        });
      }
      await AnalyticsManager.setAppsFlyerTrackEvent(
        AnalyticsKey.NAME_FEEDBACK,
        {
          // af_feedback: selectFeedback,
          af_pickup: pickupStarCount,
          af_delivery: deliveryStarCount,
          af_quality: washStarCount,
        },
      );
      AnalyticsManager.setAirbridgeTrackEvent(
        AnalyticsKey.NAME_FEEDBACK,
        Platform.OS,
        uid,
      );
    } else {
      if (pickupStarCount && deliveryStarCount && washStarCount) {
        FeedbackAction.setShowFeedbackInput({ isShowFeedbackInput: true });
      }
    }
  };

  render() {
    const FEEDBACK_GOOD = 'good';
    const FEEDBACK_BAD = 'bad';
    const {
      FeedbackState,
      FeedbackAction,
      OrderHistoryAction,
      order: { orderId },
      text,
      selectFeedback,
    } = this.props;
    const {
      pickupPoint,
      pickupPointTextColorFlag,
      pickupStarCount,
      deliveryPoint,
      deliveryPointTextColorFlag,
      deliveryStarCount,
      washPoint,
      washPointTextColorFlag,
      washStarCount,
      isShowFeedbackInput,
      isShowFeedbackInputOfBad,
      feedback,
      badExperienceAnswerObject,
      isPending,
    } = FeedbackState;
    const starCountAverage = _.round(
      (pickupStarCount + deliveryStarCount + washStarCount) / 3,
    );
    const isActiveCompletionButton = feedback.length > 0;
    const completionButtonTextColor = isActiveCompletionButton
      ? washswatColor.blue
      : washswatColor.grey_03;
    const toggleImage = this.state.badToggle
      ? require('image/feedback/radio_on.png')
      : require('image/feedback/radio_off.png');
    const {
      feedback_posivtive,
      feedback_negative,
      feedbackUpated_ios,
      feedbackUpated_android,
    } = FeedbackAfterOrderString;

    switch (text) {
      case FEEDBACK_GOOD:
        /* 주문경험 좋음 선택시 */
        return (
          <View style={{ flex: 1 }}>
            {isPending ? <LoadingBar /> : null}
            <View style={{ height: getStatusBarHeight(true) }} />
            <View
              style={{ flexDirection: 'row', justifyContent: 'space-between' }}
            >
              {/* x 버튼 */}
              <NBImageButton
                source={require('image/utils/no.png')}
                onPress={this.onPressBack}
              />
              {/* 완료 버튼 */}
              <NBTextButton
                onPress={() => this.nextButtonPress()}
                text={FeedbackAfterOrderString.completion}
                textColor={completionButtonTextColor}
                isHide={false}
                disabled={!isActiveCompletionButton}
              />
            </View>
            {/* 별점 후 피드백 입력 */}
            {isShowFeedbackInput ? (
              <View style={{ flex: 1 }}>
                {/* 별5개 */}
                <TouchableOpacity
                  onPress={this.onPressGoStarRating}
                  style={{ flex: 1 }}
                >
                  <View
                    style={{
                      flex: 1,
                      alignItems: 'center',
                      marginTop: PixelRatio.roundToNearestPixel(24),
                    }}
                  >
                    <StarRating
                      containerStyle={{
                        width: PixelRatio.roundToNearestPixel(156),
                      }}
                      disabled={true}
                      emptyStar={require('image/feedback/star_off.png')}
                      fullStar={require('image/feedback/star_on.png')}
                      starSize={PixelRatio.roundToNearestPixel(16)}
                      maxStars={5}
                      rating={starCountAverage}
                    />
                  </View>
                </TouchableOpacity>
                <View style={styles.feedbackGoodView}>
                  <TextInput
                    style={[
                      responseFont(16).regular,
                      {
                        flex: 1,
                        color: washswatColor.black,
                        lineHeight: PixelRatio.roundToNearestPixel(24),
                        textAlignVertical: 'top',
                      },
                    ]}
                    placeholder={
                      FeedbackGoodExperienceSelectionString.placeholderText
                    }
                    placeholderTextColor={washswatColor.grey_02}
                    multiline={true}
                    autoFocus={true}
                    onChangeText={feedback => {
                      this.setFeedback(feedback);
                    }}
                  />
                  {/* 보너스 포인트 */}
                  {/*<View style={{ position: 'absolute', alignSelf: 'center', marginTop: PixelRatio.roundToNearestPixel(160) }}>*/}
                  {/*  <View style={styles.bonusPointView}>*/}
                  {/*    <Text style={[washswatFont.Text12CamptonBoldDEMO, { color: washswatColor.white }]}>BONUS 50P</Text>*/}
                  {/*  </View>*/}
                  {/*</View>*/}
                </View>
                <KeyboardSpacerIOS />
              </View>
            ) : (
              <ScrollView>
                <View
                  style={{
                    flex: 1,
                    paddingStart: PixelRatio.roundToNearestPixel(30),
                    paddingEnd: PixelRatio.roundToNearestPixel(30),
                  }}
                >
                  <ChatView
                    textObj={FeedbackGoodExperienceSelectionString.question}
                  />
                </View>
                <View style={styles.starPointView}>
                  <FeedbackAfterOrderView
                    serviceName={FeedbackAfterOrderString.pickupService}
                    servicePoint={pickupPoint}
                    servicePointTextColorFlag={pickupPointTextColorFlag}
                    starCount={pickupStarCount}
                    onStarRatingPress={rating =>
                      this.onPressPickupStarRating(rating)
                    }
                  />
                  <FeedbackAfterOrderView
                    serviceName={FeedbackAfterOrderString.deliveryService}
                    servicePoint={deliveryPoint}
                    servicePointTextColorFlag={deliveryPointTextColorFlag}
                    starCount={deliveryStarCount}
                    onStarRatingPress={rating =>
                      this.onPressDeliveyStarRating(rating)
                    }
                  />
                  <FeedbackAfterOrderView
                    serviceName={FeedbackAfterOrderString.washQuality}
                    servicePoint={washPoint}
                    servicePointTextColorFlag={washPointTextColorFlag}
                    starCount={washStarCount}
                    onStarRatingPress={rating =>
                      this.onPressWashStarRating(rating)
                    }
                  />
                </View>
              </ScrollView>
            )}
          </View>
        );
        break;
      case FEEDBACK_BAD:
        /* 주문경험 나쁨 선택시 */
        return (
          <View style={{ flex: 1 }}>
            <View style={{ height: getStatusBarHeight(true) }} />
            <View style={{ flexDirection: 'row' }}>
              {/* x 버튼 */}
              <NBImageButton
                source={require('image/utils/no.png')}
                onPress={this.onPressBack}
              />
              <View style={{ flex: 1 }} />
              {/* 완료 버튼 */}
              <NBTextButton
                onPress={() => {
                  if (isActiveCompletionButton) {
                  }
                }}
                text={FeedbackAfterOrderString.completion}
                textColor={completionButtonTextColor}
                isHide={!isShowFeedbackInputOfBad}
              />
            </View>
            {/* 별점 후 피드백 입력 */}
            {isShowFeedbackInputOfBad ? (
              <View style={{ flex: 1 }}>
                <View
                  style={{
                    flex: 1,
                    paddingStart: PixelRatio.roundToNearestPixel(30),
                    paddingEnd: PixelRatio.roundToNearestPixel(30),
                  }}
                >
                  <AnswerChatView
                    textObj={badExperienceAnswerObject}
                    onPress={() => {}}
                    activeOpacity={1}
                  />
                </View>
                <View style={styles.feedbackBadView}>
                  <TextInput
                    style={[
                      responseFont(16).regular,
                      {
                        flex: 1,
                        color: washswatColor.black,
                        lineHeight: PixelRatio.roundToNearestPixel(24),
                        textAlignVertical: 'top',
                      },
                    ]}
                    placeholder={
                      FeedbackGoodExperienceSelectionString.placeholderText
                    }
                    placeholderTextColor={washswatColor.grey_02}
                    multiline={true}
                    autoFocus={true}
                    onChangeText={feedback => {
                      this.setFeedback(feedback);
                    }}
                  />
                </View>
                <View
                  style={{
                    height: PixelRatio.roundToNearestPixel(36),
                    flexDirection: 'row',
                    alignItems: 'center',
                    backgroundColor: washswatColor.grey_06,
                  }}
                >
                  <TouchableOpacity onPress={this.toggleSendFeedback}>
                    <Image
                      source={toggleImage}
                      style={{
                        width: PixelRatio.roundToNearestPixel(16),
                        height: PixelRatio.roundToNearestPixel(16),
                        marginStart: PixelRatio.roundToNearestPixel(30),
                      }}
                    />
                  </TouchableOpacity>
                  <Text
                    style={[
                      responseFont(13).regular,
                      {
                        textAlign: 'center',
                        color: washswatColor.black,
                        marginStart: PixelRatio.roundToNearestPixel(9),
                      },
                    ]}
                  >
                    {FeedbackBadExperienceSelectionString.transmissionText}
                  </Text>
                </View>
                <KeyboardSpacerIOS />
              </View>
            ) : (
              <ScrollView>
                <View
                  style={{
                    flex: 1,
                    paddingStart: PixelRatio.roundToNearestPixel(30),
                    paddingEnd: PixelRatio.roundToNearestPixel(30),
                  }}
                >
                  <ChatView
                    textObj={FeedbackBadExperienceSelectionString.question}
                  />
                  <AnswerChatView
                    textObj={badExperienceAnswerObject}
                    onPress={(index, i) => {
                      this.setBadExperienceAnswerObject(i);
                    }}
                  />
                </View>
              </ScrollView>
            )}
          </View>
        );
        break;
    }
  }
}

const styles = StyleSheet.create({
  speechBubble: {
    flexDirection: 'row',
    marginTop: PixelRatio.roundToNearestPixel(24),
    marginStart: PixelRatio.roundToNearestPixel(30),
    marginEnd: PixelRatio.roundToNearestPixel(30),
  },
  starPointView: {
    marginTop: PixelRatio.roundToNearestPixel(48),
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
  },
  feedbackGoodView: {
    height: PixelRatio.roundToNearestPixel(207),
    padding: PixelRatio.roundToNearestPixel(30),
    backgroundColor: washswatColor.white,
    ...Platform.select({
      ios: {
        shadowColor: washswatColor.black,
        shadowOffset: {
          width: PixelRatio.roundToNearestPixel(0),
          height: PixelRatio.roundToNearestPixel(0),
        },
        shadowOpacity: 0.16,
        shadowRadius: PixelRatio.roundToNearestPixel(30),
      },
      android: {
        elevation: 5,
      },
    }),
  },
  bonusPointView: {
    width: PixelRatio.roundToNearestPixel(94),
    height: PixelRatio.roundToNearestPixel(24),
    backgroundColor: washswatColor.red,
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      ios: {
        shadowColor: washswatColor.black,
        shadowOffset: {
          width: PixelRatio.roundToNearestPixel(0),
          height: PixelRatio.roundToNearestPixel(6),
        },
        shadowOpacity: 0.14,
        shadowRadius: PixelRatio.roundToNearestPixel(10),
      },
      android: {
        elevation: 5,
      },
    }),
  },
  feedbackBadView: {
    height: PixelRatio.roundToNearestPixel(171),
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(30),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(18),
    marginTop: PixelRatio.roundToNearestPixel(7),
    backgroundColor: washswatColor.white,
    ...Platform.select({
      ios: {
        shadowColor: washswatColor.black,
        shadowOffset: {
          width: PixelRatio.roundToNearestPixel(0),
          height: PixelRatio.roundToNearestPixel(0),
        },
        shadowOpacity: 0.16,
        shadowRadius: PixelRatio.roundToNearestPixel(30),
      },
      android: {
        elevation: 5,
      },
    }),
  },
});

/** redux module */
const mapStateToProps = ({ FeedbackModule }) => ({
  FeedbackState: FeedbackModule,
});
const mapDispatchToProps = dispatch => ({
  FeedbackAction: bindActionCreators(FeedbackModule, dispatch),
  OrderHistoryAction: bindActionCreators(OrderHistoryModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(FeedbackAfterOrder);
