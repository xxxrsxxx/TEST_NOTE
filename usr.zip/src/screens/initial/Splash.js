import React from 'react';
import {
  AppState,
  Dimensions,
  Image,
  Linking,
  Platform,
  StatusBar,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import DeviceInfo from 'react-native-device-info';
import { ChannelIO } from 'react-native-channel-plugin';
import codePush from 'react-native-code-push';
import appsFlyer from 'react-native-appsflyer';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as LoginActions from '../../reducers/LoginModule';
import * as StatusModule from '../../reducers/StatusModule';
import UpdatePopup from '../../components/initial/UpdatePopup';
import * as Keys from '../../utils/type/key';
import { Font } from '../../utils/style';

import moment from 'moment-timezone';
import 'moment/locale/ko';
import { install } from '../../static/settings';
moment.tz.setDefault('Asia/Seoul');
const { washswatColor } = Font;

const _window = Dimensions.get('window');

class Splash extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      syncStatus: '',
      progress: null,
      appState: AppState.currentState,
      codePushStatus: '',
    };
  }

  setAppsFlyer = () => {
    this.onInstallConversionDataCanceller = appsFlyer.onInstallConversionData(
      res => {
        if (
          res &&
          res.data &&
          res.data.is_first_launch &&
          JSON.parse(res.data.is_first_launch) == true
        ) {
          if (res.data.af_status === 'Non-organic') {
            var media_source = res.data.media_source;
            var campaign = res.data.campaign;
            console.log(
              'This is first launch and a Non-Organic install. Media source: ' +
                media_source +
                ' Campaign: ' +
                campaign,
            );
          } else if (res.data.af_status === 'Organic') {
            console.log('This is first launch and a Organic Install');
          }
        } else {
          console.log('This is not first launch');
        }
      },
    );
    this.onAppOpenAttributionCanceller = appsFlyer.onAppOpenAttribution(
      data => {
        if (data && data.status && data.status === 'success') {
          const { link } = data.data;
          if (link) {
            $_storage.set(Keys.DEEP_LINK_URL, link);
          }
        }
      },
    );
  };

  unsetAppsFlyer = () => {
    if (this.onInstallConversionDataCanceller) {
      this.onInstallConversionDataCanceller();
    }
    if (this.onAppOpenAttributionCanceller) {
      this.onAppOpenAttributionCanceller();
    }
  };

  componentDidMount = async () => {
    /**
     * @dsc 초기 설정.
     */
    await install();
    /**
     * @dsc 리덕스 status 확장
     */
    const { StatusState, StatusActions } = this.props;
    $_status.state = StatusState;
    $_status.actions = StatusActions;
    await $_status.actions.statusHandler(`env:${$_ENVMODE}`);
    /**
     * @name $_axios.init()
     * @dsc $_axios 초기화
     */
    await $_axios.init();

    this.setAppsFlyer();
    this.handleOfflineStatus();
    AppState.addEventListener('change', this._handleAppStateChange);
  };

  handleOfflineStatus = () => {
    const { LoginAction } = this.props;
    try {
      codePush.sync({
        checkFrequency: codePush.CheckFrequency.ON_APP_RESUME,
        installMode: codePush.InstallMode.ON_NEXT_RESTART,
        mandatoryInstallMode: codePush.InstallMode.ON_NEXT_RESTART,
        rollbackRetryOptions: {
          delayInHours: 3,
          maxRetryAttempts: 2,
        },
        syncStatusChangeCallback: this.syncStatusChangeCallback,
        downloadProgressCallback: this.downloadProgressCallback,
      });
    } catch (e) {}
    LoginAction.handleCheckNetwork(this.checkCodePush);
  };

  syncStatusChangeCallback = status => {
    switch (status) {
      case codePush.SyncStatus.CHECKING_FOR_UPDATE:
        console.log('Checking for updates.');
        break;
      case codePush.SyncStatus.DOWNLOADING_PACKAGE:
        console.log('Downloading package.');
        break;
      case codePush.SyncStatus.INSTALLING_UPDATE:
        console.log('Installing update.');
        break;
      case codePush.SyncStatus.UP_TO_DATE:
        console.log('Up-to-date.');
        break;
      case codePush.SyncStatus.UPDATE_INSTALLED:
        console.log('Update installed.');
        break;
    }
  };

  downloadProgressCallback = () => {};

  checkCodePush = () => {
    setTimeout(() => {
      this.doAction();
    }, 500);
  };

  componentWillUnmount = async () => {
    // await FirebaseUnMount();
    AppState.removeEventListener('change', this._handleAppStateChange);
    this.unsetAppsFlyer();
    const { LoginAction } = this.props;
    LoginAction.initUpdatePopup({ updateHard: false, updateSelect: false });
  };

  _handleAppStateChange = nextAppState => {
    console.log('nextAppState', nextAppState);

    if (
      this.state.appState.match(/active|foreground/) &&
      nextAppState === 'background'
    ) {
      this.unsetAppsFlyer();
    }
    if (
      this.state.appState.match(/inactive|background/) &&
      nextAppState === 'active'
    ) {
      this.setAppsFlyer();
      // if (Platform.OS === 'ios') {
      //   appsFlyer.trackAppLaunch();
      // }
    }
    this.setState({ appState: nextAppState });
  };

  doAction = async () => {
    const { componentId, LoginAction } = this.props;
    const _storage = await $_storage.get();
    // var uid = '16048';
    const uid = _storage[Keys.USER_ID];
    try {
      const url = await Linking.getInitialURL();
      if (url) {
        /** deepLink 타고 들어온 경우는 항상 저장 **/
        $_storage.set(Keys.DEEP_LINK_URL, url);
      }
    } catch (e) {}
    if (uid) {
      // await FirebaseMount(false);
      const name = _storage[Keys.USER_NAME];
      const userType = _storage[Keys.USER_TYPE];
      const phone = _storage[Keys.PHONE_NUMBER];
      const versionCode = DeviceInfo.getBuildNumber();

      // try {
      //   await ChannelIO.boot({
      //     pluginKey: 'ee01b6fb-0906-442a-97c3-89e744c3618b',
      //     userId: uid,
      //     locale: 'ko',
      //     profile: {
      //       name,
      //       mobileNumber: phone,
      //     },
      //   });
      // } catch (e) {}
      LoginAction.getGlobalData({
        uid,
        goToRoot: true,
        versionCode,
        callback: err => {
          if (err) {
            goLogin(componentId);
          }
        },
      });
    } else {
      goLogin(componentId);
    }
  };

  getSplashImageSource = () => {
    if (Platform.OS === 'android') {
      return require('../../../assets/image/splash/splash.gif');
    }
    const splashes = [
      {
        height: 480,
        source: require('../../../assets/image/splash/splash320x480.gif'),
        scale: 2,
      },
      {
        height: 812,
        source: require('../../../assets/image/splash/splash375x812.gif'),
        scale: 2,
      },
      {
        height: 960,
        source: require('../../../assets/image/splash/splash640x960.gif'),
        scale: 2,
      },
      {
        height: 1136,
        source: require('../../../assets/image/splash/splash640x1136.gif'),
        scale: 2,
      },
      {
        height: 1334,
        source: require('../../../assets/image/splash/splash750x1334.gif'),
        scale: 2,
      },
      {
        height: 1792,
        source: require('../../../assets/image/splash/splash828x1792.gif'),
        scale: 2,
      },
      {
        height: 2208,
        source: require('../../../assets/image/splash/splash1242x2208.gif'),
        scale: 3,
      },
      {
        height: 2436,
        source: require('../../../assets/image/splash/splash1125x2436.gif'),
        scale: 3,
      },
      {
        height: 2688,
        source: require('../../../assets/image/splash/splash1242x2688.gif'),
        scale: 3,
      },
    ];
    for (const splash of splashes) {
      const { height, source } = splash;
      if (_window.height * _window.scale <= height) {
        return source;
      }
    }
    return require('../../../assets/image/splash/splash.gif');
  };

  static options(passProps) {
    return {
      statusBar: {
        visible: true,
        backgroundColor: washswatColor.black,
        style: 'dark',
      },
      layout: {
        backgroundColor: washswatColor.black,
      },
    };
  }

  render() {
    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.black }}>
        <StatusBar />
        <Image
          style={{ width: `100%`, height: `100%` }}
          source={this.getSplashImageSource()}
          resizeMode={'cover'}
        />
        <UpdatePopup />
      </View>
    );
  }
}

function goLogin(componentId) {
  /** 로그인 화면 **/
  Navigation.push(componentId, {
    component: {
      name: 'Login',
      animated: true, // does the push have transition animation or does it happen immediately (optional)
      animationType: 'fade',
    },
  });
}

const mapStateToProps = ({ LoginModule, StatusModule }) => ({
  LoginState: LoginModule,
  StatusState: StatusModule,
});
const mapDispatchToProps = dispatch => ({
  LoginAction: bindActionCreators(LoginActions, dispatch),
  StatusActions: bindActionCreators(StatusModule, dispatch),
});

let Component;
const options = {
  checkFrequency: codePush.CheckFrequency.ON_APP_RESUME,
  installMode: codePush.InstallMode.ON_NEXT_RESTART,
  mandatoryInstallMode: codePush.InstallMode.ON_NEXT_RESTART,
};

// if(__DEV__){
export default connect(mapStateToProps, mapDispatchToProps)(Splash);
// }else{
//   Component = connect( mapStateToProps, mapDispatchToProps )(codePush(options)(Splash));
// }

// export default connect( mapStateToProps, mapDispatchToProps )(codePush(options)(Splash));
