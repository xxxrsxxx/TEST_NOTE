import React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Image,
  Platform,
} from 'react-native';

import { previewString } from '../../../utils/common/strings';
import { Font, Styles } from '../../../utils/style';

const { washswatColor, responseFont, verticalScale } = Font;

const { width } = Dimensions.get('window');

const ThirdPreview = ({ showNextPreview }) => {
  return (
    <View style={styles.container}>
      <View style={[styles.upper, { width: width }]}>
        <View style={styles.picker}>
          <Image
            source={require('../../../../assets/image/main/preview_icon.png')}
            style={{ width: verticalScale(134), height: verticalScale(80) }}
          />
          <Text style={styles.title}>{previewString.thirdText}</Text>
        </View>
      </View>
      <View style={styles.lower}>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={showNextPreview}>
            <Text style={styles.buttonText}>{previewString.nextText}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  upper: {
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom: verticalScale(20),
    flex: 3.5,
  },
  picker: {
    marginTop: verticalScale(90),
    ...Platform.select({
      android: {
        alignItems: 'center',
      },
    }),
  },
  lower: {
    flex: 6.5,
    paddingTop: verticalScale(59),
    justifyContent: 'flex-end',
  },
  title: {
    textAlign: 'center',
    ...responseFont(24).regular,
    color: washswatColor.white,
  },
  buttonContainer: {
    paddingTop: 50,
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      android: {
        paddingBottom: verticalScale(Styles.androidStatusBar),
      },
      ios: {
        paddingBottom: verticalScale(43),
      },
    }),
  },
  button: {
    paddingTop: 10,
    paddingBottom: 10,
    width: 100,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    ...responseFont(18).bold,
  },
});

export default ThirdPreview;
