import React from 'react';
import {
  Text,
  TouchableOpacity,
  View,
  StyleSheet,
  Dimensions,
  Platform,
} from 'react-native';

import { previewString } from '../../../utils/common/strings';
import { Font, Styles } from '../../../utils/style';

const { washswatColor, responseFont, verticalScale } = Font;
const { width, height } = Dimensions.get('window');

const FourthPreview = ({ showNextPreview }) => {
  return (
    <View style={styles.container}>
      <View style={[styles.upper, { width: width }]}>
        <View style={styles.menuContainer}>
          <View style={styles.menu}>
            <View style={styles.line}></View>
            <View
              style={[styles.line, { marginTop: 4, marginBottom: 4 }]}
            ></View>
            <View style={styles.line}></View>
          </View>
        </View>

        <View style={styles.titleWrap}>
          <Text style={styles.title}>{previewString.fourthText1}</Text>
          <Text style={styles.title}>{previewString.fourthText2}</Text>
        </View>
      </View>
      <View style={styles.lower}>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={showNextPreview}>
            <Text style={styles.buttonText}>{previewString.closeButton}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    flex: 1,
  },
  menuContainer: {
    width: 68,
    height: 68,
    borderRadius: 34,
    borderWidth: 2,
    borderStyle: 'dotted',
    borderColor: washswatColor.white,
    position: 'absolute',
    top: 32,
    left: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  upper: {
    // justifyContent: 'flex-end',
    alignItems: 'flex-start',
    paddingBottom: 20,
    flex: 3.5,
  },
  lower: {
    flex: 6.5,
    paddingTop: 65,
    width: '100%',
    justifyContent: 'flex-end',
  },
  title: {
    textAlign: 'left',
    ...responseFont(24).regular,
    color: washswatColor.white,
    paddingBottom: 20,
    paddingLeft: 68,
  },
  titleWrap: {
    paddingTop: 70,
    paddingLeft: 30,
  },
  menu: {
    width: 48,
    height: 48,
    backgroundColor: washswatColor.white,
    borderRadius: 24,
    shadowColor: washswatColor.black,
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.18,
    shadowRadius: 12,
    elevation: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  line: {
    backgroundColor: '#000',
    width: 22,
    height: 3,
  },
  buttonContainer: {
    paddingTop: 50,
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      android: {
        paddingBottom: verticalScale(Styles.androidStatusBar),
      },
      ios: {
        paddingBottom: verticalScale(43),
      },
    }),
  },
  button: {
    paddingTop: 10,
    paddingBottom: 10,
    width: 100,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    ...responseFont(18).bold,
  },
});

export default FourthPreview;
