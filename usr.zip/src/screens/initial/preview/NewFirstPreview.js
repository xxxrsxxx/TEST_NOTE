import React from 'react';
import { View, Image, StyleSheet, Dimensions, PixelRatio } from 'react-native';

const NewFirstPreview = props => {
  return (
    <View style={styles.container}>
      <View style={styles.lower}>
        <View
          style={[
            styles.circleWrap,
            {
              width: 53,
              height: 53,
              borderRadius: 100,
            },
          ]}
        >
          <Image
            style={{
              position: 'absolute',
              bottom: 0,
              left: 0,
            }}
            source={require('../../../../assets/image/bottom-tab/order/ic_order_default.png')}
          />
        </View>
        <View style={styles.toolTipWrap}>
          <Image
            source={require('../../../../assets/image/start/tool_tip.png')}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
  },
  lower: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  circleWrap: {
    borderWidth: 2.5,
    borderColor: '#0076FF',
    alignItems: 'center',
    bottom: PixelRatio.roundToNearestPixel(58),
  },
  toolTipWrap: {
    position: 'absolute',
    bottom: PixelRatio.roundToNearestPixel(124),
  },
});

export default NewFirstPreview;
