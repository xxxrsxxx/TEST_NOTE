import React from 'react';

import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Platform,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

import { previewString } from '../../../utils/common/strings';
import { Font, Styles } from '../../../utils/style';

import moment from 'moment';

const { washswatColor, responseFont, verticalScale } = Font;
const { height } = Dimensions.get('window');

const FirstPreview = props => {
  const diameter = Styles.diameter;
  const firstPreviewText = moment().format('MM/DD (ddd)') + '\n23시 50분 - 7시';

  return (
    <View style={styles.container}>
      <View style={styles.upper}>
        <Text style={styles.title}>{previewString.firstText}</Text>
      </View>
      <View style={styles.lower}>
        <View
          style={[
            styles.circleContainer,
            {
              width: diameter + 40,
              height: diameter + 40,
              borderRadius: (diameter + 40) / 2,
            },
          ]}
        >
          <View
            style={[
              styles.circleWrap,
              { width: diameter, height: diameter, borderRadius: diameter / 2 },
            ]}
          >
            <LinearGradient
              colors={['rgba(98, 255, 177, 0.42)', 'rgba(39, 158, 217, 1)']}
              style={[
                {
                  width: diameter,
                  height: diameter,
                  borderRadius: diameter / 2,
                },
                styles.circle,
              ]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <Text
                style={[
                  styles.circleText,
                  height > 667 ? styles.bigText : styles.smallText,
                ]}
              >
                {firstPreviewText}
              </Text>
            </LinearGradient>
          </View>
          <View style={styles.emojiView}>
            <Text style={styles.emojiIcon}>{previewString.previewEmoji}</Text>
          </View>
        </View>
        <View
          style={[
            styles.buttonContainer,
            {
              marginBottom:
                Platform.OS === 'android'
                  ? verticalScale(Styles.androidStatusBar)
                  : verticalScale(43),
            },
          ]}
        >
          <TouchableOpacity
            style={styles.button}
            onPress={props.showNextPreview}
          >
            <Text style={styles.buttonText}>{previewString.nextText}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  upper: {
    justifyContent: 'flex-end',
    paddingBottom: 20,
    flex: 3.5,
  },
  lower: {
    paddingTop: verticalScale(72),
    flex: 6.5,
    justifyContent: 'space-between',
  },
  bigText: {
    ...responseFont(27).bold,
  },
  smallText: {
    ...responseFont(22).bold,
  },
  title: {
    textAlign: 'center',
    // marginBottom: PixelRatio.roundToNearestPixel(70),
    ...responseFont(24).regular,
    color: washswatColor.white,
  },
  circleContainer: {
    borderWidth: 2,
    borderColor: '#fff',
    borderStyle: 'dotted',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  circleText: {
    textAlign: 'center',
    color: washswatColor.white,
  },
  circleWrap: {
    backgroundColor: '#fff',
    position: 'relative',
  },
  circle: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    top: 0,
    left: 0,
    zIndex: 2,
  },
  emojiView: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 15,
    backgroundColor: washswatColor.grey_07,
    justifyContent: 'center',
    alignItems: 'center',
    bottom: 20,
    right: 20,
  },
  emojiIcon: {
    ...responseFont(24).regular,
    color: washswatColor.white,
  },
  buttonContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    paddingTop: 10,
    paddingBottom: 10,
    width: 100,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    ...responseFont(18).bold,
  },
});

export default FirstPreview;
