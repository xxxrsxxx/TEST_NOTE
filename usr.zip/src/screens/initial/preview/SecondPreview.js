import React from 'react';
import {
  Text,
  View,
  StyleSheet,
  PixelRatio,
  Dimensions,
  TouchableOpacity,
  Platform,
} from 'react-native';

import { previewString } from '../../../utils/common/strings';
import { Font, Styles } from '../../../utils/style';

const { washswatColor, responseFont, verticalScale } = Font;

const SecondPreview = ({ showNextPreview }) => {
  const diameter = Styles.diameter;

  return (
    <View style={styles.container}>
      <View style={styles.upper} />

      <View style={styles.lower}>
        <View
          style={[
            styles.circleContainer,
            {
              width: diameter + 42,
              height: diameter + 42,
              borderRadius: (diameter + 42) / 2,
            },
          ]}
        >
          <View
            style={[
              { width: diameter, height: diameter, borderRadius: diameter / 2 },
            ]}
          >
            <View></View>
          </View>

          <View style={styles.emojiContainer}>
            <Text style={styles.title}>{previewString.secondText}</Text>
            <View style={styles.emojiView}>
              <Text style={styles.emojiIcon}>{previewString.previewEmoji}</Text>
            </View>
          </View>
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={showNextPreview}>
            <Text style={styles.buttonText}>{previewString.nextText}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  upper: {
    justifyContent: 'flex-end',
    paddingBottom: 20,
    flex: 3.5,
  },
  lower: {
    flex: 6.5,
    paddingTop: verticalScale(72),
    justifyContent: 'space-between',
  },
  title: {
    textAlign: 'center',
    marginBottom: PixelRatio.roundToNearestPixel(70),
    ...responseFont(24).regular,
    color: washswatColor.white,
    position: 'absolute',
    right: -40,
    width: 150,
    top: -100,
  },
  circleContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    // borderColor:'red',
    // borderWidth:2,
    position: 'relative',
  },
  circleText: {
    textAlign: 'center',
    color: washswatColor.white,
    ...responseFont(27).bold,
  },
  // circle: {
  //     backgroundColor: '#000',
  //     borderRadius: 120,
  //     alignItems: 'center',
  //     justifyContent: 'center',
  //     position: 'relative',
  // },
  emojiContainer: {
    position: 'absolute',
    width: 82,
    height: 82,
    bottom: 12,
    right: 12,
    borderRadius: 15,
    borderStyle: 'dotted',
    borderWidth: 2,
    borderColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  emojiView: {
    width: 60,
    height: 60,
    borderRadius: 15,
    backgroundColor: washswatColor.grey_07,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emojiIcon: {
    ...responseFont(24).bold,
    color: washswatColor.white,
  },
  buttonContainer: {
    paddingTop: 50,
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      android: {
        paddingBottom: verticalScale(Styles.androidStatusBar),
      },
      ios: {
        paddingBottom: verticalScale(43),
      },
    }),
  },
  button: {
    paddingTop: 10,
    paddingBottom: 10,
    width: 100,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    ...responseFont(18).bold,
  },
});

export default SecondPreview;
