import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Linking,
  AppState,
  StatusBar,
  Text,
} from 'react-native';
import PropTypes from 'prop-types';
import { ChannelIO } from 'react-native-channel-plugin';
import { useDispatch, useSelector } from 'react-redux';
// modules import
import * as MainScreenModule from '../../reducers/MainScreenModule';
import * as BottomTabModule from '../../reducers/BottomTabModule';
// containers import
import {
  StickyHeaderContainer,
  MainServiceContainer,
  SubServiceContainer,
  ReviewBoardContainer,
  ContentsWrapper,
} from '../../containers/home';
// components import
import { ScrollTopButton } from '../../components/main';
// plugins import
import { moment } from '../../plugins';
import { MAIN_SCREEN_NAME } from '../../static/screen-name';
// utils import
import * as CommonUtils from '../../utils/common';
import {
  FeedbackAfterOrderString,
  HomeScreenString,
} from '../../utils/common/strings';
import { navPushWebViewScreen } from '../../utils/common/nav';
// styles import
import { Font, Styles } from '../../utils/style';
import { NewMainString } from '../../utils/common/strings';
import WashAlert from '../../utils/alert';
const { BOTTOM_TAB_BORDER_AREA_HEIGHT } = Styles;
const { responseFont } = Font;
moment.locale('ko');

function HomeScreen({ componentId, callbackUsingGlobalPending }) {
  const dispatch = useDispatch();
  const [appState, setAppState] = useState(AppState.currentState);
  const MainScreenState = useSelector(state => state.MainScreenModule);
  const { user } = $_status.state;
  const {
    pickup,
    mainData,
    deliveryDay,
    badge,
    scrollTopVisible,
  } = MainScreenState;
  const { appReview, appMenuConfig } = mainData;
  const getNewMainAPI = () => dispatch(MainScreenModule.getNewMainAPI());
  const onScrollTopEvent = () => dispatch(MainScreenModule.onScrollTopEvent());
  const setBadge = badge => dispatch(MainScreenModule.setBadge(badge));
  const handleDeepLinkUrl = props =>
    dispatch(MainScreenModule.handleDeepLinkUrl(props));
  const refreshPickup = () => dispatch(MainScreenModule.refreshPickup());
  const offScrollTopVisible = () =>
    dispatch(MainScreenModule.offScrollTopVisible());
  const setDeliveryDateTimeAPI = props =>
    dispatch(MainScreenModule.setDeliveryDateTimeAPI(props));
  const checkOrderStatus = props =>
    dispatch(BottomTabModule.checkOrderStatus(props));

  useEffect(() => {
    async function mount() {
      const { uid, name, userType, phone } = user;
      const isRequired = uid && name && userType && phone;
      if (!isRequired) return;

      _setChannelIO({ uid, name, phone, userType });
      AppState.addEventListener('change', _handleAppStateChange);
      await callbackUsingGlobalPending(getNewMainAPI);
      ChannelIO.onUrlClicked((link, next) => {
        if (link && link.indexOf('washios://') > -1) {
          ChannelIO.hideMessenger();
          _handleOpenURL({ url: link });
        } else {
          next();
        }
      });
      ChannelIO.hasStoredPushNotification().then(result => {
        if (result) {
          ChannelIO.openStoredPushNotification();
        }
      });
    }

    async function unmount() {
      offScrollTopVisible();
      Linking.removeEventListener('url', _handleOpenURL);
      // ChannelIO.hide(true);
      // await FirebaseUnMount();
      // if (onClickChatLinkListener) {
      //   onClickChatLinkListener.remove();
      // }
      // this.commandCompletedListener.remove();
      // ChannelIO.shutdown();
      AppState.removeEventListener('change', _handleAppStateChange);
    }

    mount();

    return () => {
      unmount();
    };
  }, []);

  useEffect(() => {
    setDeliveryDateTimeAPI({ pickup });
  }, [pickup]);

  const _setChannelIO = props => {
    const { uid, name, phone, userType } = props;

    ChannelIO.boot({
      pluginKey: 'ee01b6fb-0906-442a-97c3-89e744c3618b',
      memberId: uid.toString(),
      locale: 'ko',
      profile: {
        name,
        mobileNumber: phone,
        레벨: userType,
      },
    })
      .then(result => {
        StatusBar.setBarStyle('dark-content');
      })
      .catch(e => {});

    ChannelIO.onBadgeChanged(badge => {
      console.log('onBadgeChanged : ', badge);
      setBadge(badge);
    }); //do something with push data
    ChannelIO.hideChannelButton(false);
    Linking.addEventListener('url', _handleOpenURL);
  };

  const _handleOpenURL = event => {
    if (event && event.url) {
      const { url } = event;
      handleDeepLinkUrl({ componentId, url });
    }
  };

  const _handleAppStateChange = nextAppState => {
    if (appState.match(/inactive|background/) && nextAppState === 'active') {
      if (pickup && pickup.pickupTime) {
        if (moment(pickup.pickupTime) < moment()) {
          refreshPickup();
        }
      }
    }
    setAppState(nextAppState);
  };

  const onPressService = serviceInfo => {
    if (serviceInfo.type === 'app') {
      const passProps = {
        ...serviceInfo.passProps,
        title: serviceInfo.title,
      };
      CommonUtils.navPush({
        componentId,
        name: serviceInfo.navName,
        passProps,
      });
    } else if (serviceInfo.type === 'url') {
      const passProps = {
        option: {
          title: serviceInfo.title,
          url: serviceInfo.url,
          cta: {
            anchor: HomeScreenString.order,
            anchorScreen: MAIN_SCREEN_NAME,
            cbAction: cbComponentId => {
              CommonUtils.pop(cbComponentId);
              checkOrderStatus({ componentId });
            },
          },
        },
      };
      navPushWebViewScreen({ componentId, passProps });
    }
  };

  return (
    <View style={styles.container}>
      <StickyHeaderContainer componentId={componentId} badge={badge} />
      <ContentsWrapper
        componentId={componentId}
        contentsStyle={styles.paddingStyle}
      >
        <>
          <MainServiceContainer
            style={styles.paddingStyle}
            componentId={componentId}
            MainScreenState={MainScreenState}
            globalData={user}
            mainServiceInfoList={appMenuConfig.main}
            deliveryDay={deliveryDay}
            onPressService={onPressService}
          />
          <SubServiceContainer
            style={styles.paddingStyle}
            subServiceInfoList={appMenuConfig.sub}
            onPressService={onPressService}
          />
          <ReviewBoardContainer
            style={styles.paddingStyle}
            appReview={appReview}
          />
          <View style={[styles.title, styles.paddingStyle]}>
            <Text
              style={styles.titleText}
            >{`${NewMainString.contentsTitle}`}</Text>
          </View>
        </>
      </ContentsWrapper>
      {scrollTopVisible && (
        <ScrollTopButton
          style={styles.scrollTopBtn}
          onPress={onScrollTopEvent}
        />
      )}
    </View>
  );
}

HomeScreen.defaultProps = {
  componentId: '0',
  callbackUsingGlobalPending: () => {},
};

HomeScreen.propTypes = {
  componentId: PropTypes.string.isRequired,
  callbackUsingGlobalPending: PropTypes.func,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginBottom: BOTTOM_TAB_BORDER_AREA_HEIGHT,
  },
  paddingStyle: {
    paddingLeft: 24,
    paddingRight: 24,
  },
  scrollTopBtn: {
    position: 'absolute',
    bottom: 24,
    right: 24,
  },
  title: {
    marginBottom: 16,
  },
  titleText: {
    ...responseFont(16).bold,
  },
});

export default HomeScreen;
