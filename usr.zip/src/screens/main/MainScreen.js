import React, { useEffect, useState } from 'react';
import {
  BackHandler,
  Platform,
  StyleSheet,
  View,
  StatusBar,
} from 'react-native';
import PropTypes from 'prop-types';
import { Navigation } from 'react-native-navigation';
import { useSelector, useDispatch } from 'react-redux';
import { request, PERMISSIONS } from 'react-native-permissions';
// modules import
import * as MainScreenModule from '../../reducers/MainScreenModule';
import * as OrderHistoryModule from '../../reducers/OrderHistoryModule';
import * as BottomTabModule from '../../reducers/BottomTabModule';
import * as StatusModule from '../../reducers/StatusModule';
// layouts import
import { BottomTabLayout } from '../../layouts';
// screens import
import HomeScreen from '../home/HomeScreen';
import JoinMember from '../membership/JoinMember';
import OrderHistoryScreen from '../order/OrderHistoryScreen';
import MyPageScreen from '../mypage/MyPageScreen';
// containers import
import PreviewContainer from '../../containers/preview/PreviewContainer';
// components import
import LoadingBar from '../../components/common/button/LoadingBar';
import BottomModalComponent from '../../components/common/modal/BottomModalComponent';
import MainPopup from '../../components/main/MainPopup';
import DebugFixedContainer from '../../containers/common/debug/DebugFixedContainer';
// utils import
import { FirebaseMount, FirebaseUnMount } from '../../utils/firebase/index';
import AnalyticsManager from '../../utils/tagging/analytics';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import * as CommonUtils from '../../utils/common';
import WashAlert from '../../utils/alert';
import * as Keys from '../../utils/type/key';
// static import
import {
  HOME_SCREEN_NAME,
  ORDER_HISTORY_SCREEN_NAME,
  JOIN_MEMBER_SCREEN_NAME,
  MY_PAGE_SCREEN_NAME,
  ORDER_CHAT_SCREEN_NAME,
} from '../../static/screen-name';
// style import
import { Font, Styles } from '../../utils/style';

const { washswatColor } = Font;
const { STATUSBAR_HEIGHT } = Styles;

function MainScreen({ componentId, notification }) {
  const dispatch = useDispatch();
  const [view, setView] = useState(null);
  const [subView, setSubView] = useState(null);
  const MainScreenState = useSelector(state => state.MainScreenModule);
  const BottomTabState = useSelector(state => state.BottomTabModule);
  const StatusState = useSelector(state => state.StatusModule);
  const { confirmDialogData, mainData, subScreenState } = MainScreenState;
  const { currentScreenName } = BottomTabState;
  const { isPending } = StatusState;
  let statusBarColor = washswatColor.white;
  const subScreenTag = {
    tooltip: 'tooltip',
    popup: 'popup',
  };

  const setSubScreenState = props =>
    dispatch(MainScreenModule.setSubScreenState(props));
  const setPopupDisable = popup =>
    dispatch(MainScreenModule.setPopupDisable(popup));
  const popupClose = () => dispatch(MainScreenModule.popupClose());
  const onScrollTopEvent = () => dispatch(MainScreenModule.onScrollTopEvent());
  const callbackUsingGlobalPending = callback =>
    dispatch(StatusModule.callbackUsingGlobalPending(callback));
  const getOrderHistory = () => dispatch(OrderHistoryModule.getOrderHistory());
  const setCurrentTab = currentScreenName =>
    dispatch(BottomTabModule.setCurrentTab(currentScreenName));
  const checkOrderStatus = props =>
    dispatch(BottomTabModule.checkOrderStatus(props));

  useEffect(() => {
    const mount = async () => {
      const isPreview = await CommonUtils.getValue(Keys.IS_PREVIEW);
      request(PERMISSIONS.IOS.APP_TRACKING_TRANSPARENCY).then(result => {});
      if (isPreview) setSubScreenState(subScreenTag.popup);
      else setSubScreenState(subScreenTag.tooltip);
    };

    const screenAppearEventListener = Navigation.events().registerComponentDidAppearListener(
      async ({ componentId, componentName, passProps }) => {
        await FirebaseMount(true, notification);
        if (Platform.OS === 'android') {
          BackHandler.addEventListener('hardwareBackPress', handleBackButton);
        }
      },
    );

    const screenDisappearEventListener = Navigation.events().registerComponentDidDisappearListener(
      ({ componentId, componentName }) => {
        FirebaseUnMount();
        if (Platform.OS === 'android') {
          BackHandler.removeEventListener(
            'hardwareBackPress',
            handleBackButton,
          );
        }
      },
    );

    mount();

    return () => {
      screenDisappearEventListener.remove();
      screenAppearEventListener.remove();
    };
  }, []);

  useEffect(() => {
    if (currentScreenName) {
      switch (currentScreenName) {
        case ORDER_HISTORY_SCREEN_NAME:
          setView(
            <OrderHistoryScreen
              componentId={componentId}
              callbackUsingGlobalPending={callbackUsingGlobalPending}
            />,
          );
          break;
        case MY_PAGE_SCREEN_NAME:
          setView(<MyPageScreen componentId={componentId} />);
          break;
        case JOIN_MEMBER_SCREEN_NAME:
          setView(<JoinMember componentId={componentId} />);
          break;
        default:
          setView(
            <HomeScreen
              componentId={componentId}
              callbackUsingGlobalPending={callbackUsingGlobalPending}
            />,
          );
      }
    }
  }, [currentScreenName]);

  useEffect(() => {
    if (subScreenState) {
      switch (subScreenState) {
        case subScreenTag.tooltip:
          setSubView(
            <PreviewContainer
              componentId={componentId}
              onNextState={() => {
                setSubScreenState(subScreenTag.popup);
              }}
            />,
          );
          break;
        case subScreenTag.popup:
          setSubView(
            <MainPopup
              popup={
                mainData && mainData.popup && mainData.popup.length !== 0
                  ? mainData.popup
                  : null
              }
              onPressNever={data => setPopupDisable(data)}
              onPressImage={onPressAction}
              onPressClose={popupClose}
            />,
          );
          break;
        default:
          setSubView(null);
      }
    }
  }, [subScreenState, mainData]);

  const handleBackButton = () => {
    const { currentScreenName } = BottomTabState;
    if (currentScreenName != HOME_SCREEN_NAME) {
      setCurrentTab(HOME_SCREEN_NAME);
    } else {
      if (!this.exitApp) {
        WashAlert.showToast('한번 더 누르시면 종료됩니다');
        // ToastAndroid.show('한번 더 누르시면 종료됩니다.', ToastAndroid.SHORT);
        this.exitApp = true;
        this.timeout = setTimeout(() => {
          this.exitApp = false;
        }, 2000);
      } else {
        clearTimeout(this.timeout);
        BackHandler.exitApp(); // 앱 종료
      }
    }
    return true;
  };

  const onPressTab = async screenName => {
    if (screenName == ORDER_CHAT_SCREEN_NAME) {
      checkOrderStatus({ componentId });
      return;
    }
    switch (screenName) {
      case HOME_SCREEN_NAME:
        if (BottomTabState.currentScreenName == screenName) {
          onScrollTopEvent();
          return;
        }
        break;
      case ORDER_HISTORY_SCREEN_NAME:
        getOrderHistory();
        break;
      case MY_PAGE_SCREEN_NAME:
        break;
      case JOIN_MEMBER_SCREEN_NAME:
        break;
      default:
        break;
    }
    setCurrentTab(screenName);
  };

  const onPressAction = async ({ type, url }) => {
    if (url) {
      const { uid } = StatusState.user;
      CommonUtils.navShowModalWebView({ url });
      await AnalyticsManager.setAppsFlyerTrackEvent(
        AnalyticsKey.NAME_HOME_BANNER,
        {
          af_url: url,
        },
      );
      AnalyticsManager.setAirbridgeTrackEvent(
        AnalyticsKey.NAME_HOME_BANNER,
        Platform.OS,
        uid,
      );
    }
  };

  return (
    <View style={styles.container}>
      <View
        style={[styles.statusBar, { backgroundColor: washswatColor.white }]}
      >
        <StatusBar
          backgroundColor={washswatColor.white}
          barStyle="dark-content"
        />
      </View>
      {isPending ? <LoadingBar /> : null}
      <BottomTabLayout
        componentId={componentId}
        onPressTab={onPressTab}
        barStyle={'dark-content'}
        statusBarColor={statusBarColor}
      >
        {view}
      </BottomTabLayout>
      {subView}
      <BottomModalComponent
        isOpen={confirmDialogData && true}
        contentView={confirmDialogData && confirmDialogData.contentView}
        leftButtonText={confirmDialogData && confirmDialogData.leftButtonText}
        rightButtonText={confirmDialogData && confirmDialogData.rightButtonText}
        height={confirmDialogData && confirmDialogData.height}
        onClosed={confirmDialogData && confirmDialogData.onClosed}
        onLeftButtonClicked={
          confirmDialogData && confirmDialogData.onLeftButtonClicked
        }
        onRightButtonClicked={
          confirmDialogData && confirmDialogData.onRightButtonClicked
        }
      />
      {$_status.state.debugMode && <DebugFixedContainer />}
    </View>
  );
}

MainScreen.defaultProps = {
  componentId: '0',
  notification: null,
};

MainScreen.propTypes = {
  componentId: PropTypes.string,
  notification: PropTypes.object,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  statusBar: {
    height: STATUSBAR_HEIGHT,
    backgroundColor: washswatColor.white,
  },
});

export default MainScreen;
