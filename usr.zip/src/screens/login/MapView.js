import React from 'react';
import {
  Animated,
  BackHandler,
  Dimensions,
  FlatList,
  Image,
  Keyboard,
  PixelRatio,
  Platform,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import DropdownAlert from 'react-native-dropdownalert';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as LoginActions from '../../reducers/LoginModule';
import * as ChangeAddressModule from '../../reducers/ChangeAddressModule';

import NBImageButton from '../../components/common/button/NBImageButton';
import { JoinTimer } from '../../components/common/button/CommonComponent';
import ListItem from '../../components/login/ListItem';

import { Favorite, mapString } from '../../utils/common/strings';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import AnalyticsManager from '../../utils/tagging/analytics';
import * as CommonUtils from '../../utils/common';
import * as KeyUtils from '../../utils/type/key';
import { Font } from '../../utils/style';
import WashAlert from '../../utils/alert';

const { washswatColor } = Font;

const { height, width } = Dimensions.get('window');

class MapComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      bounceValue: new Animated.Value(2000), //This is the initial position of the subview
      isHidden: false,
      subViewHeight:
        height -
        PixelRatio.roundToNearestPixel(131 + getStatusBarHeight(false)),
      searchText: props.searchText || '',
    };
    // if (props.LoginActionState.longitude && props.LoginActionState.latitude) {
    //   const { LoginAction, LoginActionState } = props;
    //   const { longitude,latitude } = LoginActionState;
    //   LoginAction.getAddress({ region: { longitude, latitude }, dropdownRef: this.dropdown });
    // }
  }

  // getMapCoordinates = async () => {
  //   const { LoginAction, LoginActionState } = await this.props;
  //   const { tLatitude, tLongitude } = await LoginActionState;
  //   LoginAction.getAddress({ region: { tLatitude, tLongitude }, dropdownRef: this.dropdown });
  // }

  componentDidMount = async () => {
    const uid = await $_storage.get(KeyUtils.USER_ID);
    const { fromPage } = this.props;
    // this.getMapCoordinates();
    switch (fromPage) {
      case 'SignTerms':
        await AnalyticsManager.setAppsFlyerTrackEvent(
          AnalyticsKey.NAME_SIGN_UP_ADDRESS,
        );
        AnalyticsManager.setAirbridgeTrackEvent(
          AnalyticsKey.NAME_SIGN_UP_ADDRESS,
          Platform.OS,
          uid,
        );
        break;
    }

    Keyboard.dismiss();
    // this.state.subViewHeight = ;
    if (Platform.OS == 'android') {
      const AndroidKeyboardAdjust = require('react-native-android-keyboard-adjust');
      AndroidKeyboardAdjust.setAdjustNothing();
    }
    BackHandler.addEventListener('hardwareBackPress', this.handleBackPress);
  };

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.handleBackPress);
  }

  static options(passProps) {
    return {
      popGesture: false,
    };
  }

  onRegionChangeComplete = region => {
    const { LoginAction } = this.props;
    const { longitude, latitude } = region;
    if (parseInt(latitude) < 33) {
      return;
    }

    LoginAction.getAddress({ region, dropdownRef: this.dropdown });
  };

  search = () => {
    const { LoginAction } = this.props;
    var { searchText } = this.state;
    this.state.searching = true;
    LoginAction.getLocation({ q: searchText });
  };

  onChange = searchText => {
    this.setState({ searchText });
  };

  show = () => {
    const { isHidden, subViewHeight, bounceValue, searchText } = this.state;
    const { LoginAction } = this.props;
    //아래에서 setState()가 불리면서 스토어 값을 기준으로 렌더링이 되는데
    //setState가 먼저 불리면 message가 아직 업데이트 되기 전의 값으로 렌더링 되고,
    //다시 dispatch 하면서 렌더링이 불릴 수 있기 때문에 액션 함수 먼저 불러서
    //끝날 때 까지 기다리고 setState() 해야함.

    Animated.spring(bounceValue, {
      toValue: 0,
      velocity: 3,
      tension: 20,
      friction: 10,
    }).start();
    this.setState({ isHidden: false });
  };

  hide = () => {
    const { isHidden, subViewHeight, bounceValue, searchText } = this.state;
    // this.toggleSubview();
    Animated.spring(bounceValue, {
      toValue: subViewHeight,
      velocity: 3,
      tension: 20,
      friction: 10,
    }).start();
    Keyboard.dismiss();
    this.setState({ isHidden: true });
  };

  handleBackPress = () => {
    const { isHidden } = this.state;
    if (!isHidden) {
      this.hide();
      return true;
    } else {
      return false;
    }
  };

  clearText = () => {
    this.setState({ searchText: '' });
  };

  goAddressChat = () => {
    const {
      componentId,
      LoginAction,
      LoginActionState,
      fromPage,
      ChangeAddressAction,
    } = this.props;
    const {
      address,
      roadAddress,
      tLatitude,
      tLongitude,
      getLatitude,
      getLongitude,
    } = LoginActionState;

    if (fromPage && fromPage === 'AddressChange') {
      ChangeAddressAction.addMyAddress({
        address,
        roadAddress,
        latitude: getLatitude,
        longitude: getLongitude,
        componentId,
      });
    } else {
      LoginAction.selectLocation({ address, roadAddress, componentId });
    }
  };

  render() {
    const { subViewHeight, isHidden, searchText, region } = this.state;
    const { componentId, LoginActionState, LoginAction, fromPage } = this.props;
    console.log(subViewHeight, addressList);
    const {
      addressList,
      roadAddress,
      timerCounter,
      locationIsOpen,
    } = LoginActionState;
    const { selectLocation } = LoginAction;
    var backbutton;
    if (fromPage) {
      backbutton = (
        <NBImageButton
          onPress={() => Navigation.pop(componentId)}
          source={require('image/common/back_button_black.png')}
        />
      );
    } else {
      if (isHidden) {
        backbutton = (
          <NBImageButton
            onPress={() => this.hide()}
            source={require('image/common/back_button_black.png')}
          />
        );
      }
    }

    /** 주소변경 관련 회원가입부분에서는 props => undefined, update 부분에서는 props 존재**/
    const { latitude, longitude } = this.props;
    /** 주소변경 관련 **/
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        {/* <StatusBar backgroundColor={washswatColor.white} barStyle="dark-content" /> */}
        <View
          style={{
            width: '100%',
            position: 'absolute',
            top: 0,
            backgroundColor: washswatColor.white,
          }}
        >
          <View style={styles.topNavi}>
            {backbutton}
            {!fromPage ? (
              <JoinTimer timerCounter={timerCounter} isHidden={isHidden} />
            ) : null}
          </View>
          <View
            style={{
              height: PixelRatio.roundToNearestPixel(70),
              flexDirection: 'row',
            }}
          >
            <TextInput
              ref={ref => (this.textInput = ref)}
              value={searchText}
              returnKeyType={'search'}
              onSubmitEditing={this.search}
              onFocus={() => this.show()}
              onChangeText={this.onChange}
              placeholder={mapString.inputPlaceholder}
              placeholderTextColor={washswatColor.grey_03}
              style={[
                {
                  flex: 1,
                  color: washswatColor.black,
                  fontSize: PixelRatio.roundToNearestPixel(24),
                  marginLeft: PixelRatio.roundToNearestPixel(30),
                  paddingTop: PixelRatio.roundToNearestPixel(18),
                  paddingBottom: PixelRatio.roundToNearestPixel(23),
                },
              ]}
            />
            {searchText.length ? (
              <TouchableOpacity activeOpacity={1} onPress={this.clearText}>
                <Image
                  style={{
                    marginRight: PixelRatio.roundToNearestPixel(30),
                    marginBottom: PixelRatio.roundToNearestPixel(29),
                    marginTop: PixelRatio.roundToNearestPixel(23),
                    width: PixelRatio.roundToNearestPixel(18),
                    height: PixelRatio.roundToNearestPixel(18),
                  }}
                  source={require('image/map/delete.png')}
                />
              </TouchableOpacity>
            ) : null}
          </View>
          <DropdownAlert
            activeStatusBarStyle={'light-content'}
            containerStyle={styles.alert}
            ref={ref => (this.dropdown = ref)}
            closeInterval={2000}
            messageStyle={{
              textAlign: 'center',
              fontWeight: 'bold',
              fontSize: PixelRatio.roundToNearestPixel(15),
              color: washswatColor.white,
            }}
          />
        </View>

        <View
          style={[
            {
              position: 'absolute',
              bottom: 0,
              left: 0,
              right: 0,
              backgroundColor: '#FFFFFF',
              height: subViewHeight,
            },
          ]}
        >
          <View style={styles.subviewContainer}>
            <FlatList
              style={{ width: '100%', height: '100%' }}
              data={addressList}
              renderItem={({ item }) => {
                var {
                  latitude,
                  longitude,
                  address,
                  roadAddress,
                  isOpen,
                } = item;
                if (latitude && typeof latitude === 'string') {
                  latitude = parseFloat(latitude);
                }
                if (longitude && typeof longitude === 'string') {
                  longitude = parseFloat(longitude);
                }

                return (
                  <ListItem
                    mapViewRef={this.MapView}
                    onPress={props => {
                      if (latitude && longitude && address && roadAddress) {
                        LoginAction.selectLocation({
                          address,
                          roadAddress,
                          componentId,
                          latitude,
                          longitude,
                          isOpen,
                        });
                      } else {
                        // 주소 유효성 검사 , 도로명 주소 없을시
                        this.hide();
                        WashAlert.showAlert(
                          mapString.validationAddress,
                          Favorite.ok,
                        );
                        // this.MapView.animateToRegion({
                        //   latitude,
                        //   longitude,
                        //   latitudeDelta: 0.003,
                        //   longitudeDelta: 0.003
                        // });
                      }
                    }}
                    {...{ ...item, componentId }}
                  />
                );
              }}
              keyExtractor={(item, index) => index.toString()}
            />
          </View>
        </View>
      </View>
    );
  }
}

const mapStateToProps = ({ LoginModule }) => ({
  LoginActionState: LoginModule,
});
const mapDispatchToProps = dispatch => ({
  LoginAction: bindActionCreators(LoginActions, dispatch),
  ChangeAddressAction: bindActionCreators(ChangeAddressModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(MapComponent);

const styles = StyleSheet.create({
  topNavi: {
    height: PixelRatio.roundToNearestPixel(61 + getStatusBarHeight(true)),
    alignItems: 'flex-end',
    flexDirection: 'row',
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  markerFrame: {
    position: 'absolute',
  },
  marker: {
    position: 'absolute',
    width: PixelRatio.roundToNearestPixel(30),
    height: PixelRatio.roundToNearestPixel(30),
  },
  button: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: washswatColor.black,
    marginBottom: PixelRatio.roundToNearestPixel(75),
    paddingTop: PixelRatio.roundToNearestPixel(9),
    paddingBottom: PixelRatio.roundToNearestPixel(9),
    paddingLeft: PixelRatio.roundToNearestPixel(10),
    paddingRight: PixelRatio.roundToNearestPixel(10),
    borderRadius: 3,
  },
  topFrame: {
    top: 0,
    position: 'absolute',
    width: '100%',
    paddingRight: PixelRatio.roundToNearestPixel(20),
    paddingBottom: PixelRatio.roundToNearestPixel(14.2),
    height: PixelRatio.roundToNearestPixel(58 + getStatusBarHeight(true)),
    backgroundColor: washswatColor.white,
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  alert: {
    width: '100%',
    backgroundColor: washswatColor.blue,
    height: PixelRatio.roundToNearestPixel(50 + getStatusBarHeight(true)),
  },
  input: {
    flex: 1,
    paddingBottom: 10,
    borderBottomColor: washswatColor.black,
    borderBottomWidth: PixelRatio.roundToNearestPixel(4.1),
    marginRight: PixelRatio.roundToNearestPixel(20),
    marginLeft: PixelRatio.roundToNearestPixel(20),
  },
  search: {
    width: PixelRatio.roundToNearestPixel(30),
    height: PixelRatio.roundToNearestPixel(30),
  },
  back: {
    width: PixelRatio.roundToNearestPixel(25),
    height: PixelRatio.roundToNearestPixel(25),
    resizeMode: 'contain',
    marginLeft: PixelRatio.roundToNearestPixel(15),
  },
  subviewContainer: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: PixelRatio.roundToNearestPixel(13),
  },
  lottieView: {
    backgroundColor: 'black',
    borderRadius: 30,
    width: PixelRatio.roundToNearestPixel(24),
    height: PixelRatio.roundToNearestPixel(24),
    position: 'absolute',
  },
  arrow_right: {
    marginLeft: PixelRatio.roundToNearestPixel(24),
    marginTop: PixelRatio.roundToNearestPixel(28),
    width: PixelRatio.roundToNearestPixel(16),
    height: PixelRatio.roundToNearestPixel(16),
  },
  bottomBtn: {
    justifyContent: 'center',
    marginLeft: PixelRatio.roundToNearestPixel(24),
    marginTop: PixelRatio.roundToNearestPixel(17),
    width: PixelRatio.roundToNearestPixel(224),
    height: PixelRatio.roundToNearestPixel(38),
  },
  bottomBtnView: {
    flexDirection: 'row',
    bottom: PixelRatio.roundToNearestPixel(36),
    position: 'absolute',
    width: PixelRatio.roundToNearestPixel(312),
    height: PixelRatio.roundToNearestPixel(72),
  },
  bottomBtn_txt: {
    fontSize: PixelRatio.roundToNearestPixel(14),
    fontWeight: 'bold',
    color: washswatColor.white,
  },
});
