import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
  ScrollView,
} from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as LoginQuestionModule from '../../reducers/LoginQuestionModule';

import { LoginQuestionText } from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { responseFont, washswatColor } = Font;

class SignTerms extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount = async () => {
    const { LoginQuestionAction, accessToken } = this.props;

    await LoginQuestionAction.init(accessToken);
  };

  render() {
    const {
      LoginQuestionModule,
      LoginQuestionAction,
      componentId,
    } = this.props;
    const { questions } = LoginQuestionModule;
    return (
      <View style={{ flex: 1 }}>
        <View style={styles.statusView}>
          <View></View>
          <TouchableOpacity
            onPress={() => LoginQuestionAction.goSignUp(componentId)}
          >
            <Text
              style={[
                styles.nextBtn,
                responseFont(16).bold,
                { color: washswatColor.blue },
              ]}
            >
              {LoginQuestionText.goSignUp}
            </Text>
          </TouchableOpacity>
        </View>
        <View style={styles.headView}>
          <View style={styles.headTitleView}>
            <Text style={responseFont(30).bold}>
              {LoginQuestionText.headTitle}
            </Text>
          </View>
          <View style={styles.headSubTitleView}>
            <Text style={responseFont(14).regular}>
              {LoginQuestionText.subTitle}
            </Text>
            <Text style={responseFont(14).bold}>
              {LoginQuestionText.subTitleBold}
            </Text>
            <Text style={responseFont(14).regular}>
              {LoginQuestionText.subTitleLast}
            </Text>
          </View>
        </View>
        <View style={styles.rowGrayLine} />
        <ScrollView>
          {_.map(questions, o => {
            const { id, data } = o;
            return (
              <TouchableOpacity
                key={`lq_${id}`}
                activeOpacity={1}
                onPress={() => {
                  LoginQuestionAction.firstAnswer(
                    id,
                    data.address,
                    componentId,
                  );
                }}
                style={styles.bottomTextView}
              >
                <View style={styles.bottomText}>
                  <View disabled={false} style={{ justifyContent: 'center' }}>
                    <Text style={responseFont(14).bold}>{data.address}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = ({ LoginQuestionModule }) => ({
  LoginQuestionModule,
});
const mapDispatchToProps = dispatch => ({
  LoginQuestionAction: bindActionCreators(LoginQuestionModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(SignTerms);

const styles = StyleSheet.create({
  bottomText: {
    marginBottom: PixelRatio.roundToNearestPixel(31),
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statusView: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: PixelRatio.roundToNearestPixel(60 + getStatusBarHeight(true)),
  },
  headView: {},
  bottomTextView: {
    paddingTop: PixelRatio.roundToNearestPixel(28),
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  rowLine: {
    marginLeft: PixelRatio.roundToNearestPixel(30),
    borderColor: washswatColor.grey_05,
    borderWidth: PixelRatio.roundToNearestPixel(0.5),
  },
  bottomHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: PixelRatio.roundToNearestPixel(27),
    paddingTop: PixelRatio.roundToNearestPixel(28),
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  nextBtn: {
    marginRight: PixelRatio.roundToNearestPixel(18),
    marginBottom: PixelRatio.roundToNearestPixel(17),
  },
  signUpBtn: {
    marginLeft: PixelRatio.roundToNearestPixel(18),
    marginBottom: PixelRatio.roundToNearestPixel(17),
  },
  headTitleView: {
    marginTop: PixelRatio.roundToNearestPixel(24),
    paddingLeft: PixelRatio.roundToNearestPixel(30),
  },
  rowGrayLine: {
    backgroundColor: washswatColor.grey_05,
    height: PixelRatio.roundToNearestPixel(12),
  },
  headSubTitleView: {
    flexDirection: 'column',
    marginTop: PixelRatio.roundToNearestPixel(18),
    // alignItems: 'center',
    marginBottom: PixelRatio.roundToNearestPixel(20),
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
  },
  bottomView: {
    // height: PixelRatio.roundToNearestPixel(326)
  },
});
