import React from 'react';

import {
  Platform,
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Dimensions,
  Keyboard,
  PixelRatio,
  ScrollView,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import AndroidKeyboardAdjust from 'react-native-android-keyboard-adjust';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as LoginActions from '../../reducers/LoginModule';

import { JoinTimer } from '../../components/common/button/CommonComponent';
import LoadingBar from '../../components/common/button/LoadingBar';
import NBImageButton from '../../components/common/button/NBImageButton';
import KeyboardSpacerIOS from '../../components/common/keyboard/KeyboardSpacerIOS';
import { ChatView, AnswerChatView } from '../../components/login/ChatComponent';

import { AddressChatText } from '../../utils/common/strings';
import * as Keys from '../../utils/type/key';
import * as CommonUtils from '../../utils/common';
import { Font } from '../../utils/style';

import _ from 'lodash';

const { washswatColor } = Font;

const windowSize = Dimensions.get('window');

class AddressChat extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      inputValue: '',
      init: true,
    };
  }

  static options(passProps) {
    return {
      popGesture: true,
      topBar: {
        visible: false,
        height: 0,
      },
    };
  }

  componentDidMount() {
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this.keyboardDidShow,
    );
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidHide',
      this.keyboardDidHide,
    );

    if (Platform.OS === 'android') {
      AndroidKeyboardAdjust.setAdjustResize();
    }
  }

  keyboardDidShow = () => {
    //스크롤뷰의 가장 끝으로 이동.
    this.scrollView.scrollToEnd({ animated: true });
  };

  keyboardDidHide = () => {
    this.scrollView.scrollToEnd({ animated: false });
  };

  componentWillUnmount() {
    Keyboard.removeListener('keyboardDidShow', this.keyboardDidShow);
    Keyboard.removeListener('keyboardDidHide', this.keyboardDidHide);
  }

  handleInputText = inputValue => {
    this.setState({ inputValue });
  };

  screenPop = () => {
    Navigation.pop(this.props.componentId);
  };

  sendPress = () => {
    const { inputValue } = this.state;
    const { LoginAction, componentId, LoginActionState } = this.props;
    const { directInput, saveName, saveBtn } = _.cloneDeep(AddressChatText);
    const {
      addressChatArr,
      addressInputTextType,
      isPending,
    } = LoginActionState;

    let data = { inputValue: '' },
      dispatchParams = {};

    directInput.textArr[0].text = inputValue;
    dispatchParams.addressInputTextType = null;

    if (addressInputTextType === Keys.REMAINING_ADDRESS) {
      if (!inputValue) {
        CommonUtils.showAlert(AddressChatText.inputAddressOthers);
        return;
      }
      if (inputValue) {
        const regex = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]{1,4}(도|시|구)\s[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]{1,4}(동|면|리|로)/;
        if (regex.test(inputValue)) {
          this.setState({ inputValue: '' });
          CommonUtils.showAlert(AddressChatText.unexpectedOtherAddress);
          return;
        }
      }
      dispatchParams.addressChatArr = addressChatArr.concat([
        directInput,
        saveName,
        saveBtn,
      ]);
      dispatchParams.addressOthers = inputValue;

      this.setState(data, () => LoginAction.addressOtherInput(dispatchParams));
    } else if (addressInputTextType === Keys.SAVE_ADDRESS_NAME) {
      dispatchParams.addressChatArr = addressChatArr.concat([directInput]);
      dispatchParams.addressTitle = inputValue;
      dispatchParams.componentId = componentId;

      this.setState(data, () => LoginAction.postLogin(dispatchParams));
    }
  };

  saveAddressName = (parentIndex, childIndex) => {
    let tempTextArr, addressInputTextType, addressTitle;
    let { LoginAction, LoginActionState, componentId } = this.props;
    let copyAddressChatArr = [...LoginActionState.addressChatArr];

    const { textArr } = copyAddressChatArr[parentIndex];
    const { btnKey } = textArr[childIndex];

    if (btnKey === 'directInput') {
      copyAddressChatArr = copyAddressChatArr.filter((item, i) => {
        return i != parentIndex;
      });
      addressInputTextType = Keys.SAVE_ADDRESS_NAME;

      LoginAction.saveAddressNameInput({
        addressChatArr: copyAddressChatArr,
        addressInputTextType,
      });
    } else {
      tempTextArr = textArr.filter((item, i) => {
        if (i == childIndex) {
          item.background = true;
          item.onPress = false;
        }
        return i == childIndex;
      });

      addressTitle = tempTextArr[0].text;
      copyAddressChatArr[parentIndex].textArr = tempTextArr;

      LoginAction.postLogin({
        addressChatArr: copyAddressChatArr,
        addressInputTextType,
        addressTitle,
        componentId,
      });
    }
  };

  _addressChatViewPush = () => {
    const {
      LoginAction,
      LoginActionState: { addressChatArr },
    } = this.props;
    const chatArrView = [];
    let answerChatPress = () => {};

    addressChatArr.map((textObj, i) => {
      if (textObj.type === 'left') {
        chatArrView.push(
          <ChatView key={`addressChat${i}`} textObj={textObj} />,
        );
      } else {
        if (textObj.answerChatType === Keys.SAVE_ADDRESS_NAME) {
          answerChatPress = this.saveAddressName;
        }

        chatArrView.push(
          <AnswerChatView
            onPress={answerChatPress}
            key={`addressChat${i}`}
            index={i}
            textObj={textObj}
          />,
        );
      }
    });

    return chatArrView;
  };

  render() {
    const { inputValue } = this.state;
    const {
      addressChatArr,
      addressOthers,
      addressInputTextType,
      timerCounter,
      isPending,
    } = this.props.LoginActionState;

    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.white }}>
        {/* <StatusBar backgroundColor={washswatColor.white} barStyle="dark-content" /> */}
        {isPending ? <LoadingBar /> : null}
        <View style={styles.topView}>
          <NBImageButton
            onPress={this.screenPop}
            source={require('image/common/back_button_black.png')}
          />
          <JoinTimer timerCounter={timerCounter} isHidden={true} />
        </View>
        <View style={styles.bodyView}>
          <ScrollView
            ref={ref => (this.scrollView = ref)}
            onContentSizeChange={(contentWidth, contentHeight) => {
              if (this.state.init) {
                this.state.init = false;
              } else {
                this.scrollView.scrollToEnd({ animated: true });
              }
            }}
          >
            {this._addressChatViewPush()}
            <View style={{ height: PixelRatio.roundToNearestPixel(36) }} />
          </ScrollView>
        </View>
        {addressInputTextType && (
          <View
            style={{
              flexDirection: 'row',
              borderTopWidth: PixelRatio.roundToNearestPixel(1),
              borderColor: washswatColor.grey_05,
            }}
          >
            <View
              style={{
                flex: 1,
                marginLeft: PixelRatio.roundToNearestPixel(30),
                width: PixelRatio.roundToNearestPixel(windowSize.width - 95),
              }}
            >
              <TextInput
                value={inputValue}
                placeholder={
                  AddressChatText.placeholderText[addressInputTextType]
                }
                onChangeText={e => this.handleInputText(e)}
                style={styles.inputText}
              />
            </View>
            <TouchableOpacity
              multiline={true}
              style={styles.sendBtn}
              onPress={this.sendPress}
              activeOpacity={1}
            >
              <Text>{AddressChatText.sendButton}</Text>
            </TouchableOpacity>
          </View>
        )}
        <KeyboardSpacerIOS />
      </View>
    );
  }
}

const mapStateToProps = ({ LoginModule }) => ({
  LoginActionState: LoginModule,
});
const mapDispatchToProps = dispatch => ({
  LoginAction: bindActionCreators(LoginActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(AddressChat);

const styles = StyleSheet.create({
  topView: {
    height: PixelRatio.roundToNearestPixel(61 + getStatusBarHeight(true)),
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  bodyView: {
    flex: 1,
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  leftChatText: {
    flex: 1,
    backgroundColor: washswatColor.grey_05,
    borderRadius: PixelRatio.roundToNearestPixel(3),
    padding: PixelRatio.roundToNearestPixel(15),
  },
  leftChatView: {
    flexDirection: 'row',
    flex: 1,
    paddingTop: PixelRatio.roundToNearestPixel(24),
  },
  imageView: {
    marginRight: PixelRatio.roundToNearestPixel(9),
    width: PixelRatio.roundToNearestPixel(30),
    height: PixelRatio.roundToNearestPixel(30),
  },
  rightChatView: {
    alignItems: 'flex-end',
    paddingTop: PixelRatio.roundToNearestPixel(24),
  },
  rightChatText: {
    borderRadius: PixelRatio.roundToNearestPixel(3),
    padding: PixelRatio.roundToNearestPixel(15),
    borderColor: washswatColor.blue,
    borderWidth: PixelRatio.roundToNearestPixel(3),
  },
  inputText: {
    height: PixelRatio.roundToNearestPixel(56),
    textAlignVertical: 'center',
    color: washswatColor.black,
  },
  sendBtn: {
    paddingTop: PixelRatio.roundToNearestPixel(20),
    paddingLeft: PixelRatio.roundToNearestPixel(24),
    paddingBottom: PixelRatio.roundToNearestPixel(18),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
});
