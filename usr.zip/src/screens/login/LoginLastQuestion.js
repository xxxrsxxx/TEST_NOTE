import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
  TextInput,
} from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as LoginQuestionModule from '../../reducers/LoginQuestionModule';
import * as LoginModule from '../../reducers/LoginModule';

import WashAlert from '../../utils/alert';
import {
  LoginQuestionText,
  LoginLastQuestionText,
} from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { responseFont, washswatColor, themeColorSelector } = Font;

class LoginLastQuestion extends React.Component {
  state = {
    boxData: [],
  };

  componentDidMount = () => {
    this.initQuestion();
  };

  initQuestion = () => {
    const {
      LoginQuestionModule,
      LoginQuestionAction,
      componentId,
      id,
    } = this.props;
    const { questions } = LoginQuestionModule;
    const response = _.find(questions, { id });
    const { data } = response;
    // data.addressOthers = '602동 1302호'
    this.getBoxFrame(data.addressOthers);
  };

  onChangeText = (text, id) => {
    const { LoginAction, componentId, LoginQuestionAction } = this.props;
    const { boxData } = this.state;
    const index = _.findIndex(boxData, { id });
    if (index > -1) {
      if (text) {
        boxData[index].text = text[text.length - 1];
      } else {
        boxData[index].text = null;
      }
      if (
        boxData[index + 1] &&
        !boxData[index + 1].text &&
        boxData[index].text
      ) {
        boxData[index].autoFocus = false;
        boxData[index + 1].autoFocus = true;
      } else {
        boxData[index].autoFocus = true;
        if (boxData[index + 1]) {
          boxData[index + 1].autoFocus = false;
        }
      }
    }

    this.setState({ boxData });

    let filled = true;
    let permit = true;
    _.map(boxData, o => {
      const { text, answer } = o;
      if (text) {
      } else {
        filled = false;
      }
      if (text && text.toString() === answer.toString()) {
      } else {
        permit = false;
      }
    });

    if (filled) {
      /** 전부 채워진 상태 **/
      if (permit) {
        /** 페이지 이동 **/
        LoginQuestionAction.complete();
        LoginAction.getGlobalData({
          goToRoot: true,
          callback: err => {
            if (err) {
              this.initQuestion();
            }
          },
        });
      } else {
        WashAlert.showAlertWithCallback(
          LoginLastQuestionText.fail,
          LoginLastQuestionText.retry,
          () => {
            const index = _.findIndex(boxData, { autoFocus: true });
            if (index > -1) {
              boxData[index].autoFocus = false;
              boxData[0].autoFocus = true;
              this.setState({ boxData });
            }

            this.initQuestion();
          },
        );
      }
    }
  };

  getBoxFrame = addressOthers => {
    const boxData = [];
    const boxFrame = [];
    let boxView = [];

    // let autoFocus = true;
    for (let i = 0; i < addressOthers.length; i++) {
      const o = addressOthers[i];
      const isTextInput = !isNaN(parseInt(o));
      let inputId = boxData.length;

      if (!isTextInput) {
        let isEmpty = !o || ['', ' ', '  '].indexOf(o) > -1;
        if (!isEmpty) {
          boxView.push({
            isTextInput,
            str: o,
            inputId,
          });
        }
        if (boxView.length && (isEmpty || ['-', '_', '동'].indexOf(o) > -1)) {
          if (boxView.length) {
            /** 공백은 개행 **/
            boxFrame.push(boxView);
            boxView = [];
          }
        }
        // boxView.push(<View key={`bx-${i}`} style={{padding : 10, }}></View>)
      } else {
        if (isTextInput) {
          boxData.push({
            id: inputId,
            text: null,
            answer: o,
            autoFocus: false,
          });
        }
        boxView.push({
          isTextInput,
          str: o,
          inputId,
        });
      }
    }
    if (boxView.length) {
      boxFrame.push(boxView);
      boxView = [];
    }
    this.setState({ boxData, boxFrame });
  };
  render = () => {
    const {
      LoginQuestionModule,
      LoginQuestionAction,
      componentId,
      id,
    } = this.props;
    const { questions } = LoginQuestionModule;
    const { boxData, boxFrame } = this.state;

    if (!boxFrame || !boxFrame.length) {
      return <View></View>;
    }

    const response = _.find(questions, { id });
    const { data } = response;

    // let autoFocus = true;
    const boxFrameView = [];

    _.map(boxFrame, (boxViewList, parentIndex) => {
      const view = [];
      _.map(boxViewList, ({ isTextInput, str, inputId }, childIndex) => {
        view.push(
          <Box
            key={`bx-${parentIndex}-${childIndex}`}
            str={str}
            onChangeText={this.onChangeText}
            isTextInput={isTextInput}
            boxData={boxData}
            inputId={inputId}
          />,
        );
        // autoFocus = false;
      });
      if (view.length) {
        boxFrameView.push(
          <View key={`box-${parentIndex}`} style={styles.boxFrame}>
            {view}
          </View>,
        );
      }
    });

    return (
      <View style={{ flex: 1 }}>
        <View style={styles.statusView}>
          <View></View>
          <TouchableOpacity
            onPress={() => LoginQuestionAction.goSignUp(componentId)}
          >
            <Text
              style={[
                styles.nextBtn,
                responseFont(16).bold,
                { color: washswatColor.blue },
              ]}
            >
              {LoginQuestionText.goSignUp}
            </Text>
          </TouchableOpacity>
        </View>
        <View style={styles.headView}>
          <View style={styles.headTitleView}>
            <Text style={responseFont(30).bold}>
              {LoginLastQuestionText.headTitle}
            </Text>
          </View>
          <View style={styles.headSubTitleView}>
            <Text style={responseFont(14).regular}>
              {LoginLastQuestionText.subTitle}
            </Text>
          </View>
        </View>
        <View style={styles.rowGrayLine} />
        <View style={[{ flexDirection: 'column' }, styles.headTitleView]}>
          <Text style={responseFont(20).bold}>{data.address}</Text>
          <View style={{ flexDirection: 'column' }}>{boxFrameView}</View>
        </View>
      </View>
    );
  };
}

const Box = props => {
  const { str, isTextInput, onChangeText, inputId, boxData, autoFocus } = props;
  const _onChangeText = (text, inputId) => {
    onChangeText(text, inputId);
  };
  if (isTextInput) {
    const boxStyle = {
      // flexDirection : 'row',
      borderWidth: 0.5,
      borderColor: washswatColor.black,
      // alignItems: 'center',
      // justifyContent: 'center',
      minWidth: PixelRatio.roundToNearestPixel(45),
      minHeight: PixelRatio.roundToNearestPixel(45),
      marginRight: PixelRatio.roundToNearestPixel(5),
      // height: PixelRatio.roundToNearestPixel(222)
    };
    const data = _.find(boxData, { id: inputId });
    const value = data && data.text ? data.text : null;
    const autoFocus = data && data.autoFocus ? true : false;
    if (autoFocus && this[`input-${inputId}`]) {
      this[`input-${inputId}`].focus();
    }
    return (
      <TextInput
        ref={input => {
          this[`input-${inputId}`] = input;
        }}
        multiline={false}
        style={[boxStyle, { color: themeColorSelector({ theme: 'primary' }) }]}
        textAlign={'center'}
        value={value ? value + '' : ''}
        autoFocus={autoFocus}
        onChangeText={text => _onChangeText(text, inputId)}
        keyboardType={'numeric'}
        returnKeyType="done"
      />
    );
  } else {
    const boxStyle = {
      flexDirection: 'row',
      padding: PixelRatio.roundToNearestPixel(5),
      alignItems: 'center',
      justifyContent: 'center',
      // height: PixelRatio.roundToNearestPixel(222)
    };

    return (
      <View style={boxStyle}>
        <Text style={responseFont(16).regular}>{str}</Text>
      </View>
    );
  }
};

const mapStateToProps = ({ LoginQuestionModule }) => ({
  LoginQuestionModule,
});
const mapDispatchToProps = dispatch => ({
  LoginQuestionAction: bindActionCreators(LoginQuestionModule, dispatch),
  LoginAction: bindActionCreators(LoginModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(LoginLastQuestion);

const styles = StyleSheet.create({
  bottomText: {
    marginBottom: PixelRatio.roundToNearestPixel(31),
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statusView: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: PixelRatio.roundToNearestPixel(60 + getStatusBarHeight(true)),
  },
  bottomTextView: {
    paddingTop: PixelRatio.roundToNearestPixel(28),
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  rowLine: {
    marginLeft: PixelRatio.roundToNearestPixel(30),
    borderColor: washswatColor.grey_05,
    borderWidth: PixelRatio.roundToNearestPixel(0.5),
  },
  bottomHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: PixelRatio.roundToNearestPixel(27),
    paddingTop: PixelRatio.roundToNearestPixel(28),
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  nextBtn: {
    marginRight: PixelRatio.roundToNearestPixel(18),
    marginBottom: PixelRatio.roundToNearestPixel(17),
  },
  signUpBtn: {
    marginLeft: PixelRatio.roundToNearestPixel(18),
    marginBottom: PixelRatio.roundToNearestPixel(17),
  },
  headTitleView: {
    marginTop: PixelRatio.roundToNearestPixel(24),
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  boxFrame: {
    marginTop: PixelRatio.roundToNearestPixel(24),
    flexDirection: 'row',
  },
  rowGrayLine: {
    backgroundColor: washswatColor.grey_05,
    height: PixelRatio.roundToNearestPixel(12),
  },
  headSubTitleView: {
    marginTop: PixelRatio.roundToNearestPixel(18),
    // alignItems: 'center',
    marginBottom: PixelRatio.roundToNearestPixel(20),
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
  },
  bottomView: {
    // height: PixelRatio.roundToNearestPixel(326)
  },
});
