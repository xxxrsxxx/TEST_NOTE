import React from 'react';

import {
  Dimensions,
  Image,
  PixelRatio,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
  KeyboardAvoidingView,
} from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as LoginActions from '../../reducers/LoginModule';

import { AnswerChatView, ChatView } from '../../components/login/ChatComponent';
import { JoinTimer } from '../../components/common/button/CommonComponent';
import CommonPopup from '../../components/common/button/CommonPopup';
import LoadingBar from '../../components/common/button/LoadingBar';
import KeyboardSpacerIOS from '../../components/common/keyboard/KeyboardSpacerIOS';

import { Favorite, LoginChatText } from '../../utils/common/strings';
import * as Keys from '../../utils/type/key';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import AnalyticsManager from '../../utils/tagging/analytics';
import * as CommonUtils from '../../utils/common';
import { Font } from '../../utils/style';

import { moment } from '../../plugins';

const { washswatColor, responseFont } = Font;
const windowSize = Dimensions.get('window');

let tid;
class LoginChat extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      inputValue: '',
      init: true,
    };
  }

  static options(passProps) {
    return {
      popGesture: false,
      statusBar: {
        visible: true,
        backgroundColor: washswatColor.white,
        style: 'dark',
      },
    };
  }

  componentDidMount = async () => {
    const { joinTimer } = this.props.LoginAction;
    let { remainTime } = this.props.LoginActionState;
    // this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);

    const uid = await $_storage.get(Keys.USER_ID);
    await AnalyticsManager.setAppsFlyerTrackEvent(
      AnalyticsKey.NAME_SIGN_UP_PHONE,
    );
    AnalyticsManager.setAirbridgeTrackEvent(
      AnalyticsKey.NAME_SIGN_UP_PHONE,
      Platform.OS,
      uid,
    );

    tid = setInterval(function() {
      let miniutes = Math.floor(remainTime / 60);
      let seconds = Math.floor(remainTime % 60);
      let timer = moment()
        .set('minute', miniutes)
        .set('second', seconds)
        .format('mm:ss');

      if (remainTime < 0) {
        clearInterval(tid);
      } else {
        remainTime -= 1;
        joinTimer({ timerCounter: timer, tid, remainTime });
      }
    }, 1000);
  };

  componentWillUnmount() {
    clearInterval(tid); // 레거시 setInterval 오류 개선
  }

  // keyboardDidShow = () => {
  //   //스크롤뷰의 가장 끝으로 이동.
  //   this.scrollView.scrollToEnd({ animated: true });
  // };
  //
  // componentWillUnmount() {
  //   Keyboard.removeListener('keyboardDidShow', this.keyboardDidShow);
  // }

  sendPhoneNum = () => {
    const { inputValue } = this.state;
    const { LoginAction } = this.props;
    let data, params;

    //전화번호 입력해서 인증번호 받기
    params = { phone: inputValue };
    data = {
      inputValue: '',
    };

    this.setState(data, () => LoginAction.getCertificateNum(params));
  };

  sendCertificateNum = () => {
    const { inputValue } = this.state;
    const { LoginAction, componentId } = this.props;
    let params, data;

    params = {
      certificateNumber: inputValue,
      componentId,
    };
    data = {
      inputValue: '',
    };

    this.setState(data, () => {
      LoginAction.postCertificateCheck(params);
    });
  };

  reEnterPhoneNum = (parentIndex, childIndex) => {
    const { LoginAction, LoginActionState } = this.props;
    const { loginChatArr } = LoginActionState;
    const tempTextObj = loginChatArr[parentIndex].textArr[childIndex];

    if (tempTextObj.btnKey === 'reEnterPhone') {
      LoginAction.reEnterPhoneNum(parentIndex, childIndex);
    }
  };

  handleInputText = inputValue => {
    this.setState({ inputValue });
  };

  render() {
    let { inputValue } = this.state;
    let sendButtonPress;
    const { LoginActionState, LoginAction } = this.props;
    const {
      loginChatArr,
      loginInputType,
      timerCounter,
      errorPopup,
      isPending,
    } = LoginActionState;
    const chat = [];
    const sendImage =
      inputValue.length > 0
        ? require('image/common/send_active.png')
        : require('image/common/send_deactive.png');

    if (loginInputType === Keys.PHONE_NUMBER) {
      sendButtonPress = this.sendPhoneNum;
    } else {
      sendButtonPress = this.sendCertificateNum;
    }

    loginChatArr.map((textObj, index) => {
      if (textObj.type === 'left') {
        chat.push(<ChatView key={`chatView${index}`} textObj={textObj} />);
      } else {
        chat.push(
          <AnswerChatView
            index={index}
            key={`AnswerChatView${index}`}
            textObj={textObj}
            onPress={this.reEnterPhoneNum}
          />,
        );
      }
    });

    const content = (
      <View style={{ flex: 1, backgroundColor: washswatColor.white }}>
        {errorPopup ? (
          <CommonPopup
            title={errorPopup}
            negativeText={Favorite.ok}
            onPressNegativeButton={LoginAction.clearErrorMessage}
          />
        ) : null}
        {isPending ? <LoadingBar /> : null}
        {/* <StatusBar backgroundColor={washswatColor.white} barStyle="dark-content" /> */}
        <View style={styles.topView}>
          <JoinTimer timerCounter={timerCounter} />
        </View>
        {/*<View style={styles.bodyView}>*/}
        <ScrollView
          style={styles.bodyView}
          showsVerticalScrollIndicator={false}
          ref={ref => (this.scrollView = ref)}
          onContentSizeChange={(contentWidth, contentHeight) => {
            if (this.state.init) {
              this.state.init = false;
            } else {
              this.scrollView.scrollToEnd({ animated: true });
            }
          }}
        >
          {chat}
          <View style={{ height: PixelRatio.roundToNearestPixel(36) }} />
        </ScrollView>
        {/*</View>*/}
        <View style={styles.bottomInputText}>
          <View style={styles.textInput}>
            <TextInput
              keyboardType={'number-pad'}
              value={inputValue}
              placeholder={LoginChatText.placeholderText[loginInputType]}
              placeholderTextColor={washswatColor.grey_03}
              onChangeText={e => this.handleInputText(e)}
              style={[responseFont(15).bold, styles.inputText]}
            />
          </View>
          <TouchableOpacity
            style={styles.sendBtn}
            onPress={sendButtonPress}
            activeOpacity={1}
          >
            <Image
              style={{
                width: PixelRatio.roundToNearestPixel(30),
                height: PixelRatio.roundToNearestPixel(30),
              }}
              source={sendImage}
            />
          </TouchableOpacity>
        </View>
      </View>
    );
    return (
      <View style={{ flex: 1 }}>
        <StatusBar barStyle="dark-content" />
        {content}
        <KeyboardSpacerIOS />
      </View>
    );
  }
}

const mapStateToProps = ({ LoginModule }) => ({
  LoginActionState: LoginModule,
});
const mapDispatchToProps = dispatch => ({
  LoginAction: bindActionCreators(LoginActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(LoginChat);

const styles = StyleSheet.create({
  bottomInputText: {
    backgroundColor: washswatColor.white,
    flexDirection: 'row',
    alignItems: 'center',
    borderTopWidth: PixelRatio.roundToNearestPixel(1),
    borderColor: washswatColor.grey_05,
    ...Platform.select({
      android: {
        // position: 'absolute',
        // bottom: 0
      },
    }),
  },
  topView: {
    height: PixelRatio.roundToNearestPixel(61 + getStatusBarHeight(true)),
    justifyContent: 'flex-end',
  },
  bodyView: {
    flex: 1,
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  inputText: {
    height: PixelRatio.roundToNearestPixel(56),
    color: washswatColor.black,
  },
  textInput: {
    flex: 1,
    marginLeft: PixelRatio.roundToNearestPixel(30),
    width: PixelRatio.roundToNearestPixel(windowSize.width - 95),
  },
  sendBtn: {
    paddingEnd: PixelRatio.roundToNearestPixel(15),
  },
});
