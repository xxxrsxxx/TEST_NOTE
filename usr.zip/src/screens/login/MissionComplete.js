import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';

import { MissionCompleteString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

export default class MissionComplete extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: washswatColor.black,
          justifyContent: 'flex-start',
        }}
      >
        <View style={{ marginLeft: 303, marginTop: 54 }}>
          <Image
            source={require('image/chat/delete.png')}
            style={{ width: 60, height: 60 }}
          />
        </View>
        <View style={{ marginLeft: 72, marginTop: 63 }}>
          {/* 텍스트는 서버데이터 받아야함! */}
          <Text
            style={[
              responseFont(36).bold,
              {
                textAlign: 'left',
                lineHeight: 54,
                marginBottom: 27,
                color: washswatColor.white,
              },
            ]}
          >
            {MissionCompleteString.load}
          </Text>
          <Text
            style={[
              responseFont(16).regular,
              {
                textAlign: 'left',
                lineHeight: 24,
                color: washswatColor.grey_03,
              },
            ]}
          >
            {MissionCompleteString.shot}
          </Text>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({});
