import React from 'react';

import {
  Image,
  PixelRatio,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as LoginActions from '../../reducers/LoginModule';

import { MissionCompleteString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { washswatColor, responseFont } = Font;

const DEFAULT = 2000;

class SignUpComplete extends React.Component {
  closeModal = () => {
    Navigation.dismissModal(this.props.componentId);
  };
  render() {
    const { coupon } = this.props;
    var benefit =
      coupon && coupon.list ? _.sumBy(coupon.list, 'value') : DEFAULT;
    if (!benefit) {
      benefit = DEFAULT;
    }
    var text = MissionCompleteString.loaded;
    text = text.replace(/{price}/gi, numberWithCommas(benefit));

    return (
      <View style={styles.frame}>
        <View style={styles.bodyFrame}>
          <View>
            <Text style={[styles.largeText, responseFont(36).bold]}>
              {text}
            </Text>
            <Text style={[styles.smallText, responseFont(16).regular]}>
              {MissionCompleteString.shot}
            </Text>
          </View>
        </View>
        <TouchableOpacity
          style={styles.cloesBtn}
          activeOpacity={1}
          onPress={this.closeModal}
        >
          <Image style={styles.closeImg} source={require('image/delete.png')} />
        </TouchableOpacity>
      </View>
    );
  }
}

const mapStateToProps = ({ LoginModule }) => ({});
const mapDispatchToProps = dispatch => ({
  LoginAction: bindActionCreators(LoginActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(SignUpComplete);

const styles = StyleSheet.create({
  frame: {
    flex: 1,
    backgroundColor: washswatColor.black,
  },
  bodyFrame: {
    alignItems: 'center',
    // marginLeft: PixelRatio.roundToNearestPixel(72),
    marginTop: PixelRatio.roundToNearestPixel(147 + getStatusBarHeight(true)),
  },
  largeText: {
    marginBottom: PixelRatio.roundToNearestPixel(27),
    color: washswatColor.white,
    lineHeight: PixelRatio.roundToNearestPixel(54),
  },
  smallText: {
    color: washswatColor.white,
    lineHeight: PixelRatio.roundToNearestPixel(24),
  },
  cloesBtn: {
    top: PixelRatio.roundToNearestPixel(54 + getStatusBarHeight(true)),
    left: PixelRatio.roundToNearestPixel(303),
    position: 'absolute',
    width: PixelRatio.roundToNearestPixel(60),
    height: PixelRatio.roundToNearestPixel(60),
  },
  closeImg: {
    width: PixelRatio.roundToNearestPixel(60),
    height: PixelRatio.roundToNearestPixel(60),
  },
});

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
