import React from 'react';
import {
  Image,
  PixelRatio,
  StyleSheet,
  TouchableOpacity,
  Text,
  View,
  Animated,
  StatusBar,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Swiper from 'react-native-swiper';
import Video from 'react-native-video';

import * as CommonUtils from '../../utils/common';
import { OnBoarding } from '../../utils/common/strings';
// font import
import { Font } from '../../utils/style';
const { responseFont, washswatColor, verticalScale } = Font;

const onBoardingSources = [
  require('../../../assets/image/onboarding/step1.png'),
  require('../../../assets/image/onboarding/step2.png'),
  require('../../../assets/image/onboarding/step3.png'),
  require('../../../assets/image/onboarding/step4.png'),
];
const videoUrl = require('../../../assets/video/onboarding_video.mp4');

class LoginMain extends React.Component {
  state = {
    // isShowPopup: true,
    number: 123456,
    swiperIndex: 0,
    showVideo: true,
    fadeAnim: new Animated.Value(1),
  };

  static options(passProps) {
    return {
      topBar: {
        _height: 0,
        visible: false,
        animate: false,
      },
      statusBar: {
        visible: false,
      },
      layout: {
        backgroundColor: washswatColor.black,
      },
    };
  }

  skipVideo = duration => {
    Animated.timing(this.state.fadeAnim, {
      toValue: 0,
      duration: duration,
    }).start();
    setTimeout(() => {
      this.setState({ showVideo: false });
    }, duration);
  };

  goNext = () => {
    /** 로그인 화면 **/
    const { componentId } = this.props;
    CommonUtils.goLoginChat(componentId);
  };

  render() {
    const { number, swiperIndex, showVideo, fadeAnim } = this.state;
    return (
      <View style={styles.frame}>
        <StatusBar />
        {showVideo ? (
          <Animated.View style={[styles.videoWrap, { opacity: fadeAnim }]}>
            <Video
              source={videoUrl}
              ref={ref => {
                this.player = ref;
              }}
              controls={false}
              muted={false}
              repeat={true}
              resizeMode="cover"
              fullscreen={true}
              onBuffer={() => {
                //console.log('onBuffer');
              }}
              onError={e => {
                console.log('onError', e);
              }}
              style={styles.videoContent}
            />
            <LinearGradient
              colors={['#0000', '#00000080']}
              style={styles.dimArea}
            />
            <View style={styles.videoCommentWrap}>
              <Image
                source={require('../../../assets/image/common/logo/BI.png')}
              />
              <Text style={styles.videoComment}>{OnBoarding.videoComment}</Text>
            </View>
            <TouchableOpacity
              style={styles.startBtn}
              onPress={() => {
                this.skipVideo(500);
              }}
            >
              <Text style={styles.startBtnText}>{OnBoarding.initialStart}</Text>
            </TouchableOpacity>
          </Animated.View>
        ) : (
          <View style={{ flex: 1 }}>
            <Swiper
              ref={swiper => {
                this._swiper = swiper;
              }}
              loop={false}
              index={0}
              paginationStyle={{ bottom: verticalScale(113) }} //{ bottom: 144 }
              dot={<View style={styles.swiperDotView} />}
              activeDot={<View style={styles.swiperActiveDotView} />}
              onIndexChanged={index => {
                this.setState({ swiperIndex: index });
              }}
              showsButtons={true}
              prevButton={<View />}
              nextButton={<View />}
            >
              {onBoardingSources.map((board, index) => {
                return (
                  <Image
                    key={index}
                    style={{ width: '100%', height: '100%' }}
                    source={onBoardingSources[index]}
                  />
                );
              })}
            </Swiper>
            <TouchableOpacity
              style={styles.swiperSkipBtn}
              onPress={this.goNext}
            >
              <Text>{OnBoarding.skipText}</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  }
}

export default LoginMain;
//(codePush({ checkFrequency: codePush.CheckFrequency.ON_APP_RESUME, installMode: codePush.InstallMode.ON_NEXT_RESUME })(LoginMain));

const styles = StyleSheet.create({
  frame: {
    // position: 'absolute',
    width: '100%',
    height: '100%',
    flex: 1,
  },
  swiperDotView: {
    backgroundColor: washswatColor.black_40,
    width: 8,
    height: 8,
    borderRadius: 30,
    marginStart: 8,
    marginEnd: 8,
  },
  swiperActiveDotView: {
    backgroundColor: washswatColor.black,
    width: 8,
    height: 8,
    borderRadius: 30,
    marginStart: 8,
    marginEnd: 8,
  },
  startText: {
    paddingLeft: PixelRatio.roundToNearestPixel(24),
    color: washswatColor.white,
  },
  startButton: {
    justifyContent: 'center',
    marginTop: PixelRatio.roundToNearestPixel(60),
    backgroundColor: washswatColor.black,
    width: PixelRatio.roundToNearestPixel(184),
    height: PixelRatio.roundToNearestPixel(60),
  },
  videoWrap: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  videoContent: {
    width: '100%',
    height: '100%',
  },
  dimArea: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 370,
  },
  videoCommentWrap: {
    position: 'absolute',
    left: 24,
    bottom: 150,
    zIndex: 1,
  },
  videoComment: {
    marginTop: 16,
    ...responseFont(35).bold,
    color: washswatColor.white,
    zIndex: 1,
  },
  startBtn: {
    position: 'absolute',
    bottom: 48,
    left: 24,
    right: 24,
    height: 54,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 20,
    borderRadius: 5,
    backgroundColor: washswatColor.black,
  },
  startBtnText: {
    ...responseFont(15).bold,
    color: washswatColor.white,
  },
  swiperSkipBtn: {
    position: 'absolute',
    right: 14,
    bottom: 30,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
    paddingVertical: 10,
    ...responseFont(20).regular,
  },
  titleText: {
    marginBottom: PixelRatio.roundToNearestPixel(15),
  },
});
