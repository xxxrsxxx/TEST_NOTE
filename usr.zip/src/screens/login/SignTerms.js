import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
  Platform,
} from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import RoundCheckbox from 'rn-round-checkbox';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as LoginModule from '../../reducers/LoginModule';

import { JoinTimer } from '../../components/common/button/CommonComponent';

import WashAlert from '../../utils/alert';
import { Favorite, SignTermsText } from '../../utils/common/strings';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import AnalyticsManager from '../../utils/tagging/analytics';
import * as CommonUtils from '../../utils/common';
import * as KeyUtils from '../../utils/type/key';
import * as Server from '../../utils/type/server';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { responseFont, washswatColor } = Font;

class SignTerms extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount = async () => {
    const { phone } = this.props;

    // if(phone){
    //   /** 로그인 문제에서 넘어온 경우. 전화번호를 LoginModule 에 따로 저장 **/
    //   const { LoginAction } = this.props;
    // }

    const uid = await CommonUtils.getValue(KeyUtils.USER_ID);
    await AnalyticsManager.setAppsFlyerTrackEvent(
      AnalyticsKey.NAME_START_SING_UP,
    );
    if (uid) {
      AnalyticsManager.setAirbridgeTrackEvent(
        AnalyticsKey.NAME_START_SING_UP,
        Platform.OS,
        uid,
      );
    }
  };

  static options(passProps) {
    return {
      popGesture: false,
    };
  }

  goAddress = () => {
    const { componentId, LoginActionState } = this.props;

    if (LoginActionState.requireAllCheck) {
      const { servicePolicy } = LoginActionState;
      const { OS } = Platform;
      var needPushCheck = false;
      if (
        OS === 'ios' &&
        servicePolicy &&
        _.find(servicePolicy, { isChecked: true, type: 'push' })
      ) {
        needPushCheck = true;
      }
      CommonUtils.navPush({
        componentId,
        name: 'MapView',
        passProps: { fromPage: 'SignTerms' },
      });
    } else {
      WashAlert.showAlert('필수약관에 동의해주세요!', Favorite.ok);
    }
  };

  handleCheck = key => {
    const { LoginAction } = this.props;
    LoginAction.serviceUsePolicyCheck({ key });
  };

  handleAllCheck = () => {
    const { LoginAction } = this.props;
    LoginAction.serviceUsePolicyAllCheck();
  };

  handleClause = key => {
    let url = '';
    switch (key) {
      case 'clause':
        url = Server.URL_CLAUSE;
        break;
      case 'privacy':
        url = Server.URL_PRIVACY;
        break;
      case 'location':
        url = Server.URL_LOCATION_CLAUSE;
        break;
      default:
        break;
    }
    CommonUtils.navShowModalWebView({ url });
  };

  render() {
    const {
      servicePolicy,
      requireAllCheck,
      policyAllCheck,
      timerCounter,
    } = this.props.LoginActionState;
    let bottomTextView = [];

    _.mapKeys(servicePolicy, (value, key) => {
      bottomTextView.push(
        <TouchableOpacity
          activeOpacity={1}
          key={`SignTermsText${key}`}
          style={styles.bottomText}
        >
          <TouchableOpacity
            disabled={value.key === 'push'}
            onPress={() => this.handleClause(value.key)}
            style={{ justifyContent: 'center' }}
          >
            <Text style={responseFont(14).bold}>{value.text}</Text>
          </TouchableOpacity>
          <RoundCheckbox
            size={24}
            checked={value.isChecked}
            onValueChange={() => this.handleCheck(key)}
          />
        </TouchableOpacity>,
      );
    });

    return (
      <View style={{ flex: 1 }}>
        {/* <StatusBar backgroundColor={washswatColor.white} barStyle="dark-content" /> */}
        <View style={styles.statusView}>
          <JoinTimer timerCounter={timerCounter} />
          <Text
            onPress={this.goAddress}
            style={[
              styles.nextBtn,
              responseFont(16).bold,
              {
                color: !requireAllCheck
                  ? washswatColor.grey_03
                  : washswatColor.blue,
              },
            ]}
          >
            {SignTermsText.next}
          </Text>
        </View>
        <View style={styles.headView}>
          <View style={styles.headTitleView}>
            <Text style={responseFont(30).bold}>{SignTermsText.headTitle}</Text>
          </View>
          <View style={styles.headSubTitleView}>
            <Text style={responseFont(14).regular}>
              {SignTermsText.subTitle}
            </Text>
          </View>
        </View>
        <View style={styles.rowGrayLine} />
        <View style={styles.bottomView}>
          <TouchableOpacity activeOpacity={1} style={styles.bottomHeadView}>
            <Text style={responseFont(14).bold}>
              {SignTermsText.termsTitle}
            </Text>
            <RoundCheckbox
              size={24}
              checked={policyAllCheck}
              onValueChange={this.handleAllCheck}
            />
          </TouchableOpacity>
          <View style={styles.rowLine} />
          <View style={styles.bottomTextView}>{bottomTextView}</View>
        </View>
      </View>
    );
  }
}

const mapStateToProps = ({ LoginModule }) => ({
  LoginActionState: LoginModule,
});
const mapDispatchToProps = dispatch => ({
  LoginAction: bindActionCreators(LoginModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(SignTerms);

const styles = StyleSheet.create({
  bottomText: {
    marginBottom: PixelRatio.roundToNearestPixel(31),
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statusView: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: PixelRatio.roundToNearestPixel(60 + getStatusBarHeight(true)),
  },
  headView: {
    // height: PixelRatio.roundToNearestPixel(222)
  },
  bottomTextView: {
    paddingTop: PixelRatio.roundToNearestPixel(28),
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  rowLine: {
    marginLeft: PixelRatio.roundToNearestPixel(30),
    borderColor: washswatColor.grey_05,
    borderWidth: PixelRatio.roundToNearestPixel(0.5),
  },
  bottomHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: PixelRatio.roundToNearestPixel(27),
    paddingTop: PixelRatio.roundToNearestPixel(28),
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  nextBtn: {
    marginRight: PixelRatio.roundToNearestPixel(18),
    marginBottom: PixelRatio.roundToNearestPixel(17),
  },
  headTitleView: {
    marginTop: PixelRatio.roundToNearestPixel(24),
    paddingLeft: PixelRatio.roundToNearestPixel(30),
  },
  rowGrayLine: {
    backgroundColor: washswatColor.grey_05,
    height: PixelRatio.roundToNearestPixel(12),
  },
  headSubTitleView: {
    marginTop: PixelRatio.roundToNearestPixel(18),
    // alignItems: 'center',
    marginBottom: PixelRatio.roundToNearestPixel(60),
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
  },
  bottomView: {
    // height: PixelRatio.roundToNearestPixel(326)
  },
});
