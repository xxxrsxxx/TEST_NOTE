import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';

// modules import
import * as EventScreenModule from '../../reducers/EventScreenModule';
// components import
import { BannerListContainer } from '../../containers/event';
import LoadingBar from '../../components/common/button/LoadingBar';
import { BasicHeader } from '../../components/common/layout';

// redux import
// import { bindActionCreators } from 'redux';
import { useSelector, useDispatch } from 'react-redux';

function EventPageScreen({ componentId, title }) {
  const dispatch = useDispatch();
  const EventScreenState = useSelector(state => state.EventScreenModule);
  const { isPending } = EventScreenState;
  const getLoadBnrApi = () => dispatch(EventScreenModule.getLoadBnrApi());
  const destroyBnrData = () => dispatch(EventScreenModule.destroyBnrData());

  useEffect(() => {
    getLoadBnrApi();
    return () => {
      destroyBnrData();
    };
  }, []);

  return (
    <>
      {isPending ? <LoadingBar /> : null}
      <BasicHeader title={title} componentId={componentId} />
      <View style={styles.container}>
        <BannerListContainer
          EventScreenState={EventScreenState}
          getLoadBnrApi={getLoadBnrApi}
        />
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom: 24,
  },
});

export default EventPageScreen;
