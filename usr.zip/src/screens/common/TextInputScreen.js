import React from 'react';

import {
  Platform,
  StyleSheet,
  Text,
  TextInput,
  View,
  StatusBar,
  TouchableOpacity,
  PixelRatio,
  Keyboard,
  ScrollView,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import AndroidKeyboardAdjust from 'react-native-android-keyboard-adjust';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import NBImageButton from '../../components/common/button/NBImageButton';
import * as PageName from '../../vo/PageName';
import KeyboardSpacerIOS from '../../components/common/keyboard/KeyboardSpacerIOS';

import { TextInputScreenString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

class TextInputScreen extends React.Component {
  constructor(props) {
    super(props);

    let inputValue = ``;
    if (props.inputValue) {
      inputValue = props.inputValue;
    }

    this.state = {
      serviceType: '',
      serviceArr: [],
      inputValue,
      isAllUse: false,
    };
    Navigation.events().bindComponent(this);
  }

  onPressBack = () => {
    Navigation.pop(this.props.componentId);
  };

  componentDidMount() {
    if (Platform.OS === 'android') {
      AndroidKeyboardAdjust.setAdjustResize();
    }
  }

  componentDidDisappear() {}

  enterText = () => {
    const { pageName, componentId, MyPageAction, finishedAction } = this.props;
    const { inputValue } = this.state;
    switch (pageName) {
      case PageName.POINT_ACCUMULATION: // 적립코드
        MyPageAction.AccumulationCodeRegist({ inputValue, componentId });
        break;
      // case PageName.COUPON_CODE: // 쿠폰코드
      //   MyPageAction.couponRegist({ inputValue, componentId });
      //   break;
      case PageName.CHANGE_NAME:
        MyPageAction.changeName({ inputValue, componentId });
        break;
      case PageName.CHANGE_PHONE_NUM:
        MyPageAction.phoneNumChange({ inputValue, componentId });
        break;
      case PageName.USE_POINT:
        if (finishedAction) {
          finishedAction(
            isNaN(parseInt(inputValue)) ? 0 : parseInt(inputValue),
          );
          this.onPressBack();
        }
        break;
      case PageName.ORDER_CANCEL:
      case PageName.EMAIL_RECEIPT:
      case PageName.RECMD_CODE: // 추천인 코드
      case PageName.DOOR_CODE:
        if (finishedAction) {
          finishedAction(inputValue);
          this.onPressBack();
        }
        break;
    }
  };

  // TextInput placeholder 설정
  setTextInputPlaceholder = () => {
    const pageName = this.props.pageName;
    switch (pageName) {
      case PageName.POINT_ACCUMULATION: // 적립코드
        return TextInputScreenString.accumulationCodeInput;
      // case PageName.COUPON_CODE: // 쿠폰코드
      //   return TextInputScreenString.couponCodeInput;
      case PageName.CHANGE_NAME: // 닉네임 변경
      case PageName.CHANGE_PHONE: // 전화번호 변경
        return TextInputScreenString.enter10Characters;
      case PageName.USE_POINT: // 사용할 포인트 입력
        // return TextInputScreenString.usePoint;
        const { maximum } = this.props;
        return `${TextInputScreenString.maximum} ${maximum.toLocaleString()}${
          TextInputScreenString.canPoint
        }`;
      case PageName.EMAIL_RECEIPT:
        return TextInputScreenString.email;
      case PageName.ORDER_CANCEL:
        return TextInputScreenString.orderCancel;
      case PageName.RECMD_CODE:
        return TextInputScreenString.recmdIdInput;
      case PageName.DOOR_CODE:
        return TextInputScreenString.doorCodeInput;
    }
  };

  onChangeText = inputValue => {
    const { maximum } = this.props;
    if (maximum === undefined) {
      this.setState({ inputValue });
    } else {
      inputValue = parseInt(inputValue);
      if (isNaN(inputValue)) {
        this.setState({ inputValue: '0', isAllUse: false });
      } else {
        if (inputValue >= maximum) {
          this.setState({ inputValue: maximum + '', isAllUse: true });
        } else {
          this.setState({ inputValue: inputValue + '', isAllUse: false });
        }
      }
    }
  };

  onPressPointButton = () => {
    const { isAllUse } = this.state;
    const maxPoint = this.props.maximum;
    if (isAllUse) {
      // 모두사용 -> 사용안함
      this.setState({ inputValue: '0', isAllUse: false });
    } else {
      // 사용안함 -> 모두사용
      this.setState({ inputValue: maxPoint.toString(), isAllUse: true });
    }
  };

  static options(passProps) {
    return {
      statusBar: {
        visible: true,
        backgroundColor: washswatColor.black,
        style: 'light',
      },
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const { inputValue, isAllUse } = this.state;
    const { componentId, keyboardType, multiLine } = this.props;
    const doneColor =
      inputValue.length > 0 ? washswatColor.blue : washswatColor.blueOpacity45;
    const pageName = this.props.pageName;
    const isShowUsePointExplain =
      pageName === PageName.USE_POINT ? true : false;
    const usePointButtonText = isAllUse
      ? TextInputScreenString.doNotUse
      : TextInputScreenString.allUse;
    const maxLengthOfTextInput = pageName === PageName.CHANGE_NAME ? 10 : 100;

    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.black }}>
        <StatusBar barStyle="light-content" />
        <View style={{ height: getStatusBarHeight(true) }} />
        <NBImageButton
          onPress={this.onPressBack}
          source={require('image/common/back_button_white.png')}
        />
        <ScrollView>
          <View
            style={{
              flex: 1,
              marginStart: PixelRatio.roundToNearestPixel(30),
              marginTop: PixelRatio.roundToNearestPixel(23),
              marginEnd: PixelRatio.roundToNearestPixel(30),
            }}
          >
            <View style={{ flexDirection: 'row' }}>
              <TextInput
                style={[
                  responseFont(24).regular,
                  {
                    color: washswatColor.white,
                    flex: 1,
                    textAlignVertical: 'top',
                  },
                ]}
                placeholder={this.setTextInputPlaceholder()}
                placeholderTextColor={washswatColor.whiteOpacity45}
                onChangeText={this.onChangeText}
                value={inputValue}
                maxLength={maxLengthOfTextInput}
                multiline={multiLine ? true : false}
                keyboardType={keyboardType ? keyboardType : 'default'}
                keyboardShouldPersistTaps={'handled'}
              />
              {isShowUsePointExplain && (
                <TouchableOpacity
                  style={styles.usePointButton}
                  onPress={this.onPressPointButton}
                >
                  <Text
                    style={[
                      responseFont(14).regular,
                      { color: washswatColor.black },
                    ]}
                  >
                    {usePointButtonText}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
            <View
              style={[
                styles.blueLine,
                { marginTop: PixelRatio.roundToNearestPixel(9) },
              ]}
            />
            {isShowUsePointExplain && (
              <Text style={[responseFont(12).regular, styles.usePointExplain]}>
                {TextInputScreenString.usePointExplain}
              </Text>
            )}
          </View>
        </ScrollView>
        <TouchableOpacity
          onPress={this.enterText}
          style={styles.bottomButton}
          disabled={!inputValue}
        >
          <Text style={[responseFont(16).bold, { color: doneColor }]}>
            {TextInputScreenString.done}
          </Text>
        </TouchableOpacity>
        <KeyboardSpacerIOS />
      </View>
    );
  }
}

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(TextInputScreen);

const styles = StyleSheet.create({
  toolbarTitle: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  usePointButton: {
    width: PixelRatio.roundToNearestPixel(78),
    height: PixelRatio.roundToNearestPixel(30),
    backgroundColor: washswatColor.blue,
    borderRadius: PixelRatio.roundToNearestPixel(30),
    justifyContent: 'center',
    alignItems: 'center',
  },
  blueLine: {
    height: PixelRatio.roundToNearestPixel(2),
    backgroundColor: washswatColor.blue,
  },
  usePointExplain: {
    color: washswatColor.blue,
    lineHeight: PixelRatio.roundToNearestPixel(18),
    marginTop: PixelRatio.roundToNearestPixel(30),
  },
  bottomButton: {
    width: PixelRatio.roundToNearestPixel(105),
    height: PixelRatio.roundToNearestPixel(55),
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'flex-end',
  },
});
