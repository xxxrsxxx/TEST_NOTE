import React from 'react';

import { Image, StyleSheet, View } from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import NBImageButton from '../../components/common/button/NBImageButton';

import * as CommonUtils from '../../utils/common';

export default class ImageView extends React.Component {
  constructor(props) {
    super(props);
    Navigation.events().bindComponent(this);
  }

  onPressBack = () => {
    Navigation.dismissModal(this.props.componentId);
  };
  static options(passProps) {
    return {
      topBar: {
        visible: false,
        height: 0,
        drawBehind: true,
      },
    };
  }
  render() {
    const { url } = this.props;
    return (
      <View style={{ flex: 1 }}>
        <View style={{ height: getStatusBarHeight(true) }} />
        <NBImageButton
          onPress={this.onPressBack}
          source={require('../../../assets/image/common/no.png')}
        />
        <Image
          style={styles.image}
          source={{ uri: CommonUtils.replaceHttpToHttps(url) }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  image: {
    flex: 1,
    width: `100%`,
    height: `100%`,
    resizeMode: 'contain',
  },
});
