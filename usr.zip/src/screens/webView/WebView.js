import React from 'react';

import { Linking, Platform, StatusBar, StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { Navigation } from 'react-native-navigation';

import CloseButton from '../../components/common/button/CloseButton';
import LoadingBar from '../../components/common/button/LoadingBar';

import WashAlert from '../../utils/alert';
import { Favorite, WebViewText } from '../../utils/common/strings';
import * as Server from '../../utils/type/server';
import { Styles } from '../../utils/style';

const { androidStatusBar } = Styles;

export default class WView extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      url: '',
      method: '',
      isLoading: true,
      // body: ''
    };
    Navigation.events().bindComponent(this);
  }

  componentDidMount() {}

  onPressBack = () => {
    Navigation.dismissModal(this.props.componentId);
  };

  static options(passProps) {
    if (passProps.video && Platform.OS === 'ios') {
      let left = {
        id: 'cancelBtn',
        text: 'Cancel',
      };

      // if(Platform.OS === 'android'){
      //   left.icon = require('../../../assets/image/utils/arrow_back.png');
      //   left.disableIconTint = true;
      // }

      return {
        topBar: {
          leftButtons: [left],
          visible: true,
        },
      };
    } else {
      return {
        topBar: {
          visible: false,
          background: {
            color: 'transparent',
          },
        },
      };
    }
  }

  handleWebViewNavigationStateChange = newNavState => {
    const { url } = newNavState;
    if (url && url !== 'about:blank') {
      if (
        !url.startsWith('http') &&
        !url.startsWith('javascript:') &&
        !url.startsWith('file://')
      ) {
        Linking.canOpenURL(url)
          .then(supported => {
            if (!supported) {
              if (this.webview) {
                this.setState({ url: '' });
              }
            } else {
              this.setState({ url: '' });
              return Linking.openURL(url);
            }
          })
          .catch(err => {
            // ('An error occurred', err)
          });
      } else {
      }
    } else {
    }
  };

  showSpinner = () => {
    this.setState({ isLoading: true });
  };
  hideSpinner = () => {
    this.setState({ isLoading: false });
  };

  navigationButtonPressed({ buttonId }) {
    if (buttonId === 'cancelBtn') {
      Navigation.dismissModal(this.props.componentId);
    }
  }

  onMessage = e => {
    const { data } = e.nativeEvent;
    const { finishedAction } = this.props;

    if (data && data.includes('{')) {
      setTimeout(() => {
        finishedAction(JSON.parse(data));
      }, 200);
      this.onPressBack();
    }
    if (data) {
      const split = data.split('\n');
      if (split.length > 0 && split[0] && split[1]) {
        const url = split[1];
        switch (split[0]) {
          case 'gs25/detail/gs25-find':
          case 'gs25/detail/washswat-channel':
            Linking.canOpenURL(url)
              .then(supported => {
                if (!supported) {
                  WashAlert.showAlert(WebViewText.appUpdate, Favorite.ok);
                } else {
                  return Linking.openURL(url);
                }
              })
              .catch(err => console.error('An error occurred', err));
            break;
          default:
            break;
        }
      }
    }
  };

  render() {
    const { data, url, video } = this.props;
    const { isLoading } = this.state;

    return (
      <View
        style={{
          flex: 1,
          marginTop:
            Platform.OS === 'android' && url !== Server.URL_USER_GUIDE
              ? -androidStatusBar
              : 0,
        }}
      >
        <StatusBar
          barStyle={
            Platform.OS === 'android' ? 'dark-content' : 'light-content'
          }
        />
        <View
          style={{
            flex: 1,
            marginTop: video && Platform.OS === 'ios' ? 55 : 0,
          }}
        >
          {Platform.OS === 'ios' || video ? (
            <WebView
              source={{ uri: url }}
              javaScriptEnabled={true}
              domStorageEnabled={true}
              onLoadStart={() => this.showSpinner()}
              onLoad={() => this.hideSpinner()}
              downloadEnabled={true}
              onMessage={this.onMessage.bind(this)}
              renderError={e => {
                if (e === 'NSURLErrorDomain') {
                  // WashAlert.showAlertWithCallback(Favorite.fail, Favorite.ok, () => {
                  //   this.onPressBack();
                  // });
                }
              }}
            />
          ) : (
            <WebView
              ref={webview => {
                this.webview = webview;
              }}
              source={{ uri: url }}
              javaScriptEnabled={true}
              domStorageEnabled={true}
              onLoadStart={() => this.showSpinner()}
              onLoad={() => this.hideSpinner()}
              originWhitelist={['*']}
              onMessage={this.onMessage.bind(this)}
              onNavigationStateChange={this.handleWebViewNavigationStateChange}
              // onShouldStartLoadWithRequest={this.handleWebViewNavigationStateChange}
              renderError={e => {
                if (e === 'NSURLErrorDomain') {
                  // WashAlert.showAlertWithCallback(Favorite.fail, Favorite.ok, () => {
                  //   this.onPressBack();
                  // });
                }
              }}
            />
          )}
          {video && Platform.OS === 'ios' ? (
            <></>
          ) : (
            <CloseButton onPress={this.onPressBack} />
          )}
        </View>
        {isLoading ? <LoadingBar /> : null}
      </View>
    );
  }
}

const styles = StyleSheet.create({});
