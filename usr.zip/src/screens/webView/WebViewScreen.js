import React from 'react';
import { View } from 'react-native';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
// modules import
import * as WebviewModule from '../../reducers/WebviewModule';
// components import
import CtaLayout from '../../layouts/CtaLayout';
import { WebViewContainer } from '../../containers/webView';
import LoadingBar from '../../components/common/button/LoadingBar';

function WebViewScreen(props) {
  /**
   *
   * @dsc
   * CommonUtils.navPush({
   *   componentId: this.props.componentId,
   *   name: 'WebViewScreen',
   *   passProps: {
   *      option: {
   *        title: '프리미엄',
   *        url:
   *          'https://setagteuggongdaes-contents.webflow.io/add-premium',
   *        cta: {
   *          anchor: '', // Cta Btn Name
   *          anchorScreen: '', // 이동할 스크린 등록 ex MyPageScreen
   *          cbAction: () => {},
   *       },
   *     },
   *   },
   * });
   */

  const dispatch = useDispatch();
  const WebviewState = useSelector(state => state.WebviewModule);
  const { isPending } = WebviewState;
  const pendingHandler = props => dispatch(WebviewModule.pendingHandler(props));

  return (
    <View style={{ flex: 1 }}>
      {isPending ? <LoadingBar /> : null}
      {CtaLayout(
        { ...props, pendingHandler: pendingHandler },
        WebViewContainer,
      )}
    </View>
  );
}

WebViewScreen.propTypes = {
  option: PropTypes.shape({
    title: PropTypes.string.isRequired,
    url: PropTypes.string.isRequired,
  }).isRequired,
};

export default WebViewScreen;
