import React from 'react';

import {
  Dimensions,
  PixelRatio,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import AndroidKeyboardAdjust from 'react-native-android-keyboard-adjust';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as ChangeAddressModule from '../../reducers/ChangeAddressModule';

import NBImageButton from '../../components/common/button/NBImageButton';
import {
  ChatRowLeft,
  ChatRowRight,
} from '../../components/login/ChatComponent';
import LoadingBar from '../../components/common/button/LoadingBar';
import KeyboardSpacerIOS from '../../components/common/keyboard/KeyboardSpacerIOS';

import { Font } from '../../utils/style';
import { AddressChatText } from '../../utils/common/strings';

import { _ } from '../../plugins';

const { washswatColor } = Font;

const windowSize = Dimensions.get('window');

class AddressChangeChat extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      init: true,
    };
  }

  componentDidMount() {
    if (Platform.OS === 'android') {
      AndroidKeyboardAdjust.setAdjustResize();
    }
  }

  static getDerivedStateFromProps(nextProps, prevProps) {
    const {
      ChangeAddressState: { finished },
    } = nextProps;
    if (finished) {
      Navigation.popToRoot(this.props.componentId);
    }
  }

  // deprecated life cycle. getDerivedStateFromProps로 변경.
  // componentWillReceiveProps(nextProps) {
  //   const {
  //     ChangeAddressState: { finished },
  //   } = nextProps;
  //   if(finished){
  //     Navigation.popToRoot(this.props.componentId);
  //   }
  // }

  onPressClose = () => {
    Navigation.pop(this.props.componentId);
  };

  static options(passProps) {
    return {
      popGesture: false,
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const {
      ChangeAddressState: {
        chatArray,
        inputTextValueForConfirmScreen,
        isPending,
      },
      ChangeAddressAction: { handleInputText, sendPress, buttonPress },
      componentId,
    } = this.props;

    console.log('chatArray');

    const chat = [];
    var viewPlaceHolder, viewNextIndex, viewKey;
    var autoScroll = true;
    _.map(
      chatArray,
      (
        {
          type,
          array,
          nextIndex,
          placeholder,
          key,
          webView,
          removeAutoScrolling,
        },
        i,
      ) => {
        if (type === 'left') {
          chat.push(<ChatRowLeft key={`ChatRowLeft_${i}`} array={array} />);
        } else if (type === 'input') {
          viewPlaceHolder = placeholder;
          viewNextIndex = nextIndex;
          viewKey = key;
        } else if (type === 'button') {
          chat.push(
            <ChatRowRight
              key={`ChatRowLeft_${i}`}
              array={array}
              onPress={buttonPress}
            />,
          );
        } else if (type === 'right') {
          chat.push(<ChatRowRight key={`ChatRowLeft_${i}`} array={array} />);
        }
      },
    );

    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.white }}>
        {isPending ? <LoadingBar /> : null}
        <View style={{ height: getStatusBarHeight(true) }} />
        <NBImageButton
          onPress={this.onPressClose}
          source={require('image/common/back_button_black.png')}
        />
        <View style={styles.bodyView}>
          <ScrollView
            ref={ref => (this.scrollView = ref)}
            showsVerticalScrollIndicator={false}
            style={{ marginRight: PixelRatio.roundToNearestPixel(30) }}
            onContentSizeChange={(contentWidth, contentHeight) => {
              if (autoScroll) {
                if (this.state.init) {
                  this.state.init = false;
                } else {
                  this.scrollView.scrollToEnd({ animated: true });
                }
              }
            }}
          >
            {chat}
            <View style={{ height: PixelRatio.roundToNearestPixel(36) }} />
          </ScrollView>
        </View>
        {viewPlaceHolder && viewNextIndex && (
          <View
            style={{
              flexDirection: 'row',
              borderTopWidth: PixelRatio.roundToNearestPixel(1),
              borderColor: washswatColor.grey_05,
            }}
          >
            <View
              style={{
                flex: 1,
                marginLeft: PixelRatio.roundToNearestPixel(30),
                width: PixelRatio.roundToNearestPixel(windowSize.width - 95),
              }}
            >
              <TextInput
                value={inputTextValueForConfirmScreen}
                placeholder={viewPlaceHolder}
                onChangeText={e => handleInputText(e)}
                style={styles.inputText}
              />
            </View>
            <TouchableOpacity
              multiline={true}
              style={styles.sendBtn}
              onPress={() =>
                sendPress({ key: viewKey, nextIndex: viewNextIndex })
              }
              activeOpacity={1}
            >
              <Text>{AddressChatText.sendButton}</Text>
            </TouchableOpacity>
          </View>
        )}
        <KeyboardSpacerIOS />
      </View>
    );
  }
}

const mapStateToProps = ({ ChangeAddressModule }) => ({
  ChangeAddressState: ChangeAddressModule,
});
const mapDispatchToProps = dispatch => ({
  ChangeAddressAction: bindActionCreators(ChangeAddressModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(AddressChangeChat);

const styles = StyleSheet.create({
  bodyView: {
    flex: 1,
    paddingLeft: PixelRatio.roundToNearestPixel(30),
  },
  leftChatText: {
    flex: 1,
    backgroundColor: washswatColor.grey_05,
    borderRadius: PixelRatio.roundToNearestPixel(3),
    padding: PixelRatio.roundToNearestPixel(15),
  },
  leftChatView: {
    flexDirection: 'row',
    flex: 1,
    paddingTop: PixelRatio.roundToNearestPixel(24),
  },
  imageView: {
    marginRight: PixelRatio.roundToNearestPixel(9),
    width: PixelRatio.roundToNearestPixel(30),
    height: PixelRatio.roundToNearestPixel(30),
  },
  rightChatView: {
    alignItems: 'flex-end',
    paddingTop: PixelRatio.roundToNearestPixel(24),
  },
  rightChatText: {
    borderRadius: PixelRatio.roundToNearestPixel(3),
    padding: PixelRatio.roundToNearestPixel(15),
    borderColor: washswatColor.blue,
    borderWidth: PixelRatio.roundToNearestPixel(3),
  },
  inputText: {
    height: PixelRatio.roundToNearestPixel(56),
    textAlignVertical: 'center',
    color: washswatColor.black,
  },
  sendBtn: {
    paddingTop: PixelRatio.roundToNearestPixel(20),
    paddingLeft: PixelRatio.roundToNearestPixel(24),
    paddingBottom: PixelRatio.roundToNearestPixel(18),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
});
