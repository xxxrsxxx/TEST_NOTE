import React from 'react';

import {
  FlatList,
  Image,
  PixelRatio,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as ChangeAddressModule from '../../reducers/ChangeAddressModule';

import { BasicHeader } from '../../components/common/layout';
import AddressChangeItemView from '../../components/delivery/AddressChangeItemView';
import ListItem from '../../components/login/ListItem';

import { AddressChangeString } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { washswatColor, responseFont } = Font;

class AddressChange extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchText: '',
    };
  }

  onPressBack = () => {
    const { ChangeAddressAction, componentId } = this.props;
    // ChangeAddressAction.backPrsess();
    Navigation.pop(componentId);
  };

  componentDidMount() {
    const { ChangeAddressAction } = this.props;
    ChangeAddressAction.init();
  }

  onSubmitEditingSearch = () => {
    const { ChangeAddressAction } = this.props;
    const { searchText } = this.state;
    ChangeAddressAction.getLocation({ q: searchText });
  };

  onChangeTextSearch = search => {
    this.setState({ searchText: search });
  };

  onPressTextInputClear = () => {
    this.setState({ searchText: '' });
  };

  selectedImageSource = {
    on: require('image/mypage/address_select_on.png'),
    off: require('image/mypage/address_select_off.png'),
  };

  _ListView = () => {
    const { ChangeAddressState, ChangeAddressAction, componentId } = this.props;
    const { userAddressList, resultList } = ChangeAddressState;
    const { changeMyAddress } = ChangeAddressAction;
    if (resultList.length > 0) {
      console.log('resultList', resultList);
      return (
        <FlatList
          style={{
            backgroundColor: washswatColor.white,
            paddingTop: PixelRatio.roundToNearestPixel(24),
          }}
          data={resultList}
          renderItem={this.itemView}
          keyExtractor={(item, index) => index.toString()}
        />
      );
    } else {
      // console.log('userAddressList', userAddressList);
      if (userAddressList.length > 0) {
        return (
          <ScrollView>
            {_.map(
              userAddressList,
              ({ idx, valid, title, roadAddress, addressOthers }) => {
                return (
                  <AddressChangeItemView
                    key={idx}
                    selectedImageSource={
                      valid
                        ? this.selectedImageSource.on
                        : this.selectedImageSource.off
                    }
                    valid={valid}
                    title={title}
                    address={roadAddress}
                    addressOthers={addressOthers}
                    onPressAddress={() => {
                      if (!valid) {
                        changeMyAddress('default', idx, componentId);
                      }
                    }}
                    onPressDelete={() =>
                      changeMyAddress('delete', idx, componentId)
                    }
                  />
                );
              },
            )}
          </ScrollView>
        );
      } else {
        return <View />;
      }
    }
  };
  itemView = ({ item }) => {
    const { ChangeAddressState, ChangeAddressAction, componentId } = this.props;
    const { userAddressList } = ChangeAddressState;
    // const { selectLocation } = LoginAction;
    const { searchText } = this.state;
    const { latitude, longitude, roadAddress, address } = item;

    return (
      <ListItem
        key={`$-${item.idx}`}
        onPress={() => {
          if (latitude && longitude && roadAddress) {
            console.log('add');
            console.log('latitude', latitude);
            console.log('longitude', longitude);
            console.log('roadAddress', roadAddress);
            ChangeAddressAction.addMyAddress({
              address,
              roadAddress,
              latitude,
              longitude,
              componentId,
            });
          } else {
            console.log('go Mapview');

            CommonUtils.navPush({
              componentId,
              name: 'MapView',
              passProps: {
                latitude: parseFloat(latitude),
                longitude: parseFloat(longitude),
                fromPage: 'AddressChange',
                searchText,
              },
            });
          }
        }}
        {...{ ...item, componentId }}
      />
    );
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const { ChangeAddressState, ChangeAddressAction, componentId } = this.props;
    const { userAddressList, resultList } = ChangeAddressState;
    // const { selectLocation } = LoginAction;
    const { searchText } = this.state;
    const isSearch = searchText.length > 0;
    console.log('address change');

    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: washswatColor.white }}>
        {/*<View style={{ flex: 1, backgroundColor: washswatColor.white, marginTop: Platform.OS === 'android' ? -androidStatusBar : 0 }}>*/}
        {/*<View style={{ height: getStatusBarHeight(true) }} />*/}
        <BasicHeader componentId={this.props.componentId} />

        {/* <NBImageButton onPress={this.onPressBack} source={require('image/common/back_button_black.png')} /> */}
        <View style={styles.textInputView}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <TextInput
              style={[
                responseFont(24).bold,
                {
                  color: washswatColor.black,
                  flex: 1,
                  textAlignVertical: 'top',
                },
              ]}
              placeholder={AddressChangeString.placeholderText}
              placeholderTextColor={washswatColor.grey_03}
              onSubmitEditing={this.onSubmitEditingSearch}
              returnKeyType={'search'}
              onChangeText={this.onChangeTextSearch}
              value={searchText}
            />
            {isSearch && (
              <TouchableOpacity onPress={this.onPressTextInputClear}>
                <Image
                  source={require('image/mypage/address_text_clear.png')}
                  style={styles.textInputClearButton}
                />
              </TouchableOpacity>
            )}
          </View>
        </View>

        <View
          style={{
            backgroundColor: washswatColor.grey_05,
            height: PixelRatio.roundToNearestPixel(1),
          }}
        />
        {this._ListView()}
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  textInputView: {
    paddingStart: PixelRatio.roundToNearestPixel(30),
    ...Platform.select({
      android: {
        paddingTop: PixelRatio.roundToNearestPixel(118),
      },
      ios: {
        paddingTop: PixelRatio.roundToNearestPixel(138),
      },
    }),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(23),
  },
  textInputClearButton: {
    width: PixelRatio.roundToNearestPixel(18),
    height: PixelRatio.roundToNearestPixel(18),
    marginStart: PixelRatio.roundToNearestPixel(30),
  },
});

const mapStateToProps = ({ ChangeAddressModule }) => ({
  ChangeAddressState: ChangeAddressModule,
});
const mapDispatchToProps = dispatch => ({
  ChangeAddressAction: bindActionCreators(ChangeAddressModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(AddressChange);
