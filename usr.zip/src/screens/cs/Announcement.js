import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  Platform,
  PixelRatio,
  ScrollView,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import Accordion from 'react-native-collapsible/Accordion';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import AnnouncementHeaderView from '../../components/cs/AnnouncementHeaderView';
import AnnouncementContentView from '../../components/cs/AnnouncementContentView';
import LoadingBar from '../../components/common/button/LoadingBar';
import { BasicHeader } from '../../components/common/layout';

import { AnnouncementString } from '../../utils/common/strings';
import { moment } from '../../plugins';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

class Announcement extends React.Component {
  state = {
    activeSections: [],
    isLoading: true,
  };

  componentDidMount() {
    const { MyPageAction } = this.props;

    MyPageAction.getAnnouncement();
  }

  _renderHeader = (section, index, isActive) => {
    const diffDay = moment().diff(
      moment(new Date(section.regdate)).format('YYYY-MM-DD'),
      'day',
    );
    return (
      <View>
        <AnnouncementHeaderView
          title={section.title}
          regdate={section.regdate}
          diffDay={diffDay}
          isActive={isActive}
        />
      </View>
    );
  };

  _renderContent = section => {
    let fullText = '';
    section.content.map((item, index) => {
      fullText += `${item.content} <br>`;
    });
    return (
      <View>
        <AnnouncementContentView content={fullText} />
      </View>
    );
  };

  _updateSections = activeSections => {
    this.setState({ activeSections });
  };

  onPressBack = () => {
    Navigation.pop(this.props.componentId);
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const { announceList } = this.props.MyPageState;
    return (
      <View style={{ flex: 1 }}>
        {announceList.length === 0 && <LoadingBar />}

        <View style={{ height: getStatusBarHeight(true) }} />

        <ScrollView>
          <Text style={[responseFont(30).bold, styles.noticeText]}>
            {AnnouncementString.notice}
          </Text>
          <View
            style={{
              height: PixelRatio.roundToNearestPixel(2),
              backgroundColor: washswatColor.black,
              marginStart: PixelRatio.roundToNearestPixel(30),
              marginTop: PixelRatio.roundToNearestPixel(60),
            }}
          />
          <View style={{ marginBottom: PixelRatio.roundToNearestPixel(94) }}>
            <Accordion
              sections={announceList}
              activeSections={this.state.activeSections}
              renderHeader={this._renderHeader}
              renderContent={this._renderContent}
              onChange={this._updateSections}
              underlayColor={'transparent'}
              containerStyle={{ backgroundColor: washswatColor.white }}
            />
          </View>
        </ScrollView>
        <BasicHeader componentId={this.props.componentId} />
      </View>
    );
  }
}

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(Announcement);

const styles = StyleSheet.create({
  noticeText: {
    color: washswatColor.black,
    marginStart: PixelRatio.roundToNearestPixel(30),
    marginTop:
      Platform.OS === 'android'
        ? PixelRatio.roundToNearestPixel(110)
        : PixelRatio.roundToNearestPixel(80),
  },
});
