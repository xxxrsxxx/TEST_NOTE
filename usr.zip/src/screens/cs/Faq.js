import React from 'react';

import {
  PixelRatio,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import Accordion from 'react-native-collapsible/Accordion';
import { ChannelIO } from 'react-native-channel-plugin';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import FaqList from '../../components/cs/FaqList';
import FaqListDetail from '../../components/cs/FaqListDetail';
import LoadingBar from '../../components/common/button/LoadingBar';
import { BasicHeader } from '../../components/common/layout';

import { FaqString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

class Faq extends React.Component {
  state = {
    activeSections: [],
    index: 0,
  };

  componentDidMount() {
    this.props.MyPageAction.getQnA();
  }
  onPressBack = () => {
    Navigation.pop(this.props.componentId);
  };
  _renderHeader = section => {
    return (
      <View>
        <FaqList title={section.question} />
      </View>
    );
  };

  _renderContent = (section, index) => {
    return (
      <View>
        <FaqListDetail contents={section.answer} />
      </View>
    );
  };

  _updateSections = activeSections => {
    this.setState({ activeSections });
  };
  selectTitle = index => {
    const { QnAList } = this.props.MyPageState;
    this.setState({
      index: index,
    });
  };

  chat = () => {
    ChannelIO.showMessenger();
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const { QnAList, isPending } = this.props.MyPageState;
    const views = [];
    const titleView = [];
    QnAList.map((item, i) => {
      titleView.push(
        <TouchableOpacity
          key={`textKey${i}`}
          onPress={() => this.selectTitle(i)}
        >
          <Text
            style={[responseFont(16).bold, { marginTop: 20, marginRight: 36 }]}
          >
            {item.title}
          </Text>
        </TouchableOpacity>,
      );
    });
    if (QnAList.length !== 0) {
      views.push(
        <View key={`qna${this.state.index}`}>
          <Accordion
            sections={QnAList[this.state.index].qa}
            activeSections={this.state.activeSections}
            renderSectionTitle={this._renderSectionTitle}
            renderHeader={this._renderHeader}
            renderContent={this._renderContent}
            onChange={this._updateSections}
            underlayColor={'transparent'}
            containerStyle={{ backgroundColor: washswatColor.white }}
          />
        </View>,
      );
    }

    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: washswatColor.white }}>
        {isPending && <LoadingBar />}
        {/*<View style={{ height: getStatusBarHeight(true) }} />*/}
        <ScrollView ref={ref => (this.scrollView = ref)}>
          <View style={styles.mainText}>
            <Text style={[responseFont(30).bold]}>FAQ</Text>
          </View>
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
            <View style={styles.titleView}>{titleView}</View>
          </ScrollView>
          <View style={styles.line} />
          {views}
        </ScrollView>
        <BasicHeader onPress={this.onPressBack} inSafeAreaView={true} />
        <View style={styles.top}>
          <View style={styles.guideBook}>
            <TouchableOpacity onPress={this.chat}>
              <Text style={styles.chatButton}>{`👆 ${FaqString.chat}`}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(Faq);

const styles = StyleSheet.create({
  top: {
    backgroundColor: 'transparent',
    marginTop: getStatusBarHeight() >= 44 ? getStatusBarHeight() + 4 : 24,
    flexDirection: 'row',
    paddingLeft: 18,
    paddingRight: 18,
    paddingBottom: 12,
    position: 'absolute',
    top: 0,
    right: 0,
    zIndex: 2,
  },
  chatButton: {
    color: washswatColor.blue,
    ...responseFont(16).regular,
    padding: 5,
  },
  guideBook: {
    paddingLeft: 7,
    paddingRight: 7,
    backgroundColor: washswatColor.blueOpacity12,
    borderRadius: 30,
    position: 'relative',
    zIndex: 100,
  },
  titleView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginLeft: PixelRatio.roundToNearestPixel(30),
    marginBottom: PixelRatio.roundToNearestPixel(30),
  },
  mainText: {
    marginBottom: PixelRatio.roundToNearestPixel(39),
    marginTop:
      Platform.OS === 'android'
        ? PixelRatio.roundToNearestPixel(110)
        : PixelRatio.roundToNearestPixel(80),
    marginLeft: PixelRatio.roundToNearestPixel(30),
  },
  line: {
    height: PixelRatio.roundToNearestPixel(2),
    backgroundColor: washswatColor.black,
    marginLeft: PixelRatio.roundToNearestPixel(30),
  },
});
