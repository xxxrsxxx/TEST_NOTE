import React from 'react';

import {
  BackHandler,
  Dimensions,
  Image,
  ImageBackground,
  PixelRatio,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import Modal from 'react-native-modalbox';
import BottomSheet from 'react-native-bottomsheet';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as PriceListModule from '../../reducers/PriceListModule';

import NormalRow from '../../components/info/NormalRow';
import DetailMessageModal from '../../components/info/DetailMessageModal';
import DetailModal from '../../components/info/DetailModal';

import * as CommonUtils from '../../utils/common';
import * as KeyUtils from '../../utils/type/key';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import AnalyticsManager from '../../utils/tagging/analytics';
import {
  Favorite,
  PriceListString,
  PriceString,
} from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { washswatColor, responseFont } = Font;

const priceListArray = [
  { title: 'ALL', image: require('image/Price/bedding.png') },
  { title: 'CLOTHING', image: require('image/Price/clothes.png') },
  { title: 'LIVING', image: require('image/Price/living.png') },
  { title: 'BEDDING', image: require('image/Price/bedding.png') },
  { title: 'SHOES', image: require('image/Price/shoes.png') },
  { title: 'LEATHER', image: require('image/Price/leather.png') },
  { title: 'REPAIR', image: require('image/Price/repair.png') },
];

const feeTypeArray = [
  {
    key: 'DEFAULT',
    name: [PriceListString.basicFee, PriceListString.premiumFee],
  },
  {
    key: 'LIVING',
    name: [
      PriceListString.smallFee,
      PriceListString.mediumFee,
      PriceListString.largeFee,
    ],
  },
  {
    key: 'BEDDING',
    name: [
      PriceListString.singleFee,
      PriceListString.doubleFee,
      PriceListString.queenKingFee,
    ],
  },
  {
    key: 'REPAIR',
    name: [PriceListString.basicFee],
  },
];

function numberWithCommas(x) {
  return x?.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

class PriceList extends React.Component {
  constructor(props) {
    super(props);
    Navigation.events().bindComponent(this);
    this.state = {
      cart: 1,
      isOpen: false,
      priceItem: {},
      bottomSheetIndexes: priceListArray.map(element => {
        return {
          key: element.title,
          index: 0,
        };
      }),
      uid: undefined,
    };
  }
  componentDidAppear() {
    if (Platform.OS === 'android') {
      BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
    }
  }
  componentDidDisappear() {
    if (Platform.OS === 'android') {
      BackHandler.removeEventListener(
        'hardwareBackPress',
        this.handleBackButton,
      );
    }
  }
  handleBackButton = () => {
    const { componentId } = this.props;
    Navigation.mergeOptions(componentId, {
      bottomTabs: {
        currentTabIndex: 0,
      },
    });
    return true;
  };

  async componentDidMount() {
    const { PriceListAction } = this.props;
    PriceListAction.getPriceList();
    const uid = await CommonUtils.getValue(KeyUtils.USER_ID);
    this.setState({ uid });
    await AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_PRICE);
    AnalyticsManager.setAirbridgeTrackEvent(
      AnalyticsKey.NAME_PRICE,
      Platform.OS,
      uid,
    );
  }

  onPressTextInputClear = () => {
    const { PriceListAction } = this.props;
    const { uid } = this.state;
    PriceListAction.searchTextChange('', uid);
  };

  onClickPriceList = async (item, index) => {
    const { PriceListAction } = this.props;
    // this.setState({
    //   priceItem: item
    // });
    PriceListAction.getItemPriceDetail(item.name);
    const { itemDetail } = this.props.PriceListState;
    this.refs.modal.open();
    const uid = await CommonUtils.getValue(KeyUtils.USER_ID);
    await AnalyticsManager.setAppsFlyerTrackEvent(
      AnalyticsKey.NAME_PRICE_DETAIL,
      {
        af_uid: uid,
        af_item: item.name,
      },
    );
    AnalyticsManager.setAirbridgeTrackEvent(
      AnalyticsKey.NAME_PRICE_DETAIL,
      Platform.OS,
      uid,
    );
  };
  onPressDetailModalClose = () => {
    this.refs.modal.close();
  };
  onTouchCart = () => {
    //장바구니
  };
  onSpecial = () => {
    this.refs.modal2.open();
  };
  onPremium = () => {
    this.refs.modal3.open();
  };
  onSpecialClose = () => {
    this.refs.modal2.close();
  };
  onPremiumClose = () => {
    this.refs.modal3.close();
  };
  onCategoryPress = text => {};

  bottomSheetAppear = (feeTypeArray, category) => {
    const bottomSheetOptionsArray = this.getBottomSheetOptionsArray(
      feeTypeArray,
      category,
    );
    const cancelButtonIndex = bottomSheetOptionsArray.length - 1;
    BottomSheet.showBottomSheetWithOptions(
      {
        options: bottomSheetOptionsArray,
        // options: ['기본요금', '스페셜요금', '프리미엄요금', '취소'],
        title: '선택',
        dark: true,
        cancelButtonIndex,
      },
      value => {
        // alert(value);
        const { bottomSheetIndexes } = this.state;
        const foundIndex = bottomSheetIndexes.findIndex(object => {
          return object.key === category;
        });
        if (foundIndex !== -1 && value !== cancelButtonIndex) {
          this.setState({
            bottomSheetOptionsArray: (bottomSheetIndexes[
              foundIndex
            ].index = value),
          });
        }
      },
    );
  };

  getBottomSheetOptionsArray = (feeTypeArray, category) => {
    const feeTypeObject = this.getFeeTypeObject(feeTypeArray, category);
    const bottomSheetOptionsArray = _.cloneDeep(feeTypeObject.name);
    bottomSheetOptionsArray.push(Favorite.cancel);
    return bottomSheetOptionsArray;
  };

  getFeeTypeName = (feeTypeArray, category) => {
    const feeTypeObject = this.getFeeTypeObject(feeTypeArray, category);
    const { bottomSheetIndexes } = this.state;
    const found = bottomSheetIndexes.find(object => object.key === category);
    if (found) {
      return feeTypeObject.name[found.index];
    } else {
      return feeTypeObject.name[0];
    }
  };

  getFeeTypeObject = (feeTypeArray, category) => {
    let feeTypeObject = feeTypeArray.find(object => {
      if (category) {
        return object.key === category;
      }
    });
    if (feeTypeObject === undefined) {
      feeTypeObject = feeTypeArray[0];
    }
    return feeTypeObject;
  };

  getTypeOfPrice = type => {
    let index = 0;
    switch (type) {
      case 'special':
        index = 1;
        break;
      case 'premium':
        index = 2;
        break;
      default:
        index = -1;
        break;
    }
    if (index === -1) {
      return '';
    }
    const { itemDetail, category } = this.props.PriceListState;
    const { isSingle, showInfoTitle, info } = itemDetail;
    let name;
    if (category === 'LIVING' || isSingle) {
      name = this.getFeeTypeObject(feeTypeArray, category).name[index];
    } else {
      if (
        type === 'premium' &&
        !(isSingle && (category === 'LIVING' || category === 'BEDDING'))
      ) {
        name = feeTypeArray[0].name[1];
      } else {
        name = feeTypeArray[0].name[index];
      }
    }
    if (info && showInfoTitle) {
      const { basic, special, premium } = info;
      if (index === 1) {
        name = special.title;
      }
      if (index === 2) {
        name = premium.title;
      }
    }
    return name;
  };

  static options(passProps) {
    return {
      statusBar: {
        visible: true,
        backgroundColor: washswatColor.white,
        style: 'dark',
      },
    };
  }

  render() {
    const {
      priceListArr,
      isPending,
      itemDetail,
      search,
      category,
    } = this.props.PriceListState;
    const {
      PriceListAction: { searchTextChange, categorySearch },
    } = this.props;
    const listofPrice = priceListArr;
    const { isSingle, info, showInfoTitle } = itemDetail;
    const { uid } = this.state;
    const onlyNumberOfDetailMessageModal =
      category === 'LIVING' || category === 'BEDDING';
    // const onlyNumberOfDetailMessageModal = isSingle && category === 'BEDDING' && info && showInfoTitle;

    let views = [];

    let listViews = [];
    if (listofPrice.length !== 0) {
      console.log('listofPrice', listofPrice);
      listofPrice.items.map((item, index) => {
        const { category } = this.props.PriceListState;
        const { bottomSheetIndexes } = this.state;
        let price = item.basic;
        const found = bottomSheetIndexes.find(
          object => object.key === category,
        );
        if (found) {
          if (category === 'LIVING' || category === 'BEDDING') {
            switch (found.index) {
              case 0:
                price = item.basic;
                break;
              case 1:
                price = item.special;
                break;
              case 2:
                price = item.premium;
                break;
              default:
                price = item.basic;
                break;
            }
          } else {
            switch (found.index) {
              case 0:
                price = item.basic;
                break;
              case 1:
                price = item.premium;
                break;
              default:
                price = item.basic;
                break;
            }
          }
        }
        // const priceText = price !== 0 ? price : item.basic;
        const priceText = !!price ? price : item.basic;

        listViews.push(
          <NormalRow
            key={`priceList${index}`}
            titleLabel={item.name}
            price={`${numberWithCommas(priceText)}원`}
            onClickPriceList={() => this.onClickPriceList(item, index)}
          />,
          // <EventRow titleLabel={item.name} eventContent={'멤버십 회원가 30% 3,400'} specialTag={'특수세탁'} price={`${numberWithCommas(item.basic)}원`} />
        );
      });
    }
    // 카테고리 스크롤뷰
    priceListArray.map((item, i) => {
      let marginStartSize = PixelRatio.roundToNearestPixel(6);
      if (i === 0) {
        marginStartSize = 0;
      }
      views.push(
        <View
          key={`priceListArray_${i}`}
          style={{ marginStart: marginStartSize }}
        >
          <TouchableOpacity onPress={() => categorySearch(item.title)}>
            <ImageBackground
              style={{
                width: 96,
                height: 54,
                justifyContent: 'center',
                alignItems: 'center',
              }}
              source={item.image}
            >
              <Text
                style={[responseFont(15).bold, { color: washswatColor.white }]}
              >
                {item.title}
              </Text>
            </ImageBackground>
          </TouchableOpacity>
        </View>,
      );
    });

    const feeTypeName = this.getFeeTypeName(feeTypeArray, category);

    const { width, height } = Dimensions.get('window');
    /** 마지막 마진 위해서 **/
    listViews.push(
      <NormalRow
        key={'d-1'}
        titleLabel={``}
        price={``}
        onClickPriceList={() => {}}
      />,
    );
    listViews.push(
      <NormalRow
        key={'d-2'}
        titleLabel={``}
        price={``}
        onClickPriceList={() => {}}
      />,
    );
    listViews.push(
      <NormalRow
        key={'d-3'}
        titleLabel={``}
        price={``}
        onClickPriceList={() => {}}
      />,
    );

    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.white }}>
        <View
          style={{
            height: PixelRatio.roundToNearestPixel(
              15 + getStatusBarHeight(true),
            ),
          }}
        />

        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            paddingLeft: 18,
            paddingRight: 18,
          }}
        >
          <TouchableOpacity
            style={{ flexBasic: '10%', marginRight: 8 }}
            onPress={() => Navigation.pop(this.props.componentId)}
          >
            <Image
              source={require('image/v5/button_back.png')}
              style={{ width: 36, height: 36 }}
            />
          </TouchableOpacity>

          <View style={styles.searchTextInputView}>
            <Image
              source={require('image/Price/search.png')}
              style={{
                width: PixelRatio.roundToNearestPixel(16),
                height: PixelRatio.roundToNearestPixel(16),
              }}
            />
            <TextInput
              value={search}
              onChangeText={text => searchTextChange(text, uid)}
              style={{
                flex: 1,
                marginStart: PixelRatio.roundToNearestPixel(15),
                textAlignVertical: 'top',
                color: washswatColor.black,
              }}
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={this.onPressTextInputClear}>
                <Image
                  source={require('image/Price/delete_search.png')}
                  style={styles.clearSearchTextInputButton}
                />
              </TouchableOpacity>
            )}
          </View>
        </View>

        <View>
          <ScrollView showsHorizontalScrollIndicator={false} horizontal={true}>
            <View style={styles.categoryView}>{views}</View>
          </ScrollView>
        </View>
        <View style={styles.priceView}>
          <TouchableOpacity style={styles.dropDown}>
            <Text
              style={[
                responseFont(15).bold,
                { marginLeft: 30, color: washswatColor.black },
              ]}
            >
              {category}
            </Text>
          </TouchableOpacity>
          <View
            style={{
              width: PixelRatio.roundToNearestPixel(1),
              height: '100%',
              backgroundColor: washswatColor.grey_05,
            }}
          />
          {category !== 'BEDDING' && (
            <TouchableOpacity
              onPress={() => {
                this.bottomSheetAppear(feeTypeArray, category);
              }}
              style={styles.dropDown}
            >
              <Text style={styles.basicPrice}>{feeTypeName}</Text>
              <Image
                style={styles.arrowImage}
                source={require('image/Price/down_arrow_small.png')}
              />
            </TouchableOpacity>
          )}
        </View>
        <ScrollView>{listViews}</ScrollView>
        <Modal
          ref={'modal'}
          style={[styles.modal, { height: height - 90 }]}
          position={'bottom'}
          backButtonClose={true}
          swipeToClose={false}
          backdropPressToClose={true}
        >
          <DetailModal
            onPressClose={this.onPressDetailModalClose}
            itemDetail={itemDetail}
            onSpecial={this.onSpecial}
            onPremium={this.onPremium}
            feeTypeObject={
              category === 'LIVING' || isSingle
                ? this.getFeeTypeObject(feeTypeArray, category)
                : feeTypeArray[0]
            }
            showInfoTitle={showInfoTitle}
            category={category}
          />
        </Modal>
        <Modal
          ref={'modal2'}
          backButtonClose={true}
          backdropPressToClose={false}
          swipeToClose={false}
          position={'center'}
          style={{ backgroundColor: 'transparent' }}
        >
          <DetailMessageModal
            onClose={this.onSpecialClose}
            typeOfPrice={this.getTypeOfPrice('special')}
            typeOfPriceContent={
              onlyNumberOfDetailMessageModal
                ? null
                : PriceString.detailModalDesc
            }
            message={itemDetail.info.special.message}
          />
        </Modal>
        <Modal
          ref={'modal3'}
          backButtonClose={true}
          backdropPressToClose={false}
          swipeToClose={false}
          position={'center'}
          style={{ backgroundColor: 'transparent' }}
        >
          <DetailMessageModal
            onClose={this.onPremiumClose}
            typeOfPrice={this.getTypeOfPrice('premium')}
            typeOfPriceContent={
              onlyNumberOfDetailMessageModal
                ? null
                : PriceString.detailModalDesc
            }
            typeOfPriceContentBottom={
              onlyNumberOfDetailMessageModal
                ? null
                : PriceString.detailModalDescBottom
            }
            message={itemDetail.info.premium.message}
          />
        </Modal>
      </View>
    );
  }
}

const mapStateToProps = ({ PriceListModule }) => ({
  PriceListState: PriceListModule,
});
const mapDispatchToProps = dispatch => ({
  PriceListAction: bindActionCreators(PriceListModule, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(PriceList);

PriceList.defaultProps = {};
const styles = StyleSheet.create({
  searchTextInputView: {
    height: PixelRatio.roundToNearestPixel(33),
    backgroundColor: washswatColor.grey_05,
    flexDirection: 'row',
    borderRadius: PixelRatio.roundToNearestPixel(33),
    alignItems: 'center',
    paddingStart: PixelRatio.roundToNearestPixel(15),
    paddingEnd: PixelRatio.roundToNearestPixel(15),
    flexBasis: '90%',
  },
  clearSearchTextInputButton: {
    width: PixelRatio.roundToNearestPixel(18),
    height: PixelRatio.roundToNearestPixel(18),
    marginStart: PixelRatio.roundToNearestPixel(15),
  },
  categoryView: {
    flexDirection: 'row',
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(15),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(13),
  },
  toggleImage: {
    width: PixelRatio.roundToNearestPixel(16),
    height: PixelRatio.roundToNearestPixel(16),
    marginTop: PixelRatio.roundToNearestPixel(43),
    marginBottom: PixelRatio.roundToNearestPixel(21),
    marginLeft: PixelRatio.roundToNearestPixel(18),
  },
  basicPrice: {
    marginLeft: PixelRatio.roundToNearestPixel(30),
    marginRight: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(12),
    paddingBottom: PixelRatio.roundToNearestPixel(12),
  },
  recommend: {
    marginLeft: PixelRatio.roundToNearestPixel(30),
    marginRight: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(12),
    paddingBottom: PixelRatio.roundToNearestPixel(12),
    borderLeftColor: washswatColor.grey_03,
    borderBottomWidth: PixelRatio.roundToNearestPixel(0.5),
  },
  arrowImage: {
    width: PixelRatio.roundToNearestPixel(10),
    height: PixelRatio.roundToNearestPixel(10),
    marginRight: PixelRatio.roundToNearestPixel(30),
  },
  searchImage: {
    marginLeft: PixelRatio.roundToNearestPixel(45),
    marginTop: PixelRatio.roundToNearestPixel(-24),
    width: PixelRatio.roundToNearestPixel(16),
    height: PixelRatio.roundToNearestPixel(16),
  },
  dropDown: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '50%',
  },
  textInput: {
    height: PixelRatio.roundToNearestPixel(33),
    width: 290,
    marginRight: PixelRatio.roundToNearestPixel(30),
    borderTopRightRadius: PixelRatio.roundToNearestPixel(30),
    borderBottomRightRadius: PixelRatio.roundToNearestPixel(30),
    backgroundColor: washswatColor.grey_05,
    paddingLeft: 20,
    color: washswatColor.black,
  },
  priceView: {
    flexDirection: 'row',
    height: PixelRatio.roundToNearestPixel(52),
    borderTopColor: washswatColor.grey_05,
    borderBottomColor: washswatColor.grey_05,
    borderBottomWidth: PixelRatio.roundToNearestPixel(1),
    borderTopWidth: PixelRatio.roundToNearestPixel(1),
  },
  floating: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    width: PixelRatio.roundToNearestPixel(60),
    height: PixelRatio.roundToNearestPixel(60),
    right: PixelRatio.roundToNearestPixel(20),
    bottom: PixelRatio.roundToNearestPixel(81),
    backgroundColor: washswatColor.black,
    borderRadius: PixelRatio.roundToNearestPixel(30),
    elevation: 8,
  },
  frame: {
    flex: 1,
  },
  modal: {
    backgroundColor: washswatColor.white,
  },
});
