import React, { Component } from 'react';

import { View, Text, StyleSheet, Dimensions } from 'react-native';

import { useDispatch, useSelector } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';
import { PageTitles } from '../../utils/common/strings';

import HistoryContainer from '../../containers/mypage/history/HistoryContainer';
import { BasicHeader } from '../../components/common/layout';
import GrayBox from '../../components/common/style/GrayBox';

import * as CommonUtils from '../../utils/common';
import { PointHistoryScreenString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor, verticalScale } = Font;
const { width } = Dimensions.get('window');

/**
 * @category Screen
 * @class
 * ### 좌측 상단 햄버거 메뉴 -> 주문목록 클릭 후 진입하는 Screen
 * @see https://www.notion.so/washswat/OrderHistoryScreen-c9543a52d045442980d1ed7cf9d3ad4a
 * @hideconstructor
 * @alias PointHistoryScreen/Screen
 */

function PointHistoryScreen(props) {
  const dispatch = useDispatch();
  const { pointHistory, userPoint, membership } = useSelector(
    state => state.MyPageModule,
  );
  const sortPointHistory = pointHistory.filter(
    history =>
      (history.isValid && history.type === 'save') || history.type === 'admin',
  );

  $_useCycleHandler.mounted(() => {
    dispatch(MyPageModule.getPoint());
  });

  return (
    <View>
      <BasicHeader componentId={props.componentId} title={PageTitles.point} />
      <View style={styles.wrap}>
        <View style={styles.container}>
          <View style={styles.upper}>
            <GrayBox>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
              >
                <Text style={styles.point}>🎁</Text>
                <Text style={styles.point}>
                  {CommonUtils.numberWithCommas(userPoint)}
                  {PointHistoryScreenString.unit}
                </Text>
              </View>
            </GrayBox>
          </View>

          <View style={styles.lower}>
            <Text style={styles.history_title}>
              {PointHistoryScreenString.history}
            </Text>
            <HistoryContainer historyData={sortPointHistory} />
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    width: width,
    alignItems: 'center',
    paddingTop: verticalScale(40),
  },
  container: {
    width: width - 48,
  },
  point: {
    paddingVertical: verticalScale(20),
    textAlign: 'center',
    ...responseFont(24).bold,
  },
  desc: {
    textAlign: 'center',
    ...responseFont(10).regular,
    color: washswatColor.grey_08,
  },
  lower: {
    marginTop: verticalScale(35),
  },
  history_title: {
    ...responseFont(16).bold,
    marginBottom: verticalScale(11),
  },
});
export default PointHistoryScreen;
