import React from 'react';

import {
  Keyboard,
  PixelRatio,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import Coupon from '../../components/mypage/Coupon';
import CouponTop from '../../components/mypage/CouponTop';
import { BasicHeader } from '../../components/common/layout';

import {
  CouponMainString,
  Favorite,
  PageTitles,
} from '../../utils/common/strings';
import WashAlert from '../../utils/alert';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { washswatColor, responseFont } = Font;

class CouponMain extends React.Component {
  constructor(props) {
    super(props);
    Navigation.events().bindComponent(this);

    const { MyPageAction, objectId } = props;
    MyPageAction.getCouponList({ objectId });
    this.state = { code: ``, seletedCoupon: [] };
  }
  componentDidAppear = () => {
    const { seletedCoupon } = this.props;
    this.setState({ seletedCoupon: seletedCoupon || [] });
  };

  componentDidDisappear() {
    this.setState({ seletedCoupon: [] });
  }

  onPressBack = () => {
    Navigation.pop(this.props.componentId);
  };

  setOver = () => {
    const { finishedAction } = this.props;

    if (finishedAction) {
      const { seletedCoupon } = this.state;
      finishedAction(seletedCoupon);
      this.onPressBack();
    }
  };

  pressCoupon = coupon => {
    const { finishedAction, status } = this.props;
    // const { finishedAction } = this.props;
    if (finishedAction) {
      /** 다른 페이지에서 쿠폰을 요청한 경우 **/

      // 검수중 단계에서 preOptions에 coupon 적용하는 경우
      if (status === 'wait') {
        let { seletedCoupon } = this.state;
        const findIndex = _.findIndex(seletedCoupon, { _id: coupon._id });
        if (findIndex > -1) {
          seletedCoupon.splice(findIndex, 1);
        } else {
          seletedCoupon = [coupon];
        }
        this.setState({ seletedCoupon });
      } else {
        // 세탁중 단계에서 coupon 선택하는 경우
        const { invalid } = coupon;
        if (invalid) {
          WashAlert.showAlert(invalid, Favorite.ok);
        } else {
          let { seletedCoupon } = this.state;
          const findIndex = _.findIndex(seletedCoupon, { _id: coupon._id });
          if (findIndex > -1) {
            seletedCoupon.splice(findIndex, 1);
          } else {
            seletedCoupon = [coupon];
          }
          this.setState({ seletedCoupon });
          // finishedAction(coupon);
        }
      }
    }
  };

  onChangeCouponCode = code => {
    this.setState({ code });
  };

  setCouponCode = () => {
    const { code } = this.state;
    if (code) {
      const { MyPageAction } = this.props;
      MyPageAction.couponRegist({
        inputValue: code,
        callback: () => {
          Keyboard.dismiss();
          this.setState({ code: `` });
        },
      });
    }
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const { finishedAction, MyPageState } = this.props;
    const { seletedCoupon } = this.state;
    const { couponList, isPending } = MyPageState;
    const { code } = this.state;
    let coupons = [];
    couponList.map((coupon, i) => {
      coupons.push(
        <Coupon
          key={i}
          seletedCoupon={finishedAction ? seletedCoupon : null}
          pressCoupon={this.pressCoupon}
          coupon={coupon}
        />,
      );
    });
    let bottomButton;
    if (finishedAction) {
      let backgroundColor;
      if (seletedCoupon.length > 0) {
        backgroundColor = washswatColor.black;
      } else {
        backgroundColor = washswatColor.grey_02;
      }
      bottomButton = (
        <View
          style={{
            width: '100%',
            position: 'absolute',
            bottom: PixelRatio.roundToNearestPixel(20),
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <TouchableOpacity
            style={[styles.orderButton, { backgroundColor }]}
            onPress={this.setOver}
          >
            <Text
              style={[responseFont(15).bold, { color: washswatColor.white }]}
            >
              {CouponMainString.set}
            </Text>
          </TouchableOpacity>
        </View>
      );
    }
    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.grey_05 }}>
        <BasicHeader
          componentId={this.props.componentId}
          title={PageTitles.coupon}
          customStyle={{ backgroundColor: washswatColor.grey_05 }}
        />
        <ScrollView style={{ backgroundColor: washswatColor.grey_05 }}>
          <View style={{ paddingTop: 100 }}>
            <CouponTop
              code={code}
              onChangeCouponCode={this.onChangeCouponCode}
              setCouponCode={this.setCouponCode}
            />
          </View>
          <View style={{ flex: 1, backgroundColor: washswatColor.grey_05 }}>
            {couponList !== undefined && couponList.length > 0 ? (
              <View>
                <View style={[styles.myCouponView]}>
                  <Text
                    style={[
                      responseFont(14).bold,
                      { color: washswatColor.black },
                    ]}
                  >
                    {CouponMainString.myCoupon}
                  </Text>
                  <Text
                    style={[
                      responseFont(14).regular,
                      {
                        color: washswatColor.black,
                        lineHeight: PixelRatio.roundToNearestPixel(21),
                        marginTop: PixelRatio.roundToNearestPixel(9),
                      },
                    ]}
                  >
                    {CouponMainString.myCouponContent}
                  </Text>
                </View>
                {coupons}
              </View>
            ) : (
              <View
                style={{
                  flex: 1,
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginTop: 50,
                }}
              >
                <Text style={[responseFont(18).bold]}>
                  {CouponMainString.noCoupon}
                </Text>
              </View>
            )}
            {finishedAction && (
              <View
                style={{ padding: 50, backgroundColor: washswatColor.grey_05 }}
              />
            )}
          </View>
        </ScrollView>
        {bottomButton}
      </View>
    );
  }
}

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(CouponMain);

const styles = StyleSheet.create({
  myCouponView: {
    backgroundColor: washswatColor.grey_05,
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(60),
    paddingBottom: PixelRatio.roundToNearestPixel(48),
  },
  orderButton: {
    width: PixelRatio.roundToNearestPixel(276),
    height: PixelRatio.roundToNearestPixel(72),

    // backgroundColor: washswatColor.black,
    borderRadius: PixelRatio.roundToNearestPixel(90),
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      ios: {
        shadowColor: washswatColor.black,
        shadowOffset: {
          width: PixelRatio.roundToNearestPixel(0),
          height: PixelRatio.roundToNearestPixel(10),
        },
        shadowOpacity: 0.16,
        shadowRadius: PixelRatio.roundToNearestPixel(10),
      },
      android: {
        elevation: PixelRatio.roundToNearestPixel(10),
      },
    }),
  },
});
