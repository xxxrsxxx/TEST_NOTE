import React, { PureComponent, useContext, useState } from 'react';
import { ScrollView, StyleSheet, View, Easing } from 'react-native';
// component import
import { IvInfo, IvShare, IvDscList } from '../../containers/mypage/invite';
import { AlertModal } from '../../components/common/modal';
// context import
import InviteContext from '../../utils/context/myPage/invite';
import { BasicHeader } from '../../components/common/layout';

export function InviteScreen(props) {
  const [showModal, setShowModal] = useState(false);

  const context = useContext(InviteContext);
  const modalArea = context.loadData.modalArea;

  const modalHandler = duration => {
    setShowModal(true);
    setTimeout(() => {
      setShowModal(false);
    }, duration);
  };

  return (
    <View style={styles.container}>
      <BasicHeader title={'친구초대'} componentId={props.componentId} />
      <ScrollView style={styles.contentsWrap}>
        <IvInfo style={styles.infoContainer} />
        <IvShare
          style={styles.shareContainer}
          modal={() => modalHandler(1000)}
        />
        <IvDscList />
      </ScrollView>
      <AlertModal
        data={modalArea}
        position={'bottom'}
        isOpen={showModal}
        easing={Easing.elastic(0.5)}
        animationDuration={500}
        onClosed={() => setShowModal(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingBottom: 24 },
  contentsWrap: {
    paddingHorizontal: 24,
  },
  infoContainer: { marginTop: 32, marginBottom: 36 },
  shareContainer: {
    marginBottom: 40,
  },
});
export default InviteScreen;
