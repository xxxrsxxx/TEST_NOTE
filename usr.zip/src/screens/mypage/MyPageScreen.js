import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';

// module import
import * as MainScreenModule from '../../reducers/MainScreenModule';
import * as MyPageModule from '../../reducers/MyPageModule';
import * as BottomTabModule from '../../reducers/BottomTabModule';
// components import
import {
  MyProfileContainer,
  MyWashSwatContainer,
  MyPaymentContainer,
  MyFaqContainer,
} from '../../containers/mypage/main';

/**
 * @category Screen Directory
 * @class
 * ### Information
 * @hideconstructor
 * @alias myPage/index
 */

function MyPageScreen(props) {
  const dispatch = useDispatch();
  const [data, setData] = useState(props);
  const MyPageState = useSelector(state => state.MyPageModule);
  const getPoint = () => dispatch(MyPageModule.getPoint());
  const toggleConfirmDialog = (
    componentId,
    height,
    contentView,
    leftButtonText,
    rightButtonText,
    onLeftButtonClicked,
    onRightButtonClicked,
    onClosed,
  ) =>
    dispatch(
      MainScreenModule.toggleConfirmDialog(
        componentId,
        height,
        contentView,
        leftButtonText,
        rightButtonText,
        onLeftButtonClicked,
        onRightButtonClicked,
        onClosed,
      ),
    );
  const setCurrentTab = currentScreenName =>
    dispatch(BottomTabModule.setCurrentTab(currentScreenName));

  /**
   * @dsc mounted hook / 액션 전달용
   */
  $_useCycleHandler.mounted(() => {
    $_status.actions.callbackUsingGlobalPending(getPoint);
  });

  return (
    <View style={styles.container}>
      <ScrollView style={styles.contentsSpace}>
        <MyProfileContainer
          componentId={data.componentId}
          style={styles.profileContainer}
        />
        <MyWashSwatContainer
          componentId={data.componentId}
          MyPageState={MyPageState}
          toggleConfirmDialog={toggleConfirmDialog}
          style={styles.myWashSwatContainer}
        />
        <MyPaymentContainer
          componentId={data.componentId}
          userCardList={MyPageState.userCardList}
          action={data.MyPageActions}
          MyPageState={MyPageState}
          setCurrentTab={setCurrentTab}
          style={styles.myPaymentContainer}
        />
        <MyFaqContainer
          componentId={data.componentId}
          style={styles.myFaqContainer}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom: 24,
  },
  contentsSpace: {
    paddingHorizontal: 24,
  },
  profileContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 52,
    paddingTop: 20,
  },
  myWashSwatContainer: {
    height: 80,
    marginTop: 32,
  },
  myPaymentContainer: {
    marginTop: 40,
  },
  myFaqContainer: {
    marginTop: 54,
    marginBottom: 20,
  },
});

export default MyPageScreen;
