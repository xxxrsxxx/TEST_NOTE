import React, { useState } from 'react';
import { StyleSheet, Platform, View } from 'react-native';
import { WebView } from 'react-native-webview';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
// modules import
import * as MyPageModule from '../../reducers/MyPageModule';
import * as StatusModule from '../../reducers/StatusModule';
// components import
import CommonButton from '../../components/common/button/CommonButton';
// utils import
import * as CommonUtils from '../../utils/common/index';
import { MyPageString } from '../../utils/common/strings';
import { DEFAULT_URL_WEB } from '../../utils/type/server';
import WashAlert from '../../utils/alert';
import {
  navPushWebViewScreen,
  navPushPaymentMethodScreen,
  navPushMembershipCancelReasonScreen,
  navPushJoinMemberScreen,
} from '../../utils/common/nav';
// styles import
import { Styles } from '../../utils/style';

const { androidStatusBar, BOTTOM_TAB_BORDER_AREA_HEIGHT } = Styles;

const MEMBERSHIP_JOIN_URL = `${DEFAULT_URL_WEB}app/membership/join`;
const MEMBERSHIP_INFO_URL = `${DEFAULT_URL_WEB}app/membership/info`;

// MembershipScreen
function JoinMember({ componentId, url, call }) {
  const dispatch = useDispatch();
  const [userType, setUserType] = useState('normal');
  const [webviewKey, setWebviewKey] = useState(0);
  const { user } = $_status.state;
  const { userType: currentUserType, accessToken } = user;
  const joinMember = props => dispatch(MyPageModule.joinMember(props));
  const globalPendingHandler = value =>
    dispatch(StatusModule.globalPendingHandler(value));

  $_useCycleHandler.mounted(() => {
    setUserType(currentUserType);
  });

  const actionHandler = e => {
    const { data } = e.nativeEvent;

    if (!(data && data.startsWith('{') && data.endsWith('}'))) {
      return;
    }

    const onMessageData = JSON.parse(data);
    const { action, title, url, type, cardList } = onMessageData;

    switch (action) {
      case 'page':
        pageAction({ title, url });
        break;
      case 'join':
        joinAction({ type, cardList });
        break;
      case 'exit':
        exitAction();
        break;
      default:
        break;
    }
  };

  const pageAction = ({ title, url }) => {
    const passProps = {
      option: {
        title,
        url,
      },
    };
    navPushWebViewScreen({ componentId, passProps });
  };

  const joinAction = async ({ type, cardList }) => {
    if (!cardList || cardList.length === 0) {
      WashAlert.showAlert(
        '등록된 결제 수단이 없어요. 카드 등록 후 다시 진행해주세요!',
        '확인',
        () => {
          // 결제수단 등록 페이지 push
          navPushPaymentMethodScreen({ componentId });
        },
      );
    } else {
      await joinMember({
        type,
        finishedAction: userType => {
          CommonUtils.dismissModal(componentId);
          if (call) call(userType);
        },
      });
    }
  };

  const exitAction = () => {
    const passProps = {
      call: refresh,
    };
    navPushMembershipCancelReasonScreen({ componentId, passProps });
  };

  const showJoinMemberModal = () => {
    const passProps = { url: MEMBERSHIP_JOIN_URL, call: refresh };
    navPushJoinMemberScreen({ componentId, passProps, showModal: true });
  };

  const refresh = userType => {
    setUserType(userType || 'normal');
    setWebviewKey(webviewKey + 1);
  };

  const handleSpinner = status => {
    globalPendingHandler(status);
  };

  return (
    <View style={styles.mainWrapper}>
      {/* {isPending ? <LoadingBar /> : null} */}
      <View style={styles.webviewWrapper}>
        <WebView
          source={{
            uri: url ? url : MEMBERSHIP_INFO_URL,
            headers: {
              'x-access-token': accessToken ? accessToken : '',
            },
          }}
          key={webviewKey}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          onMessage={actionHandler.bind(this)}
          onLoadStart={() => handleSpinner(true)}
          onLoad={() => handleSpinner(false)}
          onError={() => {
            handleSpinner(false);
            WashAlert.showAlert(
              '서버와의 통신이 원활하지 않습니다. 다시 시도해주세요.',
              '확인',
            );
          }}
        />
      </View>

      {!url && userType === 'normal' ? (
        <CommonButton
          type={'primary'}
          containerStyle={styles.ctaContainer}
          clickEvent={showJoinMemberModal}
          content={MyPageString.join}
        />
      ) : null}
    </View>
  );
}

JoinMember.defaultProps = {
  componentId: '0',
  url: '',
  call: () => {},
};

JoinMember.propTypes = {
  componentId: PropTypes.string,
  url: PropTypes.string,
  call: PropTypes.func,
};

const styles = StyleSheet.create({
  mainWrapper: {
    flex: 1,
    marginTop: Platform.OS === 'android' ? -androidStatusBar : 0,
  },
  webviewWrapper: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  ctaContainer: {
    position: 'absolute',
    width: `100%`,
    bottom: 15,
    padding: 25,
    paddingTop: 0,
    marginBottom: BOTTOM_TAB_BORDER_AREA_HEIGHT,
  },
});

export default JoinMember;
