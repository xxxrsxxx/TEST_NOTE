import React, { useState } from 'react';
import {
  Image,
  PixelRatio,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import Accordion from 'react-native-collapsible/Accordion';
import { getStatusBarHeight } from 'react-native-status-bar-height';
// components import
import NBImageButton from '../../components/common/button/NBImageButton';
// plugins import
import { moment } from '../../plugins';
// styles import
import { OSDPaymentString } from '../../utils/common/strings';
import { Font } from '../../utils/style';
const { washswatColor, responseFont } = Font;

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function PaymentHistory({ componentId, payList }) {
  const [activeSections, setActiveSections] = useState([]);

  const onPressBack = () => {
    Navigation.pop(componentId);
  };
  const _renderHeader = section => {
    const day = moment(section.payDay).format('YYYY-MM-DD'); // 포맷 찾아서 수정 moment
    return (
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderTopWidth: PixelRatio.roundToNearestPixel(1),
          borderTopColor: washswatColor.grey_04,
          borderBottomWidth: PixelRatio.roundToNearestPixel(1),
          borderBottomColor: washswatColor.grey_04,
        }}
      >
        <Text style={[responseFont(16).bold, styles.listView]}>{day}</Text>
        <Image
          style={styles.image}
          source={require('image/mypage/down_arrow_small.png')}
        />
      </View>
    );
  };

  const _renderContent = section => {
    // let fullText = '';
    // section.content.map((item, index) => {
    //   fullText += `${item.content} <br>`;
    // });
    return (
      <TouchableOpacity style={styles.viewFrame}>
        <Text style={[responseFont(16).regular, styles.listView]}>
          {section.card}
        </Text>
        <Text
          style={[responseFont(16).regular, styles.listView]}
        >{`${numberWithCommas(section.price)}${OSDPaymentString.won}`}</Text>
      </TouchableOpacity>
    );
  };

  const _updateSections = activeSections => {
    setActiveSections({ activeSections });
  };

  return (
    <View style={[styles.frame]}>
      <View style={{ height: getStatusBarHeight(true) }} />
      <NBImageButton
        onPress={onPressBack}
        source={require('image/common/back_button_black.png')}
      />
      <View style={styles.topViewFrame}>
        <View>
          <Text style={[responseFont(27).bold]}>
            {OSDPaymentString.paymentHistory}
          </Text>
        </View>
      </View>
      <View>
        {/* <View style={styles.viewFrameBorder}>{views}</View> */}

        <Accordion
          sections={payList}
          activeSections={activeSections}
          renderSectionTitle={_renderSectionTitle}
          renderHeader={_renderHeader}
          renderContent={_renderContent}
          onChange={_updateSections}
          underlayColor={'transparent'}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  frame: {
    flexDirection: 'column',
    // paddingLeft: PixelRatio.roundToNearestPixel(20),
    // paddingRight: PixelRatio.roundToNearestPixel(20),
    // paddingTop: PixelRatio.roundToNearestPixel(20),
    // paddingBottom: PixelRatio.roundToNearestPixel(20)
    flex: 1,
  },
  listView: {
    paddingTop: PixelRatio.roundToNearestPixel(27),
    paddingBottom: PixelRatio.roundToNearestPixel(27),
    paddingLeft: PixelRatio.roundToNearestPixel(20),
    paddingRight: PixelRatio.roundToNearestPixel(20),
  },
  topViewFrame: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: PixelRatio.roundToNearestPixel(65),
    paddingLeft: PixelRatio.roundToNearestPixel(20),
    paddingRight: PixelRatio.roundToNearestPixel(20),
    paddingTop: PixelRatio.roundToNearestPixel(20),
    // paddingBottom: PixelRatio.roundToNearestPixel(20)
  },
  viewFrame: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  viewFrameBorder: {
    borderTopWidth: PixelRatio.roundToNearestPixel(1),
    borderTopColor: washswatColor.grey_04,
  },
  image: {
    width: PixelRatio.roundToNearestPixel(12),
    height: PixelRatio.roundToNearestPixel(12),
    marginRight: PixelRatio.roundToNearestPixel(15),
    resizeMode: 'contain',
  },
});

export default PaymentHistory;
