import React from 'react';

import {
  Image,
  Keyboard,
  PixelRatio,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import KeyboardListener from 'react-native-keyboard-listener';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import NBImageButton from '../../components/common/button/NBImageButton';

import { Favorite, MembershipInfoString } from '../../utils/common/strings';
import WashAlert from '../../utils/alert';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import AnalyticsManager from '../../utils/tagging/analytics';
import * as CommonUtils from '../../utils/common';
import * as KeyUtils from '../../utils/type/key';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const membership = [
  '자주 맡기는 편이 아니라서',
  '내가 원하는 혜택이 없어서',
  '멤버십 회원료가 비싸서',
  '직접입력',
];

class MembershipCancelReason extends React.Component {
  popScreen = () => {
    Navigation.pop(this.props.componentId);
  };
  state = {
    text: '',
    keyboardOpen: false,
    keyboardHeight: 0,
    selectReason: -1,
    cancelReason: '',
  };
  selectedChange = (index, item) => {
    this.setState({
      selectReason: index,
      cancelReason: item,
    });
  };
  UNSAFE_componentWillMount() {
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this._keyboardDidShow,
    );
    this.keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      this._keyboardDidHide,
    );
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  _keyboardDidShow() {
    // alert('Keyboard Shown');
  }

  _keyboardDidHide() {
    // alert('Keyboard Hidden');
  }
  cancelMembership = async () => {
    const uid = await CommonUtils.getValue(KeyUtils.USER_ID);
    const { MyPageAction, componentId, call } = this.props;

    const { cancelReason } = this.state;
    if (cancelReason) {
      Keyboard.dismiss();
      WashAlert.showConfirm(
        MembershipInfoString.cancelMembershipModal,
        MembershipInfoString.cancelMembership,
        MembershipInfoString.close,
        () => {
          MyPageAction.exitMembership({
            cancelReason,
            componentId,
            finishedAction: () => {
              WashAlert.showAlertWithCallback(
                MembershipInfoString.exitMembership,
                Favorite.ok,
                () => {
                  if (call) {
                    call();
                  }
                  Navigation.popToRoot(componentId);
                },
              );
              AnalyticsManager.setAppsFlyerTrackEvent(
                AnalyticsKey.NAME_SIGN_OUT_MEMBERSHIP,
              );
              AnalyticsManager.setAirbridgeTrackEvent(
                AnalyticsKey.NAME_SIGN_OUT_MEMBERSHIP,
                Platform.OS,
                uid,
              );
            },
          });
        },
      );
    }
  };
  keyboardUp = e => {
    this.setState({
      keyboardOpen: true,
      keyboardHeight: e.endCoordinates.height,
    });
  };
  render() {
    let views = [];
    let text = {};
    membership.map((item, index) => {
      let image =
        this.state.selectReason === index
          ? require('../../../assets/image/mypage/available.png')
          : require('../../../assets/image/mypage/disAvailable.png');
      text = this.state.selectReason === membership.length - 1 && (
        <TextInput
          style={{
            marginLeft: 10,
            marginRight: 10,
            marginTop: 15,
            height: 30,
            borderBottomColor: 'black',
            borderBottomWidth: 3,
            textAlignVertical: 'top',
          }}
          onChangeText={text => this.setState({ cancelReason: text })}
          value={this.state.textInput}
          placeholder={'사유를 입력하세요'}
          // 직접입력을 클릭했을경우에만 텍스트 뷰가 나타남
          editable={true}
          maxLength={40}
          onSubmitEditing={Keyboard.dismiss}
        />
      );
      views.push(
        <View key={`mem${index}`}>
          <View style={styles.viewFrameBorder}>
            <TouchableOpacity
              onPress={() => {
                this.selectedChange(index, item);
              }}
              style={styles.viewFrame}
            >
              <Text style={[responseFont(16).regular, styles.listView]}>
                {item}
              </Text>
              <Image style={styles.image} source={image} />
            </TouchableOpacity>
          </View>
          {/* <View style={{ borderTopWidth: 1, borderTopColor: washswatColor.grey_04 }} /> */}
        </View>,
      );
    });
    const open = this.state.keyboardOpen ? -this.state.keyboardHeight / 2 : 0;
    const completeColor =
      this.state.selectReason === -1
        ? washswatColor.grey_04
        : washswatColor.blue;
    return (
      <View style={{ flex: 1, marginTop: open }}>
        <View style={{ height: getStatusBarHeight(true) }} />
        <View
          style={{
            marginRight: 30,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <NBImageButton
            onPress={this.popScreen}
            source={require('../../../assets/image/common/back_button_black.png')}
          />
          <Text
            onPress={this.cancelMembership}
            style={[responseFont(16).bold, { color: completeColor }]}
          >
            {MembershipInfoString.cancel}
          </Text>
        </View>
        <Text style={[responseFont(30).bold, styles.titleText]}>해지사유</Text>
        <View style={[styles.bottomViewFrame]}>
          {views}
          {text}
        </View>
        <KeyboardListener
          onWillShow={this.keyboardUp}
          onWillHide={() => {
            this.setState({ keyboardOpen: false });
          }}
        />
      </View>
    );
  }
}
const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(MembershipCancelReason);

const styles = StyleSheet.create({
  top: {
    flexDirection: 'row',
    // justifyContent: 'space-between',
    // alignItems: 'center',
    height: PixelRatio.roundToNearestPixel(61 + getStatusBarHeight(true)),
    backgroundColor: washswatColor.white,
    // flex: 1
  },
  topViewFrame: {
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
    backgroundColor: 'black',
  },
  listView: {
    paddingTop: 25,
    paddingBottom: 25,
    paddingLeft: PixelRatio.roundToNearestPixel(10),
  },
  bottomViewFrame: {
    flexDirection: 'column',
    marginTop: PixelRatio.roundToNearestPixel(50),
    paddingLeft: PixelRatio.roundToNearestPixel(20),
    paddingRight: PixelRatio.roundToNearestPixel(20),
    paddingBottom: PixelRatio.roundToNearestPixel(20),
    flex: 1,
  },
  viewFrame: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  viewFrameBorder: {
    borderTopWidth: 1,
    borderTopColor: washswatColor.grey_04,
  },
  image: {
    paddingRight: 20,
    marginRight: 20,
    resizeMode: 'contain',
    width: PixelRatio.roundToNearestPixel(14.7),
    height: PixelRatio.roundToNearestPixel(23.3),
  },
  toggleImage: {
    width: 16,
    height: 16,
    marginTop: 43,
    marginBottom: 21,
    marginLeft: 18,
  },
  titleText: {
    color: washswatColor.black,
    marginStart: PixelRatio.roundToNearestPixel(30),
    marginTop: PixelRatio.roundToNearestPixel(24),
  },
});
