import React from 'react';

import {
  Image,
  PixelRatio,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import LoadingBar from '../../components/common/button/LoadingBar';

import { MembershipInfoString } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

class MembershipInfo extends React.Component {
  componentDidMount() {
    const { MyPageAction } = this.props;
    MyPageAction.membershipInfo();
  }

  componentWillUnmount() {
    const { MyPageAction } = this.props;
    MyPageAction.globalPendingHandler(false);
  }

  popScreen = () => {
    Navigation.pop(this.props.componentId);
  };
  movePage = pageName => {
    const { payList } = this.props.MyPageState;
    CommonUtils.navPush({
      componentId: this.props.componentId,
      name: pageName,
      passProps: { payList: payList },
    });
  };
  render() {
    const { componentId, popEvent } = this.props;
    const { policy, payList, expireDate, isPending } = this.props.MyPageState;
    return (
      <View
        componentId={componentId}
        statusBarColor={'transparent'}
        barStyle={'light-content'}
      >
        {isPending ? <LoadingBar /> : null}
        <View style={styles.top}>
          {popEvent && (
            <TouchableOpacity onPress={this.popScreen}>
              <Image
                source={require('../../../assets/image/common/back_button_white.png')}
                style={styles.toggleImage}
              />
            </TouchableOpacity>
          )}
        </View>

        <View style={[styles.topViewFrame]}>
          <View style={{ paddingBottom: 70 }}>
            <Text
              style={[responseFont(27).bold, { color: washswatColor.white }]}
            >
              {policy.title}
            </Text>
          </View>
          <View style={{ paddingBottom: 2 }}>
            <Text
              numberOfLines={4}
              style={[
                responseFont(13).bold,
                { color: washswatColor.white },
                { lineHeight: 25, paddingBottom: 30 },
              ]}
            >
              {policy.content}
            </Text>
          </View>
        </View>
        <View style={[styles.bottomViewFrame]}>
          <View>
            <View style={styles.viewFrameBorder}>
              <TouchableOpacity
                onPress={() => this.movePage('PaymentHistory')}
                style={styles.viewFrame}
              >
                <Text style={[responseFont(16).regular, styles.listView]}>
                  {MembershipInfoString.payHistory}
                </Text>
                <Image
                  style={styles.image}
                  source={require('../../../assets/image/mypage/arrowRight.png')}
                />
              </TouchableOpacity>
            </View>
            <View style={styles.viewFrameBorder}>
              <TouchableOpacity
                onPress={() => this.movePage('MembershipCancelReason')}
                style={styles.viewFrame}
              >
                <Text
                  style={[responseFont(16).regular, styles.listView]}
                >{`${MembershipInfoString.cancelMembership}`}</Text>
                <Text
                  style={[responseFont(16).regular, styles.listView]}
                >{`${expireDate} 갱신예정`}</Text>
                {/* <Image style={styles.image} source={require('../../../../assets/image/mypage/arrowRight.png')} /> */}
              </TouchableOpacity>
            </View>
            <View
              style={{
                padding: 30,
                borderTopWidth: 1,
                borderTopColor: washswatColor.grey_04,
              }}
            />
          </View>
        </View>
      </View>
    );
  }
}

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(MembershipInfo);

const styles = StyleSheet.create({
  top: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: PixelRatio.roundToNearestPixel(61 + getStatusBarHeight(true)),
    backgroundColor: 'red',
  },
  topViewFrame: {
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
    backgroundColor: 'black',
  },
  listView: {
    paddingTop: 25,
    paddingBottom: 25,
  },
  bottomViewFrame: {
    flexDirection: 'column',
    paddingLeft: PixelRatio.roundToNearestPixel(20),
    paddingRight: PixelRatio.roundToNearestPixel(20),
    paddingBottom: PixelRatio.roundToNearestPixel(20),
  },
  viewFrame: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  viewFrameBorder: {
    borderTopWidth: 1,
    borderTopColor: washswatColor.grey_04,
  },
  image: {
    paddingRight: 20,
    resizeMode: 'contain',
    width: PixelRatio.roundToNearestPixel(14.7),
    height: PixelRatio.roundToNearestPixel(23.3),
  },
  toggleImage: {
    width: 16,
    height: 16,
    marginTop: 43,
    marginBottom: 21,
    marginLeft: 18,
  },
});
