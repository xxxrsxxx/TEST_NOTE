import React from 'react';

import {
  Image,
  PixelRatio,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { CancelReasonString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

function CancelReason() {
  return (
    <View>
      <View style={[styles.frame]}>
        <View style={styles.topViewFrame}>
          <View>
            <Text style={[responseFont(27).bold]}>
              {CancelReasonString.reason}
            </Text>
          </View>
        </View>
        <View>
          <View style={styles.viewFrameBorder}>
            <TouchableOpacity style={styles.viewFrame}>
              <Text style={[responseFont(16).bold, styles.listView]}>
                {CancelReasonString.notOften}
              </Text>
              <Image
                style={styles.image}
                source={require('../../../assets/image/mypage/settings/checkbox_off.png')}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.viewFrameBorder}>
            <TouchableOpacity style={styles.viewFrame}>
              <Text style={[responseFont(16).bold, styles.listView]}>
                {CancelReasonString.notBenefit}
              </Text>
              <Image
                style={styles.image}
                source={require('../../../assets/image/mypage/settings/checkbox_off.png')}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.viewFrameBorder}>
            <TouchableOpacity style={styles.viewFrame}>
              <Text style={[responseFont(16).bold, styles.listView]}>
                {CancelReasonString.tooExpensive}
              </Text>
              <Image
                style={styles.image}
                source={require('../../../assets/image/mypage/settings/checkbox_off.png')}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.viewFrameBorder}>
            <TouchableOpacity style={styles.viewFrame}>
              <Text style={[responseFont(16).bold, styles.listView]}>
                {CancelReasonString.directInput}
              </Text>
              <Image
                style={styles.image}
                source={require('../../../assets/image/mypage/settings/checkbox_off.png')}
              />
            </TouchableOpacity>
          </View>
          <View
            style={{
              padding: 30,
              borderTopWidth: 1,
              borderTopColor: washswatColor.grey_04,
            }}
          />
        </View>
      </View>
      <TouchableOpacity
        style={{
          backgroundColor: 'black',
          height: 60,
          marginTop: 41,
          alignItems: 'center',
        }}
      >
        <Text style={[responseFont(16).bold, styles.button]}>
          {CancelReasonString.complete}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  frame: {
    flexDirection: 'column',
    paddingLeft: PixelRatio.roundToNearestPixel(20),
    paddingRight: PixelRatio.roundToNearestPixel(20),
    paddingTop: PixelRatio.roundToNearestPixel(20),
    paddingBottom: PixelRatio.roundToNearestPixel(0),
  },
  listView: {
    paddingTop: PixelRatio.roundToNearestPixel(27),
    paddingBottom: PixelRatio.roundToNearestPixel(27),
  },
  topViewFrame: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: PixelRatio.roundToNearestPixel(65),
  },
  viewFrame: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  viewFrameBorder: {
    borderTopWidth: PixelRatio.roundToNearestPixel(1),
    borderTopColor: washswatColor.grey_04,
  },
  image: {
    paddingRight: PixelRatio.roundToNearestPixel(20),
    resizeMode: 'contain',
    width: PixelRatio.roundToNearestPixel(14.7),
    height: PixelRatio.roundToNearestPixel(23.3),
  },
  button: {
    flexDirection: 'row',
    color: washswatColor.white,
    paddingTop: PixelRatio.roundToNearestPixel(15),
  },
});

export default CancelReason;
