import React from 'react';

import {
  PixelRatio,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';

// redux
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import NBTextButton from '../../components/common/button/NBTextButton';
import NBImageButton from '../../components/common/button/NBImageButton';
import UserWithdrawalTag from '../../components/setting/UserWithdrawalTag';

import { UserWithdrawalString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

class UserWithdrawal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      inputValue: '',
    };
  }

  onPressBack = () => {
    Navigation.pop(this.props.componentId);
  };

  onChangeText = inputValue => {
    this.setState({ inputValue });
  };

  onPressWithdrawal = () => {
    const { inputValue } = this.state;
    const { MyPageAction } = this.props;
    if (inputValue.length > 0) {
      MyPageAction.withdrawal(inputValue);
    }
  };

  render() {
    const { inputValue } = this.state;
    const isActiveWithdrawalButton = inputValue.length > 0 ? true : false;
    const withdrawalButtonTextColor = isActiveWithdrawalButton
      ? washswatColor.blue
      : washswatColor.grey_03;
    const isActiveTag = inputValue.length > 0 ? false : true;
    const tagArray = [
      {
        title: UserWithdrawalString.tagNotServiceArea,
      },
    ];
    let tagView = [];
    tagArray.map((tagObject, index) => {
      const title = tagObject.title;
      tagView.push(
        <UserWithdrawalTag
          key={index}
          onPress={() => {
            this.setState({ inputValue: title.replace('#', '') });
          }}
          title={title}
        />,
      );
    });
    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.white }}>
        <View style={{ height: getStatusBarHeight(true) }} />
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <NBImageButton
            onPress={this.onPressBack}
            source={require('image/common/back_button_black.png')}
          />
          <NBTextButton
            onPress={this.onPressWithdrawal}
            text={UserWithdrawalString.withdrawal}
            textColor={withdrawalButtonTextColor}
          />
        </View>
        <ScrollView>
          <TextInput
            style={[
              responseFont(16).regular,
              styles.textInputView,
              { textAlignVertical: 'top' },
            ]}
            onChangeText={this.onChangeText}
            value={inputValue}
            placeholder={UserWithdrawalString.placeholderText}
            placeholderTextColor={washswatColor.grey_01}
            multiline={true}
            autoFocus={true}
          />
          {isActiveTag && (
            <View
              style={{
                marginStart: PixelRatio.roundToNearestPixel(30),
                marginTop: PixelRatio.roundToNearestPixel(73),
              }}
            >
              {tagView}
            </View>
          )}
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  textInputView: {
    color: washswatColor.black,
    height: PixelRatio.roundToNearestPixel(123),
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
    marginTop: PixelRatio.roundToNearestPixel(24),
  },
});

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(UserWithdrawal);
