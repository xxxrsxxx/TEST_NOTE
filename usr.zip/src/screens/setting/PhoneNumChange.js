import React from 'react';

import {
  Dimensions,
  Keyboard,
  PixelRatio,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import AndroidKeyboardAdjust from 'react-native-android-keyboard-adjust';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import NBImageButton from '../../components/common/button/NBImageButton.js';
import { AnswerChatView, ChatView } from '../../components/login/ChatComponent';
import KeyboardSpacerIOS from '../../components/common/keyboard/KeyboardSpacerIOS';

import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { washswatColor } = Font;

const windowSize = Dimensions.get('window');

class PhoneNumChange extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      inputValue: '',
      init: true,
      phone: '',
    };
  }

  componentDidMount() {
    Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);
    Keyboard.addListener('keyboardDidHide', this.keyboardDidHide);
    if (Platform.OS === 'android') {
      AndroidKeyboardAdjust.setAdjustResize();
    }
  }

  keyboardDidShow = () => {
    //스크롤뷰의 가장 끝으로 이동.
    this.scrollView.scrollToEnd({ animated: true });
  };

  keyboardDidHide = () => {
    this.scrollView.scrollToEnd({ animated: false });
  };

  componentWillUnmount() {
    Keyboard.removeListener('keyboardDidShow', this.keyboardDidShow);
    Keyboard.removeListener('keyboardDidHide', this.keyboardDidHide);
  }

  onPressBack = () => {
    const { MyPageAction } = this.props;

    MyPageAction.resetPhoneNumberChat();
    Navigation.pop(this.props.componentId);
  };

  getCertificateNum = () => {
    const { inputValue } = this.state;
    const { MyPageAction } = this.props;

    this.setState({ phone: inputValue, inputValue: '' }, () =>
      MyPageAction.getCertificateNum({ phoneNum: inputValue }),
    );
  };

  postCertificateCheck = () => {
    const { inputValue, phone } = this.state;
    const { MyPageAction, componentId } = this.props;

    this.setState({ inputValue: '' }, () =>
      MyPageAction.postCertificateCheck({
        phone,
        certificateNumber: inputValue,
        componentId,
      }),
    );
  };

  handleInputText = inputValue => {
    this.setState({ inputValue });
  };

  reEnterPhoneNumber = (parentIndex, childIndex) => {
    const { MyPageAction, MyPageState } = this.props;
    const { phoneNumChangeChatArr } = MyPageState;
    let copyPhoneNumChangeChatArr = _.cloneDeep(phoneNumChangeChatArr);

    copyPhoneNumChangeChatArr[parentIndex].textArr[
      childIndex
    ].background = true;

    MyPageAction.reEnterPhoneNumber({
      phoneNumChangeChatArr: copyPhoneNumChangeChatArr,
      phoneNumChangeInputType: 'getCertificateNum',
    });
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const { inputValue } = this.state;
    const {
      phoneNumChangeChatArr,
      phoneNumChangeInputType,
    } = this.props.MyPageState;
    let buttonPress,
      sendInputText,
      chat = [];

    sendInputText = this[phoneNumChangeInputType];

    phoneNumChangeChatArr.map((chatObj, i) => {
      if (chatObj.type === 'left') {
        chat.push(<ChatView key={`phoneNumChat${i}`} textObj={chatObj} />);
      } else {
        if (chatObj.buttonPress) {
          buttonPress = this.reEnterPhoneNumber;
        }

        chat.push(
          <AnswerChatView
            index={i}
            key={`AnswerphoneNumChatView${i}`}
            textObj={chatObj}
            onPress={buttonPress}
          />,
        );
      }
    });

    return (
      <View style={{ flex: 1, backgroundColor: washswatColor.white }}>
        <View style={{ height: getStatusBarHeight(true) }} />
        <NBImageButton
          onPress={this.onPressBack}
          source={require('image/common/back_button_black.png')}
        />
        <View style={styles.bodyView}>
          <ScrollView
            ref={ref => (this.scrollView = ref)}
            showsVerticalScrollIndicator={false}
            onContentSizeChange={(contentWidth, contentHeight) => {
              if (this.state.init) {
                this.state.init = false;
              } else {
                this.scrollView.scrollToEnd({ animated: true });
              }
            }}
          >
            {chat}
            <View style={{ height: PixelRatio.roundToNearestPixel(36) }} />
          </ScrollView>
        </View>
        <View style={styles.bottomInputText}>
          <View style={styles.textInput}>
            <TextInput
              keyboardType={'number-pad'}
              value={inputValue}
              // placeholder={LoginChatText.placeholderText[loginInputType]}
              onChangeText={e => this.handleInputText(e)}
              style={styles.inputText}
            />
          </View>
          <TouchableOpacity
            style={styles.sendBtn}
            onPress={sendInputText}
            activeOpacity={1}
          >
            <Text>SEND</Text>
          </TouchableOpacity>
        </View>
        <KeyboardSpacerIOS />
      </View>
    );
  }
}

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(PhoneNumChange);

const styles = StyleSheet.create({
  bottomInputText: {
    flexDirection: 'row',
    borderTopWidth: PixelRatio.roundToNearestPixel(1),
    borderColor: washswatColor.grey_05,
  },
  bodyView: {
    flex: 1,
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
  inputText: {
    height: PixelRatio.roundToNearestPixel(56),
    color: '#000',
  },
  textInput: {
    flex: 1,
    marginLeft: PixelRatio.roundToNearestPixel(30),
    width: PixelRatio.roundToNearestPixel(windowSize.width - 95),
  },
  sendBtn: {
    paddingTop: PixelRatio.roundToNearestPixel(20),
    paddingLeft: PixelRatio.roundToNearestPixel(24),
    paddingBottom: PixelRatio.roundToNearestPixel(18),
    paddingRight: PixelRatio.roundToNearestPixel(30),
  },
});
