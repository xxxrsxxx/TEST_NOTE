import React from 'react';
import {
  Image,
  Linking,
  PixelRatio,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

// React-Native Module
import { Navigation } from 'react-native-navigation';
import BottomSheet from 'react-native-bottomsheet';
import DeviceInfo from 'react-native-device-info';

// Redux Module
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as MyPageModule from '../../reducers/MyPageModule';

import { BasicHeader } from '../../components/common/layout';

import { navPush, navShowModalWebView } from '../../utils/common';
import {
  Favorite,
  serviceOptionArray,
  SettingsString,
  settingTextArray,
  PageTitles,
} from '../../utils/common/strings';
import WashAlert from '../../utils/alert';
import AnalyticsManager from '../../utils/tagging/analytics';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import * as Server from '../../utils/type/server';
import * as Keys from '../../utils/type/key';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

class Settings extends React.Component {
  state = {
    version: undefined,
    label: undefined,
  };

  async componentDidMount() {
    const _storage = await $_storage.get();
    const version = _storage[Keys.CODE_PUSH_VERSION];
    const label = _storage[Keys.CODE_PUSH_LABEL];
    this.setState({
      version: version ? version : '',
      label: label ? label : '',
    });
    const { MyPageAction } = this.props;
    MyPageAction.myPageInit();
    // this.getAppVersion()

    // codePush.getCurrentPackage().then((metadata) =>{
    //   this.setState({label: metadata.label, version: metadata.appVersion, description: metadata.description});
    // });
  }
  moveToPage = async (page, key) => {
    const uid = $_storage.get(Keys.USER_ID);
    if (page === 'Linking') {
      if (Platform.OS === 'ios') {
        Linking.openURL(
          'itms-apps://itunes.apple.com/us/app/itunes-u/id1049236217?action=write-review',
        );
      } else {
        Linking.openURL('market://details?id=com.washswat.android');
      }
      await AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_REVIEW, {
        af_date: new Date(),
        af_path: 'setting',
      });
      AnalyticsManager.setAirbridgeTrackEvent(
        AnalyticsKey.NAME_REVIEW,
        Platform.OS,
        uid,
      );
      return;
    } else if (page === 'ServicePolicy') {
      BottomSheet.showBottomSheetWithOptions(
        {
          options: [
            serviceOptionArray.termsOfService,
            serviceOptionArray.privacyPolicy,
            serviceOptionArray.locationTermOfService,
            serviceOptionArray.cancel,
          ],
          dark: true,
          cancelButtonIndex: 3,
        },
        value => {
          let url;
          if (value == 0) {
            url = Server.URL_CLAUSE;
          } else if (value == 1) {
            url = Server.URL_PRIVACY;
          } else if (value == 2) {
            url = Server.URL_LOCATION_CLAUSE;
          } else {
            return;
          }
          navShowModalWebView({ url });
        },
      );
      return;
    }
    navPush({
      componentId: this.props.componentId,
      name: page,
      passProps: { pageName: key },
    });
  };

  onPressBack = () => {
    Navigation.pop(this.props.componentId);
  };

  onPressLogout = () => {
    WashAlert.showConfirm(
      SettingsString.logoutAlertContent,
      Favorite.yes,
      Favorite.no,
      () => {
        const { MyPageAction } = this.props;
        MyPageAction.logOut();
      },
    );
  };

  onPressWithdrawal = () => {
    WashAlert.showConfirm(
      SettingsString.withdrawalQuestion,
      SettingsString.withdrawalQuestionYes,
      SettingsString.withdrawalQuestionNo,
      () => {
        navPush({
          componentId: this.props.componentId,
          name: 'UserWithdrawal',
        });
      },
    );
  };
  appPush = value => {
    const { MyPageAction } = this.props;
    MyPageAction.appPush(value);
  };

  static options(passProps) {
    return {
      bottomTabs: {
        visible: false,
      },
    };
  }

  render() {
    const { setting, appexit, companyInfo } = settingTextArray;
    const { version, label } = this.state;

    let views = [],
      exit = [],
      info = [];

    setting.map((settingObj, i) => {
      views.push(
        <TouchableOpacity
          key={i}
          style={styles.viewFrame}
          onPress={() => this.moveToPage(settingObj.page, settingObj.key)}
        >
          <Text style={[responseFont(16).regular, styles.listView]}>
            {settingObj.name}
          </Text>
          <Image
            style={styles.image}
            source={require('image/mypage/forward_arrow_small.png')}
          />
        </TouchableOpacity>,
      );
    });

    appexit.map((appexitObj, i) => {
      const { functionName, name } = appexitObj;
      exit.push(
        <TouchableOpacity
          key={i}
          style={styles.viewFrame}
          onPress={this[functionName]}
        >
          <Text style={[responseFont(16).regular, styles.listView]}>
            {name}
          </Text>
          <Image
            style={styles.image}
            source={require('image/mypage/forward_arrow_small.png')}
          />
        </TouchableOpacity>,
      );
    });

    companyInfo.map((text, i) => {
      info.push(
        <Text
          key={i}
          style={[responseFont(12).regular, { color: washswatColor.grey_02 }]}
        >
          {text}
        </Text>,
      );
    });
    if (version) {
      info.push(
        <Text
          key={'v'}
          style={[responseFont(12).regular, { color: washswatColor.grey_02 }]}
        >
          {`App version ${version} ${label}`}
        </Text>,
      );
    } else {
      info.push(
        <Text
          key={'v'}
          style={[responseFont(12).regular, { color: washswatColor.grey_02 }]}
        >
          {`App version ${DeviceInfo.getVersion()}`}
        </Text>,
      );
    }

    const {
      MyPageState: {
        userInfo: { appPush },
      },
    } = this.props;
    const appPushIsOn = appPush
      ? require('image/mypage/settings/switch_on.png')
      : require('image/mypage/settings/switch_off.png');
    return (
      <View style={{ flex: 1 }}>
        <BasicHeader
          componentId={this.props.componentId}
          title={PageTitles.setMyInfo}
        />

        {/* <NBImageButton onPress={this.onPressBack} source={require('image/common/back_button_black.png')} /> */}
        <ScrollView style={[styles.frame]}>
          <View style={{ padding: 30 }}></View>
          <View style={styles.views}>
            {views}
            <View>
              <View style={styles.viewFrame}>
                <Text style={[responseFont(16).regular, styles.listView]}>
                  {SettingsString.noti}
                </Text>
                <TouchableOpacity onPress={this.appPush}>
                  <Image style={styles.toggleImage} source={appPushIsOn} />
                </TouchableOpacity>
              </View>
            </View>
          </View>
          <View style={styles.info}>{exit}</View>
          <View>
            <Text
              style={[
                responseFont(18).bold,
                {
                  paddingTop: PixelRatio.roundToNearestPixel(50),
                  paddingBottom: PixelRatio.roundToNearestPixel(20),
                },
              ]}
            >
              {SettingsString.washswatInc}
            </Text>
            {info}
          </View>
          <View style={{ height: PixelRatio.roundToNearestPixel(50) }} />
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = ({ MyPageModule }) => ({
  MyPageState: MyPageModule,
});
const mapDispatchToProps = dispatch => ({
  MyPageAction: bindActionCreators(MyPageModule, dispatch),
});
export default connect(mapStateToProps, mapDispatchToProps)(Settings);

const styles = StyleSheet.create({
  frame: {
    flexDirection: 'column',
    paddingLeft: PixelRatio.roundToNearestPixel(20),
    paddingRight: PixelRatio.roundToNearestPixel(20),
    paddingBottom: PixelRatio.roundToNearestPixel(20),
  },
  listView: {
    paddingTop: PixelRatio.roundToNearestPixel(19),
    paddingBottom: PixelRatio.roundToNearestPixel(19),
  },
  topViewFrame: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: PixelRatio.roundToNearestPixel(10),
    paddingBottom: PixelRatio.roundToNearestPixel(35),
    paddingTop:
      Platform.OS === 'android'
        ? PixelRatio.roundToNearestPixel(100)
        : PixelRatio.roundToNearestPixel(60),
  },
  viewFrame: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: PixelRatio.roundToNearestPixel(10),
    paddingRight: PixelRatio.roundToNearestPixel(10),
  },
  image: {
    paddingRight: PixelRatio.roundToNearestPixel(20),
    resizeMode: 'contain',
    width: PixelRatio.roundToNearestPixel(10),
    height: PixelRatio.roundToNearestPixel(10),
  },
  toggleImage: {
    paddingRight: PixelRatio.roundToNearestPixel(20),
    resizeMode: 'contain',
    width: PixelRatio.roundToNearestPixel(60),
    height: PixelRatio.roundToNearestPixel(30),
  },
  views: {
    borderBottomColor: washswatColor.black,
    borderBottomWidth: PixelRatio.roundToNearestPixel(2),
    paddingBottom: PixelRatio.roundToNearestPixel(55),
  },
  info: {
    borderBottomColor: washswatColor.black,
    borderBottomWidth: PixelRatio.roundToNearestPixel(2),
    paddingTop: PixelRatio.roundToNearestPixel(20),
    paddingBottom: PixelRatio.roundToNearestPixel(20),
  },
});
