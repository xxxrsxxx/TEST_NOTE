// Main screens
export const MAIN_SCREEN_NAME = 'MainScreen';

// Home screens
export const HOME_SCREEN_NAME = 'HomeScreen';
export const PRICE_LIST_SCREEN_NAME = 'PriceList';
export const EVENT_PAGE_SCREEN_NAME = 'EventPageScreen';

// Mypage Screens
export const MY_PAGE_SCREEN_NAME = 'MyPageScreen';
export const ADDRESS_CHANGE_SCREEN_NAME = 'AddressChange';
export const PAYMENT_METHOD_SCREEN_NAME = 'PaymentMethod';

// Order screens
export const ORDER_CHAT_SCREEN_NAME = 'OrderChatScreen';
export const ORDER_HISTORY_SCREEN_NAME = 'OrderHistoryScreen';

// Membership screens
export const JOIN_MEMBER_SCREEN_NAME = 'JoinMember';
export const MEMBERSHIP_INFO_SCREEN_NAME = 'MembershipInfo';
export const MEMBERSHIP_CANCEL_REASON_SCREEN_NAME = 'MembershipCancelReason';

// etc screens
export const WEB_VIEW_SCREEN_NAME = 'WebViewScreen';
