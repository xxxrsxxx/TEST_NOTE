import { BottomTabString, NewMainString } from '../../utils/common/strings';
import { Styles } from '../../utils/style';
import {
  HOME_SCREEN_NAME,
  PRICE_LIST_SCREEN_NAME,
  EVENT_PAGE_SCREEN_NAME,
  ORDER_CHAT_SCREEN_NAME,
  MEMBERSHIP_INFO_SCREEN_NAME,
  ORDER_HISTORY_SCREEN_NAME,
  MY_PAGE_SCREEN_NAME,
  JOIN_MEMBER_SCREEN_NAME,
} from '../../static/screen-name';
const { ORDER_BUTTON_MARGIN_BOTTOM_DEFAULT } = Styles;
import storage from '../../utils/common/storage';
import debug from '../../utils/common/debug';
import LifeCycle from '../../utils/common/hook/LifeCycle';
import { _, moment } from '../../plugins';
import axiosInstance from '../../utils/api';
import codePush from 'react-native-code-push';

/**
 * @description 초기 인스톨 메서드
 */
export const install = async () => {
  const init = async function() {
    window.$_storage = new storage();
    window.$_debug = new debug();
    window.$_ = _;
    window.$_moment = moment;
    /**
     * @name $_useCycleHandler
     * @dsc 이벤트 발생을 위한 생명 주기 훅
     * @type {{unMounted: unMounted, mounted: mounted}}
     * @use   $_useCycleHandler.mounted(() => {}) call back function
     */
    window.$_useCycleHandler = LifeCycle();

    /**
     * @description  extend axios
     * @private
     */

    const _storage = await $_storage.get();
    const _update = await codePush.getUpdateMetadata();
    window.$_axios = axiosInstance(_storage, _update);

    /** redux module **/
    // init status module
    window.$_status = {
      state: {
        envMode: 'development',
        debugMode: false,
      },
      actions: {},
    };
  };
  await init();
};

// BottomTap Settings
export const membershipUserTabs = () => {
  return {
    children: [
      {
        stack: {
          idx: 0,
          id: 'HOME_TAB',
          name: HOME_SCREEN_NAME,
          option: {
            bottomTab: {
              text: BottomTabString.home,
              defaultIcon: require('../../../assets/image/bottom-tab/home/ic_home_default.png'),
              disableIcon: require('../../../assets/image/bottom-tab/home/ic_home_disable.png'),
            },
          },
        },
      },
      {
        stack: {
          idx: 1,
          id: 'MEMBERSHIP_TAB',
          name: MEMBERSHIP_INFO_SCREEN_NAME,
          option: {
            bottomTab: {
              text: BottomTabString.membership,
              imageStyle: { marginBottom: 2, marginRight: 1 },
              defaultIcon: require('../../../assets/image/bottom-tab/membership/ic_membership_default.png'),
              disableIcon: require('../../../assets/image/bottom-tab/membership/ic_membership_disable.png'),
            },
          },
        },
      },
      {
        stack: {
          idx: 10,
          id: 'ORDER_TAB',
          name: ORDER_CHAT_SCREEN_NAME,
          option: {
            bottomTab: {
              isOrder: true,
              text: BottomTabString.order,
              imageStyle: { marginBottom: ORDER_BUTTON_MARGIN_BOTTOM_DEFAULT },
              defaultIcon: require('../../../assets/image/bottom-tab/order/ic_order_default.png'),
            },
          },
        },
      },
      {
        stack: {
          idx: 2,
          id: 'HISTORY_TAB',
          name: ORDER_HISTORY_SCREEN_NAME,
          option: {
            bottomTab: {
              text: BottomTabString.orderHistory,
              defaultIcon: require('../../../assets/image/bottom-tab/history/ic_history_default.png'),
              disableIcon: require('../../../assets/image/bottom-tab/history/ic_history_disable.png'),
            },
          },
        },
      },
      {
        stack: {
          idx: 3,
          id: 'MYPAGE_TAB',
          name: MY_PAGE_SCREEN_NAME,
          option: {
            bottomTab: {
              text: BottomTabString.mypage,
              defaultIcon: require('../../../assets/image/bottom-tab/mypage/ic_mypage_default.png'),
              disableIcon: require('../../../assets/image/bottom-tab/mypage/ic_mypage_disable.png'),
            },
          },
        },
      },
    ],
  };
};

export const normarUserTabs = () => {
  return {
    children: [
      {
        stack: {
          idx: 0,
          id: 'HOME_TAB',
          name: HOME_SCREEN_NAME,
          option: {
            bottomTab: {
              text: BottomTabString.home,
              defaultIcon: require('../../../assets/image/bottom-tab/home/ic_home_default.png'),
              disableIcon: require('../../../assets/image/bottom-tab/home/ic_home_disable.png'),
            },
          },
        },
      },
      {
        stack: {
          idx: 1,
          id: 'JOINMEMBER_TAB',
          name: JOIN_MEMBER_SCREEN_NAME,
          option: {
            bottomTab: {
              text: BottomTabString.membership,
              imageStyle: { marginBottom: 2, marginRight: 1 },
              defaultIcon: require('../../../assets/image/bottom-tab/membership/ic_membership_default.png'),
              disableIcon: require('../../../assets/image/bottom-tab/membership/ic_membership_disable.png'),
            },
          },
        },
      },
      {
        stack: {
          idx: 10,
          id: 'ORDER_TAB',
          name: ORDER_CHAT_SCREEN_NAME,
          option: {
            bottomTab: {
              isOrder: true,
              text: BottomTabString.order,
              imageStyle: { marginBottom: ORDER_BUTTON_MARGIN_BOTTOM_DEFAULT },
              defaultIcon: require('../../../assets/image/bottom-tab/order/ic_order_default.png'),
            },
          },
        },
      },
      {
        stack: {
          idx: 2,
          id: 'HISTORY_TAB',
          name: ORDER_HISTORY_SCREEN_NAME,
          option: {
            bottomTab: {
              text: BottomTabString.orderHistory,
              defaultIcon: require('../../../assets/image/bottom-tab/history/ic_history_default.png'),
              disableIcon: require('../../../assets/image/bottom-tab/history/ic_history_disable.png'),
            },
          },
        },
      },
      {
        stack: {
          idx: 3,
          id: 'MYPAGE_TAB',
          name: MY_PAGE_SCREEN_NAME,
          option: {
            bottomTab: {
              text: BottomTabString.mypage,
              defaultIcon: require('../../../assets/image/bottom-tab/mypage/ic_mypage_default.png'),
              disableIcon: require('../../../assets/image/bottom-tab/mypage/ic_mypage_disable.png'),
            },
          },
        },
      },
    ],
  };
};

// HomeScreen Service Settings
export const mainServiceStyleList = [
  {
    key: 'wash_price',
    source: require('../../../assets/image/main/main-services/price/ic_price.png'),
    navName: PRICE_LIST_SCREEN_NAME,
    passProps: {},
  },
  {
    key: 'app_guide',
    source: require('../../../assets/image/main/main-services/guide/ic_guide.png'),
  },
  {
    key: 'event',
    source: require('../../../assets/image/main/main-services/event/ic_event.png'),
    navName: EVENT_PAGE_SCREEN_NAME,
    passProps: {},
  },
  {
    key: 'factory_tour',
    source: require('../../../assets/image/main/main-services/factory/ic_factory.png'),
  },
];

export const subServiceStyleList = [
  {
    key: 'care',
    source: require('../../../assets/image/main/sub-services/care/ic_care.png'),
  },
  {
    key: 'premium',
    source: require('../../../assets/image/main/sub-services/premium/ic_premium.png'),
  },
  {
    key: 'repair',
    source: require('../../../assets/image/main/sub-services/repair/ic_repair.png'),
  },
  {
    key: 'natural',
    source: require('../../../assets/image/main/sub-services/natural/ic_natural.png'),
  },
  {
    key: 'shoes',
    source: require('../../../assets/image/main/sub-services/shoes/ic_shoes.png'),
  },
  {
    key: 'freepass',
    source: require('../../../assets/image/main/sub-services/freepass/ic_freepass.png'),
  },
];

export const apiTimeoutValue = { timeout: 5000 }; // axios timeout
