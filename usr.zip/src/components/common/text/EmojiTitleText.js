import React from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';

import { Font } from '../../../utils/style';

const { washswatColor, responseFont } = Font;

export const EmojiTitleText = props => {
  const { emoji, title } = props;
  const emoji_icon = {
    emoji_receipt: require('../../../../assets/image/v5/emoji/emoji_receipt.png'),
  };
  return (
    <View style={styles.root}>
      {emoji.startsWith('emoji_') ? (
        <Image source={emoji_icon[emoji]} style={{ width: 44, height: 56 }} />
      ) : (
        <Text style={styles.emoji}>{emoji}</Text>
      )}
      <Text style={styles.title}>{title}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    alignItems: 'center',
  },
  emoji: {
    ...responseFont(43).bold,
  },
  title: {
    ...responseFont(24).bold,
    color: washswatColor.black,
    marginTop: 9,
  },
});
