import React from 'react';
import { Text, View } from 'react-native';

import { Font } from '../../../utils/style';

const { responseFont } = Font;

const OrderItemTagText = ({ text, textColor, backgroundColor }) => {
  if (!text) {
    return null;
  }
  return (
    <View
      style={{
        backgroundColor,
        paddingLeft: 4,
        paddingTop: 2,
        paddingRight: 4,
        paddingBottom: 2,
        borderRadius: 6,
      }}
    >
      <Text style={{ ...responseFont(11).bold, color: textColor }}>{text}</Text>
    </View>
  );
};

export default OrderItemTagText;
