import React from 'react';

import { TouchableOpacity, Text } from 'react-native';

import { Font } from '../../../utils/style';

const { horizonScale, responseFont } = Font;

const SideMenuListText = ({ menuText, onPressMenu }) => {
  return (
    <TouchableOpacity
      onPress={onPressMenu}
      style={{ paddingBottom: horizonScale(16) }}
    >
      <Text style={responseFont(13).regular}>{menuText}</Text>
    </TouchableOpacity>
  );
};

export default SideMenuListText;
