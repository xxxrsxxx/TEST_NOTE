import React from 'react';

import { Text, View, StyleSheet } from 'react-native';

import { Font } from '../../../utils/style';

const { washswatColor, responseFont } = Font;

const UserTagText = ({ userType }) => {
  return (
    <View style={styles.background}>
      <Text style={styles.text}>
        {userType === 'member' ? userType : 'basic'}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    paddingLeft: 4,
    paddingRight: 4,
    backgroundColor: washswatColor.blueOpacity14,
    borderRadius: 6,
  },
  text: {
    ...responseFont(12).bold,
    color: washswatColor.lightBlue,
  },
});

export default UserTagText;
