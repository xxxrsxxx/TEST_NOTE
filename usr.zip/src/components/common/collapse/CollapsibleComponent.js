import React from 'react';

import {
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  StatusBar,
} from 'react-native';
import Collapsible from 'react-native-collapsible';

import { BorderRadiusButton } from '../button/BorderRadiusButton';

import { Font } from '../../../utils/style';
import * as OrderUtils from '../../../utils/common/order';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  root: {
    borderRadius: 30,
  },
  titleView: {
    flexDirection: 'row',
    height: 56,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 30,
    paddingRight: 24.5,
  },
  title: {
    ...responseFont(16).bold,
    color: washswatColor.black,
  },
  arrow: {
    width: 12,
    height: 6.5,
  },
  content: {
    paddingLeft: 30,
    paddingTop: 9,
    paddingRight: 30,
  },
  buttonView: {
    marginLeft: 15,
    marginTop: 18,
    marginRight: 15,
  },
});

export const CollapsibleComponent = props => {
  const {
    title,
    onPressCollapse,
    content,
    onPressButton,
    buttonText,
    buttonTitleColor,
    borderRadius,
  } = props;
  let { collapsed, buttonBgColor, bgColor } = props;
  buttonBgColor = buttonBgColor ? buttonBgColor : washswatColor.white;
  bgColor = bgColor ? bgColor : washswatColor.grey_07;
  let arrowImgSource = collapsed
    ? require('../../../../assets/image/v5/arrow_bottom.png')
    : require('../../../../assets/image/v5/arrow_top.png');

  const ArrowImage = props => {
    const { collapsed } = props;
    if (collapsed !== undefined) {
      return <Image source={arrowImgSource} style={styles.arrow} />;
    }
    return <View />;
  };

  return (
    <View
      style={{
        ...styles.root,
        backgroundColor: bgColor,
        borderRadius: borderRadius ? borderRadius : 30,
      }}
    >
      <StatusBar barStyle="light-content" />
      <TouchableOpacity
        onPress={onPressCollapse}
        activeOpacity={collapsed !== undefined ? 0.2 : 1}
      >
        <View style={styles.titleView}>
          <Text style={styles.title}>{title}</Text>
          <ArrowImage collapsed={collapsed} />
        </View>
      </TouchableOpacity>
      <Collapsible collapsed={collapsed !== undefined ? collapsed : false}>
        {content ? (
          <View style={styles.content}>
            {OrderUtils.convertTextWithRegex({
              text: content,
              color: washswatColor.darkGrey,
              ...responseFont(16).regular,
            })}
          </View>
        ) : (
          <View />
        )}
        {buttonText ? (
          <View style={styles.buttonView}>
            <BorderRadiusButton
              onPress={onPressButton}
              buttonBgColor={buttonBgColor}
              title={buttonText}
              titleColor={
                buttonTitleColor ? buttonTitleColor : washswatColor.blue
              }
              borderRadius={borderRadius ? borderRadius : 15}
            />
          </View>
        ) : (
          <View />
        )}
        <View style={{ height: 15 }} />
      </Collapsible>
    </View>
  );
};
