import React from 'react';
import { Platform } from 'react-native';
import KeyboardSpacer from 'react-native-keyboard-spacer';

const KeyboardSpacerIOS = () => {
  if(Platform.OS === 'android'){
    return <KeyboardSpacer topSpacing={30} />;
  }else{
    return <KeyboardSpacer />;
  }

};

export default KeyboardSpacerIOS;
