import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import Modal from 'react-native-modalbox';
// components import
import TouchableOpacityActiveOne from '../style/TouchableOpacityActiveOne';
// styles import
import { Font } from '../../../utils/style';

const { washswatColor, responseFont } = Font;

function BottomModalComponent({
  isOpen,
  contentView,
  leftButtonText,
  rightButtonText,
  onLeftButtonClicked,
  onRightButtonClicked,
  onClosed,
  height,
  customModalStyle,
}) {
  // height: 314,
  return (
    <Modal
      isOpen={isOpen}
      onClosed={onClosed}
      style={[styles.modal, { height: height || 300 }, customModalStyle]}
      position={'bottom'}
    >
      {contentView}

      <View style={[styles.bottomButtons, styles.noContent_button]}>
        {leftButtonText && onLeftButtonClicked ? (
          <TouchableOpacityActiveOne
            onPress={onLeftButtonClicked}
            style={[styles.button, styles.leftButton]}
          >
            <Text
              style={[
                styles.buttonText,
                styles.leftButtonText,
                { ...responseFont(14).bold },
              ]}
            >
              {leftButtonText}
            </Text>
          </TouchableOpacityActiveOne>
        ) : null}
        {rightButtonText &&
        onRightButtonClicked &&
        leftButtonText &&
        onLeftButtonClicked ? (
          <View style={{ padding: 16 }} />
        ) : null}

        {rightButtonText && onRightButtonClicked ? (
          <TouchableOpacityActiveOne
            onPress={onRightButtonClicked}
            style={[styles.button, styles.rightButton]}
          >
            <Text
              style={[
                styles.buttonText,
                styles.rightButtonText,
                { ...responseFont(14).bold },
              ]}
            >
              {rightButtonText}
            </Text>
          </TouchableOpacityActiveOne>
        ) : null}
      </View>
    </Modal>
  );
}

BottomModalComponent.defaultProps = {
  isOpen: false,
  contentView: null,
  leftButtonText: '',
  rightButtonText: '',
  onLeftButtonClicked: () => {},
  onRightButtonClicked: () => {},
  onClosed: () => {},
  height: 300,
  customModalStyle: {},
};

BottomModalComponent.propTypes = {
  isOpen: PropTypes.bool,
  contentView: PropTypes.oneOfType([PropTypes.array, PropTypes.element]),
  leftButtonText: PropTypes.string,
  rightButtonText: PropTypes.string,
  onLeftButtonClicked: PropTypes.func,
  onRightButtonClicked: PropTypes.func,
  onClosed: PropTypes.func,
  height: PropTypes.number,
  customModalStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  modal: {
    backgroundColor: washswatColor.white,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    alignItems: 'center',
    paddingLeft: 21,
    paddingTop: 60,
    paddingRight: 21,
    paddingBottom: 27.5,
    justifyContent: 'space-between',
  },

  noContent_button: {
    marginBottom: 20,
  },
  content: {
    ...responseFont(18).regular,
    color: washswatColor.black,
    marginTop: 21,
  },
  bottomButtons: {
    flexDirection: 'row',
    marginTop: 34,
  },
  button: {
    flex: 1,
    alignItems: 'center',
    borderRadius: 5,
  },
  leftButton: {
    backgroundColor: washswatColor.grey_16,
  },
  rightButton: {
    backgroundColor: washswatColor.black,
  },
  buttonText: {
    padding: 16,
    textAlign: 'center',
  },
  leftButtonText: {
    color: washswatColor.black,
  },
  rightButtonText: {
    // backgroundColor : 'blue',
    color: washswatColor.white,
  },
  title: {
    textAlign: 'center',
  },
});

export default BottomModalComponent;
