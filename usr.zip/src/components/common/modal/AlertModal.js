import React from 'react';
import { StyleSheet, Image, View, Text } from 'react-native';
import { Modal } from '../../../plugins';

// font import
import { Font } from '../../../utils/style';
const { responseFont, washswatColor } = Font;

function AlertModal(props) {
  const { data } = props;
  return (
    <Modal backdropOpacity={0} style={styles.modalArea} {...props}>
      <View style={styles.modalLeft}>
        <Image
          width={16}
          height={16}
          source={require('../../../../assets/image/common/Ic_Check.png')}
        />
      </View>
      <View style={styles.modalRight}>
        <Text style={styles.modalTitle}>{data.comment.title}</Text>
        <Text style={styles.modalDescription}>{data.comment.description}</Text>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalArea: {
    flexDirection: 'row',
    width: 328,
    height: 64,
    bottom: 52,
    borderRadius: 4,
    backgroundColor: '#F1F7FF', // color 수정 필요
  },
  modalLeft: {
    justifyContent: 'flex-start',
    paddingTop: 16,
    paddingLeft: 16,
    paddingRight: 6,
  },
  modalRight: { justifyContent: 'center' },
  modalTitle: {
    marginTop: 4,
    ...responseFont(12).bold,
    color: washswatColor.blue,
  },
  modalDescription: {
    marginTop: 4,
    ...responseFont(12).regular,
  },
});
export default AlertModal;
