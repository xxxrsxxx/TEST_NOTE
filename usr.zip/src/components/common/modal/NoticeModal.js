import React from 'react';
import { StyleSheet, Image, View, Text } from 'react-native';
import PropTypes from 'prop-types';
import Modal from 'react-native-modalbox';
// components import
import { TouchableOpacityActiveOne } from '../index';
// styles import
import { Font, Styles } from '../../../utils/style';
import * as CommonUtils from '../../../utils/common';
import { navPushOrderChatScreen } from '../../../utils/common/nav';
const { washswatColor, responseFont } = Font;
const { BOTTOM_TAB_HEIGHT } = Styles;

function NoticeModal({ componentId, BottomTabState, toggleOrderButton }) {
  // const { componentId, BottomTabState, toggleOrderButton } = props;
  const { orderButtonPopup } = BottomTabState;

  let modalView;
  if (orderButtonPopup) {
    /** 버튼 있는 경우 **/
    // popup = {
    //   title : '죄송합니다. 주문량이 많아\n오늘 수거는 마감되었어요.',
    //   description : '지금 신청하시면 #일 새벽에 수거해요.\n최고의 세탁 품질을 위한 어쩔수 없는 선택. 양해 부탁드립니다.',
    //   button : {
    //     type : 'page',
    //     text : '#일 새벽 수거로 신청할게요',
    //     next : 'OrderChat'
    //   }
    // }
    /** 이미지만 있는 경우 **/
    // popup = {
    //   image : `https://ssl.pstatic.net/tveta/libs/1318/1318447/b4db3eaeab6e5b7624bc_20201223142714954.jpg`,
    //   title : '이미 접수된 주문이 있어요',
    //   description : '이전 주문의 수거가 완료된 이후에\n다시 신청하실 수 있어요.\n조금만 기다주세요.',
    // }
    const { button, title, description, image } = orderButtonPopup;
    modalView = (
      <View style={styles.innerContainer}>
        {image ? (
          <Image style={styles.imageContainer} source={{ uri: image }} />
        ) : // <View style={styles.imageContainer}>
        // </View>
        null}

        <View style={styles.boldTextContainer}>
          <Text style={styles.boldText}>{title}</Text>
        </View>
        {button && button.text ? <View style={styles.conditionHeight} /> : null}
        <Text style={styles.explanationText}>{description}</Text>
        {button && button.text ? (
          <TouchableOpacityActiveOne
            style={styles.orderBtn}
            onPress={() => {
              button.type === 'web'
                ? CommonUtils.navShowModalWebView({ url: button.next })
                : navPushOrderChatScreen({ componentId });
              // goOrderChatScreenEvent(componentId);
            }}
          >
            <Text style={styles.orderBtnText}>{button.text}</Text>
          </TouchableOpacityActiveOne>
        ) : null}
      </View>
    );
  }

  return (
    <Modal
      onClosed={toggleOrderButton}
      style={styles.modalContainer}
      isOpen={modalView ? true : false}
      position={'bottom'}
    >
      <View style={styles.innerContainer}>{modalView}</View>
    </Modal>
  );
}

NoticeModal.defaultProps = {
  componentId: '0',
  BottomTabState: {},
  toggleOrderButton: () => {},
};

NoticeModal.propTypes = {
  componentId: PropTypes.string.isRequired,
  BottomTabState: PropTypes.object.isRequired,
  toggleOrderButton: PropTypes.func.isRequired,
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
  },
  modalContainer: {
    height: 375,
    paddingBottom: BOTTOM_TAB_HEIGHT,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  innerContainer: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  imageContainer: {
    width: 120,
    height: 120,
    marginBottom: 16,
  },
  boldTextContainer: {
    marginBottom: 8,
  },
  conditionHeight: {
    height: 8,
  },
  boldText: {
    ...responseFont(12).bold,
    textAlign: 'center',
    lineHeight: 27,
  },
  explanationText: {
    ...responseFont(14).regular,
    color: washswatColor.grey_13,
    textAlign: 'center',
    lineHeight: 19,
  },
  orderBtn: {
    marginTop: 35,
    borderRadius: 5,
    height: 53,
    width: '85%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'black',
  },
  orderBtnText: {
    ...responseFont(15).bold,
    color: washswatColor.white,
  },
});

export default NoticeModal;
