import React, { useEffect, useRef } from 'react';
import {
  View,
  StyleSheet,
  Image,
  Text,
  Animated,
  Easing,
  Platform,
} from 'react-native';
import PropTypes from 'prop-types';
// components import
import TouchableOpacityActiveOne from '../../components/common/style/TouchableOpacityActiveOne';
// utils import
import { membershipUserTabs, normarUserTabs } from '../../static/settings';
// styles import
import { Font, Styles } from '../../utils/style';

const { washswatColor, responseFont } = Font;
const {
  ORDER_BUTTON_MARGIN_BOTTOM_DEFAULT,
  ORDER_BUTTON_MARGIN_BOTTOM_DISABLE,
  ORDER_BUTTON_ANI_DURATION,
  BOTTOM_TAB_HEIGHT,
} = Styles;

function BottomTab({ style, onPressTab, BottomTabState }) {
  const { userType, orderButtonPopup, currentScreenName } = BottomTabState;
  const moveAnim = useRef(new Animated.Value(1)).current;
  const spinAnim = useRef(new Animated.Value(0)).current;

  const marginBottomData = moveAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [
      ORDER_BUTTON_MARGIN_BOTTOM_DISABLE,
      ORDER_BUTTON_MARGIN_BOTTOM_DEFAULT,
    ],
  });
  const rotateData = spinAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '-45deg'],
  });

  const pressTab = screenName => {
    onPressTab(screenName);
  };

  const moveDownAnim = () => {
    Animated.parallel([
      Animated.timing(moveAnim, {
        toValue: 0,
        duration: ORDER_BUTTON_ANI_DURATION,
        useNativeDriver: false,
      }),
      Animated.timing(spinAnim, {
        toValue: 1,
        duration: ORDER_BUTTON_ANI_DURATION,
        easing: Easing.linear,
        useNativeDriver: false,
      }),
    ]).start();
  };

  const moveUpAnim = () => {
    Animated.parallel([
      Animated.timing(moveAnim, {
        toValue: 1,
        duration: ORDER_BUTTON_ANI_DURATION,
        useNativeDriver: false,
      }),
      Animated.timing(spinAnim, {
        toValue: 0,
        duration: ORDER_BUTTON_ANI_DURATION,
        easing: Easing.linear,
        useNativeDriver: false,
      }),
    ]).start();
  };

  const setAnimation = positive => {
    if (positive) {
      moveDownAnim();
    } else {
      moveUpAnim();
    }
  };

  useEffect(() => {
    setAnimation(orderButtonPopup ? true : false);
  }, [orderButtonPopup]);

  const bottomTaps =
    userType === 'member' ? membershipUserTabs() : normarUserTabs();
  return (
    <View style={[styles.container, !orderButtonPopup && styles.shadow, style]}>
      {bottomTaps.children.map((bottomTab, index) => {
        if (bottomTab.stack.option.bottomTab.isOrder) {
          return (
            <BottomTabViewWhenHasOrder
              bottomTab={bottomTab}
              pressTab={pressTab}
              marginBottomData={marginBottomData}
              rotateData={rotateData}
              key={bottomTab.stack.idx}
              orderButtonPopup={orderButtonPopup}
            />
          );
        } else {
          return (
            <BottomTabViewWhenHasNOOrder
              bottomTab={bottomTab}
              pressTab={pressTab}
              key={bottomTab.stack.idx}
              currentScreenName={currentScreenName}
            />
          );
        }
      })}
    </View>
  );
}

const BottomTabViewWhenHasOrder = ({
  bottomTab,
  pressTab,
  marginBottomData,
  rotateData,
  orderButtonPopup,
  // index,
}) => {
  //
  let positive = orderButtonPopup ? true : false;

  return (
    <TouchableOpacityActiveOne
      style={styles.bottomTabContainer}
      onPress={() => pressTab(bottomTab.stack.name)}
      // key={index}
    >
      <Animated.Image
        style={[
          styles.iconContainer,
          bottomTab.stack.option.bottomTab.imageStyle,
          {
            marginBottom: marginBottomData,
            transform: [{ rotate: rotateData }],
          },
        ]}
        source={bottomTab.stack.option.bottomTab.defaultIcon}
      />
      <View style={styles.textContainer}>
        {positive ? null : (
          <Text style={styles.text}>
            {' '}
            {bottomTab.stack.option.bottomTab.text}{' '}
          </Text>
        )}
      </View>
    </TouchableOpacityActiveOne>
  );
};

const BottomTabViewWhenHasNOOrder = ({
  bottomTab,
  pressTab,
  // index,
  currentScreenName,
}) => {
  return (
    <TouchableOpacityActiveOne
      style={styles.bottomTabContainer}
      onPress={() => pressTab(bottomTab.stack.name)}
      // key={index}
    >
      <View
        style={[
          styles.iconContainer,
          bottomTab.stack.option.bottomTab.imageStyle,
        ]}
      >
        <Image
          source={
            bottomTab.stack.option.bottomTab[
              `${
                currentScreenName === bottomTab.stack.name
                  ? 'default'
                  : 'disable'
              }Icon`
            ]
          }
        />
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.text}>{bottomTab.stack.option.bottomTab.text}</Text>
      </View>
    </TouchableOpacityActiveOne>
  );
};

BottomTab.defaultProps = {
  style: {},
  onPressTab: () => {},
  BottomTabState: {},
};

BottomTab.propTypes = {
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  onPressTab: PropTypes.func.isRequired,
  BottomTabState: PropTypes.object.isRequired,
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    width: '100%',
    paddingBottom: 34,
    height: BOTTOM_TAB_HEIGHT,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    alignItems: 'flex-end',
    justifyContent: 'center',
    backgroundColor: washswatColor.white,
  },
  shadow: {
    ...Platform.select({
      ios: {
        shadowOffset: {
          width: 0,
          height: 0,
        },
        shadowOpacity: 0.07,
        shadowRadius: 10,
      },
      android: {
        elevation: 12,
      },
    }),
  },
  bottomTabContainer: {
    flex: 1,
    height: 51,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  iconContainer: {
    marginBottom: 4,
  },
  textContainer: {
    height: 11,
    alignItems: 'center',
  },
  text: {
    ...responseFont(11).regular,
  },
});

export default BottomTab;
