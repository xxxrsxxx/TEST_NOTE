import React from 'react';
import { Image, StyleSheet, TouchableOpacity } from 'react-native';

export const XButton = props => {
  const { onPress } = props;

  return (
    <TouchableOpacity onPress={onPress}>
      <Image
        source={require('../../../../assets/image/v5/button_x.png')}
        style={styles.back}
      />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  back: {
    width: 36,
    height: 36,
  },
});
