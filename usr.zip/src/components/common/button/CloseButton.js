import React from 'react';
import { TouchableOpacity, Image, Platform } from 'react-native';

const CloseButton = ({onPress}) => {
  return (
    <TouchableOpacity onPress={onPress} style={{  position:'absolute', top: Platform.OS === 'android' ? 48 : 48 , right:15, zIndex: 10, padding:5, }}>
      <Image
        source={require('/image/v5/button_x.png')}
        style={{width: 36, height: 36}}
      />
    </TouchableOpacity>
  );
}

export default CloseButton;