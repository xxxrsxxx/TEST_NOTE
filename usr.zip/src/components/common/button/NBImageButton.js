import React from 'react';
import { TouchableOpacity, PixelRatio, Image } from 'react-native';

export default function NBImageButton(props) {
  const { onPress, source } = props;
  return (
    <TouchableOpacity
      style={{
        width: PixelRatio.roundToNearestPixel(52),
        height: PixelRatio.roundToNearestPixel(60),
        justifyContent: 'center',
        alignItems: 'center'
      }}
      onPress={onPress}
    >
      <Image
        source={source}
        style={{
          width: PixelRatio.roundToNearestPixel(16),
          height: PixelRatio.roundToNearestPixel(16)
        }}
      />
    </TouchableOpacity>
  );
}
