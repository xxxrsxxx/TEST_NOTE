import React from 'react';

import { View, PixelRatio, Text, StyleSheet, Platform } from 'react-native';

import { Font } from '../../../utils/style';

const { responseFont, washswatColor } = Font;

export default function UpToPercent(props) {
  const { percent } = props;
  return (
    <View style={styles.rootView}>
      <Text style={[responseFont(12).bold, { color: washswatColor.white }]}>
        {percent}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  rootView: {
    width: PixelRatio.roundToNearestPixel(72),
    height: PixelRatio.roundToNearestPixel(24),
    backgroundColor: washswatColor.red,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: PixelRatio.roundToNearestPixel(12),
    ...Platform.select({
      ios: {
        shadowColor: washswatColor.black,
        shadowOffset: {
          width: PixelRatio.roundToNearestPixel(0),
          height: PixelRatio.roundToNearestPixel(6),
        },
        shadowOpacity: 0.14,
        shadowRadius: PixelRatio.roundToNearestPixel(10),
      },
      android: {
        elevation: PixelRatio.roundToNearestPixel(10),
      },
    }),
  },
});
