import React from 'react';
import { Image, View } from 'react-native';


const ArrowButton = props => {
  const { isCollapsed } = props;

  let arrowImgSource = isCollapsed
  ? require('../../../../assets/image/v5/icons_8_forward_bottom.png')
  : require('../../../../assets/image/v5/icons_8_forward_top.png')
  
  if (isCollapsed !== undefined) {
    return <Image source={arrowImgSource} style={{ width: 12, height: 6.5, marginLeft: 18, }}/>;
  }
  return <View/>;
};

export default ArrowButton;
