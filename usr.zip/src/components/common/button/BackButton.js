import React from 'react';

import {
  Image,
  StyleSheet,
  TouchableOpacity,
  View,
  Text,
  Platform,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { getStatusBarHeight } from 'react-native-status-bar-height';

import { Font } from '../../../utils/style';

const { responseFont } = Font;

const backButtonPadding = 6;

const getTopHeight = () => {
  return getStatusBarHeight();
  // console.log(' isIphoneX()' , isIphoneX() , getBottomSpace() , getStatusBarHeight() , backButtonPadding)
  // if (isIphoneX()) {
  //
  // } else {
  //   return getStatusBarHeight();
  // }
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    paddingLeft: 18,
    paddingTop: getTopHeight(),
    zIndex: 20,
    paddingBottom: 12,
    paddingRight: backButtonPadding * 2,
  },
  back: {
    width: 11.68,
    height: 20.46,
  },
});

const BackButton = props => {
  const { componentId, onPress, customStyle, title, inSafeAreaView } = props;

  function onPressBack() {
    Navigation.pop(componentId);
  }

  if (title) {
    return (
      <View
        style={{
          height: 88 - (Platform.OS == 'android' ? getTopHeight() : 0),
          paddingTop: inSafeAreaView ? 0 : getTopHeight(),
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor: 'white',
        }}
      >
        <View style={{ flex: 1 }}>
          <TouchableOpacity
            onPress={componentId ? onPressBack : onPress}
            style={{
              paddingLeft: 15,
              paddingRight: 15,
              paddingBottom: 12,
              paddingTop: 12,
            }}
          >
            <Image
              source={require('../../../../assets/image/mypage/settings/arrow_v6_light.png')}
              style={styles.back}
            />
          </TouchableOpacity>
        </View>
        <View
          style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
        >
          <Text style={{ ...responseFont(16).bold }}>{title}</Text>
        </View>
        <View style={{ flex: 1 }}></View>
      </View>
    );
  } else {
    return (
      <TouchableOpacity
        onPress={componentId ? onPressBack : onPress}
        style={
          customStyle
            ? { ...styles.container, ...customStyle }
            : styles.container
        }
      >
        <Image
          source={require('../../../../assets/image/mypage/settings/arrow_v6_light.png')}
          style={styles.back}
        />
      </TouchableOpacity>
    );
  }
};

export default BackButton;
