import React from 'react';

import { StyleSheet, Text, View, PixelRatio } from 'react-native';

import { Font } from '../../../utils/style';

const { responseFont, washswatColor } = Font;

export const JoinTimer = props => {
  const { timerCounter, isHidden } = props;

  return (
    <View
      style={[
        styles.timerView,
        { marginLeft: PixelRatio.roundToNearestPixel(isHidden ? 20 : 27) },
      ]}
    >
      <Text style={[styles.timerText, responseFont(14).regular]}>
        {timerCounter}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  timerView: {
    marginBottom: PixelRatio.roundToNearestPixel(17),
    justifyContent: 'center',
    width: PixelRatio.roundToNearestPixel(56),
    height: PixelRatio.roundToNearestPixel(24),
    borderWidth: 1,
    borderColor: washswatColor.blue,
    borderRadius: 36,
    // marginLeft: PixelRatio.roundToNearestPixel(27)
  },
  timerText: {
    textAlign: 'center',
    color: washswatColor.blue,
  },
});
