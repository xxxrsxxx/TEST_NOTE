import React from 'react';
import PropTypes from 'prop-types';
import {
  PixelRatio,
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
} from 'react-native';

import TouchableOpacityActiveOne from '../style/TouchableOpacityActiveOne';
import { Font, Styles } from '../../../utils/style';

const { washswatColor, responseFont, themeColorSelector } = Font;

// type, containerStyle, clickEvent, content, disabled
// backgroundColor는 type으로 정형화된 컬러들만 themeColorSelector를 사용하여 가져온다.

// 현재 themeColor는 미완성본이라 opacity값을 주지 않았음.(default: 10)
function CommonButton({ type, containerStyle, clickEvent, content, disabled }) {
  const themeColor = themeColorSelector({ theme: type });

  return (
    <View style={containerStyle}>
      <TouchableOpacityActiveOne
        onPress={clickEvent}
        style={{ ...styles.contentWrapper, backgroundColor: themeColor }}
        disabled={disabled}
      >
        <Text style={styles.contentText}>{content}</Text>
      </TouchableOpacityActiveOne>
    </View>
  );
}

CommonButton.defaultProps = {
  type: 'primary',
  containerStyle: '',
  clickEvent: () => {},
  content: '',
  disabled: false,
};

const styles = StyleSheet.create({
  contentWrapper: {
    height: PixelRatio.roundToNearestPixel(55),
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 1,
  },
  contentText: {
    ...responseFont(16).bold,
    color: washswatColor.white,
  },
});

export default CommonButton;
