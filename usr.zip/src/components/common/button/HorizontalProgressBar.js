import React from 'react';

import { Platform, PixelRatio, View, ProgressViewIOS, ProgressBarAndroid } from 'react-native';

import { Font } from '../../../utils/style';

const { washswatColor } = Font;

export default function HorizontalProgressBar(props) {
  const { progress } = props;
  return (
    <View>
      {Platform.OS === 'ios' ? (
        <ProgressViewIOS progress={progress} progressTintColor={washswatColor.blue} progressViewStyle={'bar'} />
      ) : (
        <ProgressBarAndroid
          styleAttr="Horizontal"
          style={{ marginTop: PixelRatio.roundToNearestPixel(-5.2) }}
          color={washswatColor.blue}
          indeterminate={false}
          progress={progress}
        />
      )}
    </View>
  );
}
