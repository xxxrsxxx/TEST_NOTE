import React from 'react';
import { StyleSheet, Text, TouchableOpacity } from 'react-native';

import { Font } from '../../../utils/style';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  button: {
    height: 52,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export const BorderRadiusButton = props => {
  const { title, onPress } = props;
  let { buttonBgColor, titleFont, titleColor, borderRadius, disabled } = props;

  buttonBgColor = buttonBgColor ? buttonBgColor : washswatColor.blue;
  titleFont = responseFont(16).regular;
  titleColor = titleColor ? titleColor : washswatColor.white;
  borderRadius = borderRadius ? borderRadius : 30;
  disabled = disabled ? disabled : false;

  return (
    <TouchableOpacity
      disabled={disabled}
      onPress={onPress}
      style={{ ...styles.button, backgroundColor: buttonBgColor, borderRadius }}
    >
      <Text style={{ ...titleFont, color: titleColor }}>{title}</Text>
    </TouchableOpacity>
  );
};
