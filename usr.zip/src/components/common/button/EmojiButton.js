import React from 'react';
import { StyleSheet, Text, TouchableOpacity } from 'react-native';

import { Font } from '../../../utils/style';

const { washswatColor, responseFont } = Font;

export const EmojiButton = props => {
  const { title, onPress } = props;
  return (
    <TouchableOpacity onPress={onPress} style={styles.button}>
      <Text style={styles.text}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    width: 60,
    height: 60,
    borderRadius: 15,
    backgroundColor: washswatColor.grey_07,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: washswatColor.black,
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.18,
    shadowRadius: 12,
    elevation: 12,
  },
  text: {
    ...responseFont(24).bold,
    color: washswatColor.white,
  },
});
