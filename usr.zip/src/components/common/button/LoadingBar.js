import React from 'react';

import {
  Dimensions,
  Image,
  Platform,
  ProgressBarAndroid,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import { BlurView } from '@react-native-community/blur';

import { Font } from '../../../utils/style';

const { washswatColor } = Font;

const window = Dimensions.get('window');

const LoadingImage = () => {
  const diameter = window.width / 8;
  return (
    <Image
      source={require('../../../../assets/image/v5/loading.gif')}
      style={{ width: diameter, height: diameter }}
    />
  );
};

export default function LoadingBar(props) {
  const { progress } = props;
  const { OS } = Platform;
  const diameter = window.width / 8;
  return (
    <View style={styles.rootView}>
      {OS === 'ios' ? (
        <BlurView style={styles.blurView} blurType="dark" blurAmount={2} />
      ) : (
        <TouchableOpacity onPress={() => {}} style={styles.blurViewAndroid}>
          <ProgressBarAndroid color={washswatColor.transparent} />
        </TouchableOpacity>
      )}
      <LoadingImage />
    </View>
  );
}

const styles = StyleSheet.create({
  rootView: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    start: 0,
    top: 0,
    end: 0,
    bottom: 0,
    zIndex: 100,
    elevation: 100,
  },
  blurView: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
  blurViewAndroid: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    start: 0,
    top: 0,
    end: 0,
    bottom: 0,
    zIndex: 100,
    elevation: 100,
    backgroundColor: washswatColor.black,
    opacity: 0.5,
  },
});
