import React from 'react';

import {
  View,
  Text,
  PixelRatio,
  StyleSheet,
  TouchableOpacity,
  Platform,
} from 'react-native';
import { BlurView } from '@react-native-community/blur';

import { Font } from '../../../utils/style';

const { responseFont, washswatColor } = Font;

/**
 * 공통 팝업
 * option: subtitle, positiveText과 onPressPositiveButton
 */
export default function CommonPopup(props) {
  const {
    title,
    subtitleIsOption,
    negativeText,
    onPressNegativeButton,
    positiveTextIsOption,
    onPressPositiveButtonIsOption,
  } = props;
  // subtitle 유무
  let isShowSubtitle = false;
  if (
    subtitleIsOption !== undefined &&
    subtitleIsOption.length > 0 &&
    typeof subtitleIsOption === 'string'
  ) {
    isShowSubtitle = true;
  }
  // positive 버튼 유무
  let isShowPositiveButton = false;
  if (
    positiveTextIsOption !== undefined &&
    positiveTextIsOption.length > 0 &&
    typeof positiveTextIsOption === 'string'
  ) {
    isShowPositiveButton = true;
  }
  const content = (
    <View style={styles.popupView}>
      <View style={styles.textView}>
        <Text
          style={[
            responseFont(14).bold,
            {
              color: washswatColor.black,
              lineHeight: PixelRatio.roundToNearestPixel(21),
              textAlign: 'center',
            },
          ]}
        >
          {title}
        </Text>
        {isShowSubtitle && (
          <Text
            style={[
              responseFont(12).regular,
              {
                color: washswatColor.grey_02,
                lineHeight: PixelRatio.roundToNearestPixel(18),
                textAlign: 'center',
                marginTop: PixelRatio.roundToNearestPixel(18),
              },
            ]}
          >
            {subtitleIsOption}
          </Text>
        )}
      </View>
      {/* 버튼 영역 */}
      <View style={styles.buttonView}>
        <TouchableOpacity
          style={{
            flex: 1,
            backgroundColor: isShowPositiveButton
              ? washswatColor.white
              : washswatColor.black,
            justifyContent: 'center',
            alignItems: 'center',
          }}
          onPress={onPressNegativeButton}
        >
          <Text
            style={[
              responseFont(14).bold,
              isShowPositiveButton
                ? { color: washswatColor.black }
                : { color: washswatColor.white },
            ]}
          >
            {negativeText}
          </Text>
        </TouchableOpacity>
        {isShowPositiveButton && (
          <TouchableOpacity
            style={{
              flex: 1,
              backgroundColor: washswatColor.black,
              justifyContent: 'center',
              alignItems: 'center',
            }}
            onPress={onPressPositiveButtonIsOption}
          >
            <Text
              style={[responseFont(14).bold, { color: washswatColor.white }]}
            >
              {positiveTextIsOption}
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
  const { OS } = Platform;
  if (OS === 'android') {
    return <View style={styles.rootView}>{content}</View>;
  } else {
    return (
      <BlurView style={styles.rootView} blurType={'xlight'} blurAmount={5}>
        {content}
      </BlurView>
    );
  }
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    start: 0,
    top: 0,
    end: 0,
    bottom: 0,
    zIndex: 10000,
    backgroundColor: 'transparent',
  },
  popupView: {
    width: PixelRatio.roundToNearestPixel(306),
    borderColor: washswatColor.black,
    borderWidth: PixelRatio.roundToNearestPixel(1),
    backgroundColor: washswatColor.white,
    shadowColor: washswatColor.black,
    shadowOffset: {
      width: PixelRatio.roundToNearestPixel(0),
      height: PixelRatio.roundToNearestPixel(30),
    },
    shadowOpacity: 0.16,
    shadowRadius: PixelRatio.roundToNearestPixel(30),
  },
  textView: {
    paddingStart: PixelRatio.roundToNearestPixel(24),
    paddingTop: PixelRatio.roundToNearestPixel(42),
    paddingEnd: PixelRatio.roundToNearestPixel(24),
    paddingBottom: PixelRatio.roundToNearestPixel(30),
  },
  buttonView: {
    flexDirection: 'row',
    height: PixelRatio.roundToNearestPixel(55),
    borderTopWidth: PixelRatio.roundToNearestPixel(1),
    borderTopColor: washswatColor.black,
  },
});
