import React from 'react';

import { TouchableOpacity, PixelRatio, Text } from 'react-native';

import { Font } from '../../../utils/style';

const { responseFont } = Font;

export default function NBTextButton(props) {
  const { onPress, text, textColor, isHide, disabled } = props;
  if (isHide) {
    return;
  }
  return (
    <TouchableOpacity
      style={{
        height: PixelRatio.roundToNearestPixel(60),
        paddingStart: PixelRatio.roundToNearestPixel(18),
        paddingEnd: PixelRatio.roundToNearestPixel(18),
        justifyContent: 'center',
      }}
      onPress={onPress}
      activeOpacity={1}
      disabled={disabled}
    >
      <Text style={[responseFont(16).bold, { color: textColor }]}>{text}</Text>
    </TouchableOpacity>
  );
}
