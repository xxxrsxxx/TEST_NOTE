import React from 'react';
import {
  StatusBar,
  TouchableOpacity,
  StyleSheet,
  Text,
  Image,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
// style import
import { Font, Styles } from '../../../utils/style';
const { responseFont } = Font;
const { STATUSBAR_HEIGHT, GET_STATUSBAR_HEIGHT } = Styles;

const BasicHeader = props => {
  const { componentId, onPress, customStyle, title, inSafeAreaView } = props;

  const onPressBack = e => {
    Navigation.pop(componentId);
  };
  const templateA = () => {
    const statusBar = () => {
      let result = null;
      if (typeof inSafeAreaView === 'undefined' || !inSafeAreaView)
        result = <View style={styles.statusBar} />;
      return result;
    };

    return (
      <View style={{ ...customStyle }}>
        {statusBar()}
        <View
          style={
            customStyle
              ? { ...styles.containerA, ...customStyle }
              : styles.containerA
          }
        >
          <TouchableOpacity
            style={styles.backButton}
            onPress={componentId ? onPressBack : onPress}
          >
            <Image
              width={15}
              height={12}
              style={{ alignItems: 'center', justifyContent: 'center' }}
              source={require('../../../../assets/image/common/back_arrow.png')}
            />
          </TouchableOpacity>
          <View style={styles.titleWrap}>
            <Text style={styles.title}>{title}</Text>
          </View>
        </View>
      </View>
    );
  };
  const templateB = () => {
    return (
      <TouchableOpacity
        onPress={componentId ? onPressBack : onPress}
        style={
          customStyle
            ? { ...styles.containerB, ...customStyle }
            : styles.containerB
        }
      >
        <Image
          source={require('../../../../assets/image/common/back_arrow.png')}
          style={styles.back}
        />
      </TouchableOpacity>
    );
  };
  return <>{title ? templateA() : templateB()}</>;
};

const backButtonPadding = 6;
const styles = StyleSheet.create({
  statusBar: {
    height: STATUSBAR_HEIGHT,
  },
  containerA: {
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    height: 44,
    backgroundColor: '#fff',
  },
  titleWrap: {
    display: 'flex',
    alignItems: 'center',
  },
  title: { ...responseFont(16).bold },
  backButton: {
    display: 'flex',
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    paddingHorizontal: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  containerB: {
    position: 'absolute',
    paddingLeft: 18,
    paddingTop: GET_STATUSBAR_HEIGHT,
    zIndex: 20,
    paddingBottom: 12,
    paddingRight: backButtonPadding * 2,
  },
  back: {
    width: 11.68,
    height: 20.46,
  },
});
export default BasicHeader;
