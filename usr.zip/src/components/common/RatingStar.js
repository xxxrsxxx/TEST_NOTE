import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import PropTypes from 'prop-types';

const ratingStarPath = require('../../../assets/image/common/rating-star/rating_star.png');
const ratingBlankStarPath = require('../../../assets/image/common/rating-star-blank/rating_star_blank.png');

function RatingStar({ type, review, rating, starsize, style, ...props }) {
  const drawStar = (path, index) => {
    let key = `${type}_${index}_${
      review && review._id ? review._id : new Date().getTime()
    }`;
    return (
      <View key={key} style={{ width: starsize, height: starsize }}>
        <Image style={styles.starImg} source={path} />
      </View>
    );
  };

  const drawStars = () => {
    const starList = [];
    for (let i = 0; i < 5; i++) {
      if (i < rating) starList.push(drawStar(ratingStarPath, i));
      else starList.push(drawStar(ratingBlankStarPath, i));
    }
    return starList;
  };

  return <View style={[styles.container, style]}>{drawStars()}</View>;
}

RatingStar.defaultProps = {
  rating: 5,
  starsize: 12,
};

RatingStar.propTypes = {
  rating: PropTypes.number,
  starsize: PropTypes.number,
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  starImg: {
    height: '100%',
    width: '100%',
    resizeMode: 'contain',
  },
});

export default RatingStar;
