import React from 'react';
import { View, StyleSheet } from 'react-native';

import { Font } from '../../../utils/style';

const { washswatColor } = Font;

const GrayBox = ({ children, padding, mgBottom }) => {
  return (
    <View
      style={[
        styles.grayBox,
        {
          padding: padding ? padding : 0,
          marginBottom: mgBottom ? mgBottom : 12,
        },
      ]}
    >
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  grayBox: {
    backgroundColor: washswatColor.grey_07,
    borderRadius: 8,
    paddingLeft: 32,
    paddingRight: 32,
    width: '100%',
  },
});

export default GrayBox;
