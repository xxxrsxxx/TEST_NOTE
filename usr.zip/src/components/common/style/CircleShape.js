import React from 'react';
import { StyleSheet, View } from 'react-native';
import PropTypes from 'prop-types';

function CircleShape({
  length,
  backgroundColor,
  borderColor,
  borderWidth,
  style,
}) {
  return (
    <View
      style={[
        styles.container,
        {
          width: length,
          height: length,
        },
        style,
      ]}
    >
      <View
        style={[
          styles.circle,
          {
            backgroundColor,
            borderColor,
            borderWidth,
            borderRadius: length / 2,
          },
        ]}
      ></View>
    </View>
  );
}

CircleShape.defaultProps = {
  length: 100,
  backgroundColor: '#777777',
  borderColor: '#000000',
  borderWidth: 0,
  style: {},
};

CircleShape.propTypes = {
  length: PropTypes.number,
  backgroundColor: PropTypes.string,
  borderColor: PropTypes.string,
  borderWidth: PropTypes.number,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  circle: {
    width: '100%',
    height: '100%',
  },
});

export default CircleShape;
