import React from 'react';
import { StyleSheet, View } from 'react-native';

function OutlineBox({
  children,
  width,
  height,
  backgroundColor,
  borderColor,
  borderWidth,
  borderRadius,
  style,
}) {
  return (
    <View
      style={[
        styles.container,
        {
          width: width + borderWidth * 2,
          height: height + borderWidth * 2,
          backgroundColor: borderColor,
          borderRadius: borderRadius + borderWidth,
        },
      ]}
    >
      <View
        style={[
          styles.container,
          {
            width,
            height,
            backgroundColor,
            borderRadius,
          },
          style,
        ]}
      >
        {children}
      </View>
    </View>
  );
}

OutlineBox.defaultProps = {
  children: null,
  width: 100,
  height: 100,
  backgroundColor: '#FFFFFF',
  borderColor: '#000000',
  borderWidth: 2,
  borderRadius: 10,
  style: {},
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default OutlineBox;
