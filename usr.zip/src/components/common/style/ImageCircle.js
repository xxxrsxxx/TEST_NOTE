import React from 'react';
import { Image } from 'react-native';

export const ImageCircle = props => {
  const { diameter, source } = props;
  return (
    <Image
      source={source}
      style={{ width: diameter, height: diameter, borderRadius: diameter / 2 }}
    />
  );
};
