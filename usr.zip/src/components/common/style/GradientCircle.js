import React from 'react';
import LinearGradient from 'react-native-linear-gradient';

export const GradientCircle = (props) => {
  const { diameter, colors } = props;
  return (
    <LinearGradient
      colors={colors}
      style={{ width: diameter, height: diameter, borderRadius: diameter / 2 }}
      start={{x: 0, y: 0}} 
      end={{x: 1, y: 1}}
      >
    </LinearGradient>
  );
};
