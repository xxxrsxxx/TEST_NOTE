import React from 'react';
import { Image, StyleSheet, TouchableOpacity, View } from 'react-native';

const markerImage = require('../../../../assets/image/Order/Ordering/Camera/mark.png');
const deleteImage = require('../../../../assets/image/Order/Ordering/Camera/delete.png');

export default function Marker({
  location,
  isStatusDelete,
  onPressMarker,
  onPressDeleteMarker,
}) {
  const markerLocationStyle = {
    left: location.x,
    top: location.y,
  };

  return (
    <View style={[styles.imageView, markerLocationStyle]}>
      <TouchableOpacity activeOpacity={1} onPress={onPressDeleteMarker}>
        <Image source={markerImage} />
        {/**isStatusDelete && (
          <TouchableOpacity onPress={onPressDeleteMarker}>
            <Image style={styles.delete} source={deleteImage} />
          </TouchableOpacity>
        ) **/}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  imageView: {
    position: 'absolute',
    width: 35,
    height: 40,
  },
  delete: {
    left: 10,
    bottom: 15,
  },
});
