import React from 'react';
import { SvgXml } from 'react-native-svg';

const xml = `
    <svg xmlns="http://www.w3.org/2000/svg" width="44" height="56" viewBox="0 0 44 56">
        <defs>
            <style>
                .cls-1 {
                fill: #fff;
                font-size: 43px;
                font-family: AppleColorEmoji, Apple Color Emoji;
                }
            </style>
        </defs>
        <text id="_" data-name="🧾" class="cls-1" transform="translate(22 43)"><tspan x="-21.5" y="0">🧾</tspan></text>
    </svg>

`;

export default () => <SvgXml xml={xml} width="100%" height="100%" />;