import React from 'react';
import { FlatList, TouchableOpacity, Image, View, StyleSheet } from 'react-native';
import ShimmerPlaceHolder from 'react-native-shimmer-placeholder';

import * as CommonUtils from '../../utils/common/index';

const styles = StyleSheet.create({
  washRequireImage:
    {
      width: 72,
      height: 72,
      marginTop: 8,
      marginHorizontal: 4,
      borderRadius: 10,
    },
});

const OrderHistoryDetailImageComponent = (props) => {

  const { careOptions, orderItem, componentId } = props;
  let renderImages = [];

  if(careOptions && careOptions.length > 0) {
    careOptions.forEach(
      option => {
        if(option && option.images && option.images.length > 0) {
          option.images.forEach(
            (image) => renderImages.push(image)
          )
        }
      }
    )
  }

  const ImageView = ({ source }) => {
    return (
      <>
        {
          source ?
            <Image
              source={{ uri: source }}
              style={styles.washRequireImage}
            />
            :
            <ShimmerPlaceHolder
              autoRun={true}
              style={styles.washRequireImage}
            />
        }
      </>
    );
  };

  const onPressItem = (url) => () => {
    if (!url || !orderItem || !componentId) {
      return;
    }
    CommonUtils.navPush({
      componentId,
      name: 'AlbumScreen',
      passProps: {
        orderItem: orderItem ? orderItem : null,
        url,
      },
    });
  };

  return (
    <FlatList
      data={renderImages}
      renderItem={({ item: source, index }) => (
        <TouchableOpacity key={`album-${index}`} onPress={onPressItem(source)}>
          <ImageView source={source} />
        </TouchableOpacity>
      )}
      keyExtractor={source => source}
      horizontal={true}
      showsHorizontalScrollIndicator={false}
    />
  )
};

export default OrderHistoryDetailImageComponent;
