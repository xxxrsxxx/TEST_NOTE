import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet, PixelRatio, Platform } from 'react-native';

import { OrderHistoryDetailString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor } = Font

const OrderHistoryButtons = ({
  componentId,
  orderItem,
  onModalToggle,
  goToSetPickupTime,
  goToSetDeliveryTime,
  pressPay,
  finalPrice,
  setCardChecked,
  setPayPending,
  setComponentId,
  isPayPending,
}) => {
  // const exam = useRef(null);

  // const onClick = () => {
  //   if(Platform.OS === 'android') exam.current.style.elevation = 0
  // }

  return (
    <View
      style={
        Platform.OS === 'ios'
        ? {
            height: 92,
            backgroundColor: washswatColor.white,
            // shadowColor: '#000000',
            shadowOffset: {
              width: PixelRatio.roundToNearestPixel(0),
              height: PixelRatio.roundToNearestPixel(-5)
            },
            shadowOpacity: 0.1,
            shadowRadius: 3,
          }
        : {
            height: 92,
            backgroundColor: washswatColor.white,
            // elevation: 10,
            shadowOffset: {
              width: PixelRatio.roundToNearestPixel(0),
              height: PixelRatio.roundToNearestPixel(-5)
            },
            shadowOpacity: 0.3,
            shadowRadius: 3,
          }
      }>
      <View style={{
        marginHorizontal: 16,
        marginVertical: 12,
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        // backgroundColor: washswatColor.white,
      }}>
        {
          orderItem.pickup && orderItem.pickup.payType !== 'later'
          ? (
              <TouchableOpacity disabled={true} style={[ styles.ButtonContainer, { flex: 1, borderColor: '#eaeaea' }]}>
                <Text style={{ color: '#969696' }}>{ OrderHistoryDetailString.paymentComplete }</Text>
              </TouchableOpacity>
            )
          : (
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity
                  style={[ styles.ButtonContainer, { borderColor: '#eaeaea' }]}
                  onPress={(componentId) => orderItem?.status === 'pickup' ? goToSetPickupTime(componentId) : goToSetDeliveryTime(componentId)}
                >
                  <Text>{ OrderHistoryDetailString.scheduleChange }</Text>
                </TouchableOpacity>
                {
                  // 검수중 단계일때는 결제하기 버튼 비활성화
                  // 그리고 totalPrice가 0원일때는 결제하기 버튼 비활성화
                  (orderItem.status && (orderItem.status === 'pickup' || orderItem.status === 'wait'))
                  || (orderItem.pickup && orderItem.pickup.totalPrice === 0)
                  ? (
                      <TouchableOpacity disabled={true} onPress={() => onModalToggle(true)} style={[ styles.ButtonContainer, { borderColor: '#eaeaea' }]}>
                        <Text style={{ color: '#969696' }}>{ OrderHistoryDetailString.makePayment }</Text>
                      </TouchableOpacity>
                    )
                  : (
                      <TouchableOpacity
                        onPress={() => {
                          if (finalPrice === 0) {
                            setCardChecked('bill');
                            setPayPending(true);
                            setComponentId(componentId);
                            pressPay();
                          } else {
                            onModalToggle(true)
                          }
                        }}
                        disabled={isPayPending}
                        style={[ styles.ButtonContainer, { borderColor: '#2d4aff' }]}
                      >
                        <Text style={{ color: '#2d4aff' }}>{ OrderHistoryDetailString.makePayment }</Text>
                      </TouchableOpacity>
                    )
                }
              </View>
            )
          }
      </View>
    </View>
  )
};

const styles = StyleSheet.create({
  ButtonContainer: {
    width: 160,
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 8,
    marginHorizontal: 4,
    borderRadius: 16,
    borderWidth: 1,
    backgroundColor: washswatColor.white,
  }
})

export default OrderHistoryButtons;
