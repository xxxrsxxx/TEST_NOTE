import React from 'react';
import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';

import ArrowButton from '../common/button/ArrowButton';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

const OrderHistoryDetailComponent = ({ orderId, isCollapsed, onToggle }) => {
  return (
    <View style={styles.root}>
      <TouchableOpacity
        onPress={() => onToggle()}
        activeOpacity={isCollapsed !== undefined ? 0.2 : 1}
      >
        <View style={styles.titleView}>
          <Text style={styles.title}>🗂{orderId}</Text>
          <ArrowButton isCollapsed={isCollapsed} />
        </View>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    borderRadius: 30,
  },
  titleView: {
    flexDirection: 'row',
    height: 80,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 24,
    paddingRight: 26,
    marginBottom: 8,
  },
  title: {
    ...responseFont(16).bold,
    color: washswatColor.black,
  },
});

export default OrderHistoryDetailComponent;
