import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { OrderHistoryProgressText } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const styles = StyleSheet.create({
  orderDetail: {
    width: 80,
    height: 32,
    backgroundColor: washswatColor.blueOpacity_01,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  divideLine: {
    height: 1,
    backgroundColor: washswatColor.grey_12,
  },
});

const OrderIdComponent = ({ orderId, onPress }) => {
  return (
    <View>
      <View
        style={{
          flexDirection: 'row',
          height: 80,
          alignItems: 'center',
          justifyContent: 'space-between',
          paddingLeft: 24,
          paddingRight: 24,
        }}
      >
        <Text style={{ ...responseFont(16).bold, color: washswatColor.black }}>
          {orderId}
        </Text>
        <TouchableOpacity onPress={onPress} style={styles.orderDetail}>
          <Text
            style={{
              ...responseFont(14).regular,
              color: washswatColor.blue_01,
            }}
          >
            {OrderHistoryProgressText.orderDetail}
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.divideLine} />
    </View>
  );
};

export default OrderIdComponent;
