import React from 'react';
import { TouchableOpacity, View, Text } from 'react-native';

import { OrderHistoryDetailString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

const OrderHistoryModalBottomButtons = ({
  available,
  pressPay,
  componentId,
  setComponentId,
  onModalToggle,
  selectedPaymentType,
  isPayPending,
  setPayPending,
}) => (
  <View
    style={{
      height: 56,
      flexDirection: 'row',
      marginVertical: 24,
      marginHorizontal: 20,
    }}
  >
    <TouchableOpacity
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderRadius: 16,
        borderColor: '#eaeaea',
        marginHorizontal: 4,
      }}
      onPress={() => onModalToggle(false)}
    >
      <Text style={[responseFont(14).regular]}>
        {OrderHistoryDetailString.closeModal}
      </Text>
    </TouchableOpacity>
    {selectedPaymentType && (
      <TouchableOpacity
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: 16,
          marginHorizontal: 4,
          backgroundColor: '#2d4aff',
        }}
        onPress={() => {
          setPayPending(true);
          setComponentId(componentId);
          pressPay();
        }}
        disabled={isPayPending}
      >
        <Text
          style={[responseFont(14).regular, { color: washswatColor.white }]}
        >
          {selectedPaymentType === 'regist'
            ? OrderHistoryDetailString.registCard
            : !(available && available.availableCoin) &&
              selectedPaymentType === 'coin'
            ? OrderHistoryDetailString.chargeBullet
            : OrderHistoryDetailString.makePayment}
        </Text>
      </TouchableOpacity>
    )}
  </View>
);

export default OrderHistoryModalBottomButtons;
