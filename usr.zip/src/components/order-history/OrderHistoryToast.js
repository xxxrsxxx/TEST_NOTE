import React, { useEffect, useRef } from 'react';
import {
  Animated,
  Easing,
  StyleSheet,
  View,
  Text,
  Image,
  TouchableOpacity,
  Dimensions,
} from 'react-native';

import { moment } from '../../plugins';
import { Font } from '../../utils/style';

moment.locale('ko');

const { responseFont, washswatColor } = Font;
const { height } = Dimensions.get('window');

const OrderHistoryToast = ({
  deliveryTime,
  userType,
  OrderHistoryDetailString,
  onToastToggle,
  content,
}) => {
  const getup = useRef(new Animated.Value(-1000)).current;

  useEffect(() => {
    Animated.timing(getup, {
      toValue: height / 18,
      easing: Easing.elastic(0.8),
      duration: 1500,
    }).start();

    setTimeout(() => {
      Animated.timing(getup, {
        toValue: -1000,
        easing: Easing.elastic(0.8),
        duration: 1500,
      }).start();
    }, 5000);
  }, []);

  return (
    <Animated.View
      style={{
        position: 'relative',
        flex: 1,
        bottom: getup,
        justifyContent: 'center',
      }}
    >
      <View
        style={{
          height: userType === 'normal' ? 76 : 56,
          alignItems: 'center',
        }}
      >
        <View
          style={[
            styles.ToastContainer,
            {
              borderRadius: userType === 'normal' ? 8 : 32,
              marginHorizontal: userType === 'normal' ? 24 : 28,
            },
          ]}
        >
          <Text
            style={[
              responseFont(14).regular,
              { color: washswatColor.white, marginRight: 15 },
            ]}
          >
            {content
              ? content
              : userType === 'normal'
              ? `${OrderHistoryDetailString.toastEmoji}${moment(
                  new Date(
                    new Date(deliveryTime).setHours(
                      new Date(deliveryTime).getHours() - 9,
                    ),
                  ),
                ).format(`M/D (ddd) A h`)}${
                  OrderHistoryDetailString.normalToast
                }`
              : OrderHistoryDetailString.membershipToast}
          </Text>
          <TouchableOpacity onPress={() => onToastToggle()}>
            <Image
              source={require('../../../assets/image/v5/icons_8_cancel.png')}
              style={{ width: 9.4, height: 9.4 }}
            />
          </TouchableOpacity>
        </View>
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  ToastContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    backgroundColor: '#000000CC',
  },
});

export default OrderHistoryToast;
