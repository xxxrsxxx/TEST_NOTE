import React from 'react';
import { View, Text } from 'react-native';

import { OrderHistoryDetailString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

const OrderHistoryNavbar = () => (
  <View
    style={{
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      borderBottomColor: washswatColor.grey_12,
      borderBottomWidth: 1,
    }}
  >
    <Text style={[responseFont(16).bold, { marginVertical: 14 }]}>
      {OrderHistoryDetailString.orderDetail}
    </Text>
  </View>
);

export default OrderHistoryNavbar;
