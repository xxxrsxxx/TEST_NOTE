import React from 'react';
import { TouchableOpacity, View, Text } from 'react-native';

import { OrderHistoryDetailString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont } = Font;

const OrderHistoryMembershipComponent = ({ joinMembership, componentId }) => {
  return (
    <View style={{ marginVertical: 40, marginLeft: 24, marginRight: 62 }}>
      <Text style={responseFont(18).bold}>
        {OrderHistoryDetailString.membershipMeritTitle}
      </Text>
      <Text
        style={[responseFont(14).regular, { marginTop: 16, marginBottom: 32 }]}
      >
        {OrderHistoryDetailString.membershipMerit}
      </Text>
      <TouchableOpacity onPress={() => joinMembership(componentId)}>
        <Text style={[responseFont(16).regular, { color: '#2d4aff' }]}>
          {OrderHistoryDetailString.joinMembership}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default OrderHistoryMembershipComponent;
