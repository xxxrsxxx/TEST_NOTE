import React, { useState } from 'react';
import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';
import Collapsible from 'react-native-collapsible';

import ArrowButton from '../common/button/ArrowButton';

import * as CommonUtils from '../../utils/common/index';
import { OrderHistoryDetailString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { responseFont, washswatColor } = Font;

const OrderHistoryTotalPaymentComponent = ({
  orderItem,
  available,
  setReceipt,
  componentId,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const renderDetail =
    showReceiptView(orderItem) &&
    orderItem.payment.history.map(
      (detail, i) =>
        // payType이 있고, later가 아니거나 refundType이 존재하는 경우 Collapse에 나타남.
        detail &&
        ((detail.payType && detail.payType !== 'later') ||
          detail.refundType) && (
          <View
            key={`payment_${i}`}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginVertical: 12,
            }}
          >
            <Text
              style={[
                responseFont(14).regular,
                { color: washswatColor.grey_13, flex: 1 },
              ]}
            >
              {detail.payType
                ? OrderHistoryDetailString.payType[detail.payType]
                : `${OrderHistoryDetailString.payType[detail.refundType]} ${
                    OrderHistoryDetailString.refund
                  }`}
            </Text>
            <View style={{ flexDirection: 'row' }}>
              <Text
                style={[
                  responseFont(14).bold,
                  { color: washswatColor.grey_13, marginRight: 14 },
                ]}
              >
                {`${detail.payType ? '' : '- '}${CommonUtils.numberWithCommas(
                  detail.price,
                )}${OrderHistoryDetailString.won}`}
              </Text>

              {['bill', 'card', 'account', 'naverpay'].indexOf(
                detail.payType || detail.refundType,
              ) > -1 && (
                <TouchableOpacity
                  style={{
                    borderRadius: 5,
                    height: 18,
                    paddingLeft: 5,
                    paddingRight: 5,
                    backgroundColor: washswatColor.blueOpacity_01,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    const {
                      tId,
                      payType,
                      price,
                      regdate,
                      refundType,
                      type,
                    } = detail;
                    const data = {
                      tId,
                      payType,
                      price,
                      regdate,
                      refundType,
                      type,
                    };
                    setReceipt(data, componentId);
                  }}
                >
                  <Text
                    style={[
                      responseFont(11).bold,
                      { color: washswatColor.blue_01 },
                    ]}
                  >
                    {OrderHistoryDetailString.receipt}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        ),
    );

  const renderRefundPrice = () => {
    const alert = orderItem?.alert;
    if (!alert || alert.length === 0) {
      return null;
    }
    return alert.map((object, index) => {
      const { button } = object;
      if (!button) {
        return null;
      }
      const { action, needRefundPrice } = button;
      if (!action || !needRefundPrice) {
        return null;
      }
      if (action === 'refund' && needRefundPrice > 0) {
        return (
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginVertical: 12,
            }}
          >
            <Text
              style={[
                responseFont(14).regular,
                { color: washswatColor.grey_13 },
              ]}
            >
              {OrderHistoryDetailString.refundExpectPrice}
            </Text>
            <Text
              style={[responseFont(14).bold, { color: washswatColor.grey_13 }]}
            >
              {`${CommonUtils.numberWithCommas(needRefundPrice)}${
                OrderHistoryDetailString.won
              }`}
            </Text>
          </View>
        );
      }
      return null;
    });
  };

  const renderDebts =
    available &&
    available.outstandingDebts &&
    available.outstandingDebts.length > 0 &&
    available.outstandingDebts.map((debt, i) => (
      <View key={`${debt.name}-${i}`} style={styles.paymentCardContainer}>
        <Text style={styles.paymentCardTitle}>{debt.name}</Text>
        <Text
          style={styles.paymentCardContent}
        >{`${CommonUtils.numberWithCommas(debt.price ? debt.price : 0)}${
          OrderHistoryDetailString.won
        }`}</Text>
      </View>
    ));

  return (
    <View>
      {/* { orderItem.status === 'ing' && renderDebts } */}
      <TouchableOpacity
        onPress={() => setIsCollapsed(!isCollapsed)}
        activeOpacity={isCollapsed !== undefined ? 0.2 : 1}
        disabled={
          !(
            orderItem &&
            orderItem.payment &&
            orderItem.payment.history &&
            orderItem.payment.history.length > 1
          )
        }
      >
        <View
          style={{
            marginVertical: 16,
            flex: 1,
            flexDirection: 'row',
            alignItems: 'center',
          }}
        >
          <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
            <View
              style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}
            >
              <Text style={[styles.paymentContent, { marginRight: 12 }]}>
                {OrderHistoryDetailString.totalPayment}
              </Text>
            </View>
            {(orderItem && orderItem.status === 'pickup') ||
            orderItem.status === 'wait' ? (
              <Text style={styles.paymentCardContentAccounting}>
                {OrderHistoryDetailString.accounting}
              </Text>
            ) : (
              <Text style={responseFont(18).bold}>{`${available &&
                available.order &&
                CommonUtils.numberWithCommas(available.order.finalPrice)}${
                OrderHistoryDetailString.won
              }`}</Text>
            )}
          </View>
          {showReceiptView(orderItem) && (
            <ArrowButton isCollapsed={isCollapsed} />
          )}
        </View>
      </TouchableOpacity>
      {showReceiptView(orderItem) && (
        <Collapsible collapsed={isCollapsed}>
          <View
            style={{
              backgroundColor: washswatColor.grey_07,
              marginVertical: 16,
              paddingLeft: 24,
              paddingRight: 24,
              paddingTop: 12,
              paddingBottom: 12,
              borderRadius: 10,
            }}
          >
            {renderDetail}
            {renderRefundPrice()}
          </View>
        </Collapsible>
      )}
    </View>
  );
};

const showReceiptView = order => {
  if (order && order.payment && order.payment.history) {
    const row = _.find(order.payment.history || [], o => {
      const { match } = o;
      if (
        match &&
        match.company &&
        ['coin', 'point', 'washswat'].indexOf(match.company) === -1
      ) {
        return true;
      }
    });
    if (row) {
      return true;
    }
  }
  return false;
  // const _.find
};

const styles = StyleSheet.create({
  saveChip: {
    borderRadius: 5,
    backgroundColor: washswatColor.orangeOpacity16,
    width: 82,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  paymentCardContainer: {
    marginVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  paymentCardTitle: {
    ...responseFont(14).regular,
  },
  paymentCardContent: {
    ...responseFont(14).bold,
  },
  paymentTitle: {
    ...responseFont(14).regular,
  },
  paymentContent: {
    ...responseFont(14).bold,
  },
  paymentCardContentAccounting: {
    ...responseFont(14).bold,
    color: '#969696',
  },
});

export default OrderHistoryTotalPaymentComponent;
