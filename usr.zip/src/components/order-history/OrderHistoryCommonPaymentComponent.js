import React, { useState } from 'react';

import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';
import Collapsible from 'react-native-collapsible';

import ArrowButton from '../common/button/ArrowButton';

import * as CommonUtils from '../../utils/common/index';
import { OrderHistoryDetailString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

const OrderHistoryCommonPaymentComponent = ({ orderItem }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const filteredList =
    orderItem && orderItem.pickup && orderItem.pickup.item
      ? orderItem.pickup.item.filter(
          content => content.info && content.info.length > 1,
        )
      : null;

  // 추가요금 collapse
  // price가 안들어오는 것도 있음 (ex. complain )
  const renderDetails =
    filteredList &&
    filteredList.length > 0 &&
    filteredList.map((item, i) => (
      <View key={`${item.name}-${i}`} style={{ marginVertical: 8 }}>
        <Text
          style={[responseFont(14).regular, { color: washswatColor.grey_13 }]}
        >
          [{item.barcodeId[0]}] {item.name}
        </Text>
        {item.info
          .filter(content => content.type !== 'view')
          .map((listItem, i) => (
            <Text
              key={`${listItem.title}-${i}`}
              style={[
                responseFont(14).regular,
                { color: washswatColor.grey_13 },
              ]}
            >
              {OrderHistoryDetailString.addedPayment}: {listItem.title} (+
              {CommonUtils.numberWithCommas(
                listItem.price ? listItem.price : 0,
              )}
              {OrderHistoryDetailString.won})
            </Text>
          ))}
      </View>
    ));

  return (
    <View>
      <View style={styles.paymentCardContainer}>
        <Text style={styles.paymentCardTitle}>
          {OrderHistoryDetailString.washPayment}
        </Text>
        {(orderItem && orderItem.status === 'pickup') ||
        orderItem.status === 'wait' ? (
          <Text style={styles.paymentCardContentAccounting}>
            {OrderHistoryDetailString.accounting}
          </Text>
        ) : (
          <Text
            style={styles.paymentCardContent}
          >{`${CommonUtils.numberWithCommas(
            orderItem.pickup.details
              ? orderItem.pickup.details.sumOfItemPrice
              : 0,
          )}${OrderHistoryDetailString.won}`}</Text>
        )}
      </View>

      {/* status가 ing일때만 추가요금 탭이 보이도록 */}
      {orderItem &&
        orderItem.status !== 'pickup' &&
        orderItem.status !== 'wait' && (
          <View>
            <TouchableOpacity
              disabled={
                !(renderDetails && renderDetails.length > 0) ? true : false
              }
              onPress={() => setIsCollapsed(!isCollapsed)}
              activeOpacity={isCollapsed !== undefined ? 0.2 : 1}
            >
              <View
                style={{
                  marginVertical: 16,
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                }}
              >
                <View
                  style={{
                    flex: 1,
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                >
                  <View style={{ flex: 1, flexDirection: 'row' }}>
                    <Text style={styles.paymentTitle}>
                      {OrderHistoryDetailString.addedPayment}
                    </Text>
                  </View>
                </View>
                <Text style={styles.paymentContent}>
                  {CommonUtils.numberWithCommas(
                    orderItem.pickup.details
                      ? orderItem.pickup.details.itemExtra
                      : 0,
                  )}
                  {OrderHistoryDetailString.won}
                </Text>
                {renderDetails && renderDetails.length > 0 && (
                  <ArrowButton isCollapsed={isCollapsed} />
                )}
              </View>
            </TouchableOpacity>

            {renderDetails && renderDetails.length > 0 && (
              <Collapsible collapsed={isCollapsed}>
                <View
                  style={{
                    backgroundColor: washswatColor.grey_07,
                    marginVertical: 16,
                    padding: 16,
                    borderRadius: 10,
                  }}
                >
                  {renderDetails}
                </View>
              </Collapsible>
            )}
          </View>
        )}
      {/* 배송비 있으면 추가금액 아래에 배송요금 하나 나타나도록 */}
      {orderItem &&
        orderItem.pickup &&
        orderItem.pickup.details &&
        orderItem.pickup.details.deliveryFee > 0 && (
          <View style={styles.paymentCardContainer}>
            <Text style={styles.paymentCardTitle}>
              {OrderHistoryDetailString.deliveryFee}
            </Text>
            <Text
              style={styles.paymentCardContent}
            >{`${CommonUtils.numberWithCommas(
              orderItem.pickup.details
                ? orderItem.pickup.details.deliveryFee
                : 0,
            )}${OrderHistoryDetailString.won}`}</Text>
          </View>
        )}
    </View>
  );
};

const styles = StyleSheet.create({
  paymentCardContainer: {
    marginVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  paymentCardTitle: {
    ...responseFont(14).regular,
  },
  paymentCardContent: {
    ...responseFont(14).bold,
  },
  paymentCardContentAccounting: {
    ...responseFont(14).bold,
    color: '#969696',
  },
  paymentTitle: {
    ...responseFont(14).regular,
  },
  paymentContent: {
    ...responseFont(14).bold,
  },
});

export default OrderHistoryCommonPaymentComponent;
