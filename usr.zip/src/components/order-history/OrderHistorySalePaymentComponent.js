import React from 'react';
import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';

import * as CommonUtils from '../../utils/common/index';
import { OrderHistoryDetailString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

const OrderHistorySalePaymentComponent = ({
  componentId,
  available,
  orderItem,
  userType,
  goToPreCouponMain,
  goToCouponMain,
  goToPointMain,
}) => {
  return (
    <View>
      {/* 총 주문금액 */}
      <View style={styles.paymentCardContainer}>
        <Text style={styles.paymentCardTitle}>
          {OrderHistoryDetailString.totalOrderPayment}
        </Text>
        {orderItem &&
        (orderItem.status === 'pickup' || orderItem.status === 'wait') ? (
          <Text style={styles.paymentCardContentAccounting}>
            {OrderHistoryDetailString.accounting}
          </Text>
        ) : (
          <Text style={styles.paymentCardContent}>
            {available &&
              available.order &&
              CommonUtils.numberWithCommas(
                available.order.totalPrice + (available.order.deliveryFee || 0),
              )}
            {OrderHistoryDetailString.won}
          </Text>
        )}
      </View>

      {/* 쿠폰 할인 */}
      <View style={styles.paymentOptionalCardContainer}>
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ flex: 1, flexDirection: 'row' }}>
            <Text style={styles.paymentContent}>
              {OrderHistoryDetailString.couponDiscount}
            </Text>
          </View>
          {available &&
          orderItem &&
          (orderItem.status === 'pickup' || orderItem.status === 'wait') ? (
            <Text style={responseFont(14).bold}>
              {/* pickup 및 wait에서 preOptions에 쿠폰이 들어가있을 경우, 쿠폰의 name을 보여줌 */}
              {orderItem.preOptions?.payment?.discount &&
                orderItem.preOptions.payment.discount.coupon &&
                orderItem.preOptions.payment.discount.coupon.length > 0 &&
                `${CommonUtils.numberWithCommas(
                  orderItem.preOptions.payment.discount.coupon[0].name,
                )}`}
            </Text>
          ) : (
            <Text style={responseFont(14).bold}>
              {orderItem.preOptions?.payment?.discount &&
              orderItem.preOptions.payment.discount.coupon &&
              orderItem.preOptions.payment.discount.coupon.length > 0 &&
              available &&
              available.order &&
              available.order.useCoupon === 0
                ? `${
                    orderItem.pickup.couponDiscount > 0 ? '-' : ''
                  } ${CommonUtils.numberWithCommas(
                    orderItem.pickup.couponDiscount > 0
                      ? orderItem.pickup.couponDiscount
                      : 0,
                  )}${OrderHistoryDetailString.won}`
                : available.order &&
                  `${
                    available.order.useCoupon > 0 ? '-' : ''
                  } ${CommonUtils.numberWithCommas(
                    available.order.useCoupon ? available.order.useCoupon : 0,
                  )}${OrderHistoryDetailString.won}`}
            </Text>
          )}
          {showCoupon({ orderItem }) ? (
            <TouchableOpacity
              style={{ marginLeft: 8 }}
              onPress={() => {
                orderItem.status === 'wait'
                  ? goToPreCouponMain(componentId, orderItem.status)
                  : goToCouponMain(componentId);
              }}
            >
              <View style={styles.changeButton}>
                <Text
                  style={[
                    responseFont(11).bold,
                    { color: washswatColor.blue_01 },
                  ]}
                >
                  {OrderHistoryDetailString.change}
                </Text>
              </View>
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      {/* 포인트 할인 */}
      {/* 얘랑 쿠폰할인은 동작에 대한 로직이 필요, container에서 보내주는게 좋을듯 */}
      <View style={styles.paymentOptionalCardContainer}>
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
            <Text style={[styles.paymentContent]}>
              {OrderHistoryDetailString.pointDiscount}
            </Text>
            {// status가 ing이면서 결제하기 전에만 나타나도록 설정
            available &&
              orderItem &&
              orderItem.pickup.payType === 'later' &&
              orderItem.status !== 'pickup' &&
              orderItem.status !== 'wait' && (
                <View style={styles.remainPointChip}>
                  <Text
                    style={[
                      responseFont(11).bold,
                      { color: washswatColor.orange },
                    ]}
                  >
                    {`${OrderHistoryDetailString.remain}: ${available.availablePoint}${OrderHistoryDetailString.won}`}
                  </Text>
                </View>
              )}
          </View>
          {/* 검수중 status에 따른 책정중인지 아닌지에 대한 조건문 */}
          {orderItem &&
          (orderItem.status === 'pickup' || orderItem.status === 'wait') ? (
            <Text style={[responseFont(14).bold, { color: '#969696' }]}>
              {OrderHistoryDetailString.canApplyAfterCheck}
            </Text>
          ) : (
            <View style={{ flexDirection: 'row' }}>
              <Text style={responseFont(14).bold}>
                {available &&
                  available.order &&
                  `${
                    available.order.usePoint > 0 ? '-' : ''
                  } ${CommonUtils.numberWithCommas(available.order.usePoint)}${
                    OrderHistoryDetailString.won
                  }`}
              </Text>
              {/* userPoint가 0일 경우에는 disabled로 변경하고 opacity 낮춤 */}
              {/* 여기서 중요한게 포인트를 적용시켜두었을때 가용 포인트(availablePoint)가 0일 경우에도 disabled될 수 있기때문에 현재 오더에 들어간 포인트(usePoint)도 없는지 같이 확인해주어야함. */}
              {/* 쿠폰 사용하고서 남은 결제금액이 0원일 때도 안보여야함 */}
              {orderItem.payment &&
                orderItem.pickup &&
                orderItem.pickup.payType === 'later' && (
                  <TouchableOpacity
                    disabled={
                      (available &&
                        available.order &&
                        available.order.usePoint === 0 &&
                        available.availablePoint === 0) ||
                      (orderItem.pickup && !(orderItem.pickup.finalPrice > 0))
                        ? true
                        : false
                    }
                    style={
                      (available &&
                        available.order &&
                        available.order.usePoint === 0 &&
                        available.availablePoint === 0) ||
                      (orderItem.pickup && !(orderItem.pickup.finalPrice > 0))
                        ? { marginLeft: 8, opacity: 0.4 }
                        : { marginLeft: 8 }
                    }
                    onPress={() => goToPointMain(componentId)}
                  >
                    <View style={styles.changeButton}>
                      <Text
                        style={[
                          responseFont(11).bold,
                          { color: washswatColor.blue_01 },
                        ]}
                      >
                        {OrderHistoryDetailString.change}
                      </Text>
                    </View>
                  </TouchableOpacity>
                )}
            </View>
          )}
        </View>
      </View>

      {/* 멤버십 할인 */}
      {userType === 'member' &&
        orderItem &&
        orderItem.pickup &&
        orderItem.pickup.finalPrice > 0 && (
          <View style={styles.paymentCardContainer}>
            <Text style={styles.paymentCardTitle}>
              {OrderHistoryDetailString.membershipDiscount}
            </Text>
            {(orderItem && orderItem.status === 'pickup') ||
            orderItem.status === 'wait' ? (
              <Text style={[responseFont(14).bold, { color: '#969696' }]}>
                {OrderHistoryDetailString.membershipDiscountDefault}
              </Text>
            ) : (
              <Text style={styles.paymentCardContent}>
                {orderItem.pickup &&
                orderItem.pickup.details &&
                orderItem.pickup.details.protegeDiscountForMember !== 0
                  ? `- ${orderItem.pickup.details.protegeDiscountForMember}${OrderHistoryDetailString.won}`
                  : `0${OrderHistoryDetailString.won}`}
              </Text>
            )}
          </View>
        )}
    </View>
  );
};

const styles = StyleSheet.create({
  paymentCardContainer: {
    marginVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  paymentCardTitle: {
    ...responseFont(14).regular,
  },
  paymentCardContent: {
    ...responseFont(14).bold,
  },
  paymentCardContentAccounting: {
    ...responseFont(14).bold,
    color: '#969696',
  },
  paymentOptionalCardContainer: {
    marginVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  remainPointChip: {
    marginLeft: 12,
    borderRadius: 5,
    backgroundColor: washswatColor.orangeOpacity16,
    width: 74,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  changeButton: {
    borderRadius: 5,
    height: 18,
    width: 40,
    backgroundColor: washswatColor.blueOpacity_01,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

const showCoupon = ({ orderItem }) => {
  if (!orderItem) {
    return false;
  }
  if (!orderItem.pickup) {
    /** 예를들어 status === pickup */
    return false;
  }

  if (orderItem.pickup.payType !== 'later') {
    return false;
  }

  if (orderItem.pickup && orderItem.pickup.couponDiscount > 0) {
    return false;
  }

  return true;
};

export default OrderHistorySalePaymentComponent;
