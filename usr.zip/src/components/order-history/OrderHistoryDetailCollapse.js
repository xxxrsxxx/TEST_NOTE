import React from 'react';
import { StyleSheet, View, Text } from 'react-native';

import { OrderHistoryDetailString } from '../../utils/common/strings';
import { moment } from '../../plugins';
import { Font } from '../../utils/style';

moment.locale('ko');

const { responseFont, washswatColor } = Font;

const OrderHistoryDetailCollapse = ({ OrderHistoryState }) => {
  const {
    orderItem: { userInfo, mission, preOptions },
  } = OrderHistoryState;

  const { address, addressOthers, doorCode } = userInfo;
  const { pickup, delivery } = mission;
  const { pickupTime } = pickup;
  const { deliveryTime } = delivery;

  return (
    <View>
      <Text style={styles.TextTitle}>{OrderHistoryDetailString.address}</Text>
      <View style={styles.TextContainer}>
        {/* 주소 */}
        <Text style={styles.TextContent}>
          {[
            `${address} ${addressOthers} (${OrderHistoryDetailString.frontDoor}: ${doorCode})`,
          ]}
        </Text>
      </View>
      <Text style={styles.TextTitle}>
        {OrderHistoryDetailString.pickupDate}
      </Text>
      <View style={styles.TextContainer}>
        {/* 수거일정 */}
        <Text style={styles.TextContent}>
          {new Date(pickupTime).getHours() < 7
            ? `${moment(new Date(pickupTime)).format(
                `YYYY년 MMM DD일 (ddd)`,
              )} ${OrderHistoryDetailString.dawn}`
            : `${moment(new Date(pickupTime)).format(
                `YYYY년 MMM DD일 (ddd) A`,
              )}`}
        </Text>
        <Text style={styles.TextContent}>{`${
          OrderHistoryDetailString.pickupDetail
        }: ${
          pickup && pickup.where && pickup.where.location
            ? pickup.where.location
            : OrderHistoryDetailString.noCareOption
        }`}</Text>
      </View>
      <Text style={styles.TextTitle}>
        {OrderHistoryDetailString.deliveryDate}
      </Text>
      <View style={styles.TextContainer}>
        {/* 배송일정 */}
        <Text style={styles.TextContent}>
          {new Date(deliveryTime).getHours() < 7
            ? `${moment(new Date(deliveryTime)).format(
                `YYYY년 MMM DD일 (ddd)`,
              )} ${OrderHistoryDetailString.dawn}`
            : `${moment(new Date(deliveryTime)).format(
                `YYYY년 MMM DD일 (ddd) A`,
              )}`}
        </Text>
        <Text style={styles.TextContent}>{`${
          OrderHistoryDetailString.deliveryDetail
        }: ${
          delivery && delivery.where && delivery.where.location
            ? delivery.where.location
            : OrderHistoryDetailString.noCareOption
        }`}</Text>
      </View>
      <Text style={styles.TextTitle}>
        {OrderHistoryDetailString.washDetail}
      </Text>
      <View style={styles.TextContainer}>
        {/* 세탁요청사항 */}
        {preOptions &&
        preOptions.care &&
        preOptions.care.options &&
        preOptions.care.options.length > 0 ? (
          preOptions.care.options.map((option, i) => (
            <Text key={`${option.message}-${i}`} style={styles.TextContent}>
              {`${OrderHistoryDetailString.careOptions[option.type]}: ${
                option.message
              }`}
            </Text>
          ))
        ) : (
          <Text style={styles.TextContent}>
            {OrderHistoryDetailString.noCareOption}
          </Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  TextTitle: {
    ...responseFont(16).regular,
    color: washswatColor.black,
    marginVertical: 8,
  },
  TextContainer: {
    marginBottom: 8,
  },
  TextContent: {
    ...responseFont(14).regular,
    color: washswatColor.grey_13,
  },
});

export default OrderHistoryDetailCollapse;
