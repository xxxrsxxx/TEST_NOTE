import React from 'react';
import { Image, PixelRatio, StyleSheet, TouchableWithoutFeedback } from 'react-native';

export default function OrderAdvertiseView(props) {
  const { onPress, source } = props;
  return (
    <TouchableWithoutFeedback onPress={onPress} style={{ height: PixelRatio.roundToNearestPixel(150) }}>
      <Image style={{ width: '100%', height: PixelRatio.roundToNearestPixel(150) }} source={source} resizeMode={'cover'} />
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({});
