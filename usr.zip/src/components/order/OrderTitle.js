import React from 'react';
import { StyleSheet, Text, View, PixelRatio, Platform } from 'react-native';

import { StartOrderShared } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function OrderTitle(props) {
  const { stage, title } = props;
  return (
    <View>
      <View
        style={{
          paddingStart: PixelRatio.roundToNearestPixel(30),
          paddingTop:
            Platform.OS === 'android'
              ? PixelRatio.roundToNearestPixel(110)
              : PixelRatio.roundToNearestPixel(60),
          paddingEnd: PixelRatio.roundToNearestPixel(30),
          paddingBottom: PixelRatio.roundToNearestPixel(42),
        }}
      >
        {stage ? (
          <Text
            style={[
              responseFont(18).regular,
              {
                color: washswatColor.grey_02,
                marginBottom: PixelRatio.roundToNearestPixel(6),
              },
            ]}
          >
            {`${stage}${StartOrderShared.stage}`}
          </Text>
        ) : null}
        <Text style={[responseFont(30).bold, { color: washswatColor.black }]}>
          {title}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({});
