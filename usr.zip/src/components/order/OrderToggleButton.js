import React from 'react';
import {
  View,
  StyleSheet,
  Text,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function OrderToggleButton(props) {
  const {
    onPressLeft,
    leftBgColor,
    leftTextColor,
    leftString,
    onPressRight,
    rightBgColor,
    rightTextColor,
    rightString,
  } = props;
  return (
    <View style={styles.toggleButton}>
      <TouchableOpacity
        onPress={onPressLeft}
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: leftBgColor,
        }}
      >
        <Text style={[responseFont(15).regular, { color: leftTextColor }]}>
          {leftString}
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={onPressRight}
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: rightBgColor,
        }}
      >
        <Text style={[responseFont(15).regular, { color: rightTextColor }]}>
          {rightString}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  toggleButton: {
    height: PixelRatio.roundToNearestPixel(50),
    flexDirection: 'row',
    borderWidth: PixelRatio.roundToNearestPixel(1),
    borderRadius: PixelRatio.roundToNearestPixel(3),
    borderColor: washswatColor.blue,
  },
});
