import React from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  PixelRatio,
  Image,
  View,
  ScrollView,
} from 'react-native';
import Modal from 'react-native-modalbox';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function OrderHelpBottomModal(props) {
  const {
    isOpen,
    source,
    content,
    onPressButton,
    buttonText,
    onClosed,
  } = props;
  return (
    <Modal
      isOpen={isOpen}
      style={styles.rootView}
      swipeToClose={false}
      position="bottom"
      onClosed={onClosed}
    >
      <ScrollView
        style={{
          paddingStart: PixelRatio.roundToNearestPixel(30),
          paddingEnd: PixelRatio.roundToNearestPixel(30),
        }}
      >
        <Image
          source={source}
          style={{
            width: '100%',
            height: PixelRatio.roundToNearestPixel(150),
            marginTop: PixelRatio.roundToNearestPixel(36),
          }}
          resizeMode={'cover'}
        />
        <Text
          style={[
            responseFont(14).regular,
            {
              color: washswatColor.black,
              lineHeight: PixelRatio.roundToNearestPixel(24),
              marginTop: PixelRatio.roundToNearestPixel(30),
              marginBottom: PixelRatio.roundToNearestPixel(42),
            },
          ]}
        >
          {content}
        </Text>
      </ScrollView>
      <TouchableOpacity onPress={onPressButton} style={styles.modalButton}>
        <View
          style={{
            width: '100%',
            height: PixelRatio.roundToNearestPixel(1),
            backgroundColor: washswatColor.black,
          }}
        />
        <Text
          style={[
            responseFont(15).regular,
            {
              color: washswatColor.black,
              paddingTop: PixelRatio.roundToNearestPixel(25),
              paddingBottom: PixelRatio.roundToNearestPixel(25),
            },
          ]}
        >
          {buttonText}
        </Text>
      </TouchableOpacity>
    </Modal>
  );
}

const styles = StyleSheet.create({
  rootView: {
    height: '90%',
    backgroundColor: washswatColor.white,
  },
  modalButton: {
    justifyContent: 'center',
    alignItems: 'center',
  },
});
