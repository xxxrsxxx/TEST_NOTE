import React from 'react';
import {
  View,
  StyleSheet,
  Text,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';
import Modal from 'react-native-modalbox';

import { StartOrderDelivery } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function OrderCenterModal(props) {
  const { isOpen, onPressOk, onPressCancel, onClosed } = props;
  return (
    <Modal
      isOpen={isOpen}
      style={styles.rootView}
      swipeToClose={false}
      position="center"
      onClosed={onClosed}
      backdropPressToClose={false}
    >
      <View>
        <Text
          style={[
            responseFont(15).bold,
            {
              color: washswatColor.black,
              lineHeight: PixelRatio.roundToNearestPixel(24),
            },
          ]}
        >
          {`${StartOrderDelivery.modalExpressContent1}\n`}
          <Text
            style={[
              responseFont(15).regular,
              {
                color: washswatColor.black,
                lineHeight: PixelRatio.roundToNearestPixel(24),
              },
            ]}
          >
            {`${StartOrderDelivery.modalExpressContent2}\n\n`}
          </Text>
        </Text>
      </View>
      <TouchableOpacity onPress={() => onPressOk()} style={styles.okButton}>
        <Text
          style={[responseFont(15).regular, { color: washswatColor.white }]}
        >
          {StartOrderDelivery.modalOk}
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => onPressCancel()}
        style={{ marginTop: PixelRatio.roundToNearestPixel(24) }}
      >
        <Text
          style={[responseFont(15).regular, { color: washswatColor.grey_02 }]}
        >
          {StartOrderDelivery.modalCancel}
        </Text>
      </TouchableOpacity>
    </Modal>
  );
}

const styles = StyleSheet.create({
  rootView: {
    width: PixelRatio.roundToNearestPixel(300),
    height: PixelRatio.roundToNearestPixel(348),
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(36),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(36),
    alignItems: 'center',
  },
  okButton: {
    width: PixelRatio.roundToNearestPixel(162),
    height: PixelRatio.roundToNearestPixel(50),
    backgroundColor: washswatColor.blue,
    borderRadius: PixelRatio.roundToNearestPixel(90),
    shadowColor: washswatColor.blue,
    shadowOffset: {
      width: PixelRatio.roundToNearestPixel(0),
      height: PixelRatio.roundToNearestPixel(12),
    },
    shadowOpacity: 0.14,
    shadowRadius: PixelRatio.roundToNearestPixel(12),
    elevation: PixelRatio.roundToNearestPixel(12),
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: PixelRatio.roundToNearestPixel(42),
  },
});
