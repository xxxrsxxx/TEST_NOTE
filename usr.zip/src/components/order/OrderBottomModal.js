import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
  Image,
  ScrollView,
} from 'react-native';
import Modal from 'react-native-modalbox';

import { StartOrderShared } from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { responseFont, washswatColor } = Font;

export default function OrderBottomModal(props) {
  const {
    isEvent,
    eventTitle,
    isOpen,
    source,
    content,
    dayOfWeek,
    startEndTime,
    onPressButton,
    onClosed,
  } = props;
  return (
    <Modal
      isOpen={isOpen}
      style={{
        height: '70%',
        backgroundColor: washswatColor.white,
        alignContent: 'space-between',
      }}
      swipeToClose={false}
      position="bottom"
      onClosed={onClosed}
    >
      <ScrollView
        style={{
          paddingStart: PixelRatio.roundToNearestPixel(30),
          paddingEnd: PixelRatio.roundToNearestPixel(30),
        }}
      >
        <View style={{ height: PixelRatio.roundToNearestPixel(36) }} />
        {isEvent && (
          <Text
            style={[
              responseFont(16).bold,
              {
                color: washswatColor.black,
                marginBottom: PixelRatio.roundToNearestPixel(18),
              },
            ]}
          >
            {eventTitle}
          </Text>
        )}
        <Image
          source={source}
          style={{ width: '100%', height: PixelRatio.roundToNearestPixel(150) }}
          resizeMode={'contain'}
        />
        <View
          style={{
            marginTop: PixelRatio.roundToNearestPixel(30),
            marginBottom: PixelRatio.roundToNearestPixel(30),
          }}
        >
          <TextWithRegex key={`TextWithRegex{i}`} text={content} />
        </View>
      </ScrollView>
      <TouchableOpacity onPress={onPressButton} style={styles.modalButton}>
        <Text style={[responseFont(15).bold, { color: washswatColor.white }]}>
          {`${dayOfWeek}, ${startEndTime} ${StartOrderShared.selection}`}
        </Text>
      </TouchableOpacity>
    </Modal>
  );
}

const TextWithRegex = ({ text }) => {
  const regexGlobal = /\*\*(.+?)\*\*/g;
  const regex = /\*\*(.+?)\*\*/;

  if (regexGlobal.test(text)) {
    const backup = text.match(regexGlobal);
    const splited = text.split(regexGlobal);
    var views = [];
    _.map(splited, (o, index) => {
      if (o) {
        const finded = _.find(backup, c => c.indexOf(o) > -1);
        views.push(
          <Text
            key={index}
            style={[
              responseFont(16).regular,
              {
                color: washswatColor.black,
                lineHeight: PixelRatio.roundToNearestPixel(24),
                fontWeight: finded ? 'bold' : 'normal',
              },
            ]}
          >
            {o}
          </Text>,
        );
      }
    });
    return <View>{views}</View>;
  } else {
    return (
      <Text
        style={[
          responseFont(16).regular,
          {
            color: washswatColor.black,
            lineHeight: PixelRatio.roundToNearestPixel(24),
          },
        ]}
      >
        {text}
      </Text>
    );
  }
};

const styles = StyleSheet.create({
  modalButton: {
    height: PixelRatio.roundToNearestPixel(50),
    backgroundColor: washswatColor.blue,
    borderRadius: PixelRatio.roundToNearestPixel(3),
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: PixelRatio.roundToNearestPixel(30),
    marginRight: PixelRatio.roundToNearestPixel(30),
    marginBottom: PixelRatio.roundToNearestPixel(30),
  },
});
