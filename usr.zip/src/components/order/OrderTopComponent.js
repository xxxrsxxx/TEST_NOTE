import React from 'react';

import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
} from 'react-native';

import { GradientCircle } from '../common/style/GradientCircle';
import { ImageCircle } from '../common/style/ImageCircle';
import { EmojiButton } from '../common/button/EmojiButton';

import { Font, Styles } from '../../utils/style';

import { _ } from '../../plugins';
const { washswatColor, verticalScale, responseFont } = Font;

const { height } = Dimensions.get('window');

const styles = StyleSheet.create({
  orderIdText: {
    ...responseFont(18).bold,
    color: washswatColor.black,
  },
  circleTextView: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
  },
  circleText: {
    color: washswatColor.white,
    textAlign: 'center',
  },
  bigText: {
    ...responseFont(27).bold,
  },
  smallText: {
    ...responseFont(22).bold,
  },
  bottomText: {
    ...responseFont(14).bold,
    color: washswatColor.grey_08,
    textAlign: 'center',
  },
});

const OrderTopComponent = props => {
  const {
    title,
    circleText,
    circleColors,
    circleSource,
    onPressDateTime,
    bottomText,
    circleIsPress,
    history,
    status,
    pickup,
  } = props;

  // const diameter = width * 0.7;
  const diameter = Styles.diameter;

  const OrderIdView = props => {
    const { title } = props;
    if (title) {
      return (
        <Text style={[styles.orderIdText, { marginBottom: verticalScale(30) }]}>
          {title}
        </Text>
      );
    }
    return <View />;
  };

  const Circle = props => {
    const { circleColors, circleSource } = props;
    if (circleColors) {
      return <GradientCircle diameter={diameter} colors={circleColors} />;
    }
    if (circleSource) {
      return <ImageCircle diameter={diameter} source={circleSource} />;
    }
    return <View />;
  };

  const CircleTextView = props => {
    const { circleText, onPressDateTime, circleIsNotPress } = props;
    if (circleText) {
      return (
        <TouchableOpacity
          onPress={onPressDateTime}
          activeOpacity={1}
          disabled={!circleIsPress}
          style={{
            ...styles.circleTextView,
            width: diameter,
            height: diameter,
            borderRadius: diameter / 2,
          }}
        >
          <Text style={[styles.circleText, responseFont(23).bold]}>
            {circleText}
          </Text>
        </TouchableOpacity>
      );
    }
    return <View />;
  };

  const EmojiView = props => {
    const { onPressDateTime, history, status, pickup } = props;
    const deliveryCancel = _.find(
      history,
      o => o && o.info && o.info.type && o.info.type === 'deliveryCancel',
    );
    if (
      status === 'delivery' &&
      deliveryCancel &&
      pickup &&
      pickup.payType &&
      pickup.payType === 'later'
    ) {
      return null;
    }
    if (onPressDateTime) {
      return (
        <View style={{ justifyContent: 'flex-end', alignItems: 'flex-end' }}>
          <View style={{ position: 'absolute' }}>
            <EmojiButton title={'🗓'} onPress={onPressDateTime} />
          </View>
        </View>
      );
    }
    return null;
  };

  const BottomTextView = props => {
    const { bottomText } = props;
    if (bottomText) {
      return (
        <View style={{ flexDirection: 'row', marginTop: verticalScale(20) }}>
          <Text style={[styles.bottomText]}>💁</Text>
          <Text style={[styles.bottomText, { marginLeft: 3 }]}>
            {bottomText}
          </Text>
        </View>
      );
    } else {
      return <View />;
    }
  };

  return (
    <View
      style={{ alignItems: 'center', justifyContent: 'space-around' }}
      onLayout={props.getOrderTopHeight}
    >
      <OrderIdView title={title} />
      <View>
        <View style={{ width: diameter, height: diameter }}>
          <Circle circleColors={circleColors} circleSource={circleSource} />
          <CircleTextView
            circleText={circleText}
            onPressDateTime={onPressDateTime}
            circleIsPress={circleIsPress}
          />
          <EmojiView
            onPressDateTime={onPressDateTime}
            history={history}
            status={status}
            pickup={pickup}
          />
        </View>
      </View>
      <BottomTextView bottomText={bottomText} />
    </View>
  );
};

export default OrderTopComponent;
