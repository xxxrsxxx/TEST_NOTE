import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  PixelRatio,
  TouchableOpacity,
  Image,
} from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function OrderPaymentAdd(props) {
  const { onPress, title, percent } = props;
  return (
    <TouchableOpacity
      onPress={onPress}
      style={{
        flexDirection: 'row',
        height: PixelRatio.roundToNearestPixel(94),
        alignItems: 'center',
      }}
    >
      <Text
        style={[
          responseFont(16).bold,
          {
            color: washswatColor.black,
            marginLeft: PixelRatio.roundToNearestPixel(30),
          },
        ]}
      >
        {title}
      </Text>
      {percent && (
        <View
          style={{
            width: PixelRatio.roundToNearestPixel(72),
            height: PixelRatio.roundToNearestPixel(24),
            backgroundColor: washswatColor.red,
            justifyContent: 'center',
            alignItems: 'center',
            marginLeft: PixelRatio.roundToNearestPixel(12),
          }}
        >
          <Text style={[responseFont(12).bold, { color: washswatColor.white }]}>
            {percent}
          </Text>
        </View>
      )}
      <View style={{ flex: 1 }} />
      <View style={{ marginRight: PixelRatio.roundToNearestPixel(30) }}>
        <Image
          style={{
            width: PixelRatio.roundToNearestPixel(10),
            height: PixelRatio.roundToNearestPixel(10),
          }}
          source={require('image/Order/add.png')}
        />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({});
