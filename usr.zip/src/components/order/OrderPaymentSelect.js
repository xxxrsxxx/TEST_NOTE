import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  PixelRatio,
  TouchableOpacity,
} from 'react-native';

import UpToPercent from '../common/button/UpToPercent';

import { StartOrderShared } from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { responseFont, washswatColor } = Font;

export default function OrderPaymentSelect(props) {
  const {
    title,
    percent,
    info,
    onPress,
    isExpress,
    chargeAndChangeText,
    onPressChargeAndChange,
  } = props;
  const disabled = isExpress;
  const buttonBackgroundColor = isExpress
    ? washswatColor.grey_03
    : washswatColor.blue;
  return (
    <View style={styles.rootView}>
      <View>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={[responseFont(16).bold, { color: washswatColor.black }]}>
            {title}
          </Text>
          {percent && _.isEmpty(chargeAndChangeText) && (
            <UpToPercent percent={percent} />
          )}
        </View>
        <Text
          style={[
            responseFont(13).regular,
            {
              color: washswatColor.grey_02,
              marginTop: PixelRatio.roundToNearestPixel(7),
            },
          ]}
        >
          {info}
        </Text>
      </View>
      <View style={{ flex: 1 }} />
      {_.isEmpty(chargeAndChangeText) ? (
        <TouchableOpacity
          onPress={onPress}
          disabled={disabled}
          style={[
            styles.selectButton,
            { backgroundColor: buttonBackgroundColor },
          ]}
        >
          <Text
            style={[responseFont(15).regular, { color: washswatColor.white }]}
          >
            {StartOrderShared.selection}
          </Text>
        </TouchableOpacity>
      ) : (
        <View
          style={{
            flexDirection: 'row',
            width: PixelRatio.roundToNearestPixel(148),
            height: PixelRatio.roundToNearestPixel(50),
          }}
        >
          <TouchableOpacity
            onPress={onPressChargeAndChange}
            style={styles.leftButton}
          >
            <Text
              style={[responseFont(15).regular, { color: washswatColor.blue }]}
            >
              {chargeAndChangeText}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={onPress}
            disabled={disabled}
            style={[
              styles.rightButton,
              { backgroundColor: buttonBackgroundColor },
            ]}
          >
            <Text
              style={[responseFont(15).regular, { color: washswatColor.white }]}
            >
              {StartOrderShared.selection}
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  rootView: {
    height: PixelRatio.roundToNearestPixel(120),
    flexDirection: 'row',
    alignItems: 'center',
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
  },
  chargeAndChangeButton: {
    width: PixelRatio.roundToNearestPixel(148),
    height: PixelRatio.roundToNearestPixel(50),
    backgroundColor: washswatColor.white,
    borderRadius: PixelRatio.roundToNearestPixel(3),
  },
  selectButton: {
    width: PixelRatio.roundToNearestPixel(74),
    height: PixelRatio.roundToNearestPixel(50),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: PixelRatio.roundToNearestPixel(3),
  },
  leftButton: {
    backgroundColor: washswatColor.white,
    flex: 1,
    borderTopLeftRadius: PixelRatio.roundToNearestPixel(3),
    borderBottomLeftRadius: PixelRatio.roundToNearestPixel(3),
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: PixelRatio.roundToNearestPixel(1),
    borderColor: washswatColor.blue,
  },
  rightButton: {
    flex: 1,
    borderTopRightRadius: PixelRatio.roundToNearestPixel(3),
    borderBottomRightRadius: PixelRatio.roundToNearestPixel(3),
    justifyContent: 'center',
    alignItems: 'center',
  },
});
