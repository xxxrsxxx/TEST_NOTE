import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
  Image,
} from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function OrderPaySelectView(props) {
  const { title, info, onPress } = props;
  return (
    <TouchableOpacity
      onPress={onPress}
      style={{
        flexDirection: 'row',
        height: PixelRatio.roundToNearestPixel(72),
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: washswatColor.white,
        paddingStart: PixelRatio.roundToNearestPixel(30),
        paddingEnd: PixelRatio.roundToNearestPixel(30),
      }}
    >
      <Text style={[responseFont(16).regular, { color: washswatColor.black }]}>
        {title}
      </Text>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Text style={[responseFont(13).regular, { color: washswatColor.blue }]}>
          {info}
        </Text>
        <Image
          source={require('image/start/right_arrow_small.png')}
          style={{
            width: PixelRatio.roundToNearestPixel(10),
            height: PixelRatio.roundToNearestPixel(10),
            marginLeft: PixelRatio.roundToNearestPixel(12),
          }}
        />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({});
