import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import { StartOrderShared, StartOrderPickup } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function OrderPickupEventView(props) {
  const { title, subTitle, onPress, buttonText, onPressEventShow } = props;
  return (
    <View style={styles.rootView}>
      <View
        style={{
          paddingStart: PixelRatio.roundToNearestPixel(15),
          paddingEnd: PixelRatio.roundToNearestPixel(15),
        }}
      >
        <View style={styles.event}>
          <Text
            style={[responseFont(12).regular, { color: washswatColor.white }]}
          >
            {StartOrderShared.eventEn}
          </Text>
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginTop: PixelRatio.roundToNearestPixel(11),
          }}
        >
          <View>
            <View style={{ justifyContent: 'center' }}>
              <Text
                style={[responseFont(16).bold, { color: washswatColor.black }]}
              >
                {title}
              </Text>
            </View>
            <Text
              style={[
                responseFont(13).regular,
                {
                  color: washswatColor.grey_02,
                  marginTop: PixelRatio.roundToNearestPixel(6),
                },
              ]}
            >
              {subTitle}
            </Text>
          </View>
          <TouchableOpacity onPress={onPress} style={styles.button}>
            <Text
              style={[responseFont(15).regular, { color: washswatColor.white }]}
            >
              {buttonText}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      <TouchableOpacity
        onPress={onPressEventShow}
        style={{
          paddingStart: PixelRatio.roundToNearestPixel(15),
          paddingEnd: PixelRatio.roundToNearestPixel(15),
        }}
      >
        <Text
          style={[
            responseFont(12).regular,
            {
              color: washswatColor.red,
              marginTop: PixelRatio.roundToNearestPixel(21),
            },
          ]}
        >
          {StartOrderPickup.eventMessage}
        </Text>
        <Text
          style={[
            responseFont(12).regular,
            {
              color: washswatColor.red,
              textDecorationLine: 'underline',
              marginTop: PixelRatio.roundToNearestPixel(6),
            },
          ]}
        >
          {StartOrderPickup.eventShow}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  rootView: {
    height: PixelRatio.roundToNearestPixel(156),
    marginStart: PixelRatio.roundToNearestPixel(15),
    marginEnd: PixelRatio.roundToNearestPixel(15),
    borderWidth: PixelRatio.roundToNearestPixel(1),
    borderColor: washswatColor.red,
  },
  event: {
    width: PixelRatio.roundToNearestPixel(51),
    height: PixelRatio.roundToNearestPixel(24),
    backgroundColor: washswatColor.red,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    width: PixelRatio.roundToNearestPixel(74),
    height: PixelRatio.roundToNearestPixel(50),
    backgroundColor: washswatColor.blue,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: PixelRatio.roundToNearestPixel(3),
  },
});
