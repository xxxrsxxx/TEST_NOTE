import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import { StartOrderShared } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function OrderSelectView(props) {
  const { title, subTitle, onPress, buttonText, userType, onlyMember } = props;
  const disabled = userType === 'normal' && onlyMember;
  const buttonBackgroundColor = disabled
    ? washswatColor.grey_03
    : washswatColor.blue;
  return (
    <View style={styles.rootView}>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ justifyContent: 'center' }}>
            <Text
              style={[responseFont(16).bold, { color: washswatColor.black }]}
            >
              {title}
            </Text>
            {disabled && (
              <View
                style={{
                  width: '100%',
                  height: PixelRatio.roundToNearestPixel(1.2),
                  backgroundColor: washswatColor.red,
                  position: 'absolute',
                }}
              />
            )}
          </View>
          {onlyMember && (
            <Text
              style={[
                responseFont(12).regular,
                {
                  color: washswatColor.red,
                  marginLeft: PixelRatio.roundToNearestPixel(9),
                },
              ]}
            >
              {StartOrderShared.memberOnly}
            </Text>
          )}
        </View>
        <Text
          style={[
            responseFont(13).regular,
            {
              color: washswatColor.grey_02,
              marginTop: PixelRatio.roundToNearestPixel(6),
            },
          ]}
        >
          {subTitle}
        </Text>
      </View>
      <TouchableOpacity
        onPress={onPress}
        style={[styles.button, { backgroundColor: buttonBackgroundColor }]}
      >
        <Text
          style={[responseFont(15).regular, { color: washswatColor.white }]}
        >
          {buttonText}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  rootView: {
    height: PixelRatio.roundToNearestPixel(122),
    flexDirection: 'row',
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
    alignItems: 'center',
  },
  button: {
    width: PixelRatio.roundToNearestPixel(74),
    height: PixelRatio.roundToNearestPixel(50),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: PixelRatio.roundToNearestPixel(3),
  },
});
