import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
  Image,
  ScrollView,
  Platform,
} from 'react-native';
import Modal from 'react-native-modalbox';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as StartOrderModule from '../../reducers/StartOrderModule';
import * as MyPageModule from '../../reducers/MyPageModule';

import { StartOrderShared, Favorite } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import * as KeyUtils from '../../utils/type/key';
import AnalyticsManager from '../../utils/tagging/analytics';
import * as AnalyticsKey from '../../utils/tagging/analytics/key';
import WashAlert from '../../utils/alert';
import * as WashPayment from '../../utils/common/payment';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

class OrderCardListModal extends React.Component {
  _onPressCardListModalClose = () => {
    const { OrderAction } = this.props;
    OrderAction.setIsOpenCardListModal(false);
  };

  _onClosedCardListModal = () => {
    const { OrderAction } = this.props;
    OrderAction.setIsOpenCardListModal(false);
  };

  _onPressCardAdd = async () => {
    const _storage = await $_storage.get();
    const uid = _storage[KeyUtils.USER_ID];
    const name = _storage[KeyUtils.USER_NAME];
    const af_address = _storage[KeyUtils.USER_ADDRESS];
    const af_road_address = _storage[KeyUtils.USER_ROAD_ADDRESS];
    const af_detail_address = _storage[KeyUtils.USER_ADDRESS_OTHERS];
    const af_user_type = _storage[KeyUtils.USER_TYPE];

    const data = {
      uid,
      name,
      callType: 'bill',
    };
    WashPayment.show(data, json => {
      const { code, message } = json;
      if (code === 200) {
        const { OrderAction } = this.props;
        OrderAction.setAssetsAPI();
        AnalyticsManager.setAppsFlyerTrackEvent(
          AnalyticsKey.NAME_ADD_PAYMENT_INFO,
          {
            af_uid: uid,
            af_address,
            af_road_address,
            af_detail_address,
            af_user_type,
            af_path: 'payment_method',
            af_add_payment_method: 'card',
          },
        );
        AnalyticsManager.setAirbridgeTrackEvent(
          AnalyticsKey.NAME_ADD_PAYMENT_INFO,
          Platform.OS,
          uid,
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          WashAlert.showAlert(
            '카드등록 실패! 다시 한번 시도해주시겠어요?',
            Favorite.ok,
          );
        }
      }
    });
  };

  _onPressSetDefault = billKey => {
    const { MyPageAction, OrderAction } = this.props;
    MyPageAction.setDefault({ billKey }, code => {
      if (code === 200) {
        OrderAction.setAssetsAPI();
        this._onPressCardListModalClose();
      }
    });
  };

  render() {
    const { assets, isOpenCardListModal } = this.props;
    /**
     * const billArray = [
    //   {
    //     billKey: '54035b325ec9ca6461f5b4d417686cdd05a8cd58',
    //     brand: '신한',
    //     card: '신한 4499 **** 2364 ****',
    //     isDefault: 1,
    //     number: '신한 4499 **** 2364 ****',
    //     regdate: '2019-06-05 17:46:16.953'
    //   },
     */
    const { billArray } = assets;

    let cardListView = [];
    billArray.map((item, index) => {
      const { billKey, card, isDefault } = item;
      const cardSplits = card.split(' ');
      const cardTitle = `${cardSplits[0]} ${cardSplits[1]}`;
      const textColor = isDefault ? washswatColor.blue : washswatColor.black;
      cardListView.push(
        <View key={index}>
          <TouchableOpacity
            onPress={() => {
              this._onPressSetDefault(billKey);
            }}
            style={{
              height: PixelRatio.roundToNearestPixel(60),
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingLeft: PixelRatio.roundToNearestPixel(24),
              paddingRight: PixelRatio.roundToNearestPixel(24),
            }}
          >
            <Text style={[responseFont(16).regular, { color: textColor }]}>
              {cardTitle}
            </Text>
            <Image
              source={
                isDefault && require('image/start/check_default_card.png')
              }
              style={{
                width: PixelRatio.roundToNearestPixel(24),
                height: PixelRatio.roundToNearestPixel(24),
              }}
            />
          </TouchableOpacity>
          <View
            style={{
              height: PixelRatio.roundToNearestPixel(1),
              backgroundColor: washswatColor.grey_05,
            }}
          />
        </View>,
      );
    });

    return (
      <Modal
        isOpen={isOpenCardListModal}
        style={{
          backgroundColor: washswatColor.transparent,
          justifyContent: 'flex-end',
        }}
        swipeToClose={false}
        position="bottom"
        onClosed={this._onPressCardListModalClose}
      >
        <View style={styles.modalRootView}>
          <ScrollView>{cardListView}</ScrollView>
          <TouchableOpacity
            onPress={() => this._onPressCardAdd()}
            style={{
              height: PixelRatio.roundToNearestPixel(60),
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <Text
              style={[responseFont(16).regular, { color: washswatColor.black }]}
            >
              {StartOrderShared.addCard}
            </Text>
          </TouchableOpacity>
        </View>
        <View style={styles.closeButtonView}>
          <TouchableOpacity
            onPress={this._onPressCardListModalClose}
            style={{
              height: PixelRatio.roundToNearestPixel(60),
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <Text
              style={[responseFont(16).regular, { color: washswatColor.black }]}
            >
              {StartOrderShared.close}
            </Text>
          </TouchableOpacity>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  modalRootView: {
    backgroundColor: washswatColor.white,
    marginLeft: PixelRatio.roundToNearestPixel(15),
    marginRight: PixelRatio.roundToNearestPixel(15),
    borderRadius: PixelRatio.roundToNearestPixel(3),
    flexShrink: 1,
  },
  closeButtonView: {
    backgroundColor: washswatColor.white,
    marginLeft: PixelRatio.roundToNearestPixel(15),
    marginTop: PixelRatio.roundToNearestPixel(15),
    marginRight: PixelRatio.roundToNearestPixel(15),
    marginBottom: PixelRatio.roundToNearestPixel(24),
    borderRadius: PixelRatio.roundToNearestPixel(3),
  },
});

export default connect(
  state => ({
    assets: state.StartOrderModule.assets,
    isOpenCardListModal: state.StartOrderModule.isOpenCardListModal,
  }),
  dispatch => ({
    OrderAction: bindActionCreators(StartOrderModule, dispatch),
    MyPageAction: bindActionCreators(MyPageModule, dispatch),
  }),
)(OrderCardListModal);
