import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  PixelRatio,
  TouchableOpacity,
  Image,
} from 'react-native';

import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { responseFont, washswatColor } = Font;

export default function OrderServiceItem(props) {
  const {
    itemKey,
    onPress,
    onPressHelp,
    selected,
    disabled,
    title,
    subTitle,
    content,
  } = props;
  const buttonBackgroundColor = selected
    ? washswatColor.black
    : washswatColor.white;
  return (
    <TouchableOpacity
      onPress={onPress}
      style={styles.rootView}
      disabled={disabled}
    >
      <View style={{ flexDirection: 'row' }}>
        <View
          style={[styles.button, { backgroundColor: buttonBackgroundColor }]}
        >
          {disabled && (
            <Image
              style={{
                width: PixelRatio.roundToNearestPixel(24),
                height: PixelRatio.roundToNearestPixel(24),
              }}
              source={require('image/start/service_item_disable.png')}
            />
          )}
        </View>
        <View style={{ marginLeft: PixelRatio.roundToNearestPixel(15) }}>
          <View style={{ flexDirection: 'row' }}>
            <Text
              style={[responseFont(16).regular, { color: washswatColor.black }]}
            >
              {title}
            </Text>
            {itemKey === 'washAndFold' && (
              <TouchableOpacity onPress={onPressHelp}>
                <Image
                  source={require('image/start/ic_help.png')}
                  style={{
                    width: PixelRatio.roundToNearestPixel(16),
                    height: PixelRatio.roundToNearestPixel(16),
                    marginLeft: PixelRatio.roundToNearestPixel(10),
                  }}
                />
              </TouchableOpacity>
            )}
          </View>
          <Text
            style={[
              responseFont(13).regular,
              {
                color: washswatColor.black,
                marginTop: PixelRatio.roundToNearestPixel(6),
              },
            ]}
          >
            {subTitle}
          </Text>
        </View>
      </View>
      {selected && !_.isEmpty(content) && (
        <View
          style={{
            flexDirection: 'row',
            marginTop: PixelRatio.roundToNearestPixel(15),
          }}
        >
          <View style={styles.verticalLine} />
          <Text style={[responseFont(13).regular, styles.content]}>
            {content}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  rootView: {
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(21),
    paddingEnd: PixelRatio.roundToNearestPixel(27),
    paddingBottom: PixelRatio.roundToNearestPixel(21),
  },
  button: {
    width: PixelRatio.roundToNearestPixel(24),
    height: PixelRatio.roundToNearestPixel(24),
    borderWidth: PixelRatio.roundToNearestPixel(1),
    backgroundColor: washswatColor.white,
  },
  verticalLine: {
    width: PixelRatio.roundToNearestPixel(1),
    height: '100%',
    backgroundColor: washswatColor.black,
    marginLeft: PixelRatio.roundToNearestPixel(24),
  },
  content: {
    color: washswatColor.black,
    lineHeight: PixelRatio.roundToNearestPixel(20),
    flex: 1,
    marginLeft: PixelRatio.roundToNearestPixel(15),
  },
});
