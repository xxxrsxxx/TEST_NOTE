import React from 'react';
import {
  PixelRatio,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Carousel from 'react-native-snap-carousel';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as StartOrderModule from '../../reducers/StartOrderModule';
import * as MainScreenModule from '../../reducers/MainScreenModule';

import OrderSelectView from './OrderSelectView';
import OrderAdvertiseView from './OrderAdvertiseView';
import OrderPickupEventView from './OrderPickupEventView';

import {
  AlertMessage,
  Favorite,
  OrderAdvertise,
  StartOrderShared,
} from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';
import WashAlert from '../../utils/alert';
import { Font } from '../../utils/style';

import { _, moment } from '../../plugins';

const { washswatColor, responseFont } = Font;

class OrderDateTime extends React.Component {
  constructor(props) {
    super(props);
  }

  componentWillUpdate(nextProps) {
    if (nextProps.dateIndex !== this.props.dateIndex) {
      const { data, pickup } = nextProps;
      if (StartOrderModule.hasExpress({ deliveryArray: data, pickup })) {
        setTimeout(() => {
          this._carousel.snapToItem(nextProps.dateIndex);
        }, 0);
      }
    }
  }

  _renderDate = ({ item, index }) => {
    if (item) {
      const dateFormat = 'YYYY-MM-DD';
      const { page, dateIndex, eventData } = this.props;
      const eventObject = _.find(eventData, object => {
        return object.pickup.day === item.day;
      });
      // 수거날짜 비교해서 급행비관련 event표시 보여주기
      const { pickup, data } = this.props;
      const { pickupTime } = pickup;
      const pickupYMD = moment(pickupTime).format(dateFormat);
      const deliveryYMD = moment(item.day);
      const hs = StartOrderModule.hasExpress({ deliveryArray: data, pickup });

      return (
        <TouchableOpacity
          onPress={() => this._carousel.snapToItem(index)} // snapToItem (index, animated = true, fireCallback = true)
          style={{
            height: PixelRatio.roundToNearestPixel(122),
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Text style={[responseFont(24).bold, { color: washswatColor.black }]}>
            {this._getDayOfWeek(item)}
          </Text>
          <Text
            style={[
              responseFont(13).regular,
              {
                color: washswatColor.black,
                marginTop: PixelRatio.roundToNearestPixel(3),
              },
            ]}
          >
            {this._getDate(item)}
          </Text>
          {dateIndex === index && (
            <View
              style={{
                width: PixelRatio.roundToNearestPixel(6),
                height: PixelRatio.roundToNearestPixel(6),
                backgroundColor: washswatColor.black,
                borderRadius: PixelRatio.roundToNearestPixel(3),
                marginTop: PixelRatio.roundToNearestPixel(12),
              }}
            />
          )}
        </TouchableOpacity>
      );
    } else {
      return null;
    }
  };

  _getDayOfWeek = item => {
    const { title } = item;
    if (title) {
      return title;
    }
    const itemMoment = moment(item.day);
    const { dayOfWeekArray } = StartOrderShared;
    const dayOfWeekNumber = itemMoment.day();
    let dayOfWeek = dayOfWeekArray[dayOfWeekNumber];
    let date = itemMoment.format(`M${Favorite.month} D${Favorite.day}`);
    const dateFormat = 'YYYY-MM-DD';
    // 어제
    const yesterdayMoment = moment().subtract(1, 'day');
    if (itemMoment.isSame(yesterdayMoment.format(dateFormat))) {
      dayOfWeek = Favorite.yesterday;
    }
    // 오늘
    const todayMoment = moment();
    if (itemMoment.isSame(todayMoment.format(dateFormat))) {
      dayOfWeek = Favorite.today;
    }
    // 내일
    const tomorrowMoment = moment().add(1, 'day');
    if (itemMoment.isSame(tomorrowMoment.format(dateFormat))) {
      dayOfWeek = Favorite.tomorrow;
    }
    return dayOfWeek;
  };

  _getDate = item => {
    const itemMoment = moment(item.day);
    let date = itemMoment.format(`M${Favorite.month} D${Favorite.day}`);
    return date;
  };

  _getEventView = (eventData, data, dateIndex) => {
    // const eventDataDummy = [
    //   {
    //     pickup: {
    //       day: '2019-06-21',
    //       slots: [{ start: 20, end: 24 }]
    //     },
    //     delivery: {
    //       day: '2019-07-05',
    //       slots: [{ start: 20, end: 24 }]
    //     },
    //     info: {
    //       image: 'https://s3.ap-northeast-2.amazonaws.com/com.washswat.assets/growth/V5+pop+up.png',
    //       content: 'info > content'
    //     }
    //   }
    // ];
    let eventViews = [];
    const eventObject = _.find(eventData, object => {
      return object.pickup.day === data[dateIndex].day;
    });
    if (eventObject === undefined) {
      return eventViews;
    }
    const { page, onPressEventBottomModalOpen, action, userType } = this.props;
    const { pickup, delivery } = eventObject;
    const pickupDay = pickup.day;
    const pickupSlots = pickup.slots[0];
    const deliveryDay = delivery.day;
    const deliverySlots = delivery.slots[0];
    const pickupStart = pickupSlots.start;
    const pickupEnd = pickupSlots.end;
    const deliveryStart = deliverySlots.start;
    const deliveryEnd = deliverySlots.end;
    const pickupTitle = this._getTimeTitle(
      'title',
      pickupStart,
      pickupEnd,
      true,
    );
    const pickupSubTitle = this._getTimeTitle(
      'subTitle',
      pickupStart,
      pickupEnd,
      true,
    );

    eventViews.push(
      <OrderPickupEventView
        key={'event'}
        title={pickupTitle}
        subTitle={pickupSubTitle}
        buttonText={StartOrderShared.selection}
        onPress={() => {
          const pickupStartTime = moment(pickupDay)
            .hour(pickupStart)
            .toDate();
          const pickupEndTime = moment(pickupDay)
            .hour(pickupEnd)
            .toDate();
          const deliveryStartTime = moment(deliveryDay)
            .hour(deliveryStart)
            .toDate();
          const deliveryEndTime = moment(deliveryDay)
            .hour(deliveryEnd)
            .toDate();
          switch (page) {
            case 'pickup':
              action.choosePickupTimeOnV5({
                pickupTime: pickupStartTime,
                endTime: pickupEndTime,
              });
              break;
          }
          onPressEventBottomModalOpen();
        }}
        onPressEventShow={this._onPressEventShow}
      />,
    );
    return eventViews;
  };

  _onPressEventShow = () => {
    const { popup } = this.props;
    if (popup.length === 0) {
      return;
    }
    const content = popup[0].content;
    const { url } = content;
    CommonUtils.navShowModalWebView({ url });
  };

  /**
   * title or subTitle을 반환
   * titleOrSubTitle - 'title' or 'subTitle' 필요
   * isEvent - 이벤트 수거시간일 때 true, 아니면 false
   */
  _getTimeTitle = (titleOrSubTitle, start, end, isEvent) => {
    let am = 'am';
    let pm = 'pm';
    if (isEvent) {
      am = 'AM';
      pm = 'PM';
    }
    let ampm = ''; // 자정 or 오전 or 오후 or 정오 or 새벽
    let startTime = ''; // 4시
    let endTime = ''; // 6시
    let subStartTime = ''; // 4:00
    let subStartAmpm = ''; // am or pm
    let subEndTime = ''; // 6:00
    let subEndAmpm = ''; // am or pm
    startTime = start + Favorite.hour;
    endTime = end + Favorite.hour;
    subStartTime = start + ':00';
    subEndTime = end + ':00';
    // 자정
    // if (start === 0 || start === 24) {
    //   ampm = Favorite.midnight;
    //   subStartAmpm = am;
    // }

    // 새벽
    if ((start >= 0 && start <= 5) || (start >= 24 && start <= 30)) {
      ampm = Favorite.dawn;
      subStartAmpm = am;
      if (start >= 24 && start <= 30) {
        startTime = start - 24 + Favorite.hour;
      }
    }
    if (end >= 24 && end <= 30) {
      endTime = end - 24 + Favorite.hour;
      subEndAmpm = am;
    }
    // 오전
    if (start >= 6 && start <= 11) {
      ampm = Favorite.am;
      subStartAmpm = am;
    }
    if (end >= 0 && end <= 11) {
      subEndAmpm = am;
    }
    // 정오
    if (start === 12) {
      ampm = Favorite.noon;
      subStartAmpm = pm;
    }
    if (end === 12) {
      endTime = Favorite.noon;
      subEndAmpm = pm;
    }
    // 오후
    if (start >= 13 && start <= 23) {
      ampm = Favorite.pm;
      startTime = start - 12 + Favorite.hour;
      subStartAmpm = pm;
    }
    if (end >= 13 && end <= 23) {
      endTime = end - 12 + Favorite.hour;
      subEndAmpm = pm;
    }
    if (end === 24) {
      endTime = Favorite.midnight;
      subEndAmpm = am;
    }
    let title = `${ampm} ${startTime} - ${endTime} ${Favorite.between}`; // 오후 4시 - 6시 사이
    // if (start === 0 || start === 12 || start === 24) {
    //   title = `${ampm} - ${endTime} ${Favorite.between}`; // '자정 or 정오' - 2시 사이
    // }
    const subTitle = `${subStartTime} ${subStartAmpm} - ${subEndTime} ${subEndAmpm}`; // 4:00 pm - 6:00 pm
    if (titleOrSubTitle === 'title') {
      return title;
    }
    if (titleOrSubTitle === 'subTitle') {
      return subTitle;
    }
    return '';
  };

  render() {
    const {
      OrderAction,
      data,
      eventData,
      width,
      dateIndex,
      page,
      onPressCenterModalOpen,
      setDateIndex,
      deliveryBanner,
    } = this.props;
    let deliveryBannerImage = undefined;
    let deliveryBannerUrl = undefined;

    if (deliveryBanner) {
      const { banner, content } = deliveryBanner;
      deliveryBannerImage = banner.image;
      deliveryBannerUrl = content.url;
    }
    let eventViews = [];
    if (page === 'pickup' && eventData && eventData.length > 0) {
      eventViews = this._getEventView(eventData, data, dateIndex);
    }

    const TimeViewSlots = () => {
      const { data, dateIndex } = this.props;
      const { day, slots } = data[dateIndex];
      const { page, action, userType } = this.props;

      const slotsLayout = _.map(slots, (slot, i) => (
        <View key={i}>
          {i !== 0 && <View style={styles.timeBoundaryLine} />}
          <OrderSelectView
            title={this._getTimeTitle('title', slot.start, slot.end)}
            subTitle={this._getTimeTitle('subTitle', slot.start, slot.end)}
            buttonText={StartOrderShared.selection}
            userType={userType}
            onlyMember={slot.onlyMember}
            onPress={() => {
              const disabled = userType === 'normal' && slot.onlyMember;
              if (disabled) {
                WashAlert.showAlert(
                  AlertMessage.membershipOnlyTime,
                  Favorite.ok,
                );
                return;
              }
              const startTime = moment(day)
                .hour(slot.start)
                .toDate();
              const endTime = moment(day)
                .hour(slot.end)
                .toDate();

              if (page === 'pickup') {
                action.choosePickupTimeOnV5({ pickupTime: startTime, endTime });
              } else {
                action.chooseDeliveryTimeOnV5({
                  deliveryTime: startTime,
                  endTime,
                });
              }
            }}
          />
        </View>
      ));

      return slotsLayout;
    };

    return (
      <View>
        <View style={{ height: PixelRatio.roundToNearestPixel(120) }}>
          <View style={styles.dateBoundaryLine} />
          {data.length ? (
            <Carousel
              ref={c => {
                this._carousel = c;
              }}
              firstItem={this.props.dateIndex}
              data={data}
              renderItem={this._renderDate}
              sliderWidth={width}
              itemWidth={width / 3}
              onSnapToItem={index => {
                const { pickup, data } = this.props;
                const { pickupTime } = pickup;
                const pickupYMD = moment(pickupTime).format('YYYY-MM-DD');
                const deliveryYMD = moment(data[index].day);
                // const diff = CommonUtils.getDaysDiffByYMD({ pickupYMD, deliveryYMD });
                const hs = StartOrderModule.hasExpress({
                  pickup,
                  deliveryArray: data,
                });
                if (setDateIndex) {
                  setDateIndex(index);
                  if (page === 'delivery' && !hs) {
                    OrderAction.setIsExpress(false);
                  }
                }
                page === 'delivery' &&
                  index === 0 &&
                  hs &&
                  onPressCenterModalOpen();
              }}
              inactiveSlideScale={0.8}
            />
          ) : (
            <View />
          )}
        </View>
        <View style={styles.dateBoundaryLine} />
        {eventViews}
        {data.length > 0 && TimeViewSlots()}
        {page === 'delivery' && deliveryBannerImage && deliveryBannerUrl && (
          <View
            style={{
              marginTop: PixelRatio.roundToNearestPixel(23),
              marginBottom: PixelRatio.roundToNearestPixel(19),
              marginLeft: PixelRatio.roundToNearestPixel(30),
              marginRight: PixelRatio.roundToNearestPixel(30),
            }}
          >
            <OrderAdvertiseView
              onPress={() =>
                CommonUtils.navShowModalWebView({ url: deliveryBannerUrl })
              }
              source={{ uri: deliveryBannerImage }}
              content={OrderAdvertise.content}
            />
          </View>
        )}
        <View style={{ height: PixelRatio.roundToNearestPixel(50) }} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  dateBoundaryLine: {
    height: PixelRatio.roundToNearestPixel(1),
    backgroundColor: washswatColor.grey_05,
  },
  timeBoundaryLine: {
    height: PixelRatio.roundToNearestPixel(1),
    backgroundColor: washswatColor.grey_05,
    marginStart: PixelRatio.roundToNearestPixel(30),
    marginEnd: PixelRatio.roundToNearestPixel(30),
  },
});

export default connect(
  state => ({
    deliveryBanner: state.StartOrderModule.deliveryBanner,
    popup: state.MainScreenModule.popup,
    pickup: state.StartOrderModule.pickup,
    userType: state.StartOrderModule.userType,
  }),
  dispatch => ({
    OrderAction: bindActionCreators(StartOrderModule, dispatch),
    MainScreenAction: bindActionCreators(MainScreenModule, dispatch),
  }),
)(OrderDateTime);
