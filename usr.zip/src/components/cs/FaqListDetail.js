import React from 'react';

import { PixelRatio, StyleSheet, Text, View } from 'react-native';

import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

export default function FaqListDetail(props) {
  const { contents, onLayout } = props;
  return (
    <View>
      <View style={styles.top} onLayout={onLayout}>
        <Text style={[responseFont(14).regular]}>{contents}</Text>
      </View>
      <View style={styles.empty} />
    </View>
  );
}
const styles = StyleSheet.create({
  top: {
    padding: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(24),
    paddingBottom: PixelRatio.roundToNearestPixel(24),
    backgroundColor: washswatColor.grey_05,
  },
  empty: {
    height: PixelRatio.roundToNearestPixel(0.5),
    backgroundColor: washswatColor.grey_03,
    // marginLeft: PixelRatio.roundToNearestPixel(30)
  },
});
