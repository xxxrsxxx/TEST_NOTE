import React from 'react';

import { StyleSheet, Text, View, Image, PixelRatio } from 'react-native';

import { moment } from '../../plugins';
import { Font } from '../../utils/style';

moment.locale('ko');

const { responseFont, washswatColor } = Font;

const styles = StyleSheet.create({
  newView: {
    width: 20,
    borderRadius: 10,
    height: 20,
    backgroundColor: washswatColor.red,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default function AnnouncementHeaderView(props) {
  const { title, regdate, diffDay, isActive } = props;
  const date = moment(regdate).format('YYYY.MM.DD');

  return (
    <View>
      <View style={{ paddingHorizontal: 30, paddingVertical: 24 }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <View
            style={{
              flexDirection: 'row',
              flex: 1,
              flexWrap: 'wrap',
              alignItems: 'center',
            }}
          >
            <Text
              style={[
                responseFont(14).regular,
                { color: washswatColor.black, lineHeight: 21 },
              ]}
            >
              {title}
            </Text>
            {diffDay < 8 && (
              <Image
                source={require('image/mypage/new.png')}
                style={{ width: 16, height: 16, marginLeft: 10 }}
              />
            )}
          </View>
          <Image
            source={
              isActive
                ? require('image/mypage/up_arrow_small.png')
                : require('image/mypage/down_arrow_small.png')
            }
            style={{ width: 10, height: 10, marginLeft: 17 }}
          />
        </View>
        <Text
          style={[
            responseFont(12).regular,
            {
              color: washswatColor.grey_02,
              marginTop: PixelRatio.roundToNearestPixel(6),
            },
          ]}
        >
          {date}
        </Text>
      </View>
      <View
        style={{
          height: 1,
          backgroundColor: washswatColor.grey_05,
          paddingStart: 30,
        }}
      />
    </View>
  );
}
