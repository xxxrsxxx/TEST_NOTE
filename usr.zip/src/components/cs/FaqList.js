import React from 'react';

import { Image, PixelRatio, StyleSheet, Text, View } from 'react-native';

import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

export default function FaqList(props) {
  const { title } = props;
  return (
    <View>
      <View style={styles.top}>
        <Text
          style={[
            responseFont(15).regular,
            { width: PixelRatio.roundToNearestPixel(260) },
          ]}
        >
          {title}
        </Text>
        <Image
          style={styles.image}
          source={require('image/mypage/down_arrow_small.png')}
        />
      </View>
      <View style={styles.empty} />
    </View>
  );
}
const styles = StyleSheet.create({
  top: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: PixelRatio.roundToNearestPixel(30),
    paddingRight: PixelRatio.roundToNearestPixel(20),
    paddingTop: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(26),
  },
  image: {
    width: PixelRatio.roundToNearestPixel(12),
    height: PixelRatio.roundToNearestPixel(12),
    marginRight: PixelRatio.roundToNearestPixel(15),
    resizeMode: 'contain',
  },
  empty: {
    marginLeft: PixelRatio.roundToNearestPixel(30),
    height: PixelRatio.roundToNearestPixel(0.5),
    backgroundColor: washswatColor.grey_03,
  },
});
