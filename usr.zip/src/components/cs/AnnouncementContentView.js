import React from 'react';

import { StyleSheet, View, PixelRatio } from 'react-native';
import HTML from 'react-native-render-html';
import * as CommonUtils from '../../utils/common';

import { Font } from '../../utils/style';

const { washswatColor } = Font;

export default function AnnouncementContentView(props) {
  const { content } = props;
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: washswatColor.grey_05,
        paddingStart: PixelRatio.roundToNearestPixel(30),
        paddingTop: PixelRatio.roundToNearestPixel(24),
        paddingEnd: PixelRatio.roundToNearestPixel(30),
        paddingBottom: PixelRatio.roundToNearestPixel(24),
      }}
    >
      <HTML
        html={content}
        onLinkPress={(event, href) => {
          CommonUtils.navShowModalWebView({ url: href });
        }}
      />
    </View>
  );
}
const styles = StyleSheet.create({});
