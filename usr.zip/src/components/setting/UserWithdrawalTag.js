import React from 'react';

import { StyleSheet, PixelRatio, TouchableOpacity, Text } from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function UserWithdrawalTag(props) {
  const { onPress, title } = props;
  return (
    <TouchableOpacity
      style={{
        padding: PixelRatio.roundToNearestPixel(15),
        borderWidth: PixelRatio.roundToNearestPixel(1),
        borderColor: washswatColor.blue,
        borderRadius: PixelRatio.roundToNearestPixel(3),
        alignSelf: 'flex-start',
      }}
      onPress={onPress}
    >
      <Text style={[responseFont(15).regular, { color: washswatColor.blue }]}>
        {title}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({});
