import React from 'react';
import {
  StyleSheet,
  Text,
  View ,
  Image,
  PixelRatio,
  TouchableOpacity,
} from 'react-native';

export default function ListItem(props){
  const {
    mapViewRef,
    title,
    latitude,
    longitude,
    address,
    roadAddress,
    postCode,
    isOpen,
    onPress,
    componentId
  } = props;
  return(
    <TouchableOpacity onPress={() => onPress({address, roadAddress, componentId, mapViewRef, latitude, longitude, isOpen})} activeOpacity={1} style={styles.container}>
      <View style={styles.row}>
        <Image style={styles.btnImage} source={ isOpen ? require('image/map/available.png') : require('image/map/not_available.png')}/>
      </View>
      <View>
        <Text>{title}</Text>
        <Text>{address}</Text>
        {roadAddress && roadAddress != 'undefined' ? <Text>{`[도로명]${roadAddress}`}</Text> : null }
      </View>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flex: 1,
    marginBottom: PixelRatio.roundToNearestPixel(48),
    flexDirection: 'row'
  },
  btnImage: {
    width: PixelRatio.roundToNearestPixel(12),
    height: PixelRatio.roundToNearestPixel(12)
  },
  row: {
    marginRight: PixelRatio.roundToNearestPixel(24),
    marginLeft: PixelRatio.roundToNearestPixel(30)
  }
})
