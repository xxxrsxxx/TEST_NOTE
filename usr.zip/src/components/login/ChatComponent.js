import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import PropTypes from 'prop-types';
import { TouchableOpacityActiveOne } from '../common';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { responseFont, washswatColor } = Font;

export const ChatView = props => {
  var { textObj } = props;
  var textViewArr = [],
    chatViewArr = [];

  textObj.textArr.map((oneText, i) => {
    //상세주소 입력채팅창의 '선택하신 주소는 ~ '을 위한 분기 처리
    if (oneText.textMiddle) {
      textViewArr.push(
        <View key={`leftText${i}`} style={styles.leftChatText}>
          <Text style={{ flex: 1, flexWrap: 'wrap' }}>
            <Text style={responseFont(15).regular}>
              {oneText.text}
              <BoldText text={oneText.textMiddle} />
              {oneText.textEnd}
            </Text>
          </Text>
        </View>,
      );
    } else if (oneText.customTextComponent) {
      textViewArr.push(
        <View key={`leftText${i}`} style={styles.leftChatText}>
          {oneText.customTextComponent}
        </View>,
      );
    } else {
      textViewArr.push(
        <View
          key={`leftText${i}`}
          style={{
            backgroundColor: washswatColor.grey_05,
            borderRadius: PixelRatio.roundToNearestPixel(3),
            padding: PixelRatio.roundToNearestPixel(15),
            marginBottom: PixelRatio.roundToNearestPixel(6),
          }}
        >
          <Text style={responseFont(15).regular}>{oneText.text}</Text>
        </View>,
      );
    }
  });

  chatViewArr.push(
    <View key={'chatViewArr'} style={textObj.flexWrap ? { flex: 1 } : {}}>
      {textViewArr}
    </View>,
  );

  return (
    <View style={styles.leftChatView}>
      <Image
        source={require('image/chat/profile.png')}
        style={styles.imageView}
      />
      {chatViewArr}
    </View>
  );
};

export const ChatRowLeft = props => {
  const { array, onPress } = props;

  return (
    <View style={styles.leftChatViewFrame}>
      {_.map(array, ({ text }, i) => {
        return (
          <View
            key={`leftChatViewNorMargin_${i}`}
            style={styles.leftChatViewNorMargin}
          >
            {i === 0 ? (
              <Image
                source={require('image/chat/profile.png')}
                style={styles.imageView}
              />
            ) : (
              <View style={styles.imageView}></View>
            )}
            <View
              style={{
                flexDirection: 'column',
                flexWrap: 'wrap',
                flex: text.length > 15 ? 1 : null,
              }}
            >
              <View style={{ flex: 1, flexWrap: 'wrap' }}>
                <View
                  key={`leftText${i}`}
                  style={{
                    backgroundColor: washswatColor.grey_05,
                    borderRadius: PixelRatio.roundToNearestPixel(3),
                    padding: PixelRatio.roundToNearestPixel(15),
                    marginBottom: PixelRatio.roundToNearestPixel(6),
                  }}
                >
                  <TextWithRegex
                    key={`TextWithRegex${i}`}
                    text={text}
                    onPress={onPress}
                  />
                </View>
              </View>
            </View>
          </View>
        );
      })}
    </View>
  );
};

const TextWithRegex = ({ text, onPress }) => {
  const regexGlobal = /\*\*(.+?)\*\*/g;
  const regex = /\*\*(.+?)\*\*/;
  if (regexGlobal.test(text)) {
    const backup = text.match(regexGlobal);
    const splited = text.split(regexGlobal);
    var views = [];
    _.map(splited, (o, i) => {
      if (o) {
        const finded = _.find(backup, c => c.indexOf(o) > -1);
        if (finded) {
          views.push(<BoldText key={`BoldText${i}`} text={o} />);
        } else {
          views.push(o);
        }
      }
    });
    return <Text style={responseFont(15).regular}>{views}</Text>;
  } else if (onPress) {
    return (
      <TouchableOpacity onPress={onPress}>
        <Text
          style={[
            responseFont(15).bold,
            { color: washswatColor.blue, textDecorationLine: 'underline' },
          ]}
        >
          {text}
        </Text>
      </TouchableOpacity>
    );
  } else {
    return <Text style={responseFont(15).regular}>{text}</Text>;
  }
};

export const ChatRowRight = props => {
  var { array, onPress } = props;
  var textViewArr = [];

  return (
    <View style={styles.rightChatView}>
      {_.map(array, ({ key, value, background, nextIndex }, i) => {
        if (onPress) {
          return (
            <TouchableOpacity
              onPress={() => onPress({ key, value, nextIndex })}
              key={`rightText${i}`}
              style={[
                {
                  marginBottom: PixelRatio.roundToNearestPixel(6),
                  backgroundColor: background
                    ? washswatColor.blue
                    : washswatColor.white,
                },
                styles.rightChatText,
              ]}
            >
              <Text
                style={[
                  responseFont(15).bold,
                  {
                    color: background
                      ? washswatColor.white
                      : washswatColor.blue,
                  },
                ]}
              >
                {value}
              </Text>
            </TouchableOpacity>
          );
        } else {
          return (
            <View
              key={`rightText${i}`}
              style={[
                {
                  marginBottom: PixelRatio.roundToNearestPixel(6),
                  backgroundColor: background
                    ? washswatColor.blue
                    : washswatColor.white,
                },
                styles.rightChatText,
              ]}
            >
              <Text
                style={[
                  responseFont(15).bold,
                  {
                    color: background
                      ? washswatColor.white
                      : washswatColor.blue,
                  },
                ]}
              >
                {value}
              </Text>
            </View>
          );
        }
      })}
    </View>
  );
};

//텍스트 볼드
const BoldText = ({ text }) => (
  <Text style={{ fontWeight: 'bold' }}>{text}</Text>
);

export const AnswerChatView = props => {
  var { textObj, onPress, index, activeOpacity } = props;
  var textViewArr = [];

  textObj.textArr.map((oneText, i) => {
    var { text, background } = oneText;
    textViewArr.push(
      <TouchableOpacityActiveOne
        onPress={() => onPress(index, i)}
        key={`rightText${i}`}
        style={[
          {
            marginBottom: PixelRatio.roundToNearestPixel(6),
            backgroundColor: background
              ? washswatColor.blue
              : washswatColor.white,
          },
          styles.rightChatText,
        ]}
        // activeOpacity={activeOpacity}
      >
        <Text
          style={{
            color: background ? washswatColor.white : washswatColor.blue,
          }}
        >
          {text}
        </Text>
      </TouchableOpacityActiveOne>,
    );
  });
  return <View style={styles.rightChatView}>{textViewArr}</View>;
};

ChatView.propTypes = {
  textObj: PropTypes.shape({
    textArr: PropTypes.arrayOf(
      PropTypes.shape({
        text: PropTypes.string.isRequired,
        textMiddle: PropTypes.string,
        textEnd: PropTypes.string,
        profile: PropTypes.bool,
      }),
    ).isRequired,
  }).isRequired,
};

const styles = StyleSheet.create({
  leftChatText: {
    flex: 1,
    backgroundColor: washswatColor.grey_05,
    borderRadius: PixelRatio.roundToNearestPixel(3),
    padding: PixelRatio.roundToNearestPixel(15),
    marginBottom: PixelRatio.roundToNearestPixel(6),
  },
  leftChatView: {
    flexDirection: 'row',
    paddingBottom: PixelRatio.roundToNearestPixel(24),
  },
  leftChatViewNorMargin: {
    flexDirection: 'row',
    // paddingBottom: PixelRatio.roundToNearestPixel(24)
  },
  leftChatViewFrame: {
    // flexDirection: 'row',
    paddingBottom: PixelRatio.roundToNearestPixel(24),
  },
  imageView: {
    marginRight: PixelRatio.roundToNearestPixel(9),
    width: PixelRatio.roundToNearestPixel(30),
    height: PixelRatio.roundToNearestPixel(30),
  },
  rightChatView: {
    alignItems: 'flex-end',
    paddingBottom: PixelRatio.roundToNearestPixel(24),
  },
  rightChatText: {
    borderRadius: PixelRatio.roundToNearestPixel(3),
    padding: PixelRatio.roundToNearestPixel(15),
    borderColor: washswatColor.blue,
    borderWidth: PixelRatio.roundToNearestPixel(1),
  },
});
