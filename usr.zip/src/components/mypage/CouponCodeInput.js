import React from 'react';

import {
  KeyboardAvoidingView,
  PixelRatio,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

export default function CouponCodeInput(props) {
  return (
    <KeyboardAvoidingView behavior="padding">
      <View style={styles.bottom}>
        <View style={styles.bottomText}>
          <Text
            style={[
              responseFont(18).bold,
              {
                color: washswatColor.black,
                paddingBottom: PixelRatio.roundToNearestPixel(25),
              },
            ]}
          >
            {CouponCodeInput.inputCode}
          </Text>
          <TextInput
            placeholder={CouponCodeInput.couponNumber}
            style={[responseFont(15).regular, styles.textInput]}
          ></TextInput>
        </View>
        <TouchableOpacity style={{ backgroundColor: washswatColor.black }}>
          <Text style={[responseFont(18).bold, styles.regist]}>
            {CouponCodeInput.regist}
          </Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}
const styles = StyleSheet.create({
  bottom: {
    width: '100%',
    justifyContent: 'center',
    position: 'absolute',
    bottom: PixelRatio.roundToNearestPixel(-610),
  },
  bottomText: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    padding: PixelRatio.roundToNearestPixel(20),
  },
  textInput: {
    borderBottomColor: 'black',
    borderBottomWidth: PixelRatio.roundToNearestPixel(4),
    paddingBottom: PixelRatio.roundToNearestPixel(10),
    textAlignVertical: 'top',
  },
  regist: {
    color: washswatColor.white,
    textAlign: 'center',
    padding: PixelRatio.roundToNearestPixel(20),
  },
});
