import React from 'react';

import {
  Dimensions,
  PixelRatio,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { CouponString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

import { _, moment } from '../../plugins';

const { washswatColor, responseFont } = Font;

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const scale = SCREEN_WIDTH / 400;

function normalize(size) {
  const newSize = size * scale;
  if (Platform.OS === 'ios') {
    return Math.round(PixelRatio.roundToNearestPixel(newSize));
  } else {
    return Math.round(PixelRatio.roundToNearestPixel(newSize)) - 2;
  }
}

function getCouponTitle(coupon) {
  const { useType, loop } = coupon;
  if (useType === 'member') {
    if (loop) {
      const { index } = loop;
      // 연쇄쿠폰
      let number = index < 10 ? '0' + index : index;
      return CouponString.chainCoupon + ' ' + number;
    } else {
      // 멤버십쿠폰
      return CouponString.membershipCoupon;
    }
  } else {
    return 'none';
  }
}

function isChainCoupon(coupon) {
  const { loop } = coupon;
  return loop;
}

function getDDay(coupon) {
  const { startDate, loop } = coupon;
  if (moment().isBefore(startDate) && loop) {
    const day = moment(startDate).diff(moment(), 'days');
    return 'D-' + day;
  }
  return undefined;
}

function isCouponDisabled(coupon) {
  return isChainCoupon(coupon) && getDDay(coupon);
}

export default function Coupon(props) {
  const { coupon, seletedCoupon, pressCoupon } = props;
  const {
    _id,
    useType,
    name,
    comment,
    validate,
    couponDetail,
    startDate,
    loop,
  } = coupon;
  // 쿠폰 타이틀
  const couponViewWidth = PixelRatio.roundToNearestPixel(42);
  const couponViewHeight = PixelRatio.roundToNearestPixel(150);
  const couponViewOffset = couponViewHeight / 2 - couponViewWidth / 2;
  // 쿠폰색상 설정
  let couponTitleColor = washswatColor.blue;
  let backgroundColor = washswatColor.blue;
  let fontColor = washswatColor.white;
  let borderColor = washswatColor.blue;
  if (seletedCoupon) {
    /** 쿠폰을 선택하는 페이지 (결제할때 등등) **/
    const finded = _.find(seletedCoupon || [], { _id });
    if (finded) {
      /** 이 쿠폰은 선택된 경우. 이건 파란색 **/
      backgroundColor = washswatColor.blue;
      fontColor = washswatColor.white;
    } else {
      /** 선택되지 않은쿠폰. 회색으로 칠하자 **/
      backgroundColor = washswatColor.white;
      fontColor = washswatColor.blue;
    }
  } else {
    /** 일반적인 쿠폰페이지. 그냥 파란색으로 칠하면된다.  **/
    if (loop) {
      // 연쇄쿠폰 설정
      if (isChainCoupon(coupon)) {
        couponTitleColor = washswatColor.blueOpacity14;
        backgroundColor = washswatColor.blueOpacity14;
        borderColor = washswatColor.transparent;
      }
    } else {
      backgroundColor = washswatColor.blue;
    }
    fontColor = washswatColor.white;
  }
  // 쿠폰 왼쪽에 오려낸 부분
  let leftCutOutViews = [];
  for (var i = 0; i < 8; i++) {
    leftCutOutViews.push(
      <View
        key={i}
        style={[styles.leftCutOutViews, { borderColor: borderColor }]}
      />,
    );
  }
  // 유효기간
  const editedValidate = validate.replace('· ', '');
  return (
    <View style={{ backgroundColor: washswatColor.grey_05 }}>
      <View style={{ flexDirection: 'row', height: couponViewHeight }}>
        <View
          style={{
            width: couponViewHeight,
            height: couponViewWidth,
            transform: [
              { rotate: '270deg' },
              { translateX: -couponViewOffset },
              { translateY: -couponViewOffset },
            ],
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Text
            style={[
              responseFont(14).regular,
              {
                color:
                  useType === 'member' ? couponTitleColor : washswatColor.white,
              },
            ]}
          >
            {getCouponTitle(coupon)}
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => pressCoupon(coupon)}
          style={{
            flexDirection: 'row',
            flex: 1,
            marginLeft: -(couponViewHeight - couponViewWidth),
            backgroundColor,
            borderWidth: 1,
            borderColor: borderColor,
          }}
          disabled={isCouponDisabled(coupon)}
        >
          <View>{leftCutOutViews}</View>
          <View style={styles.couponContentView}>
            {!isCouponDisabled(coupon) ? (
              // 사용할 수 있는 쿠폰
              <View
                style={{
                  paddingLeft: PixelRatio.roundToNearestPixel(30),
                  paddingRight: PixelRatio.roundToNearestPixel(36),
                }}
              >
                <Text
                  style={[
                    responseFont(30).bold,
                    { color: fontColor, fontSize: normalize(30) },
                  ]}
                  numberOfLines={2}
                  ellipsizeMode={'tail'}
                >
                  {name}
                </Text>
                <Text
                  style={[
                    responseFont(15).regular,
                    {
                      color: fontColor,
                      lineHeight: PixelRatio.roundToNearestPixel(24),
                      marginTop: PixelRatio.roundToNearestPixel(15),
                    },
                  ]}
                >
                  {comment + '\n' + editedValidate}
                </Text>
              </View>
            ) : (
              // 사용할 수 없는 쿠폰
              <View style={{ alignItems: 'center' }}>
                <Text style={[responseFont(30).bold, { color: fontColor }]}>
                  {getDDay(coupon)}
                </Text>
              </View>
            )}
          </View>
        </TouchableOpacity>
      </View>
      <View style={{ height: PixelRatio.roundToNearestPixel(30) }} />
      {!isCouponDisabled(coupon) && (
        <View style={styles.couponDetailView}>
          <Text
            style={[
              responseFont(15).regular,
              {
                color: washswatColor.black,
                lineHeight: PixelRatio.roundToNearestPixel(21),
              },
            ]}
          >
            {couponDetail}
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  leftCutOutViews: {
    marginLeft: PixelRatio.roundToNearestPixel(-2.5),
    marginTop: PixelRatio.roundToNearestPixel(5),
    marginBottom: PixelRatio.roundToNearestPixel(4),
    height: PixelRatio.roundToNearestPixel(9),
    width: PixelRatio.roundToNearestPixel(9),
    borderRadius: PixelRatio.roundToNearestPixel(20),
    backgroundColor: washswatColor.grey_05,
    borderTopWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
  },
  couponContentView: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  couponDetailView: {
    marginLeft: PixelRatio.roundToNearestPixel(42),
    marginRight: PixelRatio.roundToNearestPixel(30),
    marginBottom: PixelRatio.roundToNearestPixel(60),
  },
});
