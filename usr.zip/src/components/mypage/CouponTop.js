import React from 'react';

import {
  StyleSheet,
  View,
  PixelRatio,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';

import { CouponTopString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function CouponTop(props) {
  const { code, onChangeCouponCode, setCouponCode, onPress } = props;
  const source = code
    ? require('../../../assets/image/mypage/add_active.png')
    : require('../../../assets/image/mypage/add.png');
  return (
    <View style={[styles.rootView]}>
      <TextInput
        style={[
          responseFont(15).regular,
          { color: washswatColor.black, flex: 1 },
        ]}
        placeholder={CouponTopString.hint}
        returnKeyType="done"
        value={code}
        onChangeText={onChangeCouponCode}
        placeholderTextColor={washswatColor.grey_02}
        onSubmitEditing={setCouponCode}
      />
      <TouchableOpacity onPress={setCouponCode}>
        <Image
          style={{
            width: PixelRatio.roundToNearestPixel(30),
            height: PixelRatio.roundToNearestPixel(30),
          }}
          source={source}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  rootView: {
    flexDirection: 'row',
    backgroundColor: washswatColor.white,
    height: PixelRatio.roundToNearestPixel(48),
    borderRadius: PixelRatio.roundToNearestPixel(60),
    paddingStart: PixelRatio.roundToNearestPixel(18),
    paddingEnd: PixelRatio.roundToNearestPixel(9),
    marginStart: PixelRatio.roundToNearestPixel(42),
    marginEnd: PixelRatio.roundToNearestPixel(42),
    alignItems: 'center',
  },
});
