import React from 'react';
import { Text, View, PixelRatio, StyleSheet } from 'react-native';
import { Font } from '../../utils/style';
import { SettingsString } from '../../utils/common/strings/index';
const { responseFont, washswatColor } = Font;

const ProfileUserInfo = ({ userInfo }) => {
  return (
    <View>
      <View>
        <Text
          style={styles.title}
        >{`${userInfo.userName}${SettingsString.sir}`}</Text>
      </View>
      <View style={styles.textArea}>
        <Text style={styles.text}>
          {userInfo.userType === 'Member' ? userInfo.userType : 'Basic'} 회원
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  title: {
    alignItems: 'center',
    ...responseFont(20).bold,
  },
  textArea: {
    alignSelf: 'flex-start',
    justifyContent: 'center',
    height: 18,
    paddingHorizontal: 4,
    marginTop: 6,
    borderRadius: 2,
    backgroundColor: washswatColor.blue,
  },
  text: {
    ...responseFont(11).bold,
    color: washswatColor.white,
  },
});

export default ProfileUserInfo;
