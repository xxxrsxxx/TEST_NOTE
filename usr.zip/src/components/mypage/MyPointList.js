import React from 'react';

import { StyleSheet, Text, View, PixelRatio } from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export default function MyPointList(props) {
  const { titleLabel, dateString, point, isPlus } = props;
  let points = isPlus
    ? `${numberWithCommas(point)}`
    : `-${numberWithCommas(point)}`;
  let pointColors = isPlus
    ? { color: washswatColor.blue }
    : { color: washswatColor.black };

  return (
    <View style={styles.rootView}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text
          style={[responseFont(15).regular, { color: washswatColor.black }]}
        >
          {titleLabel}
        </Text>
        <Text style={[responseFont(15).bold, pointColors]}>{`${points}p`}</Text>
      </View>
      <Text
        style={[
          responseFont(13).regular,
          {
            color: washswatColor.grey_02,
            marginTop: PixelRatio.roundToNearestPixel(6),
          },
        ]}
      >
        {dateString}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  rootView: {
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(21),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(21),
  },
});
