import React from 'react';
import {
  StyleSheet,
  Text,
  Image,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function CodeRegistrationButton(props) {
  const { onPress, title } = props;

  return (
    <TouchableOpacity
      onPress={onPress}
      style={styles.accumulationCodeRegistration}
    >
      <Text style={[responseFont(15).bold, { color: washswatColor.white }]}>
        {title}
      </Text>
      <Image
        style={{
          width: PixelRatio.roundToNearestPixel(30),
          height: PixelRatio.roundToNearestPixel(30),
        }}
        source={require('image/mypage/add.png')}
      />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  accumulationCodeRegistration: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: washswatColor.black,
    height: PixelRatio.roundToNearestPixel(72),
    paddingStart: PixelRatio.roundToNearestPixel(24),
    paddingEnd: PixelRatio.roundToNearestPixel(18),
  },
});
