import React from 'react';

import { Text, View, PixelRatio } from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function PaymentBuyBulletNoticeContent(props) {
  const { content } = props;
  return (
    <View>
      <View style={{ flexDirection: 'row' }}>
        <Text
          style={[responseFont(14).regular, { color: washswatColor.black }]}
        >
          ⋅
        </Text>
        <Text
          style={[
            responseFont(14).regular,
            {
              color: washswatColor.black,
              lineHeight: PixelRatio.roundToNearestPixel(21),
              marginStart: PixelRatio.roundToNearestPixel(6),
            },
          ]}
        >
          {content}
        </Text>
      </View>
    </View>
  );
}
