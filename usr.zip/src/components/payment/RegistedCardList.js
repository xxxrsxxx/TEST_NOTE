import React from 'react';

import {
  Image,
  PixelRatio,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

export default function RegistedCardList(props) {
  const { cardName, isDefault, billKey, onPress, setDefault } = props;
  const defalut = isDefault
    ? require('../../../assets/image/Payment/available.png')
    : require('../../../assets/image/Payment/disAvailable.png');

  return (
    <View>
      <View style={styles.top}>
        <View style={{ flexDirection: 'column' }}>
          <View style={styles.cardName}>
            <TouchableOpacity
              style={styles.cardName}
              onPress={() => setDefault && setDefault({ billKey })}
            >
              <Image style={styles.image} source={defalut} />
              <Text style={[responseFont(15).bold]}>{cardName}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => onPress(billKey)}
              style={{ alignItems: 'center' }}
            >
              <Image
                style={styles.deleteImage}
                source={require('image/Payment/delete.png')}
              />
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <View style={styles.bottom}></View>
    </View>
  );
}

const styles = StyleSheet.create({
  top: {
    paddingTop: PixelRatio.roundToNearestPixel(25),
    paddingRight: PixelRatio.roundToNearestPixel(30),
    paddingLeft: PixelRatio.roundToNearestPixel(40),
    paddingBottom: PixelRatio.roundToNearestPixel(25),
  },
  cardName: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  image: {
    width: PixelRatio.roundToNearestPixel(12),
    height: PixelRatio.roundToNearestPixel(12),
    marginRight: PixelRatio.roundToNearestPixel(15),
    resizeMode: 'contain',
  },
  deleteImage: {
    width: PixelRatio.roundToNearestPixel(30),
    height: PixelRatio.roundToNearestPixel(30),
    resizeMode: 'contain',
  },
  bottom: {
    height: PixelRatio.roundToNearestPixel(0.5),
    backgroundColor: washswatColor.grey_03,
    marginLeft: PixelRatio.roundToNearestPixel(30),
  },
});
