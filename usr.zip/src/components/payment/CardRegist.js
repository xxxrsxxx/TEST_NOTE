import React from 'react';

import {
  Image,
  PixelRatio,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { CardRegistString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

export default function CardRegist(props) {
  const moveToPage = props.moveToPage;

  return (
    <TouchableOpacity onPress={moveToPage}>
      <View style={styles.top}></View>
      <View style={styles.wrap}>
        <View style={{ flexDirection: 'column' }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}
            >
              <Text style={[responseFont(18).bold]}>
                {CardRegistString.titleLabel}
              </Text>
              <Text style={[responseFont(15).regular]}>
                {CardRegistString.content}
              </Text>
            </View>
            <View style={{ alignItems: 'center' }}>
              <Image
                style={styles.image}
                source={require('image/Order/Ordering/SelectType/add.png')}
              />
            </View>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  top: {
    height: PixelRatio.roundToNearestPixel(2),
    marginLeft: PixelRatio.roundToNearestPixel(30),
    backgroundColor: washswatColor.black,
  },
  wrap: {
    padding: PixelRatio.roundToNearestPixel(40),
    paddingRight: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(30),
  },
  image: {
    width: PixelRatio.roundToNearestPixel(30),
    height: PixelRatio.roundToNearestPixel(30),
    resizeMode: 'contain',
  },
});
