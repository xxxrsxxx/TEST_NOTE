import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
  Platform,
} from 'react-native';

import { PaymentBuyBulletItemString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function PaymentBuyBulletItem(props) {
  const { onPress, payment, CoinAction } = props;
  const { value, bonus, memberBonus } = payment;
  return (
    <TouchableOpacity style={styles.rootView} onPress={onPress}>
      <View
        style={{
          width: '100%',
          height: '100%',
          paddingStart: PixelRatio.roundToNearestPixel(30),
          paddingTop: PixelRatio.roundToNearestPixel(20),
          paddingEnd: PixelRatio.roundToNearestPixel(30),
          paddingBottom: PixelRatio.roundToNearestPixel(20),
          backgroundColor: washswatColor.white,
        }}
      >
        <View style={{ flexDirection: 'row' }}>
          <Text style={[responseFont(45).bold, { color: washswatColor.black }]}>
            {value / 10000}
          </Text>
          <View
            style={{
              justifyContent: 'flex-end',
              marginStart: PixelRatio.roundToNearestPixel(4),
              marginBottom: PixelRatio.roundToNearestPixel(10),
            }}
          >
            <Text
              style={[responseFont(18).bold, { color: washswatColor.black }]}
            >
              {PaymentBuyBulletItemString.tenThousandWon}
            </Text>
          </View>
        </View>
        <Text style={[responseFont(18).bold, { color: washswatColor.red }]}>
          {`멤버십회원 보너스 ${numberWithCommas(memberBonus)}원`}
        </Text>
        {bonus ? (
          <Text
            style={[
              responseFont(18).bold,
              {
                color: washswatColor.black,
                marginTop: PixelRatio.roundToNearestPixel(4),
              },
            ]}
          >
            {`일반회원 보너스 ${numberWithCommas(bonus)}원`}
          </Text>
        ) : null}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  rootView: {
    // width: PixelRatio.roundToNearestPixel(300),
    width: '100%',
    height: PixelRatio.roundToNearestPixel(144),
    ...Platform.select({
      ios: {
        shadowColor: washswatColor.black,
        shadowOffset: {
          width: PixelRatio.roundToNearestPixel(0),
          height: PixelRatio.roundToNearestPixel(12),
        },
        shadowOpacity: 0.14,
        shadowRadius: PixelRatio.roundToNearestPixel(24),
      },
      android: {
        backgroundColor: washswatColor.grey_01,
        elevation: 5,
      },
    }),
  },
});

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
