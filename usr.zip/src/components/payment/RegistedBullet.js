import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import * as CommonUtils from '../../utils/common';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export default function RegistedBullet(props) {
  const { bullet, componentId } = props;
  if (bullet === 0) {
    return null;
  } else {
    return (
      <View>
        <View style={styles.top}>
          <View style={{ flexDirection: 'column' }}>
            <View style={styles.available}>
              <TouchableOpacity
                style={styles.available}
                onPress={() =>
                  CommonUtils.navPush({
                    componentId,
                    name: 'BulletHistoryScreen',
                  })
                }
              >
                <Image
                  style={styles.image}
                  source={require('image/Payment/available.png')}
                />
                <Text style={[responseFont(15).bold]}>{`총알 ${numberWithCommas(
                  bullet,
                )}`}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <View style={styles.bottom}></View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  top: {
    paddingTop: PixelRatio.roundToNearestPixel(25),
    paddingRight: PixelRatio.roundToNearestPixel(30),
    paddingLeft: PixelRatio.roundToNearestPixel(40),
    paddingBottom: PixelRatio.roundToNearestPixel(25),
  },
  image: {
    width: PixelRatio.roundToNearestPixel(12),
    height: PixelRatio.roundToNearestPixel(12),
    marginRight: PixelRatio.roundToNearestPixel(15),
    resizeMode: 'contain',
  },
  available: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  bottom: {
    height: PixelRatio.roundToNearestPixel(0.5),
    backgroundColor: washswatColor.grey_03,
    marginLeft: PixelRatio.roundToNearestPixel(30),
  },
});
