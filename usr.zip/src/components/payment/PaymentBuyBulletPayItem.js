import React from 'react';

import { Text, TouchableOpacity, PixelRatio } from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function PaymentBuyBulletPayItem(props) {
  const { onPress, title, content } = props;
  return (
    <TouchableOpacity
      onPress={onPress}
      style={{
        height: PixelRatio.roundToNearestPixel(150),
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <Text style={[responseFont(30).bold, { color: washswatColor.grey_03 }]}>
        {title}
      </Text>
      <Text
        style={[
          responseFont(16).regular,
          {
            color: washswatColor.grey_03,
            lineHeight: PixelRatio.roundToNearestPixel(24),
            marginTop: PixelRatio.roundToNearestPixel(9),
          },
        ]}
      >
        {content}
      </Text>
    </TouchableOpacity>
  );
}
