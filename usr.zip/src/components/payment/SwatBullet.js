import React from 'react';

import {
  Image,
  PixelRatio,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { SwatBulletString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont } = Font;

export default function SwatBullet(props) {
  return (
    <TouchableOpacity onPress={props.onPress}>
      <View style={styles.top}>
        <View style={{ flexDirection: 'column' }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}
            >
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'flex-start',
                }}
              >
                <Text
                  style={[
                    responseFont(18).bold,
                    { marginRight: PixelRatio.roundToNearestPixel(10) },
                  ]}
                >
                  {SwatBulletString.titleLabel}
                </Text>
              </View>
              <Text style={[responseFont(15).regular]}>
                {SwatBulletString.content}
              </Text>
            </View>
            <View style={{ alignItems: 'center' }}>
              <Image
                style={{
                  width: PixelRatio.roundToNearestPixel(30),
                  height: PixelRatio.roundToNearestPixel(30),
                  resizeMode: 'contain',
                }}
                source={require('image/Order/Ordering/SelectType/add.png')}
              />
            </View>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  top: {
    padding: PixelRatio.roundToNearestPixel(40),
    paddingRight: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(30),
  },
});
