import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
  BackHandler,
  Platform,
} from 'react-native';
import Modal from 'react-native-modalbox';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as LoginActions from '../../reducers/LoginModule';

import * as CommonUtils from '../../utils/common';
import { Favorite, UpdatePopupString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

class UpdatePopup extends React.Component {
  render() {
    const { LoginState } = this.props;
    const { updateHard, updateSelect } = LoginState;
    let content =
      (updateHard && UpdatePopupString.updateHard) ||
      (updateSelect && UpdatePopupString.updateSelect);
    return (
      <Modal
        isOpen={updateHard || updateSelect}
        style={{
          width: PixelRatio.roundToNearestPixel(300),
          height: PixelRatio.roundToNearestPixel(151),
          backgroundColor: washswatColor.white,
        }}
        swipeToClose={false}
        position="center"
        backdropPressToClose={false}
      >
        <View
          style={{
            height: 100,
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: washswatColor.white,
          }}
        >
          <Text style={[responseFont(14).bold, { color: washswatColor.black }]}>
            {content}
          </Text>
        </View>
        <View style={{ height: 1, backgroundColor: washswatColor.black }} />
        <View style={{ flex: 1, flexDirection: 'row' }}>
          {!updateHard && (
            <TouchableOpacity
              onPress={() => {
                if (updateHard) {
                  if (Platform.OS === 'android') {
                    BackHandler.exitApp();
                  } else {
                  }
                }
                if (updateSelect) {
                  CommonUtils.setNavigationRoot();
                }
              }}
              style={[styles.button, { backgroundColor: washswatColor.white }]}
            >
              <Text
                style={[
                  responseFont(14).regular,
                  { color: washswatColor.black },
                ]}
              >
                {Favorite.no}
              </Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            onPress={() => {
              CommonUtils.goAppStore();
            }}
            style={[styles.button, { backgroundColor: washswatColor.black }]}
          >
            <Text
              style={[responseFont(14).regular, { color: washswatColor.white }]}
            >
              {Favorite.yes}
            </Text>
          </TouchableOpacity>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  button: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});

const mapStateToProps = ({ LoginModule }) => ({
  LoginState: LoginModule,
});
const mapDispatchToProps = dispatch => ({
  LoginAction: bindActionCreators(LoginActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(UpdatePopup);
