import React from 'react';

import {
  StyleSheet,
  View,
  PixelRatio,
  TouchableOpacity,
  Image,
  Text,
} from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function AddressChangeItemView(props) {
  const {
    selectedImageSource,
    title,
    address,
    onPressAddress,
    onPressDelete,
    valid,
    addressOthers,
  } = props;
  return (
    <TouchableOpacity style={styles.rootView} onPress={onPressAddress}>
      <Image
        source={selectedImageSource}
        style={{
          width: PixelRatio.roundToNearestPixel(12),
          height: PixelRatio.roundToNearestPixel(12),
        }}
      />
      <View
        style={{ marginStart: PixelRatio.roundToNearestPixel(24), flex: 1 }}
      >
        <Text style={[responseFont(16).bold, { color: washswatColor.black }]}>
          {title}
        </Text>
        <Text style={[responseFont(14).regular, styles.addressText]}>
          {address}
        </Text>
        <Text style={[responseFont(14).regular, styles.addressText]}>
          {addressOthers}
        </Text>
      </View>
      {!valid && (
        <TouchableOpacity onPress={onPressDelete}>
          <Image
            source={require('image/mypage/address_delete.png')}
            style={{
              width: PixelRatio.roundToNearestPixel(30),
              height: PixelRatio.roundToNearestPixel(30),
            }}
          />
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  rootView: {
    flexDirection: 'row',
    paddingStart: PixelRatio.roundToNearestPixel(30),
    paddingTop: PixelRatio.roundToNearestPixel(28),
    paddingEnd: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(28),
    alignItems: 'center',
  },
  addressText: {
    color: washswatColor.black,
    lineHeight: PixelRatio.roundToNearestPixel(21),
    marginTop: PixelRatio.roundToNearestPixel(6),
  },
});
