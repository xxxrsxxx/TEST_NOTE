import React from 'react';

import {
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';
import Swiper from 'react-native-swiper';

import { Font } from '../../utils/style';
import * as CommonUtils from '../../utils/common';

import { _ } from '../../plugins';

const { washswatColor } = Font;

export default function MainAd(props) {
  const { onPressAction, banner } = props;
  if (banner && banner.length > 0) {
    return (
      <View style={{ height: PixelRatio.roundToNearestPixel(103) }}>
        <Swiper
          autoplay={true}
          autoplayTimeout={4.5}
          index={0}
          paginationStyle={{ bottom: PixelRatio.roundToNearestPixel(9) }}
          dot={<View style={styles.swiperDotView} />}
          activeDot={<View style={styles.swiperActiveDotView} />}
        >
          {_.map(banner, (o, index) => {
            const {
              banner: { image, imageV5, imageV6 },
              content: { url },
              type,
              _id,
            } = o;
            return (
              <TouchableOpacity
                key={`imageBanner${_id}`}
                onPress={() => onPressAction({ type, url })}
                style={{ height: '100%' }}
              >
                <Image
                  source={{ uri: CommonUtils.replaceHttpToHttps(imageV6) }}
                  style={{
                    width: '100%',
                    height: '100%',
                    resizeMode: 'contain',
                  }}
                />
              </TouchableOpacity>
            );
          })}
        </Swiper>
      </View>
    );
  } else {
    return <View />;
  }
}

const styles = StyleSheet.create({
  swiperDotView: {
    backgroundColor: washswatColor.grey_05,
    width: PixelRatio.roundToNearestPixel(4),
    height: PixelRatio.roundToNearestPixel(4),
    borderRadius: PixelRatio.roundToNearestPixel(2),
    marginStart: PixelRatio.roundToNearestPixel(5),
    marginEnd: PixelRatio.roundToNearestPixel(5),
  },
  swiperActiveDotView: {
    backgroundColor: washswatColor.black,
    width: PixelRatio.roundToNearestPixel(4),
    height: PixelRatio.roundToNearestPixel(4),
    borderRadius: PixelRatio.roundToNearestPixel(2),
    marginStart: PixelRatio.roundToNearestPixel(5),
    marginEnd: PixelRatio.roundToNearestPixel(5),
  },
});
