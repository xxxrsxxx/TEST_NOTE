import React from 'react';
import { StyleSheet, View, Dimensions } from 'react-native';
import PropTypes from 'prop-types';
// components import
import ServiceButton from './ServiceButton';

function ServiceButtonGroup({ serviceList, onPressService, style }) {
  const drawButtons = () => {
    const buttons = serviceList.map((service, index) => {
      if (service.isValid)
        return (
          <View style={styles.serviceContainer} key={service.key}>
            <ServiceButton service={service} onPressService={onPressService} />
          </View>
        );
    });
    return buttons;
  };
  return <View style={[styles.container, style]}>{drawButtons()}</View>;
}

ServiceButtonGroup.defaultProps = {
  serviceList: [],
  onPressService: () => {},
  style: {},
};

ServiceButtonGroup.propTypes = {
  serviceList: PropTypes.array.isRequired,
  onPressService: PropTypes.func.isRequired,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  container: {
    width: Dimensions.get('window').width - 30, // 디자인 상에 ButtonGroup Layout을 맞추기 위해 전체간격에서 좌우 15 padding된 수치적용
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  serviceContainer: {
    marginBottom: 24,
    width: '25%',
    alignItems: 'center',
  },
  serviceName: {},
});

export default ServiceButtonGroup;
