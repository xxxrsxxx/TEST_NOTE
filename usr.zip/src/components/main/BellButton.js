import React from 'react';
import { StyleSheet, Image } from 'react-native';
import PropTypes from 'prop-types';
// component import
import { TouchableOpacityActiveOne, CircleShape } from '../common';
// style import
import { Font } from '../../utils/style';
const { washswatColor } = Font;

function BellButton({ onPress, style, badge }) {
  return (
    <TouchableOpacityActiveOne
      style={[styles.bellIconBtn, style]}
      onPress={onPress}
    >
      {badge ? (
        <CircleShape
          style={styles.iconWrap}
          length={5}
          backgroundColor={washswatColor.red_20}
        />
      ) : null}
      <Image
        style={styles.bellIcon}
        source={require('../../../assets/image/main/bell/Ic_notification.png')}
      />
    </TouchableOpacityActiveOne>
  );
}

BellButton.defaultProps = {
  onPress: () => {},
  badge: 0,
  style: {},
};

BellButton.propTypes = {
  onPress: PropTypes.func,
  badge: PropTypes.number.isRequired,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  bellIconBtn: {
    width: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bellIcon: {
    width: '100%',
    height: '100%',
  },
  iconWrap: {
    position: 'absolute',
    right: -3,
    top: 2,
    zIndex: 1,
  },
});

export default BellButton;
