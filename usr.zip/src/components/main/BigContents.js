import React, { useRef, useEffect } from 'react';
import { StyleSheet, View, Text, FlatList, Image } from 'react-native';
import PropTypes from 'prop-types';
// components import
import { TouchableOpacityActiveOne } from '../common';
// styles import
import { Font, Styles } from '../../utils/style';
const { HOME_SCROLL_TOP_BTN_THRESHOLD } = Styles;
const { washswatColor, responseFont } = Font;

function BigContents({
  MainScreenState,
  offScrollTopEvent,
  onScrollTopVisible,
  offScrollTopVisible,
  getContents,
  onPressContents,
  headerComponents,
  contentsStyle,
  style,
}) {
  const scrollRef = useRef();
  const { contentsData, isScrollTopEvent, scrollTopVisible } = MainScreenState;
  const { contentsBoard } = contentsData;

  useEffect(() => {
    if (isScrollTopEvent) {
      scrollTopEvent();
      offScrollTopEvent();
    }
  }, [isScrollTopEvent]);

  const scrollTopEvent = () => {
    scrollRef.current.scrollToOffset({ animated: true, offset: 0 });
  };

  const onScrollEvent = e => {
    if (
      e.nativeEvent.contentOffset.y > HOME_SCROLL_TOP_BTN_THRESHOLD &&
      scrollTopVisible == false
    )
      onScrollTopVisible();
    else if (
      e.nativeEvent.contentOffset.y <= HOME_SCROLL_TOP_BTN_THRESHOLD &&
      scrollTopVisible == true
    )
      offScrollTopVisible();
  };

  const footerComponents = () => {
    return <View style={styles.footer} />;
  };

  return (
    <View style={style}>
      <FlatList
        data={contentsBoard}
        renderItem={({ item }) => (
          <TouchableOpacityActiveOne
            style={[styles.container, contentsStyle]}
            onPress={() => onPressContents(item)}
          >
            <View style={[styles.imageContainer, styles.imageBorder]}>
              <Image
                style={[styles.image, styles.imageBorder]}
                source={{ uri: item.image }}
              />
              <View style={styles.categoryContainer}>
                {item.tags.map((tag, index) => (
                  <View style={styles.category} key={index}>
                    <Text style={styles.categoryText}>{tag.keyword}</Text>
                  </View>
                ))}
              </View>
            </View>
            <View style={styles.title}>
              <Text style={styles.titleText}>{item.title}</Text>
            </View>
            <View style={styles.subTitle}>
              <Text style={styles.subTitleText}>{item.subTitle}</Text>
            </View>
          </TouchableOpacityActiveOne>
        )}
        keyExtractor={item => String(item.idx)}
        nestedScrollEnabled
        showsVerticalScrollIndicator={false}
        onEndReached={getContents}
        scrollEventThrottle={200}
        onEndReachedThreshold={0.01}
        ref={scrollRef}
        onScroll={onScrollEvent}
        ListHeaderComponent={headerComponents}
        ListFooterComponent={footerComponents}
      />
    </View>
  );
}

BigContents.defaultProps = {
  MainScreenState: null,
  offScrollTopEvent: () => {},
  onScrollTopVisible: () => {},
  offScrollTopVisible: () => {},
  getContents: () => {},
  onPressContents: () => {},
  headerComponents: null,
  contentsStyle: {},
  style: {},
};

BigContents.propTypes = {
  MainScreenState: PropTypes.object,
  offScrollTopEvent: PropTypes.func,
  onScrollTopVisible: PropTypes.func,
  offScrollTopVisible: PropTypes.func,
  getContents: PropTypes.func,
  onPressContents: PropTypes.func,
  headerComponents: PropTypes.oneOfType([PropTypes.array, PropTypes.element]),
  contentsStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 40,
  },
  imageContainer: {
    marginBottom: 16,
    height: 220,
    backgroundColor: washswatColor.black_60,
  },
  imageBorder: {
    borderRadius: 8,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  categoryContainer: {
    position: 'absolute',
    flexDirection: 'row',
    marginLeft: 16,
    marginTop: 16,
  },
  category: {
    paddingTop: 2,
    marginRight: 4, // 서버에서 tag를 array로 넘겨줘서 margin갑을 임의로 넣음 by charles
    height: 20,
    borderRadius: 2,
    alignSelf: 'flex-start',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: washswatColor.white,
  },
  categoryText: {
    marginLeft: 4,
    marginRight: 4,
    ...responseFont(11).bold,
  },
  title: {
    marginBottom: 8,
  },
  titleText: {
    ...responseFont(20).bold,
    color: washswatColor.black_10,
  },
  subTitle: {},
  subTitleText: {
    ...responseFont(12).regular,
    color: washswatColor.black_40,
  },
  footer: {
    height: 50,
  },
});

export default BigContents;
