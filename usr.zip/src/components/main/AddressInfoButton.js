import React from 'react';
import { StyleSheet, Text, Image } from 'react-native';
import PropTypes from 'prop-types';
// components import
import { TouchableOpacityActiveOne } from '../common';
// styles import
import { Font } from '../../utils/style';
const { washswatColor, responseFont } = Font;

function AddressInfoButton({ addressText, style, onPressAddress }) {
  return (
    <TouchableOpacityActiveOne
      style={[styles.addressContainer, style]}
      onPress={onPressAddress}
    >
      <Text numberOfLines={1} style={styles.addressText}>
        {addressText}
      </Text>
      <Image
        style={styles.arrowIcon}
        source={require('../../../assets/image/main/arrow/Icon_arrow.png')}
      />
    </TouchableOpacityActiveOne>
  );
}

AddressInfoButton.defaultProps = {
  addressText: '',
  style: {},
  onPressAddress: () => {},
};

AddressInfoButton.propTypes = {
  addressText: PropTypes.string.isRequired,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  onPressAddress: PropTypes.func.isRequired,
};

const styles = StyleSheet.create({
  addressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 4,
    backgroundColor: washswatColor.grey_05,
  },
  addressText: {
    width: '80%',
    marginLeft: 16,
    ...responseFont(12).regular,
    color: washswatColor.black_10,
  },
  arrowIcon: {
    marginRight: 8,
    width: 24,
    height: 24.6,
  },
});

export default AddressInfoButton;
