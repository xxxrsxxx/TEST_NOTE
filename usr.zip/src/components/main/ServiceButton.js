import React from 'react';
import { StyleSheet, Image, Text, View } from 'react-native';
import PropTypes from 'prop-types';
// component import
import { TouchableOpacityActiveOne, CircleShape } from '../common';
// style import
import { Font } from '../../utils/style';
const { washswatColor, responseFont } = Font;

function ServiceButton({ service, onPressService, style }) {
  const serviceBtn = () => {
    switch (service.service) {
      case 'main':
        return (
          <>
            {service.new ? (
              <Image
                style={styles.newIcon}
                source={require('../../../assets/image/main/new-icon/ic_new.png')}
              />
            ) : null}
            <Image style={styles.serviceIcon} source={service.source} />
            <Text style={styles.serviceTitle}>{service.title}</Text>
          </>
        );
      case 'sub':
        return (
          <>
            <Image style={styles.serviceIcon} source={service.source} />
            <View style={styles.titleContainer}>
              <Text style={styles.serviceTitle}>{service.title}</Text>
              {service.new ? (
                <CircleShape
                  style={styles.newDot}
                  length={5}
                  backgroundColor={washswatColor.red_20}
                />
              ) : null}
            </View>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <TouchableOpacityActiveOne
      style={[styles.container, style]}
      onPress={() => onPressService(service)}
    >
      {serviceBtn()}
    </TouchableOpacityActiveOne>
  );
}

ServiceButton.defaultProps = {
  service: {
    service: '',
    title: '',
    source: null,
  },
  onPressService: () => {},
  style: {},
};

ServiceButton.propsTypes = {
  service: PropTypes.shape({
    service: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    title: PropTypes.number.isRequired,
  }).isRequired,
  onPressService: PropTypes.func.isRequired,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  container: {
    width: 56,
    height: 76,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  serviceIcon: {
    width: 55,
    height: 55,
  },
  titleContainer: {
    flexDirection: 'row',
  },
  serviceTitle: {
    ...responseFont(12).regular,
    color: washswatColor.black_20,
  },
  newIcon: {
    position: 'absolute',
    right: 4,
    top: 3,
    zIndex: 150,
  },
  newDot: {
    marginLeft: 2,
  },
});

export default ServiceButton;
