import React from 'react';
import { StyleSheet, Image, View, Platform } from 'react-native';
import PropTypes from 'prop-types';
// components import
import { TouchableOpacityActiveOne } from '../common';

function ScrollTopButton({ onPress, style, ...props }) {
  return (
    <TouchableOpacityActiveOne
      style={[styles.arrowIconBtn, style]}
      onPress={onPress}
    >
      <View style={[styles.arrowIcon, styles.shadow]}>
        <Image
          source={require('../../../assets/image/main/arrow-scroll-top/arrow_scroll_top.png')}
        />
      </View>
    </TouchableOpacityActiveOne>
  );
}

ScrollTopButton.defaultProps = {
  onPress: () => {},
  style: {},
};

ScrollTopButton.propTypes = {
  onPress: PropTypes.func.isRequired,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

const styles = StyleSheet.create({
  arrowIconBtn: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 100,
    backgroundColor: 'white',
  },
  shadow: {
    ...Platform.select({
      ios: {
        shadowOffset: {
          width: 0,
          height: 0,
        },
        shadowOpacity: 0.07,
        shadowRadius: 10,
      },
      android: {
        elevation: 2,
      },
    }),
  },
});

export default ScrollTopButton;
