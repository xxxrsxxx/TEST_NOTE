import React, { useState } from 'react';
import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Modal from 'react-native-modalbox';
import Swiper from 'react-native-swiper';
import LinearGradient from 'react-native-linear-gradient';

import { Font } from '../../utils/style';
import { Favorite } from '../../utils/common/strings';
import { _ } from '../../plugins';

const { washswatColor } = Font;
const { width } = Dimensions.get('window');

function MainPopup(props) {
  const [loadedMainPopup, setLoadedMainPopup] = useState(false);
  const { popup, onPressClose, onPressImage, onPressNever } = props;
  const popupUI = _.map(popup, (popupObject, i) => {
    const {
      content: { url },
      popup: { type, image },
    } = popupObject;
    return (
      <TouchableOpacity
        onPress={() => onPressImage({ type, url })}
        style={styles.fullLink}
        activeOpacity={1}
        key={i}
      >
        <Image
          source={{ uri: image }}
          style={styles.fullImg}
          onLoad={() => {
            if (i === 0) {
              setLoadedMainPopup(true);
            }
          }}
        />
        <LinearGradient
          colors={[
            'rgba(0, 0, 0, 0)',
            'rgba(0, 0, 0, 0)',
            'rgba(0, 0, 0, 0.6)',
          ]}
          style={styles.backgroundShadow}
          locations={[0, 0.8, 1]}
        />
      </TouchableOpacity>
    );
  });

  if (popup && popup.length > 0 && !loadedMainPopup) {
    return (
      <View
        style={{
          width: 50,
          height: 50,
          position: 'absolute',
          right: 0,
          bottom: 0,
          marginRight: -50,
          marginBottom: -50,
        }}
      >
        {popupUI}
      </View>
    );
  } else {
    return (
      <Modal
        isOpen={popup && popup.length > 0 && loadedMainPopup}
        style={styles.modal}
        swipeToClose={false}
        position="bottom"
      >
        <Swiper
          dotColor={'rgba(255, 255 ,255, 0.3)'}
          activeDotColor={washswatColor.white}
          dotStyle={{ width: 7, height: 7 }}
          activeDotStyle={{ width: 7, height: 7 }}
        >
          {popupUI}
        </Swiper>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={() => onPressNever(popup)}
        >
          <Text style={styles.closeButtonColor}>{Favorite.close}</Text>
        </TouchableOpacity>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  button: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modal: {
    width: '100%',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    backgroundColor: 'transparent',
    height: width,
    position: 'relative',
  },
  fullLink: {
    width: width,
    height: width,
  },
  fullImg: {
    width: '100%',
    height: '100%',
    flex: 1,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },
  backgroundShadow: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    zIndex: 1,
  },
  closeButton: {
    position: 'absolute',
    bottom: 15,
    right: 32,
    padding: 10,
  },
  closeButtonColor: {
    color: washswatColor.white,
  },
});

export default MainPopup;
