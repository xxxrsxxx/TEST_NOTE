import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import PropTypes from 'prop-types';
import Swiper from 'react-native-swiper';
// components import
import { RatingStar } from '../../components/common';
// utils import
import { NewMainString } from '../../utils/common/strings';
// styles import
import { Font } from '../../utils/style';
const { washswatColor, responseFont } = Font;

function ReviewBoard({ appReview, style, autoplayTimeout }) {
  const reviewList = appReview.map((review, index) => (
    <View
      key={`rvRR__${review.name}`}
      style={[styles.container, styles.containerHeight, style]}
    >
      <View style={styles.nameContainer}>
        <View style={styles.name}>
          <Text style={styles.nameText} numberOfLines={1}>
            {`${review.name}`}
          </Text>
        </View>
        <View style={styles.info}>
          <Text style={styles.infoText}>
            {`${NewMainString.orderIndexFront}${review.orderIndex}${NewMainString.orderIndexRear}${review.differentRegdateTitle}`}
          </Text>
        </View>
      </View>
      <View style={styles.ratingContainer}>
        <Text style={styles.categoryText}>{NewMainString.pickup}</Text>
        <RatingStar
          review={review}
          type={'pickup'}
          style={styles.ratingStars}
          rating={review.pickupRate}
          starsize={12}
        />
        <Text style={styles.categoryText}>{NewMainString.delivery}</Text>
        <RatingStar
          review={review}
          type={'delivery'}
          style={styles.ratingStars}
          rating={review.deliveryRate}
          starsize={12}
        />
        <Text style={styles.categoryText}>{NewMainString.wash}</Text>
        <RatingStar
          review={review}
          type={'wash'}
          style={styles.ratingStars}
          rating={review.washRate}
          starsize={12}
        />
      </View>
      <View style={styles.contentsContainer}>
        <Text numberOfLines={5} style={styles.contentsText}>
          {review.contents}
        </Text>
      </View>
    </View>
  ));
  return (
    <Swiper
      style={styles.containerHeight}
      showsPagination={false}
      autoplay={true}
      autoplayTimeout={autoplayTimeout}
      index={0}
      nestedScrollEnabled
    >
      {reviewList}
    </Swiper>
  );
}

ReviewBoard.defaultProps = {
  appReview: [],
  style: {},
  autoplayTimeout: 5,
};

ReviewBoard.propTypes = {
  appReview: PropTypes.array.isRequired,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  autoplayTimeout: PropTypes.number,
};

const styles = StyleSheet.create({
  container: {
    padding: 24,
    borderRadius: 8,
    backgroundColor: washswatColor.blue_60,
  },
  containerHeight: {
    // height: 154,
    height: 188,
  },
  nameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    height: 16,
  },
  name: {
    marginRight: 8,
    height: 16,
    justifyContent: 'center',
  },
  nameText: {
    ...responseFont(12).bold,
  },
  info: {
    justifyContent: 'center',
    height: 16,
  },
  infoText: {
    ...responseFont(12).regular,
    color: washswatColor.black_40,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 13,
  },
  ratingStars: {
    marginRight: 8,
  },
  categoryText: {
    ...responseFont(12).regular,
  },
  contentsContainer: {
    // height: 52,
    height: 86,
  },
  contentsText: {
    lineHeight: 17,
    ...responseFont(12).regular,
  },
});

export default React.memo(ReviewBoard);
