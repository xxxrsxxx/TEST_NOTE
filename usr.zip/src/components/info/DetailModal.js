import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
  ScrollView,
  Image,
} from 'react-native';

import CloseButton from '../common/button/CloseButton';

import * as OrderUtils from '../../utils/common/order';
import { Font } from '../../utils/style';

import { _ } from '../../plugins';

const { responseFont, washswatColor } = Font;

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export default function DetailModal(props) {
  const {
    itemDetail,
    onSpecial,
    onPremium,
    onPressClose,
    feeTypeObject,
    category,
  } = props;
  const { isSingle, info, showInfoTitle } = itemDetail || {};
  let basicName = null;
  let specialName = null;
  let premiumName = null;
  if (category === 'LIVING' || category === 'BEDDING') {
    basicName = feeTypeObject.name[0];
    specialName = feeTypeObject.name[1];
    premiumName = feeTypeObject.name[2];
    if (info && showInfoTitle) {
      const { basic, special, premium } = info;
      basicName = basic.title;
      specialName = special.title;
      premiumName = premium.title;
    }
  } else {
    basicName = feeTypeObject.name[0];
    premiumName = feeTypeObject.name[1];
    if (info && showInfoTitle) {
      const { basic, special, premium } = info;
      basicName = basic.title;
      premiumName = premium.title;
    }
  }
  return (
    <View style={{ flex: 1 }}>
      <ScrollView>
        <View>
          <Text
            style={[
              responseFont(24).bold,
              {
                textAlign: 'center',
                marginTop: PixelRatio.roundToNearestPixel(42),
              },
            ]}
          >
            {itemDetail.name}
          </Text>
          <Text
            style={[
              responseFont(14).regular,
              {
                textAlign: 'center',
                marginTop: 9,
                color: washswatColor.grey_02,
              },
            ]}
          >
            {`세탁기간 평균 ${itemDetail.periodInfo.period}일`}
          </Text>
        </View>
        <View
          style={{
            height: 2,
            backgroundColor: 'black',
            marginLeft: 30,
            marginRight: 30,
            marginTop: 42,
            marginBottom: 30,
          }}
        />

        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-around',
          }}
        >
          <View style={styles.modalPriceList}>
            <Text style={[responseFont(12).bold, { marginBottom: 6 }]}>
              {basicName}
            </Text>
            <Text style={[responseFont(16).bold]}>{`${numberWithCommas(
              itemDetail.basic,
            )}원`}</Text>
          </View>
          {specialName && itemDetail.special && itemDetail.special !== 0 ? (
            <View>
              <TouchableOpacity
                style={styles.modalPriceList}
                onPress={onSpecial}
              >
                <View style={{ flexDirection: 'row', marginBottom: 6 }}>
                  <Text style={[responseFont(12).bold, { marginRight: 3 }]}>
                    {specialName}
                  </Text>
                  <Image
                    style={{ width: 16, height: 16 }}
                    resizeMode={'contain'}
                    source={require('image/Price/help.png')}
                  />
                </View>
                <Text style={[responseFont(16).bold]}>{`${numberWithCommas(
                  itemDetail.special,
                )}원`}</Text>
              </TouchableOpacity>
            </View>
          ) : null}
          {premiumName && itemDetail.premium && itemDetail.premium !== 0 ? (
            <View>
              <TouchableOpacity
                style={styles.modalPriceList}
                onPress={onPremium}
              >
                <View style={{ flexDirection: 'row', marginBottom: 6 }}>
                  <Text style={[responseFont(12).bold, { marginRight: 3 }]}>
                    {premiumName}
                  </Text>
                  <Image
                    style={{ width: 16, height: 16 }}
                    resizeMode={'contain'}
                    source={require('image/Price/help.png')}
                  />
                </View>
                <Text style={[responseFont(16).bold]}>{`${numberWithCommas(
                  itemDetail.premium,
                )}원`}</Text>
              </TouchableOpacity>
            </View>
          ) : null}
        </View>

        {itemDetail.detail && itemDetail.detail.length > 3 ? (
          <View style={{ marginTop: 42, marginLeft: 30, marginBottom: 0 }}>
            <View style={{ flexDirection: 'row' }}>
              <Image
                style={{ width: 30, height: 30, marginRight: 9 }}
                resizeMode={'contain'}
                source={require('image/chat/profile.png')}
              />
              <Text style={[responseFont(14).bold]}>Quality Manager</Text>
            </View>
            <View
              style={[
                responseFont(15).regular,
                {
                  lineHeight: 22,
                  backgroundColor: washswatColor.grey_03,
                  marginLeft: 39,
                  marginRight: 30,
                  padding: 15,
                  marginBottom: 0,
                },
              ]}
            >
              <Text>{itemDetail.detail}</Text>
            </View>
          </View>
        ) : null}
        {_.map(itemDetail.detailCommon, (item, index) => {
          if (item.length > 3) {
            return (
              <View
                key={index}
                style={{ marginTop: 0, marginLeft: 30, marginBottom: 5 }}
              >
                <View
                  style={{
                    height: 1,
                    marginTop: 16,
                    marginBottom: 16,
                    backgroundColor: washswatColor.grey_03,
                    marginLeft: 39,
                    marginRight: 30,
                  }}
                />
                <View
                  style={[
                    responseFont(15).regular,
                    {
                      lineHeight: 22,
                      backgroundColor: washswatColor.grey_03,
                      marginLeft: 39,
                      marginRight: 30,
                      padding: 15,
                      marginBottom: 6,
                    },
                  ]}
                >
                  {OrderUtils.convertTextWithRegex({
                    text: item,
                    font: responseFont(14).regular,
                    color: washswatColor.black,
                  })}
                </View>
              </View>
            );
          }
        })}
        <View style={{ marginBottom: 45 }} />
      </ScrollView>
      <View style={{ position: 'absolute' }}>
        <CloseButton onPress={onPressClose} />
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  tag: {
    textAlign: 'center',
    color: washswatColor.white,
    padding: PixelRatio.roundToNearestPixel(3),
    marginLeft: PixelRatio.roundToNearestPixel(10),
    marginBottom: PixelRatio.roundToNearestPixel(2.5),
  },
  toggleImage: {
    width: PixelRatio.roundToNearestPixel(16),
    height: PixelRatio.roundToNearestPixel(16),
    marginTop: PixelRatio.roundToNearestPixel(30),
    marginBottom: PixelRatio.roundToNearestPixel(21),
    marginLeft: PixelRatio.roundToNearestPixel(18),
  },
  modalPriceList: {
    alignItems: 'center',
  },
});
