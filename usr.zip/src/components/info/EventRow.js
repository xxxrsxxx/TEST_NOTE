import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function EventRow(props) {
  const { titleLabel, specialTag, eventContent, price } = props;
  const background =
    specialTag !== undefined ? washswatColor.blue : washswatColor.white;
  return (
    <View>
      <TouchableOpacity style={styles.top}>
        <View style={{ marginLeft: PixelRatio.roundToNearestPixel(30) }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={[responseFont(16).bold, { textAlign: 'center' }]}>
              {titleLabel}
            </Text>
            <Text
              style={[
                responseFont(10).bold,
                styles.tag,
                { backgroundColor: background },
              ]}
            >
              {specialTag}
            </Text>
          </View>
          <Text
            style={[
              responseFont(14).regular,
              { marginTop: PixelRatio.roundToNearestPixel(5), color: 'red' },
            ]}
          >
            {eventContent}
          </Text>
        </View>
        <View style={{ paddingRight: PixelRatio.roundToNearestPixel(20) }}>
          <Text
            style={[
              responseFont(16).regular,
              { paddingRight: PixelRatio.roundToNearestPixel(10) },
            ]}
          >
            {price}
          </Text>
        </View>
      </TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
  top: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: PixelRatio.roundToNearestPixel(30),
    paddingBottom: PixelRatio.roundToNearestPixel(30),
    borderBottomWidth: PixelRatio.roundToNearestPixel(0.7),
    borderColor: washswatColor.grey_05,
  },
  tag: {
    textAlign: 'center',
    color: washswatColor.white,
    padding: PixelRatio.roundToNearestPixel(3),
    paddingLeft: PixelRatio.roundToNearestPixel(6),
    paddingRight: PixelRatio.roundToNearestPixel(9),
    marginLeft: PixelRatio.roundToNearestPixel(10),
    marginBottom: PixelRatio.roundToNearestPixel(2.5),
  },
});
