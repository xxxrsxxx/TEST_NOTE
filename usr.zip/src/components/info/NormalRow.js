import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function NormalRow(props) {
  const { titleLabel, specialTag, price, onClickPriceList } = props;
  const background =
    specialTag !== undefined ? washswatColor.blue : washswatColor.white;
  return (
    <View>
      <TouchableOpacity style={styles.top} onPress={onClickPriceList}>
        <View style={{ flex: 7, flexDirection: 'row', alignItems: 'center' }}>
          <Text style={[responseFont(16).regular]}>{titleLabel}</Text>
          {specialTag ? (
            <Text
              style={[
                responseFont(10).bold,
                styles.tag,
                { backgroundColor: background },
              ]}
            >
              {specialTag}
            </Text>
          ) : null}
        </View>
        <View
          style={{ flex: 3, justifyContent: 'center', alignItems: 'flex-end' }}
        >
          <Text style={[responseFont(16).regular]}>{price}</Text>
        </View>
      </TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
  top: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 30,
    paddingTop: PixelRatio.roundToNearestPixel(15),
    paddingRight: 30,
    paddingBottom: PixelRatio.roundToNearestPixel(15),
    marginLeft: 8,
    marginRight: 8,
    borderBottomWidth: PixelRatio.roundToNearestPixel(1),
    borderColor: washswatColor.grey_05,
  },
  tag: {
    textAlign: 'center',
    color: washswatColor.white,
    padding: PixelRatio.roundToNearestPixel(3),
    paddingLeft: PixelRatio.roundToNearestPixel(6),
    paddingRight: PixelRatio.roundToNearestPixel(9),
    marginLeft: PixelRatio.roundToNearestPixel(10),
    marginBottom: PixelRatio.roundToNearestPixel(2.5),
  },
});
