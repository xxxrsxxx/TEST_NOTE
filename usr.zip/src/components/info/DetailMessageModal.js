import React from 'react';

import {
  Dimensions,
  PixelRatio,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { Favorite } from '../../utils/common/strings';
import * as OrderUtils from '../../utils/common/order';
import { Font } from '../../utils/style';

const { washswatColor, responseFont } = Font;

const { width } = Dimensions.get('window');

export default function DetailMessageModal(props) {
  const {
    typeOfPrice,
    typeOfPriceContent,
    typeOfPriceContentBottom,
    message,
    onClose,
  } = props;
  let messageViews = [];
  try {
    const messages = message.split('\n');
    messages.map((item, index) => {
      let marginTopLayoutSize = 18;
      if (index === 0) {
        marginTopLayoutSize = 0;
      }
      messageViews.push(
        <View
          style={{
            flexDirection: 'row',
            marginTop: PixelRatio.roundToNearestPixel(marginTopLayoutSize),
          }}
        >
          <View style={styles.circleNumberView}>
            <Text
              style={[responseFont(12).regular, { color: washswatColor.white }]}
            >
              {index + 1}
            </Text>
          </View>
          <Text
            key={`message${index}`}
            style={[
              responseFont(14).regular,
              {
                color: washswatColor.black,
                marginStart: PixelRatio.roundToNearestPixel(9),
              },
            ]}
          >
            {item.replace('- ', '')}
          </Text>
        </View>,
      );
    });
  } catch (e) {}
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center', flex: 1 }}>
      <View style={[styles.rootView, { width: width - 50 }]}>
        <ScrollView
          style={{
            padding: 30,
          }}
        >
          {typeOfPrice ? (
            <Text
              style={[responseFont(15).bold, { color: washswatColor.black }]}
            >
              {typeOfPrice}
            </Text>
          ) : null}
          {typeOfPriceContent ? (
            <Text
              style={[
                responseFont(14).regular,
                {
                  color: washswatColor.black,
                  marginTop: PixelRatio.roundToNearestPixel(6),
                  lineHeight: PixelRatio.roundToNearestPixel(22),
                },
              ]}
            >
              {typeOfPriceContent}
            </Text>
          ) : null}
          <View style={{ marginTop: PixelRatio.roundToNearestPixel(36) }}>
            {messageViews}
          </View>
          {typeOfPriceContentBottom ? (
            <Text
              style={[
                responseFont(14).regular,
                {
                  color: washswatColor.black,
                  marginTop: PixelRatio.roundToNearestPixel(36),
                  lineHeight: PixelRatio.roundToNearestPixel(22),
                },
              ]}
            >
              {OrderUtils.convertTextWithRegex({
                text: typeOfPriceContentBottom,
                ...responseFont(14).regular,
                color: washswatColor.black,
              })}
            </Text>
          ) : null}
        </ScrollView>
        <TouchableOpacity
          onPress={onClose}
          style={{
            alignItems: 'center',
            justifyContent: 'center',
            bottom: 0,
            borderTopWidth: 1,
            borderTopColor: washswatColor.black,
            borderBottomWidth: 1,
            borderBottomColor: washswatColor.black,
            height: PixelRatio.roundToNearestPixel(55),
          }}
        >
          <Text style={[responseFont(14).bold, { color: washswatColor.black }]}>
            {Favorite.close}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  rootView: {
    borderColor: washswatColor.black,
    borderWidth: 1,
    borderBottomWidth: 0,
    borderBottomColor: washswatColor.white,
    minHeight: 300,
    backgroundColor: 'white',
    shadowColor: 'grey',
    shadowOffset: {
      width: PixelRatio.roundToNearestPixel(10),
      height: PixelRatio.roundToNearestPixel(10),
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 24,
  },
  circleNumberView: {
    width: PixelRatio.roundToNearestPixel(16),
    height: PixelRatio.roundToNearestPixel(16),
    borderRadius: PixelRatio.roundToNearestPixel(8),
    backgroundColor: washswatColor.black,
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButton: {},
});
