import React from 'react';
import { StyleSheet, Image, TouchableOpacity, PixelRatio } from 'react-native';

export default function FeedbackStarView(props) {
  const { isOn } = props;
  let starImage = isOn
    ? require('../../../assets/image/feedback/star_on.png')
    : require('../../../assets/image/feedback/star_off.png');
  return (
    <TouchableOpacity style={{ padding: PixelRatio.roundToNearestPixel(9) }}>
      <Image
        source={starImage}
        style={{
          width: PixelRatio.roundToNearestPixel(16),
          height: PixelRatio.roundToNearestPixel(16),
        }}
      />
    </TouchableOpacity>
  );
}
const styles = StyleSheet.create({});
