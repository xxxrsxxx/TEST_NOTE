import React from 'react';
import { TouchableOpacity, PixelRatio, Image } from 'react-native';

export default function FeedbackBackButton(props) {
  const { onPress } = props;
  return (
    <TouchableOpacity
      style={{
        width: PixelRatio.roundToNearestPixel(56),
        height: PixelRatio.roundToNearestPixel(56),
        justifyContent: 'center',
      }}
      onPress={onPress}
    >
      <Image
        source={require('../../../assets/image/feedback/no.png')}
        style={{
          width: PixelRatio.roundToNearestPixel(16),
          height: PixelRatio.roundToNearestPixel(16),
          marginStart: PixelRatio.roundToNearestPixel(18),
        }}
      />
    </TouchableOpacity>
  );
}
