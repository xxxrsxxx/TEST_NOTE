import React from 'react';

import { StyleSheet, Text, View, PixelRatio } from 'react-native';
import StarRating from 'react-native-star-rating';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function FeedbackAfterOrderView(props) {
  const {
    serviceName,
    servicePoint,
    servicePointTextColorFlag,
    starCount,
    onStarRatingPress,
  } = props;
  const servicePointColor = servicePointTextColorFlag
    ? washswatColor.black
    : washswatColor.grey_03;
  return (
    <View>
      <View
        style={{
          height: PixelRatio.roundToNearestPixel(2),
          backgroundColor: washswatColor.black,
        }}
      />
      <View
        style={{
          height: PixelRatio.roundToNearestPixel(113),
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingLeft: PixelRatio.roundToNearestPixel(19),
          paddingRight: PixelRatio.roundToNearestPixel(22),
        }}
      >
        {/* 서비스와 점수 */}
        <View
          style={{
            width: PixelRatio.roundToNearestPixel(80),
            alignItems: 'center',
          }}
        >
          <Text
            style={[responseFont(12).regular, { color: washswatColor.black }]}
          >
            {serviceName}
          </Text>
          <Text
            style={[
              responseFont(16).bold,
              {
                color: servicePointColor,
                marginTop: PixelRatio.roundToNearestPixel(7),
              },
            ]}
          >
            {servicePoint}
          </Text>
        </View>
        {/* 별5개 */}
        <StarRating
          containerStyle={{ width: PixelRatio.roundToNearestPixel(156) }}
          buttonStyle={{ padding: PixelRatio.roundToNearestPixel(9) }}
          disabled={false}
          emptyStar={require('image/feedback/star_off.png')}
          fullStar={require('image/feedback/star_on.png')}
          starSize={PixelRatio.roundToNearestPixel(16)}
          maxStars={5}
          rating={starCount}
          selectedStar={onStarRatingPress}
        />
      </View>
    </View>
  );
}
const styles = StyleSheet.create({});
