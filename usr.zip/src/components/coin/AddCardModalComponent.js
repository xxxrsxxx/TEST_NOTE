import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import {
  Image,
  Text,
  TouchableOpacity,
  View,
  StyleSheet,
  Dimensions,
} from 'react-native';
import Modal from 'react-native-modalbox';

// components import
import { XButton } from '../common/button/XButton';

// redux import
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as buyBulletActions from '../../reducers/BuyBulletModule';

import { SelectPaymentString } from '../../utils/common/strings';
import { Font } from '../../utils/style';

const { responseFont, washswatColor, horizonScale } = Font;

const { width } = Dimensions.get('window');

class AddCardModalComponent extends PureComponent {
  handleBuyBullet = i => {
    const { BuyBulletActions } = this.props;
    BuyBulletActions.setActiveCard(i);
    BuyBulletActions.buyBullet('addCard');
  };

  handleCloseModal = () => {
    const { BuyBulletActions } = this.props;
    BuyBulletActions.toggleOpenAddCardModal({
      isOpen: false,
      isActiveIndex: null,
    });
  };

  render() {
    const {
      billArray,
      isOpenAddCardModal,
      BuyBulletActions,
      componentId,
      activeCardIndex,
    } = this.props;
    const cardListUI = billArray.map((card, i) => (
      <TouchableOpacity
        style={[styles.list_button, styles.card_button]}
        key={i}
        onPress={() => this.handleBuyBullet(i)}
      >
        <Text
          style={
            i === activeCardIndex ? styles.active_button : styles.basic_button
          }
        >
          {card.card
            .split(' ')
            .slice(0, 2)
            .join(' ')}
        </Text>
        {i === activeCardIndex && (
          <Image
            source={require('image/v5/ic_checkmark.png')}
            style={{ width: 12, height: 9 }}
          />
        )}
      </TouchableOpacity>
    ));

    return (
      <Modal
        isOpen={isOpenAddCardModal}
        onClosed={this.handleCloseModal}
        style={[styles.modal, { height: 186 + billArray.length * 60 }]}
        position={'bottom'}
      >
        <View style={styles.modal_content}>
          <View style={styles.modal_header}>
            <Text style={[responseFont(12).bold, styles.modal_title]}>
              {SelectPaymentString.modal_title}
            </Text>
            <View style={styles.xButton}>
              <XButton onPress={this.handleCloseModal} />
            </View>
          </View>
          <View>
            {billArray.length !== 0 ? (
              cardListUI
            ) : (
              <TouchableOpacity
                onPress={() => {
                  BuyBulletActions.setCard(componentId);
                }}
              >
                <Text style={styles.list_text}>
                  {SelectPaymentString.bullet_modal_cardAdd}
                </Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  modal: {
    backgroundColor: washswatColor.white,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    paddingTop: 12,
  },
  modal_content: {
    marginLeft: 21,
    marginRight: 12,
  },
  modal_header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    alignItems: 'center',
    paddingBottom: 24,
  },
  modal_title: {
    color: washswatColor.grey_08,
  },
  list_text: {
    ...responseFont(14).regular,
    paddingVertical: horizonScale(15),
  },
  basic_button: {
    ...responseFont(14).regular,
    height: horizonScale(45),
    lineHeight: horizonScale(45),
  },
  active_button: {
    ...responseFont(14).bold,
    color: washswatColor.blue,
    height: horizonScale(45),
    lineHeight: horizonScale(45),
  },
  card_button: {
    flexDirection: 'row',
    width: width - 45,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});

AddCardModalComponent.propTypes = {
  billArray: PropTypes.array.isRequired,
  componentId: PropTypes.string.isRequired,
};

export default connect(
  state => ({
    openModalKind: state.BuyBulletModule.openModalKind,
    isOpenAddCardModal: state.BuyBulletModule.isOpenAddCardModal,
    activeCardIndex: state.BuyBulletModule.activeCardIndex,
  }),
  dispatch => ({
    BuyBulletActions: bindActionCreators(buyBulletActions, dispatch),
  }),
)(AddCardModalComponent);
