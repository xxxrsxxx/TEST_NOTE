import React from 'react';
import PropTypes from 'prop-types';

import { StyleSheet, Text, TouchableOpacity } from 'react-native';

import GrayBox from '../common/style/GrayBox';

import { PaymentBuyBulletString } from '../../utils/common/strings';
import * as CommonUtils from '../../utils/common';

import { Font } from '../../utils/style';

const { responseFont, verticalScale, washswatColor } = Font;

const SelectBulletList = ({ bulletList, handleBuyBullet }) => {
  const changeStringFromNumber = bulletList.value.toString();
  return (
    <TouchableOpacity style={styles.list_box} onPress={handleBuyBullet}>
      <GrayBox padding={verticalScale(30)}>
        <Text style={styles.list_title}>
          {changeStringFromNumber.length > 0 &&
            changeStringFromNumber.substring(0, 2)}{' '}
          {PaymentBuyBulletString.unit}
        </Text>
        <Text style={styles.member_bonus}>
          {PaymentBuyBulletString.membershipBonus}{' '}
          {CommonUtils.numberWithCommas(bulletList.memberBonus)}{' '}
          {PaymentBuyBulletString.won}
        </Text>
        {bulletList.bonus !== 0 && (
          <Text style={styles.normal_bonus}>
            {PaymentBuyBulletString.normalBonus}{' '}
            {CommonUtils.numberWithCommas(bulletList.bonus)}{' '}
            {PaymentBuyBulletString.won}
          </Text>
        )}
      </GrayBox>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  list_box: {},
  list_title: {
    ...responseFont(20).bold,
    paddingBottom: 5,
  },
  member_bonus: {
    ...responseFont(11).regular,
    color: washswatColor.blue,
    paddingBottom: 2,
  },
  normal_bonus: {
    ...responseFont(11).regular,
  },
});

SelectBulletList.propTypes = {
  bulletList: PropTypes.object.isRequired,
  handleBuyBullet: PropTypes.func.isRequired,
};

export default SelectBulletList;
