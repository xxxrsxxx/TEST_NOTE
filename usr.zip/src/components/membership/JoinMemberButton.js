import React from 'react';

import { Text, TouchableOpacity, PixelRatio, View } from 'react-native';

import { Font } from '../../utils/style';

const { responseFont, washswatColor } = Font;

export default function JoinMemberButton(props) {
  const { type, onPress, title, origin, price, content } = props;
  return (
    <TouchableOpacity
      onPress={onPress}
      style={{ height: PixelRatio.roundToNearestPixel(150) }}
    >
      <View
        style={{
          flex: 1,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text style={[responseFont(15).bold, { color: washswatColor.black }]}>
          {title}
        </Text>
        {origin ? (
          <Text
            style={[
              responseFont(13).regular,
              {
                color: washswatColor.grey_01,
                marginLeft: PixelRatio.roundToNearestPixel(10),
                marginRight: PixelRatio.roundToNearestPixel(10),
              },
            ]}
          >
            {`${origin.toLocaleString('kr')}원`}
          </Text>
        ) : null}
        <Text
          style={[responseFont(13).bold, { color: washswatColor.black }]}
        >{`${price.toLocaleString('kr')}원`}</Text>
      </View>
      <View
        style={{
          flex: 1,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text
          style={[
            responseFont(13).regular,
            {
              color: washswatColor.grey_01,
              lineHeight: PixelRatio.roundToNearestPixel(24),
            },
          ]}
        >
          {content}
        </Text>
      </View>
      {type === 'yearly' && (
        <View
          style={{
            height: 1,
            backgroundColor: washswatColor.grey_03,
            marginLeft: PixelRatio.roundToNearestPixel(20),
            marginRight: PixelRatio.roundToNearestPixel(20),
          }}
        />
      )}
    </TouchableOpacity>
  );
}
