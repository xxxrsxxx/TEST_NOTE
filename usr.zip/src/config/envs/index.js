import local from './local.json';
import stg from './stg.json';
import prod from './prod.json';
import dev from './dev.json';

export { local, stg, prod, dev };
