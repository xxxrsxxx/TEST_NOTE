import Config from 'react-native-config';
import { prod, stg, dev, local } from './envs';

const _environment = Config.ENVMODE;
let rootConfig = prod;

const configSelector = {
  production: prod,
  staging: stg,
  development: dev,
  local,
};

if (_environment) rootConfig = configSelector[_environment];

export { rootConfig };
