import { createAction, handleActions } from 'redux-actions';

import { Favorite } from '../utils/common/strings';
import * as ServerUtils from '../utils/type/server';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';

const SERVICE_PENDING = 'price/SERVICE_PENDING';
const GET_PRICE_LIST = 'price/GET_PRICE_LIST';
const GET_ITEM_PRICE_DETAIL = 'price/GET_ITEM_PRICE_DETAIL';
const SEARCH_TEXT_CHANGE = 'price/SEARCH_TEXT_CHANGE';
const CLEAR_SEARCH_TEXT_INPUT = 'price/CLEAR_SEARCH_TEXT_INPUT';
const CATEGORY_SEARCH = 'price/CATEGORY_SEARCH';

export const getPriceList = () => async (dispatch, getState) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  const { uid, userType, sector, centerId } = $_status.state.user;
  return await $_axios
    .post(ServerUtils.GET_PRICE_LIST, {}, { uid, userType, sector, centerId })
    .then(response => {
      const { code, data, message } = response.data;
      if (code == 200) {
        dispatch(
          createAction(GET_PRICE_LIST)({
            priceListArr: data,
            priceListBackupArr: $_.cloneDeep(data),
            isPending: false,
          }),
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const searchTextChange = (text, uid) => async (dispatch, getState) => {
  const {
    priceListBackupArr: { items },
  } = getState().PriceListModule;
  var { priceListArr } = getState().PriceListModule;
  const finded = [];
  for (let i = 0; i < items.length; i++) {
    const { name } = items[i];
    if (name && name.indexOf(text) > -1) {
      finded.push(items[i]);
    }
  }
  if (finded.length > 0) {
    priceListArr.items = finded;
    if (text && text.length > 2 && uid) {
      await AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_SEARCH, {
        af_search_string: text,
      });
      // AnalyticsManager.setAirbridgeTrackEvent(AnalyticsKey.NAME_SEARCH, Platform.OS, uid, 0, { af_search_string: text });
    }
  } else {
    priceListArr.items = items;
  }

  dispatch(createAction(SEARCH_TEXT_CHANGE)({ search: text, priceListArr }));
};

export const categorySearch = text => async (dispatch, getState) => {
  const {
    priceListBackupArr: { items },
  } = getState().PriceListModule;
  let { priceListArr } = getState().PriceListModule;
  const finded = [];
  items.map((item, i) => {
    const { category } = item;
    if (text === category.enTitle) {
      finded.push(items[i]);
    }
  });

  if (finded.length > 0) {
    priceListArr.items = finded;
  } else {
    priceListArr.items = items;
  }

  dispatch(createAction(CATEGORY_SEARCH)({ category: text, priceListArr }));
};
export const getItemPriceDetail = item => async (dispatch, getState) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  const { uid, userType, sector, centerId } = $_status.state.user;

  return await $_axios
    .post(
      ServerUtils.GET_PRICE_LIST,
      {},
      { uid, userType, sector, centerId, item },
    )
    .then(response => {
      const { code, data, message } = response.data;

      if (code == 200) {
        dispatch(
          createAction(GET_ITEM_PRICE_DETAIL)({
            itemDetail: data,
            isPending: false,
          }),
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

const initialState = {
  priceListArr: [],
  priceListBackupArr: [],
  isPending: false,
  itemDetail: {
    info: {
      premium: {
        title: '',
        message: '',
        images: [''],
      },
      showSpecialCare: true,
      special: {
        title: '',
        message: '',
        images: [''],
      },
      care: [
        {
          title: '',
          message: '',
        },
        {
          title: '',
          message: '',
        },
        {
          title: '',
          message: '',
        },
        {
          title: '',
          message: '',
        },
        {
          title: '',
          message: '',
        },
      ],
      basic: {
        title: '',
      },
    },
    sub: {
      enTitle: '',
      title: '',
    },
    detail: '',
    basic: 0,
    name: '',
    backgroundImage: '',
    thumbnailImage: '',
    tag: [''],
    isSingle: false,
    periodInfo: {
      period: 0,
    },
    premium: 0,
    special: 0,
    showInfoTitle: false,
  },
  search: '',
  category: 'ALL',
};

export default handleActions(
  {
    [SERVICE_PENDING]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SEARCH_TEXT_CHANGE]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [CLEAR_SEARCH_TEXT_INPUT]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [CATEGORY_SEARCH]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },

    [GET_PRICE_LIST]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_ITEM_PRICE_DETAIL]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
  initialState,
);
