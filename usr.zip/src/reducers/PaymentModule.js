import { createAction, handleActions } from 'redux-actions';

import { ChannelIO } from 'react-native-channel-plugin';

import WashAlert from '../utils/alert';
import { Favorite } from '../utils/common/strings';
import * as CommonUtils from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import * as KeyUtils from '../utils/type/key';
import * as WashPayment from '../utils/common/payment';

import { _ } from '../plugins';

const ANY_ACIONS = 'payment/ANY_ACIONS';

export const showBill = ({ componentId, finishedAction }) => async (
  dispatch,
  getState,
) => {
  const _storage = await $_storage.get();
  const uid = _storage[KeyUtils.USER_ID];
  const name = _storage[KeyUtils.USER_NAME];

  const data = { callType: 'bill', uid, name };
  WashPayment.show(data, json => {
    const { code, message } = json;
    if (code == 200) {
      finishedAction(json);
    } else if (code == 300) {
      /** 그냥 화면 닫은 경우 **/
    } else {
      if (message) {
        WashAlert.showAlert(message, Favorite.ok);
        /** 서버에서 돌려주는 메시지 **/
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    }
  });
};

export const requestRegistCard = ({ componentId }, finishedAction) => async (
  dispatch,
  getState,
) => {
  const _storage = await $_storage.get();
  const uid = _storage[KeyUtils.USER_ID];
  const name = _storage[KeyUtils.USER_NAME];
  const data = { callType: 'bill', uid, name };
  WashPayment.show(data, json => {
    const { code, message } = json;
    if (code == 200) {
      finishedAction(json);
    } else if (code == 300) {
      /** 그냥 화면 닫은 경우 **/
    } else {
      if (message) {
        WashAlert.showAlert(message, Favorite.ok);
        /** 서버에서 돌려주는 메시지 **/
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    }
  });
};

export const showInicisCard = (
  { uid, name, orderId, objectId, finalPrice, usePoint, phone, usedCouponList },
  finishedAction,
  failAction,
) => async (dispatch, getState) => {
  if (usedCouponList && usedCouponList.length > 0) {
    const list = [];
    usedCouponList.map(o => {
      const { _id, couponId } = o;
      list.push({ _id, couponId });
    });
    usedCouponList = list;
  } else {
    usedCouponList = [];
  }

  /** 이니시스 카드 **/
  const data = {
    callType: 'inicisCard',
    uid,
    name,
    orderId,
    objectId,
    finalPrice,
    usePoint,
    phone,
    usedCouponList,
  };
  WashPayment.show(data, json => {
    const { code, message } = json;

    if (code == 200) {
      finishedAction();
    } else if (code == 300) {
      /** 그냥 화면 닫은 경우 **/
      if (failAction) {
        failAction();
      }
    } else {
      if (message) {
        WashAlert.showAlert(message, Favorite.ok);
        /** 서버에서 돌려주는 메시지 **/
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    }
  });
};

export const showBankList = ({
  uid,
  name,
  orderId,
  objectId,
  finalPrice,
  usePoint,
  phone,
  usedCouponList,
  componentId,
}) => async (dispatch, getState) => {
  /** 계좌이체  **/
  // TODO: 포인트, 쿠폰등이 추가가될 수 있다 **/

  CommonUtils.navShowModal({
    name: 'Account',
    passProps: {
      orderId,
      finalPrice,
      usePoint,
      phone,
      usedCouponList,
    },
  });
};

export const actionPaymentRequest = (
  { uid, name, objectId, finalPrice, usePoint, usedCouponList, payType },
  finishedAction,
) => async (dispatch, getState) => {
  dispatch(createAction(ANY_ACIONS)({ isPending: true }));
  const {
    available: { cardList },
    billKey,
  } = getState().OrderHistoryModule;

  const _url = `${ServerUtils.PAY_ACTION}${payType}`;
  await $_axios
    .post(
      _url,
      {},
      {
        uid,
        name,
        objectId,
        finalPrice,
        usePoint,
        usedCouponList,
        billKey,
      },
    )
    .then(response => {
      dispatch(createAction(ANY_ACIONS)({ isPending: false }));

      const { code, message } = response.data;
      if (code === 200) {
        finishedAction();
      } else {
        if (message) {
          /** 서버 실패 메시지 **/
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          /** 기본메시지 **/
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    });
};

export const actionPayment = (
  { uid, name, objectId, finalPrice, usePoint, usedCouponList, payType },
  finishedAction,
) => async (dispatch, getState) => {
  dispatch(createAction(ANY_ACIONS)({ isPending: true }));
  const {
    available: { cardList },
  } = getState().OrderHistoryModule;
  var billKey;
  const finded = _.find(cardList, { isDefault: 1 });
  if (finded && finded.billKey) {
    billKey = finded.billKey;
  }
  const _url = `${ServerUtils.PAY_ACTION}${payType}`;
  await $_axios
    .post(
      _url,
      {},
      {
        uid,
        name,
        objectId,
        finalPrice,
        usePoint,
        usedCouponList,
        billKey,
      },
    )
    .then(response => {
      dispatch(createAction(ANY_ACIONS)({ isPending: false }));

      const { code, message } = response.data;
      if (code === 200) {
        finishedAction();
      } else {
        if (message) {
          /** 서버 실패 메시지 **/
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          /** 기본메시지 **/
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    });
};

const sendAccount = async ({
  uid,
  name,
  orderId,
  objectId,
  finalPrice,
  usePoint,
  phone,
  usedCouponList,
  code,
  dispatch,
  getState,
}) => {
  dispatch(createAction(ANY_ACIONS)({ isPending: true }));
  $_axios
    .post(
      ServerUtils.SNED_ACCOUNT_MESSAGE,
      {},
      {
        objectId,
        finalPrice,
        phone,
        bankCode: code,
        name,
        usedCouponList,
        usePoint,
      },
    )
    .then(response => {
      const { code, message } = response.data;
      dispatch(createAction(ANY_ACIONS)({ isPending: false }));

      if (code === 200) {
        // WashAlert.showAlert('계좌를 문자 메시지로 전송드렸어요!',Favorite.ok);
        ChannelIO.showMessenger();
      } else {
        if (message) {
          /** 서버 실패 메시지 **/
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          /** 기본메시지 **/
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    });
};

export const updatePaymentMethodAPI = ({ orderId, payType }) => async (
  dispatch,
  getState,
) => {
  dispatch(createAction(ANY_ACIONS)({ isPending: true }));
  await $_axios
    .post(
      ServerUtils.SET_PRE_OPTIONS,
      {},
      {
        orderId,
        list: [
          {
            key: 'payment',
            data: {
              // discount: {
              //   coupon: [],
              //   point: 0
              // },
              payType,
            },
          },
        ],
      },
    )
    .then(res => {
      dispatch(createAction(ANY_ACIONS)({ isPending: false }));
      const { code } = res.data;
      if (code === 200) {
        dispatch(getOrderHistory());
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    })
    .catch(err => {
      dispatch(createAction(ANY_ACIONS)({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const getAlertValue = alert => () => {
  return _getAlertValue(alert);
};
const _getAlertValue = alert => {
  if (alert && alert.length > 0) {
    if (alert[0].button && alert[0].button.action === 'payment') {
      return alert[0].buttom.needPayPrice;
    } else if (alert[0].button && alert[0].button.action === 'refund') {
      return -alert[0].buttom.needRefundPrice;
    }
  }
  return 0;
};

const initialState = {
  bankList: [
    { title: '기업은행', code: '003' },
    { title: '국민은행', code: '004' },
    { title: 'KEB하나은행', code: '005' },
    { title: 'SC제일은행', code: '023' },
    { title: '우체국', code: '071' },
  ],
};

export default handleActions(
  {
    [ANY_ACIONS]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
  initialState,
);
