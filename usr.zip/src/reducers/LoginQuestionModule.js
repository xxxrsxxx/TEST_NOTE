import { createAction, handleActions } from 'redux-actions';

import axios from 'axios';

import WashAlert from '../utils/alert';
import { Favorite, LoginQuestionText } from '../utils/common/strings';
import * as CommonUtils from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import * as Keys from '../utils/type/key';
import { apiTimeoutValue } from '../static/settings';

import { _ } from '../plugins';

const INIT = 'LoginQuestion/INIT';

export const init = accessToken => async (dispatch, getState) => {
  try {
    const {
      data: { list },
    } = await $_axios.get(ServerUtils.GET_LOGIN_QUESTION, {
      userAccessToken: accessToken,
    });
    dispatch(createAction(INIT)({ list, accessToken }));
  } catch (error) {
    if (error && error.response && error.response.data) {
      WashAlert.showAlert(
        error.response.data.title || Favorite.fail,
        Favorite.ok,
      );
    } else {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    }
  }
};

export const goSignUp = componentId => async (dispatch, getState) => {
  // 신규회원 가입 시작
  CommonUtils.navPush({
    componentId,
    name: 'SignTerms',
  });
};

export const complete = () => async (dispatch, getState) => {
  const { accessToken, questions } = getState().LoginQuestionModule;
  $_storage.set(Keys.ACCESS_TOKEN, accessToken);
};

export const firstAnswer = (answer, address, componentId) => async (
  dispatch,
  getState,
) => {
  const { accessToken, questions } = getState().LoginQuestionModule;
  try {
    await new Promise((resolve, reject) => {
      WashAlert.showConfirm(
        `[${address}]\n${LoginQuestionText.check_first}`,
        Favorite.yes,
        Favorite.no,
        () => {
          resolve();
        },
      );
    });

    const {
      data: { permit },
    } = await $_axios.post(
      ServerUtils.POST_LOGIN_QUESTION_CHECK_FIRST_QUESTION,
      { userAccessToken: accessToken },
      { list: questions, answer },
    );

    if (permit) {
      CommonUtils.navPush({
        componentId,
        name: 'LoginLastQuestion',
        passProps: { id: answer },
      });
    } else {
      dispatch(init(accessToken));
    }
  } catch (error) {
    console.log('error', error);
    if (error && error.response && error.response.data) {
      WashAlert.showAlert(
        error.response.data.title || Favorite.fail,
        Favorite.ok,
      );
    }
  }
};

const initialState = {
  questions: [],
  accessToken: null,
};

export default handleActions(
  {
    [INIT]: (state, action) => {
      const { list, accessToken } = action.payload;
      return {
        ...state,
        accessToken,
        questions: _.cloneDeep(list),
      };
    },
  },
  _.cloneDeep(initialState),
);
