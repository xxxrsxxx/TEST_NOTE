import { handleActions } from 'redux-actions';

const ANY_ACIONS = 'payment/ANY_ACIONS';

const initialState = {

};

export default handleActions(
  {
    [ANY_ACIONS]: (state, action) => {
      return {
        ...state,
        ...action.payload
      };
    }
  },
  initialState
);
