import { handleActions, createAction } from 'redux-actions';

import moment from 'moment';

import * as ServerUtils from '../utils/type/server';
import * as KeyUtils from '../utils/type/key';
import * as CommonUtils from '../utils/common/index';
import { Favorite } from '../utils/common/strings';
import WashAlert from '../utils/alert';

import { _ } from '../plugins';

const BACK_PRESS = 'regularOrder/BACK_PRESS';

// action constructor

const SET_PICKUP_TIME_LIST = 'regularOrder/SET_PICKUP_TIME_LIST';
const SET_DELIVERY_TIME_LIST = 'regularOrder/SET_DELIVERY_TIME_LIST';

const PENDDING = 'regularOrder/PENDDING';
const SET_OPTION_VALUE = 'regularOrder/SET_OPTION_VALUE';
const SET_OPTION_VALUE_DEEP = 'regularOrder/SET_OPTION_VALUE_DEEP';

const SET_DELIVERY_DAY = 'regularOrder/SET_DELIVERY_DAY';
const SET_DELIVERY_HOUR = 'regularOrder/SET_DELIVERY_HOUR';

export const swipeOnDate = createAction(SET_DELIVERY_DAY);
export const setDeliveryHour = createAction(SET_DELIVERY_HOUR);
export const backPrsess = createAction(BACK_PRESS);

export const setOptionValue = ({ key, value, cloneDeep }) => async (
  dispatch,
  getStore,
) => {
  if (cloneDeep) {
    dispatch(createAction(SET_OPTION_VALUE_DEEP)({ key, value }));
  } else {
    dispatch(createAction(SET_OPTION_VALUE)({ key, value }));
  }
};

export const getPickupDateTimeAPI = ({
  finishedActionWhenOrderComplete,
}) => async (dispatch, getStore) => {
  dispatch(createAction(PENDDING)({ isPending: true }));
  let uid = await CommonUtils.getValue(KeyUtils.USER_ID);
  let centerId = await CommonUtils.getValue(KeyUtils.CENTER_ID);

  await $_axios
    .post(ServerUtils.GET_PICKUP_DATETIME, {}, { uid, centerId, weekly: true })
    .then(res => {
      const { code, data, message } = res.data;
      if (code === 200) {
        const { slots } = res.data;
        const today = moment();
        if (23 >= today.hour() && today.hour() >= 11) {
          today.add(1, 'day');
        }
        const day = today.weekday();
        dispatch(
          createAction(SET_PICKUP_TIME_LIST)({
            isPending: false,
            pickupSlots: slots,
            day,
            finishedActionWhenOrderComplete,
          }),
        );
      } else {
        dispatch(createAction(PENDDING)({ isPending: false }));

        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      dispatch(createAction(PENDDING)({ isPending: false }));

      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const getDeliveryDateTimeAPI = () => async (dispatch, getStore) => {
  dispatch(createAction(PENDDING)({ isPending: true }));

  let uid = $_status.state.user.uid;
  let centerId = $_status.state.user.centerId;
  await $_axios
    .post(
      ServerUtils.GET_DELIVERY_DATETIME,
      {},
      { uid, centerId, weekly: true },
    )
    .then(res => {
      const { code, data, message } = res.data;
      if (code === 200) {
        const { slots } = res.data;

        dispatch(
          createAction(SET_DELIVERY_TIME_LIST)({
            isPending: false,
            deliverySlots: slots,
          }),
        );
      } else {
        dispatch(createAction(PENDDING)({ isPending: false }));

        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      dispatch(createAction(PENDDING)({ isPending: false }));

      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

const initialState = {
  weekModalData: [
    {
      ko: '매주',
      key: 'everyWeek',
      en: 'Weekly',
    },
    {
      ko: '격주',
      en: 'Biweekly',
      key: 'everyTwoWeeks',
    },
  ],
  //정기주문 파라미터
  isPending: false,
  pickupSlots: [],
  day: 0,
  periodIndex: 0,
  hour: {
    start: null,
    end: null,
  },

  delivery: {
    day: null,
    hour: {
      start: null,
      end: null,
    },
  },
  finishedActionWhenOrderComplete: null,
};

export default handleActions(
  {
    [PENDDING]: (state, action) => {
      return {
        ...state,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
      };
    },
    [SET_OPTION_VALUE]: (state, action) => {
      const { key, value } = action.payload;
      var send = { ...state, [key]: value };

      return send;
    },
    [SET_DELIVERY_DAY]: (state, action) => {
      var { delivery } = state;
      delivery.day = action.payload;

      return {
        ...state,
        delivery: _.cloneDeep(delivery),
      };
    },
    [SET_OPTION_VALUE_DEEP]: (state, action) => {
      const { key, value } = action.payload;
      var send = { ...state, [key]: value };

      if (key === 'hour') {
        var { delivery, day } = state;
        delivery.day = moment()
          .weekday(parseInt(day))
          .add(2, 'days')
          .weekday();
        send.delivery = _.cloneDeep(delivery);
      }
      return send;
    },
    [SET_DELIVERY_HOUR]: (state, action) => {
      const { start, end } = action.payload;
      var { delivery } = state;
      delivery.hour = {
        start,
        end,
      };

      return {
        ...state,
        delivery: _.cloneDeep(delivery),
      };
    },

    [SET_PICKUP_TIME_LIST]: (state, action) => {
      const {
        pickupSlots,
        day,
        finishedActionWhenOrderComplete,
      } = action.payload;

      return {
        ...state,
        pickupSlots: _.cloneDeep(pickupSlots),
        finishedActionWhenOrderComplete,
        day,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
      };
    },
    [SET_DELIVERY_TIME_LIST]: (state, action) => {
      const { deliverySlots, day } = action.payload;
      return {
        ...state,
        deliverySlots: _.cloneDeep(deliverySlots),
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
      };
    },
    [BACK_PRESS]: (state, action) => {
      return initialState;
    },
  },
  _.cloneDeep(initialState),
);
