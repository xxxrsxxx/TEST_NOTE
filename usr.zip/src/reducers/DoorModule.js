import { handleActions, createAction } from 'redux-actions';

import axios from 'axios';

import * as CommonUtils from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import * as KeyUtils from '../utils/type/key';
import { Favorite } from '../utils/common/strings';
import WashAlert from '../utils/alert';

import moment from 'moment';

import { _ } from '../plugins';

moment.locale('ko');

const SET_HTTP_PENDING = 'door/SET_HTTP_PENDING';

const setHttpPending = createAction(SET_HTTP_PENDING);

export const updateDoorCodeAPI = ({ orderId, doorCode }) => async (
  dispatch,
  getState,
) => {
  dispatch(setHttpPending({ isPending: true }));
  const _storage = await $_storage.get();
  const uid = _storage[KeyUtils.USER_ID];
  const address = _storage[KeyUtils.USER_ADDRESS];
  await $_axios
    .post(ServerUtils.UPDATE_DOOR_CODE, {}, { uid, orderId, address, doorCode })
    .then(res => {
      const { code } = res.data;
      if (code === 200) {
      }
      dispatch(setHttpPending({ isPending: false }));
    })
    .catch(err => {
      dispatch(setHttpPending({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

const initialState = {
  isPending: false,
};

export default handleActions(
  {
    [SET_HTTP_PENDING]: (state, action) => {
      const { isPending } = action.payload;
      return {
        ...state,
        isPending,
      };
    },
  },
  _.cloneDeep(initialState),
);
