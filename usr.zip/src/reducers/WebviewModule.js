import { createAction, handleActions } from 'redux-actions';

import axios from 'axios';
import moment from 'moment';

import * as ServerUtils from '../utils/type/server';
import { Favorite } from '../utils/common/strings';
import WashAlert from '../utils/alert';

moment.locale('ko');

const SET_PENDING = 'webview/SET_PENDING';

const setPending = createAction(SET_PENDING);

export const pendingHandler = value => async (dispatch, getState) => {
  dispatch(setPending({ isPending: value }));
};

const initialState = {
  isPending: false,
};

export default handleActions(
  {
    [SET_PENDING]: (state, action) => {
      const { isPending } = action.payload;
      return {
        ...state,
        isPending,
      };
    },
  },
  initialState,
);
