import { Platform } from 'react-native';
import { Navigation } from 'react-native-navigation';
import { handleActions, createAction } from 'redux-actions';

import * as ServerUtils from '../utils/type/server';
import * as KeyUtils from '../utils/type/key';
import * as CommonUtils from '../utils/common/index';
import WashAlert from '../utils/alert';
import { ModalString, Favorite } from '../utils/common/strings';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';

import { _ } from '../plugins';

// action constructor
const SET_PREMIUM_CARE_ITEM = 'specialCare/SET_PREMIUM_CARE_ITEM';
const SET_PLUS_CARE_ITEM = 'specialCare/SET_PLUS_CARE_ITEM';
const SET_BASIC_REPAIR_ITEM = 'specialCare/SET_BASIC_REPAIR_ITEM';
const SET_ETC_ITEM = 'specialCare/SET_ETC_ITEM';
const RESET_SPECIAL_CARE_ITEM = 'specialCare/RESET_SPECIAL_CARE_ITEM';
const SET_ORDER = 'specialCare/SET_ORDER';
const ANY_ACIONS = 'specialCare/ANY_ACIONS';
const HTTP_PENDING = 'specialCare/HTTP_PENDING';

export const setPremiumCareItem = createAction(SET_PREMIUM_CARE_ITEM);
export const setPlusCareItem = createAction(SET_PLUS_CARE_ITEM);
export const setBasicRepairItem = createAction(SET_BASIC_REPAIR_ITEM);
export const setEtcItem = createAction(SET_ETC_ITEM);

export const resetSpecialCareItem = createAction(RESET_SPECIAL_CARE_ITEM);
export const setOrder = createAction(SET_ORDER);

export const setHttpPending = createAction(HTTP_PENDING);

const DB_KEY = 'care';

export const onSave = ({ orderId, componentId, callback }) => async (
  dispatch,
  getStore,
) => {
  const {
    premiumCareItem,
    plusCareItem,
    basicRepairItem,
    etcItem,
  } = getStore().SpecialCareModule;
  // Navigation.dismissModal(componentId);
  if (
    !premiumCareItem.isSelected &&
    !plusCareItem.isSelected &&
    !basicRepairItem.isSelected &&
    !etcItem.isSelected
  ) {
    /** 선택한게 없다면 그냥 닫기 **/
    dispatch(resetSpecialCareItem());
    Navigation.dismissModal(componentId);
  } else {
    /** 저장 **/
    WashAlert.showConfirm(
      ModalString.confirm,
      Favorite.yes,
      Favorite.no,
      async () => {
        const send = [];
        if (premiumCareItem.isSelected) {
          send.push({
            type: 'premium',
            message: premiumCareItem.comment,
            images: premiumCareItem.imageList,
          });
        }

        if (plusCareItem.isSelected) {
          send.push({
            type: 'pluscare',
            message: plusCareItem.comment,
            images: plusCareItem.imageList,
          });
        }
        if (basicRepairItem.isSelected) {
          send.push({
            type: 'repair',
            message: basicRepairItem.comment,
            images: basicRepairItem.imageList,
          });
        }
        if (etcItem.isSelected) {
          send.push({
            type: 'etc',
            message: etcItem.comment,
          });
        }
        if (send.length > 0) {
          dispatch(createAction(ANY_ACIONS)({ isPending: true }));
          await $_axios
            .post(
              ServerUtils.SET_PRE_OPTIONS,
              {},
              { orderId, key: DB_KEY, data: send },
            )
            .then(res => {
              dispatch(createAction(ANY_ACIONS)({ isPending: false }));
              const { code } = res.data;
              if (code === 200) {
                WashAlert.showAlertWithCallback(
                  '접수완료! 꼼꼼히 체크하겠습니닷',
                  Favorite.ok,
                  () => {
                    callback();
                    Navigation.dismissAllModals();
                  },
                );
                setAppsFlyerTrackEvent(send);
              } else {
                WashAlert.showAlert(Favorite.fail, Favorite.ok);
              }
            })
            .catch(err => {
              /** 에러처리 **/
              dispatch(createAction(ANY_ACIONS)({ isPending: false }));
              WashAlert.showAlert(Favorite.fail, Favorite.ok);
            });
        }
      },
    );
  }
};

const setAppsFlyerTrackEvent = async requestTypes => {
  const uid = await CommonUtils.getValue(KeyUtils.USER_ID);
  requestTypes.map((value, index) => {
    const { type } = value;
    AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_REQUEST, {
      af_content_type: type,
    });
    AnalyticsManager.setAirbridgeTrackEvent(
      AnalyticsKey.NAME_REQUEST,
      Platform.OS,
      uid,
    );
  });
};

const initialState = {
  order: null,
  premiumCareItem: {
    isSelected: false,
    comment: '',
    imageList: [],
  },
  plusCareItem: {
    isSelected: false,
    comment: '',
    selectedCareTypeList: [],
    imageList: [],
  },
  // plusCareS3ImageList: [],
  basicRepairItem: {
    isSelected: false,
    comment: '',
    selectedRepairTypeList: [],
    imageList: [],
  },
  etcItem: {
    isSelected: false,
    comment: '',
    imageList: [],
  },
  // plusCareTypeItem, repairTypeItem는 현재 프론트단에서 하드코딩 하고있으나 추후 API연동을 고려해 리덕스에서 관리
  plusCareTypeItem: {
    yellowRemove: {
      title: '황변제거',
      price: 2000,
    },
    bleaching: {
      title: '표백',
      price: 6000,
    },
    stainRemove: {
      title: '특수얼룩 제거',
      price: 3000,
    },
    etc: {
      title: '기타',
      price: 0,
    },
  },
  repairTypeItem: {
    buttonOrHookAttach: {
      title: '단추 후크 달기',
      price: 2000,
    },
    reSewing: {
      title: '재박음질',
      price: 3000,
    },
    zipperChange: {
      title: '지퍼교체',
      price: 2000,
    },
    pantsLengthRepair: {
      title: '바지 기장수선',
      price: 10000,
    },
    etc: {
      title: '기타',
      price: 0,
    },
  },
  isPending: false,
};

export default handleActions(
  {
    [SET_PREMIUM_CARE_ITEM]: (state, action) => {
      return {
        ...state,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
        premiumCareItem: action.payload,
      };
    },
    [SET_ORDER]: (state, action) => {
      var { premiumCareItem, plusCareItem, basicRepairItem, etcItem } = state;
      const { preOptions } = action.payload;
      if (preOptions && preOptions[DB_KEY] && preOptions[DB_KEY].options) {
        const { options } = preOptions[DB_KEY];
        const premium = _.find(options, { type: 'premium' });
        const pluscare = _.find(options, { type: 'pluscare' });
        const repair = _.find(options, { type: 'repair' });
        const etc = _.find(options, { type: 'etc' });

        if (premium) {
          premiumCareItem.isSelected = true;
          premiumCareItem.comment = premium.message;
          premiumCareItem.imageList = premium.images;
        }
        if (pluscare) {
          plusCareItem.isSelected = true;
          plusCareItem.comment = pluscare.message;
          plusCareItem.imageList = pluscare.images;
        }
        if (repair) {
          basicRepairItem.isSelected = true;
          basicRepairItem.comment = repair.message;
          basicRepairItem.imageList = repair.images;
        }
        if (etc) {
          etcItem.isSelected = true;
          etcItem.comment = etc.message;
        }
      }

      return {
        ...state,
        premiumCareItem: _.cloneDeep(premiumCareItem),
        plusCareItem: _.cloneDeep(plusCareItem),
        basicRepairItem: _.cloneDeep(basicRepairItem),
        etcItem: _.cloneDeep(etcItem),
      };
    },
    [SET_PLUS_CARE_ITEM]: (state, action) => {
      return {
        ...state,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
        plusCareItem: _.cloneDeep(action.payload),
      };
    },
    [SET_BASIC_REPAIR_ITEM]: (state, action) => {
      return {
        ...state,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
        basicRepairItem: _.cloneDeep(action.payload),
      };
    },
    [SET_ETC_ITEM]: (state, action) => {
      return {
        ...state,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
        etcItem: _.cloneDeep(action.payload),
      };
    },

    [RESET_SPECIAL_CARE_ITEM]: (state, action) => {
      return {
        ...state,
        premiumCareItem: {
          isSelected: false,
          comment: '',
          imageList: [],
        },
        plusCareItem: {
          isSelected: false,
          comment: '',
          selectedCareTypeList: [],
          imageList: [],
        },
        basicRepairItem: {
          isSelected: false,
          comment: '',
          selectedRepairTypeList: [],
          imageList: [],
        },
        etcItem: {
          isSelected: false,
          comment: '',
          imageList: [],
        },
      };
    },
    [HTTP_PENDING]: (state, action) => {
      return {
        ...state,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
      };
    },
  },
  initialState,
);
