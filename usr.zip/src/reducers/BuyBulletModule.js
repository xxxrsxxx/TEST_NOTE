import { Platform } from 'react-native';

import { createAction, handleActions } from 'redux-actions';

import * as PaymentAction from './PaymentModule';
import * as OrderHistoryAction from './OrderHistoryModule';
import * as MyPageAction from './MyPageModule';
import * as StartOrderAction from './StartOrderModule';

import * as KeyUtils from '../utils/type/key';
import * as ServerUtils from '../utils/type/server';
import WashAlert from '../utils/alert';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';
import { BuyBulletString, Favorite } from '../utils/common/strings';

const TOGGLE_OPEN_ADD_CARD_MODAL = 'BuyBulletModule/IS_OPEN_ADD_CARD_MODAL';
const TOGGLE_OPEN_PAY_COIN_MODAL = 'BuyBulletModule/IS_OPEN_PAY_COIN_MODAL';
const SET_ACTIVE_CARD = 'BuyBulletModule/SET_ACTIVE_CARD';
const BUY_COIN_PENDING = 'BuyBulletModule/BUY_COIN_PENDING';
const BUY_COIN_SUCCESS = 'BuyBulletModule/BUY_COIN_SUCCESS';
const BUY_COIN_FAILURE = 'BuyBulletModule/BUY_COIN_FAILURE';
const FINISH_COIN_PURCHASE = 'BuyBulletModule/FINISH_COIN_PURCHASE';

export const toggleOpenAddCardModal = createAction(TOGGLE_OPEN_ADD_CARD_MODAL);
export const toggleOpenPayCoinModal = createAction(TOGGLE_OPEN_PAY_COIN_MODAL);
export const setActiveCard = createAction(SET_ACTIVE_CARD);
const buyCoinPending = createAction(BUY_COIN_PENDING);
const buyCoinSuccess = createAction(BUY_COIN_SUCCESS);
const buyCoinFailure = createAction(BUY_COIN_FAILURE);
const finishCoinPurchase = createAction(FINISH_COIN_PURCHASE);

/**
 * 총알 구매 Screen의 Reducer
 * @category Reducer
 * @module
 */

/**
 * @description 카드 세팅
 * @method
 * @param {string} componentId
 */

export const setCard = componentId => (dispatch, getState) => {
  dispatch(
    PaymentAction.showBill({
      componentId,
      finishedAction: () => {
        dispatch(StartOrderAction.setAssetsAPI());
      },
    }),
  );
};

export const selectCard = billKey => (dispatch, getState) => {
  MyPageAction.setDefault({ billKey }, code => {
    if (code === 200) {
      dispatch(OrderHistoryAction.getAvailable());
    }
  });
};

export const selectPayCard = () => (dispatch, getState) => {
  WashAlert.showAlert(BuyBulletString.selectPayCard, Favorite.ok);
};

export const buyBullet = modalKind => async (dispatch, getState) => {
  const { activeButtonIndex, paymentArr } = getState().BuyBulletModule;
  const _storage = await $_storage.get();
  const uid = _storage[KeyUtils.USER_ID];
  const userType = _storage[KeyUtils.USER_TYPE];
  const name = _storage[KeyUtils.USER_NAME];

  const af_address = _storage[KeyUtils.USER_ADDRESS];
  const af_road_address = _storage[KeyUtils.USER_ROAD_ADDRESS];
  const af_detail_address = _storage[KeyUtils.USER_ADDRESS_OTHERS];
  const af_user_type = _storage[KeyUtils.USER_TYPE];

  const { value, bonus, memberBonus } = paymentArr[activeButtonIndex];
  const coinBonus = userType && userType == 'member' ? memberBonus : bonus;
  const coin = value;

  if (activeButtonIndex <= -1) return;

  dispatch(buyCoinPending());

  await $_axios
    .post(
      ServerUtils.BUY_COIN,
      {},
      { payType: 'bill', uid, coin: value, bonus: coinBonus, name },
    )
    .then(response => {
      const { code, message } = response.data;
      dispatch(
        buyCoinSuccess({
          loading: false,
        }),
      );

      if (code === 200) {
        dispatch(finishCoinPurchase({ purchasedCoin: value + coinBonus }));
        WashAlert.showAlert(BuyBulletString.buyBulletSuccess, Favorite.ok);

        if (modalKind === 'addCard') {
          dispatch(
            toggleOpenAddCardModal({
              isOpen: false,
              isActiveIndex: null,
            }),
          );
        } else {
          dispatch(
            toggleOpenPayCoinModal({
              isOpen: false,
              isActiveIndex: null,
            }),
          );
        }
        /* Analytic Manager */
        AnalyticsManager.setAppsFlyerTrackEvent(
          AnalyticsKey.NAME_ADD_PAYMENT_INFO,
          {
            af_uid: uid,
            af_address,
            af_road_address,
            af_detail_address,
            af_user_type,
            af_path: 'payment_method',
            af_add_payment_method: `coin${coin}`,
          },
        );
        AnalyticsManager.setAirbridgeTrackEvent(
          AnalyticsKey.NAME_ADD_PAYMENT_INFO,
          Platform.OS,
          uid,
        );
      } else {
        if (message) {
          /** 서버 실패 메시지 **/
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          /** 기본메시지 **/
          WashAlert.showAlert(BuyBulletString.buyBulletFail, Favorite.ok);
        }
      }
    })
    .then(() => {
      dispatch(MyPageAction.getCardAndCoin());
      dispatch(StartOrderAction.setAssetsAPI());
    })
    .catch(err => {
      WashAlert.showAlert(BuyBulletString.buyBulletFail, Favorite.ok);
    });
};

const initialState = {
  isOpenAddCardModal: false,
  isOpenPayCoinModal: false,
  activeButtonIndex: null,
  activeCardIndex: null,
  paymentArr: [
    { value: 150000, bonus: 0, memberBonus: 5000 },
    { value: 300000, bonus: 5000, memberBonus: 15000 },
    { value: 500000, bonus: 15000, memberBonus: 35000 },
  ],
  loading: false,
  error: false,
  purchasedCoin: 0,
};

export default handleActions(
  {
    [TOGGLE_OPEN_ADD_CARD_MODAL]: (state, action) => {
      const { isOpen, isActiveIndex } = action.payload;
      return {
        ...state,
        isOpenAddCardModal: isOpen,
        activeButtonIndex: isActiveIndex,
      };
    },
    [TOGGLE_OPEN_PAY_COIN_MODAL]: (state, action) => {
      const { isOpen, isActiveIndex } = action.payload;
      return {
        ...state,
        isOpenPayCoinModal: isOpen,
        activeButtonIndex: isActiveIndex,
      };
    },
    [SET_ACTIVE_CARD]: (state, action) => {
      const cardIndex = action.payload;
      return {
        ...state,
        activeCardIndex: cardIndex,
      };
    },
    [BUY_COIN_PENDING]: (state, action) => {
      return {
        ...state,
        loading: true,
      };
    },
    [BUY_COIN_SUCCESS]: (state, action) => {
      return {
        ...state,
        loading: false,
        activeButtonIndex: null,
      };
    },
    [BUY_COIN_FAILURE]: (state, action) => {
      return {
        ...state,
        loading: false,
        error: true,
      };
    },
  },
  initialState,
);
