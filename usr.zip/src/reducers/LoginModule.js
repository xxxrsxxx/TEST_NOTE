import { handleActions, createAction } from 'redux-actions';

import { Platform } from 'react-native';
import PushNotificationIOS from '@react-native-community/push-notification-ios';
import messaging from '@react-native-firebase/messaging';

import axios from 'axios';

import {
  SignTermsText,
  LoginChatText,
  AddressChatText,
  mapString,
  Favorite,
  LoginString,
} from '../utils/common/strings';

import {
  setNavigationRoot,
  globalDataSplit,
  navPush,
  showAlert,
} from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import WashAlert from '../utils/alert';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';
import * as Keys from '../utils/type/key';
import { apiTimeoutValue } from '../static/settings';

const DLAT = 37.50758963943969;
const DLON = 127.02647924423218;

const SERVICE_PENDING = 'login/SERVICE_PENDING';
const SERVICE_ERROR = 'login/SERVICE_ERROR';

const SEARCH_LOCATION = 'login/SEARCH_LOCATION';
const GET_ADDRESS = 'login/GET_ADDRESS';
const GET_ADDRESS_ERR = 'login/GET_ADDRESS_ERR';
const ADDRESS_ERROR_INIT = 'login/ADDRESS_ERROR_INIT';
const SELECT_LOCATION = 'login/SELECT_LOCATION';

const RE_ENTER_PHONE_NUM = 'login/RE_ENTER_PHONE_NUM';
const GET_CERTIFICATE_NUMBER = 'login/GET_CERTIFICATE_NUMBER';
const POST_CERTIFICATE_CHECK = 'login/POST_CERTIFICATE_CHECK';
const CERTIFICATE_CHECK_ERR = 'login/CERTIFICATE_CHECK_ERR';
const CERTIFICATE_OK = 'login/CERTIFICATE_OK';

const SERVICE_USE_POLICY_CHECK = 'login/SERVICE_USE_POLICY_CHECK';
const ALL_CHECK_USE_POLICY = 'login/ALL_CHECK_USE_POLICY';

const ADDRESS_OTHER_INPUT = 'login/ADDRESS_OTHER_INPUT';
const SAVE_ADDRESS_NAME_INPUT = 'login/SAVE_ADDRESS_NAME_INPUT';
const LOGIN_PENDING = 'login/LOGIN_PENDING';
const CLEAR_ERROR_MESSAGE = 'login/CLEAR_ERROR_MESSAGE';
const SET_ERROR_MESSAGE = 'login/SET_ERROR_MESSAGE';

const CLEAR_ADDRESS_LIST = 'login/CLEAR_ADDRESS_LIST';

const JOIN_TIMER = 'login/JOIN_TIMER';
const IS_UPDATE_POPUP = 'login/IS_UPDATE_POPUP';
const CHECK_NETWORK = 'login/CHECK_NETWORK';

export const joinTimer = createAction(JOIN_TIMER);

//모달 열리고 닫힐 때 message 초기화
export const addressErrUpdate = createAction(ADDRESS_ERROR_INIT);
export const addressOtherInput = createAction(ADDRESS_OTHER_INPUT);
export const clearErrorMessage = createAction(CLEAR_ERROR_MESSAGE);
export const clearAddressList = createAction(CLEAR_ADDRESS_LIST);
export const checkNetwork = createAction(CHECK_NETWORK);

export const saveAddressNameInput = createAction(SAVE_ADDRESS_NAME_INPUT);

export const handleCheckNetwork = successAction => async (
  dispatch,
  getState,
) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  let check = false;
  try {
    await $_axios.get(ServerUtils.CHECK_OFFLINE, {});

    dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
    successAction();
  } catch (err) {
    let message = LoginString.networkErrorModal;
    if (err && err.response && err.response.data && err.response.data.message) {
      message = err.response.data.message;
    }
    dispatch(createAction(SERVICE_ERROR)(err));
    if (!check) {
      check = true;
      WashAlert.showAlertWithCallback(
        message,
        LoginString.networkErrorModalButton,
        () => {},
      );
    }
  }
};

export const serviceUsePolicyCheck = ({ key }) => (dispatch, getState) => {
  let { servicePolicy, policyAllCheck } = getState().LoginModule;
  let requireAllCheck;
  const copyServicePolicy = $_.cloneDeep(servicePolicy);

  copyServicePolicy[key].isChecked = !copyServicePolicy[key].isChecked;

  requireAllCheck = copyServicePolicy
    .filter(item => {
      return item.isRequire == true;
    })
    .every(function(o) {
      return o.isChecked == true;
    });

  policyAllCheck = copyServicePolicy.every(function(o) {
    return o.isChecked == true;
  });

  dispatch(
    createAction(SERVICE_USE_POLICY_CHECK)({
      requireAllCheck,
      policyAllCheck,
      servicePolicy: copyServicePolicy,
    }),
  );
};

export const serviceUsePolicyAllCheck = () => (dispatch, getState) => {
  let { servicePolicy, policyAllCheck } = getState().LoginModule;
  const copyServicePolicy = $_.cloneDeep(servicePolicy);

  copyServicePolicy.map((item, i) => {
    item.isChecked = !policyAllCheck;
  });

  dispatch(
    createAction(ALL_CHECK_USE_POLICY)({
      servicePolicy: copyServicePolicy,
      policyAllCheck: !policyAllCheck,
      requireAllCheck: !policyAllCheck,
    }),
  );
};

export const postLogin = ({
  addressChatArr,
  addressInputTextType,
  addressTitle,
  componentId,
}) => async (dispatch, getState) => {
  const {
    roadAddress,
    addressOthers,
    phone,
    getLongitude,
    getLatitude,
    servicePolicy,
    tid,
    remainTime,
  } = getState().LoginModule;
  const appPush = $_.find(servicePolicy, { isChecked: true, type: 'push' });
  const giveMeGift = remainTime > 0 ? true : false;
  dispatch(
    createAction(LOGIN_PENDING)({
      addressChatArr,
      addressInputTextType,
      addressTitle,
      isPending: true,
    }),
  );

  try {
    const response = await $_axios.post(
      ServerUtils.USER_LOGIN,
      {},
      {
        roadAddress,
        addressOthers,
        phone,
        addressTitle,
        lat: getLatitude,
        lon: getLongitude,
        deviceType: Platform.OS,
        name: phone.substr(phone.length - 4, 4),
        appPush: appPush ? true : false,
        giveMeGift,
        bypassJoinAction: true,
      },
    );

    const { code, user, coupon, message } = response.data;
    if (code == 200) {
      const { uid, dong, accessToken } = user;
      // const { gift } = params;

      await new Promise(resolve => {
        AnalyticsManager.setAlias(uid, true, err => resolve());
      });
      clearInterval(tid);
      await logTimeout(0);
      AnalyticsManager.setAppsFlyerTrackEvent(
        AnalyticsKey.NAME_COMPLETE_REGISTRATION,
        {
          af_registration_method: 'phone',
          af_address: user.address,
          af_road_address: user.roadAddress,
          af_detail_address: user.addressOthers,
          af_date: new Date(),
        },
      );
      AnalyticsManager.setAirbridgeTrackEvent(
        AnalyticsKey.NAME_COMPLETE_REGISTRATION,
        Platform.OS,
        dong,
      );
      await logTimeout(100);
      $_storage.set(globalDataSplit(user));
      $_status.actions.statusHandler({ user });
      await logTimeout(100);
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
      setNavigationRoot({ coupon });
    } else {
      showAlert(message);
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
    }
  } catch (e) {}
};

export const selectLocation = ({
  address,
  roadAddress,
  componentId,
  mapViewRef,
  latitude,
  longitude,
  isOpen,
}) => (dispatch, getState) => {
  const { tLatitude, tLongitude, locationIsOpen } = getState().LoginModule;
  const copyAddressChatText = $_.cloneDeep(AddressChatText);
  const tempIsOpen = isOpen !== undefined ? isOpen : locationIsOpen;

  if (mapViewRef) {
    mapViewRef.animateToRegion({
      latitude: latitude,
      longitude: longitude,
      latitudeDelta: 0.003,
      longitudeDelta: 0.003,
    });
  }
  // if (false) {
  if (tempIsOpen) {
    copyAddressChatText.firstChat.textArr[0].textMiddle = `${roadAddress}`;
  } else {
    copyAddressChatText.firstChat.textArr[0].textMiddle = `${roadAddress}`;
    copyAddressChatText.firstChat.textArr[0].textEnd = `입니다.\n\n정말 아쉽게도 이 주소는 아직 서비스가 되지 않는 지역입니닷. 하지만 조만간 서비스 오픈 예정이니 가입해두시면, 오픈 즉시 알려드릴게요!\n\n가입 절차를 위해 나머지 동/호수를 알려주세요!`;
  }

  dispatch(
    createAction(SELECT_LOCATION)({
      address,
      roadAddress,
      tLatitude: latitude || tLatitude,
      tLongitude: longitude || tLongitude,
      addressChatArr: [copyAddressChatText.firstChat],
      locationIsOpen: isOpen === undefined || locationIsOpen,
      addressInputTextType: Keys.REMAINING_ADDRESS,
    }),
  );

  navPush({
    componentId,
    name: 'AddressChat',
  });
};

//전화번호 파라미터로 넘겨서 인증번호 요청
export const getCertificateNum = ({ phone }) => async (dispatch, getState) => {
  if (!phone) return;
  const { loginChatArr } = getState().LoginModule;
  const { certificate, reEnterPhoneNum, inputDemoText } = $_.cloneDeep(
    LoginChatText,
  );
  const tempDemoText = { ...inputDemoText };
  let tempChatArr = [];

  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  tempDemoText.textArr[0].text = phone;
  tempChatArr = tempChatArr.concat([
    tempDemoText,
    certificate,
    reEnterPhoneNum,
  ]);

  return await $_axios
    .post(ServerUtils.GET_CERTIFICATE_NUMBER, {}, { phone })
    .then(response => {
      const { code, certificate, message } = response.data;
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
      if (code == 200) {
        dispatch(
          createAction(GET_CERTIFICATE_NUMBER)({
            loginChatArr: loginChatArr.concat(tempChatArr),
            phone: phone,
            loginInputType: Keys.CERTIFICATE_NUMBER,
            isPending: false,
          }),
        );
      } else {
        //인증번호 횟수 초과 하거나 에러
        WashAlert.showAlert(message, Favorite.ok);
      }
    })
    .catch(err => {
      dispatch(createAction(SERVICE_ERROR)(err));
    });
};
//전화번호 재입력
export const reEnterPhoneNum = (parentIndex, childIndex) => (
  dispatch,
  getState,
) => {
  const { loginChatArr } = getState().LoginModule;
  let tempLoginChatArr = [...loginChatArr];
  const tempTextObj = tempLoginChatArr[parentIndex].textArr[childIndex];
  tempTextObj.background = true;

  dispatch(
    createAction(RE_ENTER_PHONE_NUM)({
      loginChatArr: tempLoginChatArr,
      loginInputType: Keys.PHONE_NUMBER,
    }),
  );
};

//인증번호 검사
export const postCertificateCheck = ({
  componentId,
  certificateNumber,
}) => async (dispatch, getState) => {
  const { loginChatArr, phone, tid } = getState().LoginModule;
  const { notMatchCertificate, reEnterPhoneNum } = $_.cloneDeep(LoginChatText);

  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  try {
    const response = await $_axios.post(
      ServerUtils.POST_CERTIFICATE_CHECK,
      {},
      { phone, certificateNumber },
    );

    dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
    const { code, user } = response.data;

    if (code == 200) {
      if (user) {
        const { hasActiveOrder } = user;
        if (hasActiveOrder) {
          $_storage.set(globalDataSplit(user));
          $_status.actions.statusHandler({ user });

          await logTimeout(0);
          setNavigationRoot();
          await logTimeout(0);
          clearInterval(tid);
        } else {
          navPush({
            componentId,
            name: 'LoginQuestion',
            passProps: {
              accessToken: user.accessToken,
            },
          });
        }
      } else {
        // 신규회원 가입 시작
        navPush({
          componentId,
          name: 'SignTerms',
        });
      }
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
    } else {
      WashAlert.showAlert(LoginChatText.certificateNumberCheck, Favorite.ok);
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
    }
  } catch (e) {
    WashAlert.showAlert(LoginChatText.certificateNumberCheck, Favorite.ok);
    dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
  }
};

export const getGlobalData = ({
  uid,
  goToRoot,
  versionCode,
  callback,
}) => async dispatch => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  const { OS } = Platform;

  try {
    const userAppNotificationToken = await $_storage.get(Keys.TOKEN);
    const response = await $_axios.post(
      ServerUtils.PATH_GLOBALDATA,
      {},
      { uid, versionCode, deviceType: OS },
    );
    const { user } = response.data;
    dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
    if (user) {
      let notification;
      $_storage.set(globalDataSplit(user));
      $_status.actions.statusHandler({ user });

      /**
       * Noti check
       */
      if (userAppNotificationToken) {
        try {
          if (OS === 'android') {
            notification = await messaging().getInitialNotification();
          } else {
            // notification = await PushNotificationIOS.getInitialNotification();
          }
          console.log('Washswat-Firebase,', 'module', notification);
        } catch (e) {
          // console.log('Washswat-Firebase' , 'ok' ,e);
        }
      }

      if (goToRoot) {
        /** 페이지 이동 **/
        const {
          update: { hard, popup },
        } = user;
        if (hard || popup) {
          dispatch(
            createAction(IS_UPDATE_POPUP)({
              updateHard: hard,
              updateSelect: popup,
            }),
          );
        } else {
          setNavigationRoot({ notification });
        }
      } else {
        if (callback) {
          callback();
        }
      }
    } else {
      if (callback) {
        callback(100);
      }
    }
  } catch (err) {
    dispatch(createAction(SERVICE_ERROR)(err));
    if (callback) {
      callback(100);
    }
  }
};

const checkUpdatePopup = (user, dispatch, finishedAction) => {
  const {
    versionCode,
    update: { hard, popup },
  } = user;
  dispatch(
    createAction(IS_UPDATE_POPUP)({ updateHard: hard, updateSelect: popup }),
  );
  if (!(hard || popup)) {
    finishedAction();
  }
};

//주소 리스트 불러오기
export const getLocation = ({ q }) => async dispatch => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  return await $_axios
    .post(ServerUtils.LOCATION_SEARCH, {}, { q })
    .then(response => {
      const { code, count, result, data } = response.data;
      if (code == 200) {
        if (count) {
          dispatch(
            createAction(SEARCH_LOCATION)({
              addressList: data,
              isPending: false,
            }),
          );
        } else {
          dispatch(createAction(SERVICE_PENDING)({ isPending: false }));

          WashAlert.showAlert(mapString.noResult, Favorite.ok);
        }
      } else {
        dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    })
    .catch(err => {
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

//지도에서 마커 움직일 때 액션
export const getAddress = ({ region, dropdownRef }) => async dispatch => {
  const { longitude, latitude } = region;

  return await $_axios
    .post(ServerUtils.GET_ADDRESS, {}, { lon: longitude, lat: latitude })
    .then(response => {
      const { code, address, address2, message, isOpen } = response.data;

      if (code == 200) {
        dispatch(
          createAction(GET_ADDRESS)({
            getLongitude: longitude,
            getLatitude: latitude,
            roadAddress: address,
            address: address2,
            locationIsOpen: isOpen,
          }),
        );
      } else {
        dropdownRef.alertWithType('custom', '', message);
        dispatch(
          createAction(GET_ADDRESS_ERR)({ message, locationIsOpen: undefined }),
        );
      }
    })
    .catch(err => {
      dispatch(createAction(SERVICE_ERROR)(err));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const initUpdatePopup = ({ updateHard, updateSelect }) => (
  dispatch,
  getState,
) => {
  dispatch(createAction(IS_UPDATE_POPUP)({ updateSelect, updateHard }));
};

const initialState = {
  loginInputType: Keys.PHONE_NUMBER,
  addressList: [], //주소 검색했을 때 나오는 주소 리스트
  address: '', //일반 주소
  roadAddress: '', //도로명 주소
  message: '', //지도 핀 이동시 돌아오는 메시지
  userData: null, //휴대폰 인증 하고 돌아오는 유저 정보
  loginChatArr: [LoginChatText.firstChat], //로그인 채팅 리스트
  phone: '', //전번
  addressChatArr: [AddressChatText.firstChat],
  tLatitude: DLAT,
  tLongitude: DLON,
  getLatitude: DLAT,
  getLongitude: DLON,
  addressOthers: '', //나머지 주소
  addressTitle: '', //주소 이름 등록

  addressInputTextType: Keys.REMAINING_ADDRESS,

  commonPorchText: '',

  servicePolicy: SignTermsText.bottomTextArr,
  requireAllCheck: false, //필수 약관 전체 동의
  policyAllCheck: false, //모든 약관 전체 동의

  timerCounter: '05:00',
  tid: null,
  errorPopup: ``,
  remainTime: 300,
  locationIsOpen: undefined,
  isPending: false,
  updateSelect: false,
  updateHard: false,
};

export default handleActions(
  {
    [LOGIN_PENDING]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SAVE_ADDRESS_NAME_INPUT]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [ADDRESS_OTHER_INPUT]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [CLEAR_ERROR_MESSAGE]: (state, action) => {
      return {
        ...state,
        errorPopup: ``,
      };
    },
    [SET_ERROR_MESSAGE]: (state, action) => {
      const { message } = action.payload;
      return {
        ...state,
        errorPopup: message || ``,
      };
    },

    [ALL_CHECK_USE_POLICY]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SERVICE_USE_POLICY_CHECK]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SEARCH_LOCATION]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SERVICE_ERROR]: (state, action) => {},

    [GET_ADDRESS]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_ADDRESS_ERR]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [ADDRESS_ERROR_INIT]: (state, action) => {
      return {
        ...state,
        message: action.payload,
      };
    },
    [RE_ENTER_PHONE_NUM]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_CERTIFICATE_NUMBER]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [CERTIFICATE_CHECK_ERR]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SELECT_LOCATION]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [JOIN_TIMER]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SERVICE_PENDING]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [CLEAR_ADDRESS_LIST]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [IS_UPDATE_POPUP]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
  initialState,
);

const logTimeout = async ms => {
  return new Promise(resolve => setTimeout(resolve, ms));
};
