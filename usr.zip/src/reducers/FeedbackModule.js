import { createAction, handleActions } from 'redux-actions';

import {
  Favorite,
  FeedbackAfterOrderString,
  FeedbackBadExperienceSelectionString,
} from '../utils/common/strings';
import * as CommonUtils from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import WashAlert from '../utils/alert';

import { _ } from '../plugins';

const ACTION_CHANGE_STAR_RATING = 'feedback/ACTION_CHANGE_STAR_RATING';
const ACTION_SET_FEEDBACK = 'feedback/ACTION_SET_FEEDBACK';
const ACTION_SET_SHOW_FEEDBACK_INPUT =
  'feedback/ACTION_SET_SHOW_FEEDBACK_INPUT';
const ACTION_SET_SHOW_FEEDBACK_INPUT_BAD =
  'feedback/ACTION_SET_SHOW_FEEDBACK_INPUT_BAD';
const ACTION_SET_BAD_EXPERIENCE_ANSWER_OBJECT =
  'feedback/ACTION_SET_BAD_EXPERIENCE_ANSWER_OBJECT';
const BACK_PRESS = 'feedback/BACK_PRESS';
const ANY_ACIONS = 'feedback/ANY_ACIONS';

export const backPrsess = createAction(BACK_PRESS);
export const anyAction = createAction(ANY_ACIONS);

export const finished = (orderId, callback) => async (dispatch, getStore) => {
  const {
    pickupStarCount,
    deliveryStarCount,
    washStarCount,
    feedback,
  } = getStore().FeedbackModule;
  if (pickupStarCount && deliveryStarCount && washStarCount && feedback) {
    dispatch(createAction(ANY_ACIONS)({ isPending: true }));
    await $_axios
      .post(
        ServerUtils.UPDATE_FEEDBACK,
        {},
        {
          pickup: pickupStarCount,
          delivery: deliveryStarCount,
          quality: washStarCount,
          message: feedback,
          orderId,
        },
      )
      .then(response => {
        const { code } = response.data;
        if (code === 200) {
          callback();
        } else {
          dispatch(createAction(ANY_ACIONS)({ isPending: false }));
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      })
      .catch(error => {
        dispatch(createAction(ANY_ACIONS)({ isPending: false }));
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      });
  }
};

export const setPickupStarRating = ({
  pickupPoint,
  pickupPointTextColorFlag,
  pickupStarCount,
}) => (dispatch, getStore) => {
  dispatch(
    createAction(ACTION_CHANGE_STAR_RATING)({
      pickupPoint,
      pickupPointTextColorFlag,
      pickupStarCount,
    }),
  );
};
export const setDeliveryStarRating = ({
  deliveryPoint,
  deliveryPointTextColorFlag,
  deliveryStarCount,
}) => (dispatch, getStore) => {
  dispatch(
    createAction(ACTION_CHANGE_STAR_RATING)({
      deliveryPoint,
      deliveryPointTextColorFlag,
      deliveryStarCount,
    }),
  );
};
export const setWashStarRating = ({
  washPoint,
  washPointTextColorFlag,
  washStarCount,
}) => (dispatch, getStore) => {
  const payload = { washPoint, washPointTextColorFlag, washStarCount };
  dispatch(createAction(ACTION_CHANGE_STAR_RATING)(payload));
};
export const setFeedback = ({ feedback }) => (dispatch, getStore) => {
  dispatch(createAction(ACTION_SET_FEEDBACK)({ feedback }));
};
export const setShowFeedbackInput = createAction(
  ACTION_SET_SHOW_FEEDBACK_INPUT,
);
export const setShowFeedbackInputOfBad = createAction(
  ACTION_SET_SHOW_FEEDBACK_INPUT_BAD,
);
export const setBadExperienceAnswerObject = createAction(
  ACTION_SET_BAD_EXPERIENCE_ANSWER_OBJECT,
);

const initialState = {
  pickupPoint: FeedbackAfterOrderString.pickupPoint,
  pickupPointTextColorFlag: false,
  pickupStarCount: 0,
  deliveryPoint: FeedbackAfterOrderString.deliveryPoint,
  deliveryPointTextColorFlag: false,
  deliveryStarCount: 0,
  washPoint: FeedbackAfterOrderString.washPoint,
  washPointTextColorFlag: false,
  washStarCount: 0,
  isShowFeedbackInput: false,
  isShowFeedbackInputOfBad: false,
  feedback: '',
  badExperienceAnswerObject: FeedbackBadExperienceSelectionString.answer,
  isPending: false,
};

export default handleActions(
  {
    [ACTION_CHANGE_STAR_RATING]: (state, action) => {
      const { payload } = action;
      var newState = _.cloneDeep(state);
      _.map(payload, (value, index) => {
        newState[index] = value;
      });
      const {
        pickupPointTextColorFlag,
        deliveryPointTextColorFlag,
        washPointTextColorFlag,
      } = newState;
      if (
        pickupPointTextColorFlag &&
        deliveryPointTextColorFlag &&
        washPointTextColorFlag
      ) {
        newState.isShowFeedbackInput = true;
      } else {
        newState.isShowFeedbackInput = false;
      }
      return newState;
    },
    [ACTION_SET_FEEDBACK]: (state, action) => {
      const { feedback } = action.payload;
      return {
        ...state,
        feedback,
      };
    },
    [ACTION_SET_SHOW_FEEDBACK_INPUT]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [ACTION_SET_SHOW_FEEDBACK_INPUT_BAD]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [ACTION_SET_BAD_EXPERIENCE_ANSWER_OBJECT]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [BACK_PRESS]: (state, action) => {
      return initialState;
    },
    [ANY_ACIONS]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
  _.cloneDeep(initialState),
);
