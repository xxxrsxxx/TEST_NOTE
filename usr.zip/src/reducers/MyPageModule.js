import { handleActions, createAction } from 'redux-actions';

import { Platform } from 'react-native';
import { Navigation } from 'react-native-navigation';

import async from 'async';

import {
  PhoneNumChangeChat,
  MyPageString,
  UserWithdrawalString,
  SettingsString,
  Favorite,
} from '../utils/common/strings';
import { setRootLogin, globalDataSplit } from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import * as Keys from '../utils/type/key';
import WashAlert from '../utils/alert';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';
import * as comm from '../utils/common';
const ANY_ACTIONS = 'myPage/ANY_ACTIONS';
const SERVICE_PENDING = 'myPage/SERVICE_PENDING';
const SERVICE_ERROR = 'myPage/SERVICE_ERROR';

const GET_POINT = 'myPage/GET_POINT';
const GET_CARD_AND_COIN = 'myPage/GET_CARD_AND_COIN';

const IS_POINT_RENDER = 'myPage/IS_POINT_RENDER';

const GET_COUPON_LIST = 'myPage/GET_COUPON_LIST';
const MEMBERSHIP_INFO = 'myPage/MEMBERSHIP_INFO';

const GET_QNA = 'myPage/GET_QNA';
const CHANGE_NAME = 'myPage/CHANGE_NAME';
const LOGOUT = 'myPage/LOGOUT';
const GET_ANNOUNCEMENT = 'myPage/GET_ANNOUNCEMENT';
const APP_PUSH = 'mypage/APP_PUSH';
const MY_PAGE_INIT = 'mypage/MY_PAGE_INIT';
const SET_MEMBER_VALUE = 'mypage/SET_MEMBER_VALUE';
const SET_FREE_TICKET_VALUE = 'mypage/SET_FREE_TICKET_VALUE';
const JOIN_MEMBER = 'mypage/JOIN_MEMBER';

const GET_CERTIFICATE_NUMBER = 'myPage/GET_CERTIFICATE_NUMBER';
const POST_CERTIFICATE_CHECK = 'myPage/POST_CERTIFICATE_CHECK';
const RESET_PHONE_NUMBER_CHAT = 'myPage/RESET_PHONE_NUMBER_CHAT';
const RE_ENTER_PHONE_NUM = 'myPage/RE_ENTER_PHONE_NUM';
const UPDATE_CARD = 'myPage/UPDATE_CARD';
const CHANGE_USER_NAME_SUCCESS = 'myPage/CHANGE_USER_NAME_SUCCESS';
const SET_CERTIFICATION_CODE_ID = 'myPage/SET_CERTIFICATION_CODE_ID';
const SET_CERTIFICATION_TOKEN = 'myPage/SET_CERTIFICATION_TOKEN';

import { ChannelIO } from 'react-native-channel-plugin';

export const setServicePending = createAction(SERVICE_PENDING);
export const resetPhoneNumberChat = createAction(RESET_PHONE_NUMBER_CHAT);
export const reEnterPhoneNumber = createAction(RE_ENTER_PHONE_NUM);
const changeUserNameSuccess = createAction(CHANGE_USER_NAME_SUCCESS);

const setCertificationCodeId = certificationCodeId => (dispatch, getState) => {
  dispatch(createAction(SET_CERTIFICATION_CODE_ID)({ certificationCodeId }));
};

const setCertificationToken = certificationToken => (dispatch, getState) => {
  dispatch(createAction(SET_CERTIFICATION_TOKEN)({ certificationToken }));
};

export const setDefault = ({ billKey }, finishedAction) => async (
  dispatch,
  getState,
) => {
  const { uid } = $_status.state.user;

  WashAlert.showConfirm(
    MyPageString.defaultCard,
    Favorite.yes,
    Favorite.no,
    async () => {
      await $_axios
        .post(ServerUtils.SET_DEFAULT_CARD, {}, { uid, billKey })
        .then(response => {
          const { code, card } = response.data;
          if (code === 200) {
            if (finishedAction) {
              finishedAction(code);
            } else {
              dispatch(createAction(UPDATE_CARD)(card));
            }
          } else {
            WashAlert.showAlert(Favorite.fail, Favorite.ok);
          }
        });
    },
  );
};

export const setDefaultCardAPI = ({ billKey }, finishedAction) => async (
  dispatch,
  getState,
) => {
  const { uid } = $_status.state.user;

  await $_axios
    .post(ServerUtils.SET_DEFAULT_CARD, {}, { uid, billKey })
    .then(response => {
      const { code, card } = response.data;
      if (code === 200) {
        if (finishedAction) {
          finishedAction(code);
        } else {
          dispatch(createAction(UPDATE_CARD)(card));
        }
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    });
};

export const deleteBillKey = ({ billKey }) => async (dispatch, getState) => {
  const { uid } = $_status.state.user;
  WashAlert.showConfirm(
    MyPageString.deleteCard,
    Favorite.yes,
    Favorite.no,
    async () => {
      await $_axios
        .post(ServerUtils.DELETE_CARD, {}, { uid, billKey })
        .then(response => {
          const { code, card } = response.data;
          if (code === 200) {
            dispatch(createAction(UPDATE_CARD)(card));
          } else {
            WashAlert.showAlert(Favorite.fail, Favorite.ok);
          }
        });
    },
  );
};

export const getCertificateNum = ({ phoneNum }) => async (
  dispatch,
  getState,
) => {
  const { certificate, directInput, reEnterPhoneNum } = $_.cloneDeep(
    PhoneNumChangeChat,
  );
  let { phoneNumChangeChatArr } = getState().MyPageModule;

  return await $_axios
    .post(ServerUtils.GET_CERTIFICATION_CODE, {}, { phone_number: phoneNum })
    .then(response => {
      const { certification_code_id, created_at, expired_at } = response.data;
      dispatch(setCertificationCodeId(certification_code_id));
      directInput.textArr[0].text = phoneNum;
      let copyPhoneNumChangeChatArr = phoneNumChangeChatArr.concat([
        directInput,
        certificate,
        reEnterPhoneNum,
      ]);
      dispatch(
        createAction(GET_CERTIFICATE_NUMBER)({
          phoneNumChangeChatArr: copyPhoneNumChangeChatArr,
          phoneNumChangeInputType: 'postCertificateCheck',
        }),
      );
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const postCertificateCheck = ({
  phone,
  certificateNumber,
  componentId,
}) => async (dispatch, getState) => {
  const { certificationCodeId } = getState().MyPageModule;

  return await $_axios
    .post(
      ServerUtils.GET_CERTIFICATION_TOKEN,
      {},
      {
        phone_number: phone,
        code: certificateNumber,
        code_id: certificationCodeId,
      },
    )
    .then(response => {
      const { expired_at, token } = response.data;
      dispatch(
        updatePhoneNumber({
          phoneNumber: phone,
          certificationToken: token,
          componentId,
        }),
      );
    })
    .catch(err => {
      WashAlert.showAlert(err.response.data.title, Favorite.ok);
    });
};

const updatePhoneNumber = ({
  phoneNumber,
  certificationToken,
  componentId,
}) => async (dispatch, getState) => {
  const { uid } = $_status.state.user;

  return await $_axios
    .patch(
      ServerUtils.UPDATE_PHONE_NUMBER,
      { headers: { 'x-authorization-temporary': certificationToken } },
      { user_id: uid, phone_number: phoneNumber },
    )
    .then(response => {
      dispatch(resetPhoneNumberChat());
      Navigation.pop(componentId);
      WashAlert.showAlert(SettingsString.phoneChangeComplete, Favorite.ok);
    })
    .catch(err => {
      WashAlert.showAlert(err.response.data.title, Favorite.ok);
    });
};

export const getAnnouncement = () => async (dispatch, getState) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  const { uid } = $_status.state.user;
  return await $_axios
    .post(
      ServerUtils.GET_ANNOUNCEMENT,
      {},
      {
        uid,
      },
    )
    .then(response => {
      const { code, list, message } = response.data;

      if (code == 200) {
        dispatch(
          createAction(GET_ANNOUNCEMENT)({
            announceList: list,
            isPending: false,
          }),
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const couponRegist = ({ inputValue, callback }) => async (
  dispatch,
  getState,
) => {
  const { uid } = $_status.state.user;

  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  return await $_axios
    .post(
      ServerUtils.COUPON_REGIST,
      {},
      {
        uid,
        code: inputValue,
        issueType: 'auto',
      },
    )
    .then(response => {
      const { code, message } = response.data;
      callback();
      if (code == 200) {
        dispatch(getCouponList());
        // Navigation.pop(componentId);
        AnalyticsManager.setAppsFlyerTrackEvent(
          AnalyticsKey.NAME_REGISTRATION_COUPON,
        );
        AnalyticsManager.setAirbridgeTrackEvent(
          AnalyticsKey.NAME_REGISTRATION_COUPON,
          Platform.OS,
          uid,
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

//로그아웃
export const logOut = () => (dispatch, getState) => {
  if (ChannelIO) {
    ChannelIO.shutdown();
  }
  $_storage.allClear();
  dispatch(createAction(LOGOUT)());
  setRootLogin();
};

//회원 이름 변경
export const changeName = ({ inputValue, componentId }) => async (
  dispatch,
  getState,
) => {
  dispatch(createAction(SERVICE_PENDING));
  const { uid } = $_status.state.user;

  return $_axios
    .post(ServerUtils.CHANGE_NAME, {}, { uid, value: inputValue })
    .then(response => {
      const { code } = response.data;
      if (code === 200) {
        $_storage.set(Keys.USER_NAME, inputValue);
        $_status.actions.statusHandler(
          { user: { name: inputValue } },
          'overriding',
        );
        dispatch(changeUserNameSuccess(inputValue));
        Navigation.pop(componentId);
        WashAlert.showAlert(SettingsString.nicknameChangeComplete, Favorite.ok);
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

//쿠폰 리스트 가져오기
export const getCouponList = props => async (dispatch, getState) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  const { uid } = $_status.state.user;
  const send = { uid };
  if (props && props.objectId) send.objectId = props.objectId;

  return await $_axios
    .post(ServerUtils.GET_COUPON_LIST, {}, send)
    .then(response => {
      const { code, dataList, message } = response.data;
      if (code == 200) {
        dispatch(
          createAction(GET_COUPON_LIST)({
            couponList: dataList,
            isPending: false,
          }),
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
    });
};
//앱 푸쉬
export const appPush = () => async (dispatch, getState) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  const { uid } = $_status.state.user;

  const {
    userInfo: { appPush },
  } = getState().MyPageModule;

  return await $_axios
    .post(
      ServerUtils.APP_PUSH,
      {},
      {
        uid,
        agreed: !appPush,
      },
    )
    .then(response => {
      const { date, code, message } = response.data;
      var getPushValue;
      if (code == 200) {
        if (date) {
          getPushValue = true;
          $_storage.set(Keys.APP_PUSH, date);
          WashAlert.showAlert(SettingsString.notiOn, Favorite.ok);
        } else {
          getPushValue = false;
          $_storage.delete(Keys.APP_PUSH);
          WashAlert.showAlert(SettingsString.notiOff, Favorite.ok);
        }
        dispatch(
          createAction(APP_PUSH)({ appPush: getPushValue, isPending: false }),
        );
        AnalyticsManager.setAppsFlyerTrackEvent(
          AnalyticsKey.NAME_PUSH_SETTING,
          {
            af_push: getPushValue,
          },
        );
        AnalyticsManager.setAirbridgeTrackEvent(
          AnalyticsKey.NAME_PUSH_SETTING,
          Platform.OS,
          uid,
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const getMemberValue = () => async (dispatch, getState) => {
  const { uid } = $_status.state.user;
  const url = ServerUtils.MEMBER_VALUE;
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  const _url = url.replace(':uid', uid);
  await $_axios
    .post(_url, {}, {})
    .then(response => {
      const { data, message } = response.data;
      dispatch(
        createAction(SET_MEMBER_VALUE)({
          memberValue: data,
          uid,
          isPending: false,
        }),
      );
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const getFreeTicketValue = () => async (dispatch, getState) => {
  const { uid } = $_status.state.user;
  const url = ServerUtils.FREE_TICKET_VALUE;
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  const _url = url.replace(':uid', uid);
  await $_axios
    .post(_url, {}, {})
    .then(response => {
      const { json, message } = response.data;
      dispatch(
        createAction(SET_FREE_TICKET_VALUE)({
          freeTicketValue: json,
          uid,
          isPending: false,
        }),
      );
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const joinMember = ({ type, finishedAction }) => async (
  dispatch,
  getState,
) => {
  const { uid } = $_status.state.user;
  WashAlert.showConfirm(
    MyPageString.joinMember,
    Favorite.yes,
    Favorite.no,
    async () => {
      dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
      try {
        await $_axios.post(ServerUtils.JOIN_MEMBER, {}, { uid, type });
        $_storage.set(Keys.USER_TYPE, 'member');
        if (finishedAction) {
          finishedAction('member');
        }
      } catch (error) {
        dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
        if (error && error.response && error.response.data) {
          WashAlert.showAlert(
            error.response.data.message || Favorite.fail,
            Favorite.ok,
          );
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    },
  );
};

export const checkMember = ({ finishedAction }) => async (
  dispatch,
  getState,
) => {
  const uid = $_status.state.user.uid;

  await $_axios
    .post(ServerUtils.CHECK_MEMBER, {}, { uid })
    .then(response => {
      const { code, isMember, isHadMember, message } = response.data;
      if (code === 200) {
        dispatch(createAction(ANY_ACTIONS)({ isMember, isHadMember }));
        if (finishedAction) {
          finishedAction();
        }
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
    });
};

const global = ({ uid, callback }) => async dispatch => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  await $_axios
    .post(ServerUtils.PATH_GLOBALDATA, {}, { uid })
    .then(response => {
      const { code, user, message } = response.data;
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
      if (code == 200) {
        $_storage.set(globalDataSplit(user));
        if (callback) {
          callback();
        }
      }
    })
    .catch(err => {
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

//My 페이지 들어올때 실행
export const myPageInit = () => async (dispatch, getState) => {
  const { uid, userType, name, appPush } = $_status.state.user;
  const send = { ...{ uid }, ...{ userType }, ...{ name }, ...{ appPush } };

  $_.forEach(send, (value, key) => {
    if (value === null || value === 'null') send[key] = null;
  });

  dispatch(createAction(MY_PAGE_INIT)(send));
};

//QnA 가져오기
export const getQnA = () => async (dispatch, getState) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  return await $_axios
    .post(ServerUtils.GET_QNA, {}, {})
    .then(response => {
      const { data, code, message } = response.data;
      if (code == 200) {
        dispatch(createAction(GET_QNA)({ QnAList: data, isPending: false }));
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

//초대번호 입력
export const AccumulationCodeRegist = ({ inputValue, componentId }) => async (
  dispatch,
  getState,
) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  const globalData = await $_storage.getArray([Keys.USER_ID, Keys.USER_NAME]);

  const tmpObj = {};
  globalData.map((data, i) => {
    tmpObj[data[0]] = data[1];
  });
  return await $_axios
    .post(
      ServerUtils.ACCUMULATIONCODE_REGIST,
      {},
      {
        uid: tmpObj.uid,
        name: tmpObj.name,
        code: inputValue,
        deviceType: Platform.OS,
      },
    )
    .then(response => {
      const { data, code, message } = response.data;
      if (code == 200) {
        dispatch(getPoint());
        Navigation.pop(componentId);
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

//포인트 내역 및 보유포인트, 카드리스트, 총알
export const getPoint = () => async (dispatch, getState) => {
  const { uid } = $_status.state.user;
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  // dispatch(globalPendingHandler(true));

  return await $_axios
    .post(
      ServerUtils.GET_ASSETS,
      {},
      {
        uid,
        point: true,
        pointHistory: true,
        membership: true,
        coin: true,
        coinHistory: true,
      },
    )
    .then(response => {
      const { data, code, message } = response.data;
      if (code == 200) {
        const { point, membership, coin } = data;
        const payload = { membership };
        payload.isPending = false;
        if (point) {
          payload.userPoint = point.point;
          payload.pointHistory = point.history;
          payload.isPlus = point.isPlus;
        }
        if (coin) {
          payload.userCoin = coin.coin;
          payload.coinHistory = coin.history;
        }

        dispatch(createAction(GET_POINT)(payload));
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
        dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
      }

      // dispatch(globalPendingHandler(false));
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
      // dispatch(globalPendingHandler(false));
    });
};

export const getCardAndCoin = () => async (dispatch, getState) => {
  const { uid } = $_status.state.user;
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  return await $_axios
    .post(
      ServerUtils.GET_ASSETS,
      {},
      { uid, bill: true, coin: true, coinHistory: true },
    )
    .then(response => {
      const { data, code, message } = response.data;
      if (code == 200) {
        const { coin, bill } = data;
        const payload = {};
        payload.isPending = false;

        if (coin) {
          payload.userCoin = coin.coin;
          payload.coinHistory = coin.history;
        }

        if (bill) {
          payload.userCardList = bill;
        }

        dispatch(createAction(GET_CARD_AND_COIN)(payload));
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

// 회원탈퇴
export const withdrawal = reason => async (dispatch, getState) => {
  const { uid } = $_status.state.user;
  return await $_axios
    .post(ServerUtils.WITHDRAWAL, {}, { uid, reason })
    .then(response => {
      const { code, message } = response.data;
      if (code === 200) {
        WashAlert.showAlertWithCallback(
          UserWithdrawalString.withdrawalAlertContent,
          Favorite.ok,
          () => {
            dispatch(logOut());
          },
        );
        AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_SIGN_OUT, {
          af_date: new Date(),
        });
        AnalyticsManager.setAirbridgeTrackEvent(
          AnalyticsKey.NAME_SIGN_OUT,
          Platform.OS,
          uid,
        );
      } else {
        WashAlert.showAlert(message, Favorite.ok);
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};
// 멤버십 해지
export const exitMembership = ({
  cancelReason,
  componentId,
  finishedAction,
}) => async (dispatch, getState) => {
  const uid = $_status.state.user.uid;

  async.waterfall(
    [
      async callback => {
        await $_axios
          .post(ServerUtils.MEMBERSHIPCANCEL, {}, { uid, cancelReason })
          .then(response => {
            const { code, message } = response.data;
            if (code === 200) {
              callback();
            } else {
              callback(message || Favorite.fail);
            }
          })
          .catch(err => {
            callback(Favorite.fail);
          });
      },
      callback => {
        dispatch(
          global({
            uid,
            callback,
          }),
        );
      },
    ],
    errMessage => {
      if (errMessage) {
        WashAlert.showAlert(errMessage, Favorite.ok);
      } else {
        dispatch(myPageInit());
        if (finishedAction) {
          finishedAction();
        }
      }
    },
  );
};
// 멤버십 인포(혜택,결제내역)
export const membershipInfo = () => async (dispatch, getState) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  const uid = $_status.state.user.uid;
  return await $_axios
    .post(ServerUtils.MEMBERSHIPINFO, {}, { uid })
    .then(response => {
      dispatch(
        createAction(MEMBERSHIP_INFO)({
          payList: response.data.data.payList,
          policy: response.data.data.policy,
          expireDate: response.data.data.expireDate,
          isPending: false,
        }),
      );
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};
export const pendingHandler = value => async (dispatch, getState) => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: value }));
};

const initialState = {
  userName: '',
  couponList: [],
  pointHistory: [],
  userPoint: 0,

  userCardList: [],
  userCoin: 0,
  coinHistory: [],
  QnAList: [],
  isPending: false, //indicator 제어 변수
  announceList: [],

  payList: [],
  policy: {},
  expireDate: '',
  phoneNumChangeChatArr: [PhoneNumChangeChat.userCheck],
  phoneNumChangeInputType: 'getCertificateNum',

  userInfo: {
    name: undefined,
    userType: undefined,
    appPush: true,
  },
  memberValue: undefined,
  freeTicketValue: undefined,
  isMember: false,
  isHadMember: 0,
  inviteCode: undefined, // 추천인 코드
  certificationCodeId: '',
  certificationToken: '',
};

export default handleActions(
  {
    [ANY_ACTIONS]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_CARD_AND_COIN]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SERVICE_PENDING]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_COUPON_LIST]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_QNA]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_POINT]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [IS_POINT_RENDER]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_ANNOUNCEMENT]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_CERTIFICATE_NUMBER]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [POST_CERTIFICATE_CHECK]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [RESET_PHONE_NUMBER_CHAT]: (state, action) => {
      const { phoneNumChangeChatArr, phoneNumChangeInputType } = initialState;
      return {
        ...state,
        phoneNumChangeChatArr,
        phoneNumChangeInputType,
      };
    },
    [RE_ENTER_PHONE_NUM]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [APP_PUSH]: (state, action) => {
      let { userInfo } = state;
      userInfo.appPush = action.payload.appPush;

      return {
        ...state,
        userInfo: $_.cloneDeep(userInfo),
        isPending: false,
      };
    },
    [MEMBERSHIP_INFO]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },

    [SET_MEMBER_VALUE]: (state, action) => {
      let { userInfo } = state;
      const { memberValue, uid } = action.payload;
      userInfo.uid = uid;
      return {
        ...state,
        memberValue: $_.cloneDeep(memberValue),
        userInfo: $_.cloneDeep(userInfo),
        isPending: false,
      };
    },
    [SET_FREE_TICKET_VALUE]: (state, action) => {
      let { userInfo } = state;
      const { freeTicketValue, uid } = action.payload;
      userInfo.uid = uid;
      return {
        ...state,
        freeTicketValue: $_.cloneDeep(freeTicketValue),
        isPending: false,
      };
    },
    [JOIN_MEMBER]: (state, action) => {
      const { uid, name } = action.payload;
      const userInfo = {
        uid,
        name,
        userType: 'member',
      };
      userInfo.uid = uid;
      return {
        ...state,
        userInfo: $_.cloneDeep(userInfo),
        isPending: false,
      };
    },
    [UPDATE_CARD]: (state, action) => {
      return {
        ...state,
        userCardList: $_.cloneDeep(action.payload),
        isPending: false,
      };
    },

    [MY_PAGE_INIT]: (state, action) => {
      let { userInfo } = state;
      for (let key in action.payload) {
        if (key === Keys.APP_PUSH) {
          userInfo[key] = action.payload[key];
        } else {
          if (action.payload[key] && userInfo[key] != action.payload[key]) {
            userInfo[key] = action.payload[key];
          }
        }
      }
      return {
        ...state,
        userInfo: $_.cloneDeep(userInfo),
      };
    },
    [CHANGE_USER_NAME_SUCCESS]: (state, action) => {
      return {
        ...state,
        userName: action.payload,
      };
    },
    [SET_CERTIFICATION_CODE_ID]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SET_CERTIFICATION_TOKEN]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
  initialState,
);
