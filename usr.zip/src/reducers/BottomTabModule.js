import { createAction, handleActions } from 'redux-actions';

import axios from 'axios';

import * as CommonUtils from '../utils/common/index';
import * as Keys from '../utils/type/key';
import WashAlert from '../utils/alert';
import { Favorite } from '../utils/common/strings/index';
import { ORDER_CHECK_URL } from '../utils/type/server';
import { navPushOrderChatScreen } from '../utils/common/nav';

import moment from 'moment';

import { _ } from '../plugins';

moment.locale('ko');
const SET_HTTP_PENDING = 'bottomTab/SET_HTTP_PENDING';

const SET_CURRENT_TAB = 'bottomTab/SET_CURRENT_TAB';
const SET_INIT_BOTTOMTAB = 'bottomTab/SET_INIT_BOTTOMTAB';
const TOGGLE_ORDER_BUTTON = 'bottomTab/TOGGLE_ORDER_BUTTON';
const GO_TO_ORDER_CHAT_SCREEN = 'bottomTab/GO_TO_ORDER_CHAT_SCREEN';

const setCurrentTabAction = createAction(SET_CURRENT_TAB);

export const init = () => async (dispatch, getState) => {
  let userType = await CommonUtils.getValue(Keys.USER_TYPE);
  dispatch(createAction(SET_INIT_BOTTOMTAB)({ userType }));
};

export const setCurrentTab = currentScreenName => async (
  dispatch,
  getState,
) => {
  // const { orderButtonPopup } = getState().BottomTabModule;
  // // console.log('currentScreenName: ', currentScreenName);
  // if (currentScreenName === 'OrderScreen') {
  //   if (orderButtonPopup) {
  //     /** X 상태 **/
  //     dispatch(toggleOrderButton());
  //   } else {
  //     let permission = await dispatch(doOrder());
  //     if (permission) {
  //       dispatch(toggleGoToOrderChatScreen(true));
  //     } else {
  //       dispatch(toggleGoToOrderChatScreen(false));
  //     }
  //   }
  // } else {
  //   dispatch(setCurrentTabAction({ currentScreenName }));
  // }
  dispatch(setCurrentTabAction({ currentScreenName }));
};

export const checkOrderStatus = ({ componentId, passProps }) => async (
  dispatch,
  getState,
) => {
  const { orderButtonPopup } = getState().BottomTabModule;

  if (orderButtonPopup) {
    /** X 상태 **/
    dispatch(toggleOrderButton());
  } else {
    let permission = await dispatch(doOrder());
    if (permission) {
      navPushOrderChatScreen({ componentId, passProps });
    } else {
      dispatch(toggleGoToOrderChatScreen(false));
    }
  }
};

const doOrder = () => async (dispatch, getState) => {
  try {
    const { orderButtonPopup, isPending } = getState().BottomTabModule;
    if (isPending) {
      return false;
    }
    dispatch(createAction(SET_HTTP_PENDING)(true));

    if (orderButtonPopup) {
      dispatch(toggleOrderButton());
      return false;
    }

    //TEST

    // IS_NOT_SERVICE_AREA
    // ALEADY_HAS_ORDER
    // FULL_CAPA
    const uid = $_status.state.user.uid;
    const {
      data: { popup },
    } = await $_axios.post(ORDER_CHECK_URL, {}, { uid });

    dispatch(createAction(SET_HTTP_PENDING)(false));

    if (popup) {
      dispatch(toggleOrderButton(popup));
      return false;
    } else {
      return true;
    }
  } catch (e) {
    console.log(e);
    dispatch(createAction(SET_HTTP_PENDING)(false));

    WashAlert.showAlert(Favorite.fail, Favorite.ok);
  }
  return false;
};

export const toggleOrderButton = popup => async (dispatch, getState) => {
  dispatch(createAction(TOGGLE_ORDER_BUTTON)(popup));
};

export const toggleGoToOrderChatScreen = permission => async (
  dispatch,
  getState,
) => {
  dispatch(createAction(GO_TO_ORDER_CHAT_SCREEN)(permission));
};

const initialState = {
  isPending: false,
  currentScreenName: 'HomeScreen',
  userType: null,
  orderButtonPopup: null,
  goToOrderChatScreen: null, // 주문하기 버튼을 module에서 관리하기 위한 수단
};

export default handleActions(
  {
    [SET_HTTP_PENDING]: (state, action) => {
      const { isPending } = action.payload;
      return {
        ...state,
        isPending,
      };
    },
    [SET_INIT_BOTTOMTAB]: (state, action) => {
      const { userType } = action.payload;
      let data = {
        ...state,
      };
      if (userType) {
        data.userType = userType;
      }
      return data;
    },
    [SET_CURRENT_TAB]: (state, action) => {
      const { currentScreenName } = action.payload;
      return {
        ...state,

        currentScreenName,
      };
    },
    [TOGGLE_ORDER_BUTTON]: (state, action) => {
      return {
        ...state,
        orderButtonPopup: action.payload ? _.cloneDeep(action.payload) : null,
      };
    },
    [GO_TO_ORDER_CHAT_SCREEN]: (state, action) => {
      return {
        ...state,
        goToOrderChatScreen: action.payload ? true : false,
      };
    },
  },
  initialState,
);
