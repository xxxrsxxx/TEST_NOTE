import { Platform } from 'react-native';
import { createAction, handleActions } from 'redux-actions';

import * as WashPayment from '../utils/common/payment';
import WashAlert from '../utils/alert';
import * as ServerUtils from '../utils/type/server';
import * as KeyUtils from '../utils/type/key';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';
import { CoinString, Favorite } from '../utils/common/strings';

const ACTION_ = 'coin/ACTION_';
const ACTION_SET_MODAL = 'coin/ACTION_SET_MODAL';
const LOADING = 'coin/LOADING';
const FINISH_PURCHASE = 'coin/FINISH_PURCHASE';
const MODAL_CLOSE = 'coin/MODAL_CLOSE';
const RESET_COIN = 'coin/RESET_COIN';
export const sampleFunc = createAction(ACTION_);
export const modalClose = createAction(MODAL_CLOSE);
export const resetCoin = createAction(RESET_COIN);
export const setModal = ({
  isOpen,
  payType,
  arrayIndex,
  userType,
  pathOfPaymentMethod,
}) => async (dispatch, getState) => {
  var send = {};
  if (isOpen != undefined) {
    send.isOpen = isOpen;
  }

  if (arrayIndex != undefined) {
    send.arrayIndex = arrayIndex;
  }

  if (payType != undefined) {
    send.payType = payType;
    doPay({ payType, pathOfPaymentMethod, getState, dispatch });
  }

  dispatch(createAction(ACTION_SET_MODAL)(send));
};

const doPay = async ({ payType, pathOfPaymentMethod, getState, dispatch }) => {
  let { arrayIndex, paymentArr } = getState().CoinModule;

  const _storage = await $_storage.get();

  const userType = _storage[KeyUtils.USER_TYPE];
  const uid = _storage[KeyUtils.USER_ID];
  const name = _storage[KeyUtils.USER_NAME];
  const phone = _storage[KeyUtils.PHONE_NUMBER];

  const { value, bonus, memberBonus } = paymentArr[arrayIndex];
  const coinBonus = userType && userType == 'member' ? memberBonus : bonus;
  const af_address = _storage[KeyUtils.USER_ADDRESS];
  const af_road_address = _storage[KeyUtils.USER_ROAD_ADDRESS];
  const af_detail_address = _storage[KeyUtils.USER_ADDRESS_OTHERS];
  const af_user_type = _storage[KeyUtils.USER_TYPE];
  const coin = value;
  if (payType === 'card') {
    // dispatch(createAction(FINISH_PURCHASE)({
    //   loading : false,
    //   purchasedCoin : (value+bonus),
    //   isOpen: false,
    //   payType: null,
    //   arrayIndex : -1,
    // }));

    const data = {
      uid,
      name,
      phone,
      coin: value,
      bonus: coinBonus,
      callType: 'coin',
    };

    WashPayment.show(data, json => {
      const { code, message } = json;
      if (code === 200) {
        dispatch(
          createAction(FINISH_PURCHASE)({
            loading: false,
            purchasedCoin: value + coinBonus,
            isOpen: false,
            payType: null,
            arrayIndex: -1,
          }),
        );
        if (pathOfPaymentMethod !== undefined) {
          AnalyticsManager.setAppsFlyerTrackEvent(
            AnalyticsKey.NAME_ADD_PAYMENT_INFO,
            {
              af_uid: uid,
              af_address,
              af_road_address,
              af_detail_address,
              af_user_type,
              af_path: pathOfPaymentMethod,
              af_add_payment_method: `coin${coin}`,
            },
          );
          AnalyticsManager.setAirbridgeTrackEvent(
            AnalyticsKey.NAME_ADD_PAYMENT_INFO,
            Platform.OS,
            uid,
          );
        }
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          /** 디폴트 메시지 **/
          WashAlert.showAlert(CoinString.failBuyCoinModal, Favorite.ok);
        }
      }
    });
  } else if (payType === 'bill') {
    if (arrayIndex > -1) {
      /** 결제 시도를 한다 우선 로딩바를 띄운다. */
      dispatch(createAction(LOADING)({ loading: true }));
      /** 서버 포스트 */
      await $_axios
        .post(
          ServerUtils.BUY_COIN,
          {},
          { payType, uid, coin: value, bonus: coinBonus, name },
        )
        .then(response => {
          const { code, message } = response.data;

          if (code === 200) {
            dispatch(
              createAction(FINISH_PURCHASE)({
                loading: false,
                purchasedCoin: value + coinBonus,
                isOpen: false,
                payType: null,
                arrayIndex: -1,
              }),
            );
            if (pathOfPaymentMethod !== undefined) {
              AnalyticsManager.setAppsFlyerTrackEvent(
                AnalyticsKey.NAME_ADD_PAYMENT_INFO,
                {
                  af_uid: uid,
                  af_address,
                  af_road_address,
                  af_detail_address,
                  af_user_type,
                  af_path: pathOfPaymentMethod,
                  af_add_payment_method: `coin${coin}`,
                },
              );
              AnalyticsManager.setAirbridgeTrackEvent(
                AnalyticsKey.NAME_ADD_PAYMENT_INFO,
                Platform.OS,
                uid,
              );
            }
          } else {
            if (message) {
              /** 서버 실패 메시지 **/
              WashAlert.showAlert(message, Favorite.ok);
            } else {
              /** 기본메시지 **/
              WashAlert.showAlert(CoinString.failBuyCoinModal, Favorite.ok);
            }
          }
        });
    }
  }
};

const initialState = {
  paymentArr: [
    { value: 150000, bonus: 0, memberBonus: 5000 },
    { value: 300000, bonus: 5000, memberBonus: 15000 },
    { value: 500000, bonus: 15000, memberBonus: 35000 },
  ],
  isOpen: false,
  payType: null,
  arrayIndex: -1,
  loading: false,
  purchasedCoin: 0,
};

export default handleActions(
  {
    [ACTION_]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [LOADING]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [FINISH_PURCHASE]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [RESET_COIN]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },

    [ACTION_SET_MODAL]: (state, action) => {
      const { isOpen, payType, arrayIndex } = action.payload;
      // const clone = _.clone(action.payload);
      return {
        ...state,
        isOpen: isOpen ? new Boolean(isOpen) : isOpen,
        payType,
        arrayIndex,
      };
    },
    [MODAL_CLOSE]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
  initialState,
);
