import { Platform } from 'react-native';
import { createAction, handleActions } from 'redux-actions';
import { Navigation } from 'react-native-navigation';

import moment from 'moment';

import * as CommonUtils from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import * as KeyUtils from '../utils/type/key';
import { Favorite, StartOrderConfirm } from '../utils/common/strings';
import WashAlert from '../utils/alert';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';

import { _ } from '../plugins';

moment.locale('ko');

// action constructor
const SET_HTTP_PENDING = 'start/order/SET_HTTP_PENDING';
const SET_PICKUP_DATETIME_LIST = 'start/order/SET_PICKUP_DATETIME_LIST';
const SET_PICKUP = 'start/order/SET_PICKUP';
const SET_PICKUP_MODAL = 'start/order/SET_PICKUP_MODAL';
const SET_PICKUP_IS_OPEN_BOTTOM_MODAL =
  'start/order/SET_OPEN_PICKUP_BOTTOM_MODAL';
const SET_PICKUP_EVENT_IS_OPEN_BOTTOM_MODAL =
  'start/order/SET_PICKUP_EVENT_IS_OPEN_BOTTOM_MODAL';
const SET_PICKUP_DATE_INDEX = 'start/order/SET_PICKUP_DATE_INDEX';
const SET_DELIVERY_DATETIME_LIST = 'start/order/SET_DELIVERY_DATETIME_LIST';
const SET_DELIVERY = 'start/order/SET_DELIVERY';
const SET_DELIVERY_MODAL = 'start/order/SET_DELIVERY_MODAL';
const SET_DELIVERY_DATE_INDEX = 'start/order/SET_DELIVERY_DATE_INDEX';
const SET_DELIVERY_IS_OPEN_CENTER_MODAL =
  'start/order/SET_DELIVERY_IS_OPEN_CENTER_MODAL';
const SET_DELIVERY_IS_OPEN_BOTTOM_MODAL =
  'start/order/SET_DELIVERY_IS_OPEN_BOTTOM_MODAL';
const SET_IS_EXPRESS = 'start/order/SET_IS_EXPRESS';
const SET_IS_OPEN_ORDER_INFO = 'start/order/SET_IS_OPEN_ORDER_INFO';
const SET_IS_OPEN_HELP_BOTTOM_MODAL =
  'start/order/SET_IS_OPEN_HELP_BOTTOM_MODAL';
const SET_IS_DOOR = 'start/order/SET_IS_DOOR';
const SET_SERVICE_ITEM_ARRAY = 'start/order/SET_SERVICE_ITEM_ARRAY';
const SET_DOOR = 'start/order/SET_DOOR';
const SET_PAYMENT_METHOD = 'start/order/SET_PAYMENT_METHOD';
const SET_COUPON_INFO = 'start/order/SET_COUPON_INFO';
const SET_POINT_INFO = 'start/order/SET_POINT_INFO';
const SET_PAY_TYPE = 'start/order/SET_PAY_TYPE';
const SET_ASSETS = 'start/order/SET_ASSETS';
const SET_COIN = 'start/order/SET_COIN';
const SET_IS_OPEN_CARD_LIST_MODAL = 'start/order/SET_IS_OPEN_CARD_LIST_MODAL';
const INIT_THREE_STAGE = 'start/order/INIT_THREE_STAGE';
const INIT_ORDER = 'start/order/INIT_ORDER';
const SET_DELIVERY_DATETIME_LIST_VIA_ORDERID =
  'start/order/SET_DELIVERY_DATETIME_LIST_VIA_ORDERID';

const _setHttpPending = createAction(SET_HTTP_PENDING);
const _setPickupDateTimeList = createAction(SET_PICKUP_DATETIME_LIST);
const _setPickup = createAction(SET_PICKUP);
const _setPickupModal = createAction(SET_PICKUP_MODAL);
const _setPickupIsOpenBottomModal = createAction(
  SET_PICKUP_IS_OPEN_BOTTOM_MODAL,
);
const _setPickupEventIsOpenBottomModal = createAction(
  SET_PICKUP_EVENT_IS_OPEN_BOTTOM_MODAL,
);
const _setPickupDateIndex = createAction(SET_PICKUP_DATE_INDEX);
const _setDeliveryDateTimeList = createAction(SET_DELIVERY_DATETIME_LIST);
const _setDelivery = createAction(SET_DELIVERY);
const _setDeliveryModal = createAction(SET_DELIVERY_MODAL);
const _setDeliveryDateIndex = createAction(SET_DELIVERY_DATE_INDEX);
const _setDeliveryIsOpenCenterModal = createAction(
  SET_DELIVERY_IS_OPEN_CENTER_MODAL,
);
const _setDeliveryIsOpenBottomModal = createAction(
  SET_DELIVERY_IS_OPEN_BOTTOM_MODAL,
);
const _setIsExpress = createAction(SET_IS_EXPRESS);
const _setIsOpenOrderInfo = createAction(SET_IS_OPEN_ORDER_INFO);
const _setIsOpenHelpBottomModal = createAction(SET_IS_OPEN_HELP_BOTTOM_MODAL);
const _setIsDoor = createAction(SET_IS_DOOR);
const _setServiceItemArray = createAction(SET_SERVICE_ITEM_ARRAY);
const _setDoor = createAction(SET_DOOR);
const _setPaymentMethod = createAction(SET_PAYMENT_METHOD);
const _setCouponInfo = createAction(SET_COUPON_INFO);
const _setPointInfo = createAction(SET_POINT_INFO);
const _setPayType = createAction(SET_PAY_TYPE);
const _setAssets = createAction(SET_ASSETS);
const _setCoin = createAction(SET_COIN);
const _setIsOpenCardListModal = createAction(SET_IS_OPEN_CARD_LIST_MODAL);
export const initThreeStage = createAction(INIT_THREE_STAGE);
const _initOrder = createAction(INIT_ORDER);

export const setPickup = (pickupTime, endTime) => (dispatch, getState) => {
  if (pickupTime && endTime) {
    dispatch(_setPickup({ pickupTime, endTime }));
  }
};

export const setPickupModal = (dayOfWeek, startEndTime) => (
  dispatch,
  getState,
) => {
  if (dayOfWeek && startEndTime) {
    dispatch(_setPickupModal({ dayOfWeek, startEndTime }));
  }
};

export const setPickupIsOpenBottomModal = isOpen => (dispatch, getState) => {
  dispatch(_setPickupIsOpenBottomModal({ isOpen }));
};

export const setPickupEventIsOpenBottomModal = isOpen => (
  dispatch,
  getState,
) => {
  dispatch(_setPickupEventIsOpenBottomModal({ isOpen }));
};

export const setPickupDateIndex = index => (dispatch, getState) => {
  dispatch(_setPickupDateIndex({ index }));
};

export const setDelivery = (deliveryTime, endTime) => (dispatch, getState) => {
  if (deliveryTime && endTime) {
    dispatch(_setDelivery({ deliveryTime, endTime }));
  }
};

export const setDeliveryModal = (dayOfWeek, startEndTime) => (
  dispatch,
  getState,
) => {
  if (dayOfWeek && startEndTime) {
    dispatch(_setDeliveryModal({ dayOfWeek, startEndTime }));
  }
};

export const setDeliveryDateIndex = index => (dispatch, getState) => {
  dispatch(_setDeliveryDateIndex({ index }));
};

export const setDeliveryIsOpenCenterModal = isOpen => (dispatch, getState) => {
  dispatch(_setDeliveryIsOpenCenterModal({ isOpen }));
};

export const setDeliveryIsOpenBottomModal = isOpen => (dispatch, getState) => {
  dispatch(_setDeliveryIsOpenBottomModal({ isOpen }));
};

export const setIsExpress = isExpress => (dispatch, getState) => {
  dispatch(_setIsExpress({ isExpress }));
};

export const setIsOpenOrderInfo = isOpen => (dispatch, getState) => {
  dispatch(_setIsOpenOrderInfo({ isOpen }));
};

export const setIsOpenHelpBottomModal = isOpen => (dispatch, getState) => {
  dispatch(_setIsOpenHelpBottomModal({ isOpen }));
};

export const setIsDoor = isDoor => (dispatch, getState) => {
  dispatch(_setIsDoor({ isDoor }));
};

export const setServiceItemArray = key => (dispatch, getState) => {
  dispatch(_setServiceItemArray({ key }));
};

export const setDoor = door => (dispatch, getState) => {
  dispatch(_setDoor({ door }));
};

export const setPreOptions = () => (dispatch, getState) => {
  // dispatch(_setPreOptions({ }));
};

export const setPaymentMethod = info => (dispatch, getState) => {
  dispatch(_setPaymentMethod({ info }));
};

export const setCouponInfo = coupon => (dispatch, getState) => {
  dispatch(_setCouponInfo({ coupon }));
};

export const setPointInfo = point => (dispatch, getState) => {
  dispatch(_setPointInfo({ point }));
};

export const setPayType = payType => (dispatch, getState) => {
  dispatch(_setPayType({ payType }));
};

export const setCoin = coin => (dispatch, getState) => {
  dispatch(_setCoin({ coin }));
};

export const setIsOpenCardListModal = isOpen => (dispatch, getState) => {
  dispatch(_setIsOpenCardListModal({ isOpen }));
};

export const initOrder = () => (dispatch, getState) => {
  dispatch(_initOrder());
};

/**
 * 수거시간 가져와서 설정하기
 */
export const setPickupDateTimeAPI = ({
  componentId,
  timeSelectCallback,
}) => async (dispatch, getState) => {
  dispatch(_setHttpPending({ isPending: true }));
  const _storage = await $_storage.get();
  const uid = _storage[KeyUtils.USER_ID];
  const centerId = _storage[KeyUtils.CENTER_ID];
  const basic = true;
  const userType = _storage[KeyUtils.USER_TYPE];
  const address = _storage[KeyUtils.USER_ADDRESS];
  const addressOthers = _storage[KeyUtils.USER_ADDRESS_OTHERS];

  // const doorCode = await CommonUtils.getValue(KeyUtils.DOOR_CODE);
  await $_axios
    .post(
      ServerUtils.GET_PICKUP_DATETIME,
      {},
      {
        uid,
        centerId,
        basic,
      },
    )
    .then(res => {
      const { code, message } = res.data;
      if (code === 200) {
        const { array, event } = res.data;
        dispatch(
          _setPickupDateTimeList({
            isPending: false,
            userType,
            address,
            addressOthers,
            pickupArray: array,
            pickupEventArray: event,
            componentId,
            timeSelectCallback,
          }),
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
        throw 'API response code no 200';
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(_setHttpPending({ isPending: false }));
    });
};

/**
 * 배달시간 가져와서 설정하기
 */
export const setDeliveryDateTimeAPI = ({
  pickup,
  orderId,
  timeSelectCallback,
  componentId,
  midnight,
}) => async (dispatch, getState) => {
  // dispatch(_setHttpPending({ isPending: true }));
  dispatch(_setDeliveryDateIndex({ index: 0 }));
  const _storage = await $_storage.get();
  const basic = true;
  const userType = _storage[KeyUtils.USER_TYPE];

  let data;

  if (orderId) {
    data = { orderId };
  } else {
    const { pickupTime } = pickup;
    const uid = _storage[KeyUtils.USER_ID];
    const centerId = _storage[KeyUtils.CENTER_ID];
    const { chatList, dataList } = getState().OrderChatModule;
    data = {
      uid,
      centerId,
      pickupTime: moment(new Date(pickupTime)).format('YYYY-MM-DD'),
      basic,
      midnight: midnight ? midnight : moment(new Date(pickupTime)).hour() === 0,
      express: dataList && dataList.length > 0 && dataList[2].key === 'express',
    };
  }
  await $_axios
    .post(ServerUtils.GET_DELIVERY_DATETIME, {}, data)
    .then(res => {
      const { code, message } = res.data;
      if (code === 200) {
        const { array } = res.data;
        if (orderId) {
          dispatch(
            createAction(SET_DELIVERY_DATETIME_LIST_VIA_ORDERID)({
              deliveryArray: array,
              componentId,
              timeSelectCallback,
              userType,
            }),
          );
        } else {
          dispatch(
            _setDeliveryDateTimeList({
              isPending: false,
              deliveryArray: array,
              pickup,
              componentId,
              timeSelectCallback,
              userType,
            }),
          );
        }
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
        throw 'API response code no 200';
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(_setHttpPending({ isPending: false }));
    });
};

/**
 * 보유자산 가져와서 설정하기
 */
export const setAssetsAPI = () => async dispatch => {
  dispatch(_setHttpPending({ isPending: true }));
  const uid = $_status.state.user.uid;
  await $_axios
    .post(
      ServerUtils.GET_ASSETS,
      {},
      {
        uid,
        point: true,
        coin: true,
        bill: true,
        coupon: true,
      },
    )
    .then(res => {
      const { code, message, data } = res.data;
      if (code === 200) {
        const { bill, coin, coupon, point } = data;
        const billArray = bill;
        const coinObject = coin;
        const couponArray = coupon;
        const pointObject = point;
        dispatch(
          _setAssets({
            isPending: false,
            billArray,
            coinObject,
            couponArray,
            pointObject,
          }),
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
        throw 'API response code no 200';
      }
      dispatch(_setHttpPending({ isPending: false }));
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(_setHttpPending({ isPending: false }));
    });
};

export const chooseDeliveryTimeOnV5 = delivery => (dispatch, getState) => {
  const { timeSelectCallback, componentId } = getState().StartOrderModule;
  if (timeSelectCallback) {
    timeSelectCallback(delivery, componentId);
  }
  setTimeout(() => {
    Navigation.dismissModal(componentId);
  }, 200);
};

export const choosePickupTimeOnV5 = pickup => (dispatch, getState) => {
  const { componentId, timeSelectCallback } = getState().StartOrderModule;

  dispatch(createAction(KeyUtils.GLOBAL_KEY_SET_PICKUP_TIME)({ pickup }));

  setTimeout(() => {
    Navigation.dismissModal(componentId);

    if (timeSelectCallback) {
      timeSelectCallback(pickup);
    }
  }, 200);
};

export const isDisabledServiceItem = () => (dispatch, getState) => {
  const { pickup, delivery } = getState().StartOrderModule;
  const { pickupTime } = pickup;
  const { deliveryTime } = delivery;
  const deliveryMoment = moment(deliveryTime);
  const deliveryEndMoment = moment(delivery.endTime);
  const pickupMoment = moment(pickupTime);
  const deliveryYMD = moment([
    deliveryMoment.get('year'),
    deliveryMoment.get('month'),
    deliveryMoment.get('date'),
  ]);
  const pickupYMD = moment([
    pickupMoment.get('year'),
    pickupMoment.get('month'),
    pickupMoment.get('date'),
  ]);
  const diffDays = deliveryYMD.diff(pickupYMD, 'days', true);
  // 수거시간 기준으로 +2일 또는 +2일에 배달시간이 6시 이후일 때 shoes, repair, etc 선택 제외
  if (diffDays < 2) {
    return true;
  }
  if (diffDays < 3) {
    const hour = moment(deliveryTime).get('hour');
    if (hour >= 0 && hour <= 6) {
      // 새벽배송이면 신발, 수선, 기타 풀려야 함
      return false;
    }
    if (hour < 18) {
      // 6시 이전
      if (
        moment(deliveryTime)
          .set('hour', 18)
          .isBetween(deliveryMoment, deliveryEndMoment, null, '[]')
      ) {
        // 6시가 포함되어있다
      } else {
        // 6시가 포함되어있지 않다
        return true;
      }
    } else {
      // 6시 이후
    }
  } else {
    // +4일 이상
  }
  return false;
};

const setAppsFlyerTrackEvent = (
  orderId,
  uid,
  af_address,
  af_road_address,
  af_detail_address,
  af_user_type,
  payType,
  couponName,
) => {
  AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_COMPLETE_ORDER, {
    af_order_id: orderId,
    af_uid: uid,
    af_address,
    af_road_address,
    af_detail_address,
    af_user_type,
    af_payment_method: payType,
    af_coupon_name: couponName,
  });
  AnalyticsManager.setAirbridgeTrackEvent(
    AnalyticsKey.NAME_COMPLETE_ORDER,
    Platform.OS,
    uid,
  );
};

// reducer
const initialState = {
  isPending: false,
  uid: '',
  userType: '',
  address: '',
  addressOthers: '',
  pickup: {
    // make order API에 필요
    pickupTime: null,
    endTime: null,
    where: { door: '', locate: '' },
  },
  pickupArray: [],
  pickupEventArray: [],
  pickupModal: {
    dayOfWeek: '',
    startEndTime: '',
  },
  pickupIsOpenBottomModal: false,
  pickupEventIsOpenBottomModal: false,
  pickupDateIndex: 0,
  delivery: {
    // make order API에 필요
    deliveryTime: null,
    endTime: null,
    where: { door: '', locate: '' },
  },
  deliveryArray: [],
  deliveryModal: {
    dayOfWeek: '',
    startEndTime: '',
  },
  deliveryDateIndex: 0,
  deliveryIsOpenCenterModal: false,
  deliveryIsOpenBottomModal: false,
  deliveryBanner: null, // 배달 배너의 정보
  isExpress: false, // 급행주문 여부
  isOpenOrderInfo: true, // 주문정보 확인
  isOpenHelpBottomModal: false, // 생활빨래 도움말
  isDoor: false, // 공동현관
  // selectedServiceList: [], // 서비스 종류 선택, make order API에 필요
  door: '', // make order API에 필요
  preOptions: {
    // make order API에 필요
    payment: {
      discount: {
        coupon: [],
        point: 0,
      },
      payType: '',
    },
    service: [], // 서비스 종류 선택(드라이클리닝, 생활빨래, 침구류 등...)
  },
  paymentInfo: {
    payment: {
      info: '',
    },
    coupon: {
      info: '',
    },
    point: {
      info: '',
    },
  },
  isOpenCardListModal: false, // 카드변경시 목록
  assets: {
    billArray: [],
    coinObject: null,
    couponArray: [],
    pointObject: null,
  },

  timeSelectCallback: undefined, // v5에서 배송시간 선택
  componentId: undefined,
};

export const hasExpress = props => {
  const { pickup, deliveryArray } = props;
  if (deliveryArray && deliveryArray.length > 0) {
    const { pickupTime } = pickup;
    const pickupYMD = moment(new Date(pickupTime));

    const { slots, day } = deliveryArray[0];

    const deliveryYMD = moment(new Date(deliveryArray[0].day));

    if (slots && slots.length > 0) {
      deliveryYMD.hour(slots[0].start);
    }

    const diff = CommonUtils.getDaysDiffByYMD({ pickupYMD, deliveryYMD });
    if (diff === 1) {
      return true;
    } else {
      return false;
    }
  }
};

export default handleActions(
  {
    [SET_HTTP_PENDING]: (state, action) => {
      const { isPending } = action.payload;
      return {
        ...state,
        isPending,
      };
    },
    [SET_PICKUP_DATETIME_LIST]: (state, action) => {
      const {
        isPending,
        userType,
        address,
        addressOthers,
        pickupArray,
        pickupEventArray,
        componentId,
        timeSelectCallback,
      } = action.payload;
      return {
        ...state,
        isPending,
        userType,
        address,
        addressOthers,
        pickupArray,
        pickupEventArray,
        componentId,
        timeSelectCallback,
      };
    },
    [SET_PICKUP]: (state, action) => {
      const { pickupTime, endTime } = action.payload;
      const { pickup } = state;
      const { where } = pickup;
      return {
        ...state,
        pickup: {
          pickupTime,
          endTime,
          where,
        },
      };
    },
    [SET_PICKUP_MODAL]: (state, action) => {
      const { dayOfWeek, startEndTime } = action.payload;
      return {
        ...state,
        pickupModal: {
          dayOfWeek,
          startEndTime,
        },
      };
    },
    [SET_PICKUP_IS_OPEN_BOTTOM_MODAL]: (state, action) => {
      const { isOpen } = action.payload;
      return {
        ...state,
        pickupIsOpenBottomModal: isOpen,
      };
    },
    [SET_PICKUP_EVENT_IS_OPEN_BOTTOM_MODAL]: (state, action) => {
      const { isOpen } = action.payload;
      return {
        ...state,
        pickupEventIsOpenBottomModal: isOpen,
      };
    },
    [SET_PICKUP_DATE_INDEX]: (state, action) => {
      const { index } = action.payload;
      return {
        ...state,
        pickupDateIndex: index,
      };
    },
    [SET_DELIVERY_DATETIME_LIST]: (state, action) => {
      const {
        isPending,
        deliveryArray,
        pickup,
        timeSelectCallback,
        componentId,
        userType,
      } = action.payload;
      const he = hasExpress({ pickup, deliveryArray });
      return {
        ...state,
        isPending,
        deliveryArray,
        deliveryDateIndex: he ? 1 : 0,
        pickup: _.cloneDeep(pickup),
        timeSelectCallback,
        componentId,
        userType,
      };
    },
    [SET_DELIVERY_DATETIME_LIST_VIA_ORDERID]: (state, action) => {
      const {
        deliveryArray,
        timeSelectCallback,
        componentId,
        userType,
      } = action.payload;
      return {
        ...state,
        isPending: false,
        deliveryArray,
        deliveryDateIndex: 0,
        timeSelectCallback,
        componentId,
        userType,
      };
    },
    [SET_DELIVERY]: (state, action) => {
      const { deliveryTime, endTime } = action.payload;
      const { delivery } = state;
      const { where } = delivery;

      return {
        ...state,
        delivery: {
          deliveryTime,
          endTime,
          where,
        },
      };
    },
    [SET_DELIVERY_MODAL]: (state, action) => {
      const { dayOfWeek, startEndTime } = action.payload;
      return {
        ...state,
        deliveryModal: {
          dayOfWeek,
          startEndTime,
        },
      };
    },
    [SET_DELIVERY_DATE_INDEX]: (state, action) => {
      const { index } = action.payload;
      return {
        ...state,
        deliveryDateIndex: index,
      };
    },
    [SET_DELIVERY_IS_OPEN_CENTER_MODAL]: (state, action) => {
      const { isOpen } = action.payload;
      return {
        ...state,
        deliveryIsOpenCenterModal: isOpen,
      };
    },
    [SET_DELIVERY_IS_OPEN_BOTTOM_MODAL]: (state, action) => {
      const { isOpen } = action.payload;
      return {
        ...state,
        deliveryIsOpenBottomModal: isOpen,
      };
    },
    [SET_IS_EXPRESS]: (state, action) => {
      const { isExpress } = action.payload;
      return {
        ...state,
        isExpress,
      };
    },
    [SET_IS_OPEN_ORDER_INFO]: (state, action) => {
      const { isOpen } = action.payload;
      return {
        ...state,
        isOpenOrderInfo: isOpen,
      };
    },
    [SET_IS_OPEN_HELP_BOTTOM_MODAL]: (state, action) => {
      const { isOpen } = action.payload;
      return {
        ...state,
        isOpenHelpBottomModal: isOpen,
      };
    },
    [SET_IS_DOOR]: (state, action) => {
      const { isDoor } = action.payload;
      return {
        ...state,
        isDoor,
      };
    },
    [SET_SERVICE_ITEM_ARRAY]: (state, action) => {
      const { key } = action.payload;
      // 전체 리스트(구조체)에서 key의 로우를 찾는다
      const finded = _.find(StartOrderConfirm.serviceItemArray, { key });
      const { preOptions } = state;
      const { payment, service } = preOptions;
      // const { selectedServiceList } = state;
      // 선택된 리스트 안에 그 키가 있는지 찾는다. 만약에 리스트 안에 키값이 있으면 인덱스가 떨어진다. 없으면 -1로 떨어진다.
      const index = _.findIndex(service, { key });
      if (index > -1) {
        // 선택된 리스트 안에 해당 키가 있다. 토글이기 때문에 그 아이는 빼준다
        _.pullAt(service, index);
      } else {
        // 선택된 리스트 안에 해당 키가 없다, 선택된 리스트에 누른 키값을 넣어준다
        service.push({ key });
      }
      return {
        ...state,
        preOptions: {
          payment,
          service: _.cloneDeep(service),
        },
      };
    },

    [SET_DOOR]: (state, action) => {
      const { door } = action.payload;
      return {
        ...state,
        door,
      };
    },
    [SET_PAYMENT_METHOD]: (state, action) => {
      const { info } = action.payload;
      const { paymentInfo } = state;
      const { coupon, point } = paymentInfo;
      return {
        ...state,
        paymentInfo: {
          payment: {
            info,
          },
          coupon,
          point,
        },
      };
    },
    [SET_COUPON_INFO]: (state, action) => {
      const { coupon } = action.payload;
      const { name } = coupon[0];
      const { paymentInfo, preOptions } = state;
      const { payment, point } = paymentInfo;
      return {
        ...state,
        paymentInfo: {
          payment,
          coupon: {
            info: name,
          },
          point,
        },
        preOptions: {
          // make order API에 필요
          payment: {
            discount: {
              coupon,
              point: preOptions.payment.discount.point,
            },
            payType: preOptions.payment.payType,
          },
          service: preOptions.service,
        },
      };
    },
    [SET_POINT_INFO]: (state, action) => {
      const { point } = action.payload;
      const { paymentInfo, preOptions } = state;
      const { payment, coupon } = paymentInfo;
      return {
        ...state,
        paymentInfo: {
          payment,
          coupon,
          point: {
            info: point,
          },
        },
        preOptions: {
          // make order API에 필요
          payment: {
            discount: {
              coupon: preOptions.payment.discount.coupon,
              point,
            },
            payType: preOptions.payment.payType,
          },
          service: preOptions.service,
        },
      };
    },
    [SET_PAY_TYPE]: (state, action) => {
      const { payType } = action.payload;
      const { preOptions } = state;
      const { payment, service } = preOptions;
      const { discount } = payment;
      return {
        ...state,
        preOptions: {
          payment: {
            discount,
            payType,
          },
          service,
        },
      };
    },
    [SET_ASSETS]: (state, action) => {
      const {
        isPending,
        billArray,
        coinObject,
        couponArray,
        pointObject,
      } = action.payload;
      return {
        ...state,
        isPending,
        assets: {
          billArray,
          coinObject,
          couponArray,
          pointObject,
        },
      };
    },
    [SET_COIN]: (state, action) => {
      const { coin } = action.payload;
      const { assets } = state;
      const { billArray, couponArray, pointObject } = assets;
      return {
        ...state,
        assets: {
          billArray,
          coinObject: {
            coin,
          },
          couponArray,
          pointObject,
        },
      };
    },
    [SET_IS_OPEN_CARD_LIST_MODAL]: (state, action) => {
      const { isOpen } = action.payload;
      return {
        ...state,
        isOpenCardListModal: isOpen,
      };
    },
    [INIT_THREE_STAGE]: (state, action) => {
      return {
        ...state,
        isOpenOrderInfo: _.cloneDeep(initialState.isOpenOrderInfo),
        isDoor: _.cloneDeep(initialState.isDoor),
        door: _.cloneDeep(initialState.door),
        preOptions: _.cloneDeep(initialState.preOptions),
        paymentInfo: _.cloneDeep(initialState.paymentInfo),
      };
    },
    [INIT_ORDER]: (state, action) => {
      return _.cloneDeep(initialState);
    },
  },
  _.cloneDeep(initialState),
);
