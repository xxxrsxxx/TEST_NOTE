import { createAction, handleActions } from 'redux-actions';

import { _ } from '../plugins';

const INIT = 'album/INIT';
const SET_DATA = 'album/SET_DATA';
const SET_ANY_DATA = 'album/SET_ANY_DATA';
const SET_SELECTED_ITEM = 'album/SET_SELECTED_ITEM';
const SET_SHOW_DETAIL_PAGE = 'album/SET_SHOW_DETAIL_PAGE';

export const init = (orderItem) => (dispatch, getState) => {
  const { orderId } = orderItem;
  dispatch(createAction(INIT)({ orderId }));
};

const getData = items => {
  const data = [];
  if (items && items.length > 0) {
    items.map((item, index) => {
      const { info: infoArray, name, price, barcodeId, brand, option, emoji } = item;
      if (infoArray && infoArray.length > 0) {
        const careArray = [];
        infoArray.map((infoObject) => {
          const { type, image, title } = infoObject;
          if (type !== 'view' && title && infoObject.price !== undefined) {
            careArray.push({ title, price: infoObject.price });
          }
        });
        infoArray.map((infoObject) => {
          const { type, image, title } = infoObject;
          if (type === 'view' && image && image.length > 0) {
            image.map((url, imageIndex) => {
              data.push({ type, name, price, url, barcodeId: barcodeId[0], brand, option, careArray });
            });
          }
        });
      }
    });
  }
  return data;
};

export const setData = (orderItem, url) => (dispatch, getState) => {
  /**
   * info
   * url이 있는 경우는 사진을 직접 클릭하고 이 페이지를 호출하는 경우
   * **/
  if (orderItem) {
    let data = [];
    if (orderItem.pickup && orderItem.pickup.item && orderItem.pickup.item.length > 0) {
      data = getData(orderItem.pickup.item);
    }
    // if (orderItem.media && orderItem.media.length > 0) {
    //   orderItem.media.map((media, index) => {
    //     const { type, url } = media;
    //     if (type === 'dropbox') {
    //       data.push({ type, url });
    //     }
    //   });
    // }
    if (orderItem.preOptions && orderItem.preOptions.care && orderItem.preOptions.care.options) {
      orderItem.preOptions.care.options.forEach((options) => {
        const { type, message, images } = options;
        if (!images) {
          return;
        }
        images.forEach((image) => {
          data.push({ name: type, content: message, url: image });
        });
      });
    }
    if (data.length > 0) {
      let selectedItem;
      if(url){
        selectedItem = _.find(data , { url })
      }
      dispatch(createAction(SET_DATA)({ data, selectedItem }));
    }
  }
};

export const setSelectedItem = (selectedItem) => (dispatch, getState) => {
  dispatch(createAction(SET_SELECTED_ITEM)({ selectedItem }));
};

export const setAnyData = createAction(SET_ANY_DATA);

const initialState = {
  orderId: '',
  data: [],
  selectedItem: null,
  showDetailPage: false
};

export default handleActions(
  {
    [INIT]: (state, action) => {
      const { orderId } = action.payload;
      return {
        ...initialState,
        orderId
      };
    },
    [SET_DATA]: (state, action) => {
      const { data, selectedItem } = action.payload;
      return {
        ...state,
        data : _.cloneDeep(data),
        selectedItem : selectedItem ? _.cloneDeep(selectedItem) : null,
      };
    },
    [SET_ANY_DATA]: (state, action) => {
      return {
        ...state,
        ...action.payload
      };
    },
    [SET_SELECTED_ITEM]: (state, action) => {
      const { selectedItem } = action.payload;
      return {
        ...state,
        selectedItem
      };
    },
    [SET_SHOW_DETAIL_PAGE]: (state, action) => {
      const { showDetailPage } = action.payload;
      return {
        ...state,
        showDetailPage
      };
    },
  },
  initialState
);
