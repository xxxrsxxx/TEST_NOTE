import { createAction, handleActions } from 'redux-actions';

import axios from 'axios';
import moment from 'moment';

import * as ServerUtils from '../utils/type/server';
import { Favorite } from '../utils/common/strings';
import WashAlert from '../utils/alert';

moment.locale('ko');

const SET_HTTP_PENDING = 'status/SET_HTTP_PENDING';
const SET_STATUS = 'status/SET_STATUS';
const SET_PENDING = 'status/SET_PENDING';

const setHttpPending = createAction(SET_HTTP_PENDING);
const setStatus = createAction(SET_STATUS);
const setPending = createAction(SET_PENDING);

export const setStatusAPI = () => async (dispatch, getState) => {
  dispatch(setHttpPending({ isPending: true }));

  const axiosConfig = {
    method: 'get',
    url: ServerUtils.GET_STATUS,
  };
  axios(axiosConfig)
    .then(res => {
      const { status, data } = res;
      if (status === 200) {
        dispatch(setStatus({ statusList: data }));
      }
      dispatch(setHttpPending({ isPending: false }));
    })
    .catch(err => {
      dispatch(setHttpPending({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};
/**
 * @dsc global pending management
 * @param value:boolean
 */
export const globalPendingHandler = value => async (dispatch, getState) => {
  dispatch(setPending({ isPending: value }));
};

/**
 * callback은 Promise만 사용.
 * await 안쓰고 싶으면 callback 내부에 middleware 형식으로 만들면 됨.
 */
export const callbackUsingGlobalPending = callback => async (
  dispatch,
  getState,
) => {
  dispatch(globalPendingHandler(true));
  await callback();
  dispatch(globalPendingHandler(false));
};

/**
 * callback은 Promise만 사용.
 * await 안쓰고 싶으면 callback 내부에 middleware 형식으로 만들면 됨.
 */
export const callbackUsingGlobalPendingWithTimeout = ({
  callback,
  time,
}) => async (dispatch, getState) => {
  dispatch(globalPendingHandler(true));
  let timeout = setTimeout(() => {
    dispatch(globalPendingHandler(false));
    return;
  }, time);
  await callback();
  clearTimeout(timeout);
  dispatch(globalPendingHandler(false));
};

/**
 * @naee  statusHandler
 * @param value:string or value:object action: string
 * @dsc 글로벌 디버깅 겸 상태 핸들러
 * window.$_status actions 확장 되어짐 중복 호출시 await 동기 로직
 * path src/static/settings/index.js initial state 선언 필수
 * ex) await $_status.actions.statusHandler(`env:value:string`);
 * ex) $_status.actions.statusHandler({ user });
 * @dsc 기존 할당된 데이터 셀렉트 재 할당
 * ex) $_status.actions.statusHandler({ user: { doorCode: 10 } }, 'overriding');
 */
export const statusHandler = (value, action) => async (dispatch, getState) => {
  let _state = getState().StatusModule;
  let config = {
    ..._state,
  };
  const _undefined = value === undefined;
  const _object = typeof value === 'object' && !Array.isArray(value);

  /**
   * @name _assign
   * @param data:object
   * @dsc 기존 할당된 데이터 셀렉트 재 할당
   * @returns {*}
   * @private
   */
  function _assign(data) {
    const strObj = JSON.stringify(value);
    // keyword 추출
    const keyTrim = strObj.replace(/\"|\'/gm, '');
    const keyReg = /(?:^\{)([a-zA-Z]+)/;
    const key = keyTrim.match(keyReg);
    // 키워드 값 가공
    const obj = strObj.replace(/(^\{\"[a-zA-Z]+\"\:)|(\}$)/gm, '');
    const _data = JSON.parse(obj);

    $_.forEach(_data, (_value, _key) => {
      data[key[1]][_key] = _value;
    });

    return data;
  }

  if (_undefined || _object) {
    let _result =
      value && !action
        ? {
            ...config,
            ...value,
          }
        : config;
    if (action === 'overriding') _result = _assign(_result);
    dispatch(setStatus(_result));
    return;
  }

  const _debug = () => {
    const _data = value.split(':');
    const _boolean = _data[1] !== 'false';
    config = {
      ..._state,
    };
    switch (_data[0]) {
      case 'env':
        config['envMode'] = _data[1];
        break;
      case 'debug':
        // (deg:boolean):string
        config['debugMode'] = _boolean;
        break;
      default:
    }
    dispatch(setStatus(config));
  };

  if (typeof value === 'string') _debug();
};

const initialState = {
  isPending: false,
  statusList: [],
  envMode: 'development',
  debugMode: false,
  user: {
    centerId: '',
    userType: '',
    name: '',
    myCode: '',
    phone: '',
    notiId: '',
    versionCode: null,
    deviceType: '',
    picture: '',
    thumbPicture: '',
    appPush: null,
    created: '',
    addressOthers: '',
    uid: null,
    token: '',
    isTemp: null,
    comment: '',
    dong: '',
    lat: '',
    lon: '',
    address: '',
    roadAddress: '',
    postCode: '',
    doorCode: '',
    addressTitle: '',
    isService: null,
    sector: '',
    NODE_ENV: '',
    accessToken: '',
  },
  api: {
    debug: false,
    debugUrl: {
      DEFAULT_URL: '',
      DEFAULT_URL_WEB: '',
    },
  },
};

export default handleActions(
  {
    [SET_HTTP_PENDING]: (state, action) => {
      const { isPending } = action.payload;
      return {
        ...state,
        isPending,
      };
    },
    [SET_STATUS]: (state, action) => {
      const { statusList, isPending } = action.payload;
      $_status.state = action.payload;
      return {
        ...state,
        statusList,
        ...action.payload,
      };
    },
    [SET_PENDING]: (state, action) => {
      const { isPending } = action.payload;
      return {
        ...state,
        isPending,
      };
    },
  },
  initialState,
);
