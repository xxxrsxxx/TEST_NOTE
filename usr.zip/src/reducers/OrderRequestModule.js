import { Platform } from 'react-native';
import { Navigation } from 'react-native-navigation';
import { handleActions, createAction } from 'redux-actions';

import * as ServerUtils from '../utils/type/server';
import * as CommonUtils from '../utils/common/index';
import WashAlert from '../utils/alert';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';
import { OrderRequest, Favorite } from '../utils/common/strings';

import { _ } from '../plugins';

import moment from 'moment';
moment.locale('ko');

// action constructor
const SET_HTTP_PENDING = 'order/request/SET_HTTP_PENDING';
const SET_IS_OPEN_REQUEST_MODAL = 'order/request/SET_IS_OPEN_REQUEST_MODAL';
const SET_REQUESTS = 'order/request/SET_REQUESTS';
const ADD_REQUEST = 'order/request/ADD_REQUEST';
const DELETE_REQUEST = 'order/request/DELETE_REQUEST';
const SET_PICKUP_REQUESTS = 'order/request/SET_PICKUP_REQUESTS';
const SET_REQUEST_MESSAGE = 'order/request/SET_REQUEST_MESSAGE';
const ADD_IMAGE = 'order/request/ADD_IMAGE';
const DELETE_IMAGE = 'order/request/DELETE_IMAGE';
const INIT_REQUESTS = 'order/request/INIT_REQUESTS';
const SET_REQUESTS_OF_ORDER = 'order/request/SET_REQUESTS_OF_ORDER';

const _setHttpPending = createAction(SET_HTTP_PENDING);
const _setIsOpenRequestModal = createAction(SET_IS_OPEN_REQUEST_MODAL);
const _setRequests = createAction(SET_REQUESTS);
const _addRequest = createAction(ADD_REQUEST);
const _deleteRequest = createAction(DELETE_REQUEST);
const _setPickupRequests = createAction(SET_PICKUP_REQUESTS);
const _setRequestMessage = createAction(SET_REQUEST_MESSAGE);
const _addImage = createAction(ADD_IMAGE);
const _deleteImage = createAction(DELETE_IMAGE);
const _initRequests = createAction(INIT_REQUESTS);

export const setIsOpenRequestModal = (isOpen, selectedType) => (
  dispatch,
  getState,
) => {
  dispatch(_setIsOpenRequestModal({ isOpen, selectedType }));
};

export const setRequests = requests => (dispatch, getState) => {
  dispatch(_setRequests({ requests }));
};

export const addRequest = type => (dispatch, getState) => {
  dispatch(_addRequest({ type }));
};

export const deleteRequest = type => (dispatch, getState) => {
  dispatch(_deleteRequest({ type }));
};

export const setPickupRequests = index => (dispatch, getState) => {
  dispatch(_setPickupRequests({ index }));
};

export const setRequestMessage = (index, message) => (dispatch, getState) => {
  dispatch(_setRequestMessage({ index, message }));
};

export const addImage = (type, uri) => (dispatch, getState) => {
  dispatch(_addImage({ type, uri }));
};

export const deleteImage = (type, images, index) => (dispatch, getState) => {
  dispatch(_deleteImage({ type, images, index }));
};

export const initRequests = () => (dispatch, getState) => {
  dispatch(_initRequests());
};

export const setRequestsOfOrder = (order, callback) => (dispatch, getState) => {
  dispatch(createAction(SET_REQUESTS_OF_ORDER)({ order }));
  callback();
};

export const saveRequestAPI = ({ orderId, componentId, callback }) => async (
  dispatch,
  getState,
) => {
  dispatch(_setHttpPending({ isPending: true }));
  const { requests } = getState().OrderRequestModule;
  if (_.find(requests, ['isRequest', true]) === undefined) {
    // 요청사항이 없을 때
    dispatch(_initRequests());
    Navigation.dismissModal(componentId);
  } else {
    // 저장
    WashAlert.showConfirm(
      OrderRequest.requestSave,
      Favorite.yes,
      Favorite.no,
      async () => {
        const careData = [];
        const deliveryData = [];
        requests.map((item, index) => {
          const { isRequest } = item;
          if (isRequest) {
            const { type, message, detailRequests, images } = item;
            if (type === 'pickup') {
              // 수거/배달 요청은 사진이 없음
              let pickupMessage = message;
              detailRequests.map((item, index) => {
                const { type, title, selected } = item;
                if (type !== 'message' && selected) {
                  if (!_.isEmpty(pickupMessage)) {
                    pickupMessage += '\n';
                  }
                  pickupMessage += title;
                }
              });
              deliveryData.push({
                type,
                message: pickupMessage,
              });
            } else {
              careData.push({
                type,
                message,
                images,
              });
            }
          }
        });
        if (careData.length > 0 || deliveryData.length > 0) {
          await $_axios
            .post(
              ServerUtils.SET_PRE_OPTIONS,
              {},
              {
                orderId,
                list: [
                  {
                    key: 'care',
                    data: careData,
                  },
                  {
                    key: 'delivery',
                    data: deliveryData,
                  },
                ],
              },
            )
            .then(res => {
              dispatch(_setHttpPending({ isPending: false }));
              const { code } = res.data;
              if (code === 200) {
                WashAlert.showAlertWithCallback(
                  OrderRequest.requestSuccess,
                  Favorite.ok,
                  () => {
                    callback();
                    Navigation.dismissAllModals();
                  },
                );
                // setAppsFlyerTrackEvent(send);
              } else {
                WashAlert.showAlert(Favorite.fail, Favorite.ok);
              }
            })
            .catch(err => {
              /** 에러처리 **/
              dispatch(_setHttpPending({ isPending: false }));
              WashAlert.showAlert(Favorite.fail, Favorite.ok);
            });
        }
      },
    );
  }
};

const setAppsFlyerTrackEvent = (
  orderId,
  uid,
  af_address,
  af_road_address,
  af_detail_address,
  af_user_type,
  payType,
  couponName,
) => {
  AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_COMPLETE_ORDER, {
    af_order_id: orderId,
    af_uid: uid,
    af_address,
    af_road_address,
    af_detail_address,
    af_user_type,
    af_payment_method: payType,
    af_coupon_name: couponName,
  });
  AnalyticsManager.setAirbridgeTrackEvent(
    AnalyticsKey.NAME_COMPLETE_ORDER,
    Platform.OS,
    uid,
  );
};

// reducer
const initialState = {
  isPending: false,
  isOpenRequestModal: false,
  selectedType: null,
  requests: _.cloneDeep(OrderRequest.requests),
};

export default handleActions(
  {
    [SET_HTTP_PENDING]: (state, action) => {
      const { isPending } = action.payload;
      return {
        ...state,
        isPending,
      };
    },
    [SET_IS_OPEN_REQUEST_MODAL]: (state, action) => {
      const { isOpen, selectedType } = action.payload;
      return {
        ...state,
        isOpenRequestModal: isOpen,
        selectedType,
      };
    },
    [SET_REQUESTS]: (state, action) => {
      const { requests } = action.payload;
      return {
        ...state,
        requests,
      };
    },
    [ADD_REQUEST]: (state, action) => {
      const { type } = action.payload;
      const { requests } = state;
      const request = _.find(requests, ['type', type]);
      request.isRequest = true;
      return {
        ...state,
        requests,
      };
    },
    [DELETE_REQUEST]: (state, action) => {
      const { type } = action.payload;
      const { requests } = state;
      const initRequests = _.cloneDeep(initialState.requests);
      const initRequest = _.find(initRequests, ['type', type]);
      const requestIndex = _.findIndex(requests, ['type', type]);
      requests[requestIndex] = initRequest;
      return {
        ...state,
        requests: _.cloneDeep(requests),
      };
    },
    [SET_PICKUP_REQUESTS]: (state, action) => {
      const { index } = action.payload;
      const { requests } = state;
      const request = requests[0];
      let { detailRequests } = request;
      const { type, title, selected } = detailRequests[index];
      // detailRequests.map((item, i) => {
      // detailRequests[i].selected = false;
      // if (index === i) {
      detailRequests[index].selected = !selected;
      // }
      // if (type !== 'message') {
      //   if (!selected) {
      //      message = title;
      //   } else {
      //     message = '';
      //   }
      // } else {
      //   message = '';
      // }
      // });
      if (type === 'message' && selected) {
        request.message = '';
      }
      return {
        ...state,
        requests: _.cloneDeep(requests),
      };
    },
    [SET_REQUEST_MESSAGE]: (state, action) => {
      const { index, message } = action.payload;
      const { requests } = state;
      requests[index].message = message;
      return {
        ...state,
        requests: _.cloneDeep(requests),
      };
    },
    [ADD_IMAGE]: (state, action) => {
      const { type, uri } = action.payload;
      const { requests } = state;
      const requestObject = _.find(requests, ['type', type]);
      const { images } = requestObject;
      if (images === undefined) {
        requestObject.images = [];
        requestObject.images.push(uri);
      } else {
        images.push(uri);
      }
      return {
        ...state,
        requests: _.cloneDeep(requests),
      };
    },
    [DELETE_IMAGE]: (state, action) => {
      const { type, index } = action.payload;
      const { requests } = state;
      const requestObject = _.find(requests, ['type', type]);
      const { images } = requestObject;
      images.splice(index, 1);
      return {
        ...state,
        requests: _.cloneDeep(requests),
      };
    },
    [INIT_REQUESTS]: (state, action) => {
      return _.cloneDeep(initialState);
    },
    [SET_REQUESTS_OF_ORDER]: (state, action) => {
      const { requests } = state;
      const { order } = action.payload;
      const { preOptions } = order;
      if (!preOptions) {
        return {
          ...state,
          requests: _.cloneDeep(requests),
        };
      }
      const { care, delivery } = preOptions;
      if (care && care.options.length > 0) {
        care.options.map((item, index) => {
          const { type } = item;
          const careObject = _.find(care.options, ['type', type]);
          if (careObject) {
            const requestObject = _.find(requests, ['type', type]);
            if (requestObject) {
              requestObject.isRequest = true;
              requestObject.message = _.cloneDeep(careObject.message);
              requestObject.images = _.cloneDeep(careObject.images);
            }
          }
        });
      }
      if (delivery && delivery.options.length > 0) {
        let { type, message, pickupMessage } = delivery.options[0];
        if (type === 'pickup') {
          const requestObject = _.find(requests, ['type', type]);
          requestObject.isRequest = true;
          message = message || pickupMessage;
          const pickupMessages = message ? message.split('\n') : [];
          const { detailRequests } = requestObject;
          pickupMessages.map((message, index) => {
            const findedObject = _.find(detailRequests, o => {
              if (o.type !== 'message') {
                return o.title === message;
              } else {
                const bellObject = _.find(detailRequests, o => {
                  return o.type === 'bell';
                });
                const securityObject = _.find(detailRequests, o => {
                  return o.type === 'security';
                });
                if (
                  bellObject.title !== message &&
                  securityObject.title !== message
                ) {
                  requestObject.message = message;
                  const messageObject = _.find(detailRequests, o => {
                    return o.type === 'message';
                  });
                  messageObject.selected = true;
                }
              }
            });
            if (findedObject) {
              findedObject.selected = true;
            }
          });
        }
      }
      return {
        ...state,
        requests: _.cloneDeep(requests),
      };
    },
  },
  _.cloneDeep(initialState),
);
