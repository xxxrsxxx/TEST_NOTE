import { handleActions, createAction } from 'redux-actions';

import { Navigation } from 'react-native-navigation';
import BottomSheet from 'react-native-bottomsheet';
import { ChannelIO } from 'react-native-channel-plugin';

import async from 'async';

import * as CommonUtils from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import * as KeyUtils from '../utils/type/key';
import WashAlert from '../utils/alert';
import { showNaverPay } from '../utils/common/payment';
import {
  Favorite,
  OSDPaymentString,
  OrderHistoryPaymentString,
  OrderHistoryText,
} from '../utils/common/strings';

import {
  requestRegistCard,
  showInicisCard,
  showBankList,
  actionPaymentRequest,
} from './PaymentModule';
import * as OrderAction from './OrderModule';
import * as MyPageAction from './MyPageModule';

import * as PageName from 'vo/PageName';

import { _ } from '../plugins';

// action constructor
const SET_ORDER_LIST = 'orderHistory/SET_ORDER_LIST';
const HTTP_PENDING = 'orderHistory/HTTP_PENDING';
const TOGGLE_PAY_TYPE = 'orderHistory/TOGGLE_PAY_TYPE';
const GET_AVAILABLE = 'orderHistory/GET_AVAILABLE';
const SET_ORDER = 'orderHistory/SET_ORDER';
const SET_RECEIPT_LIST = 'orderHistory/SET_RECEIPT_LIST';
const SET_REFUND_PRICE = 'orderHistory/SET_REFUND_PRICE';
const SET_IS_REFUND_COMPLETION = 'orderHistory/SET_IS_REFUND_COMPLETION';
const SET_DISCOUNT_PRICE_FOR_BASIC_USER =
  'orderHistory/SET_DISCOUNT_PRICE_FOR_BASIC_USER';
const SET_TAB = 'orderHistory/SET_TAB';

const SET_MODAL_ON = 'orderHistory/SET_MODAL_ON';
const SET_TOAST_ON = 'orderHistory/SET_TOAST_ON';
const SET_CARD_CHECKED = 'orderHistory/SET_CARD_CHECKED';
const SET_COMPONENT_ID = 'orderHistory/SET_COMPONENT_ID';
const SET_BILL_KEY = 'orderHistory/SET_BILL_KEY';
const SET_PAY_PENDING = 'orderHistory/SET_PAY_PENDING';
const SET_TOAST_DELIVERY_FAIL = 'orderHistory/SET_TOAST_DELIVERY_FAIL';

export const setOrderListData = createAction(SET_ORDER_LIST);
const setHttpPending = createAction(HTTP_PENDING);
export const setReceiptList = createAction(SET_RECEIPT_LIST);
export const setRefundPrice = createAction(SET_REFUND_PRICE);
export const setTab = createAction(SET_TAB);

export const setModalOn = createAction(SET_MODAL_ON);
export const setToastOn = createAction(SET_TOAST_ON);
export const setCardChecked = createAction(SET_CARD_CHECKED);
export const setComponentId = createAction(SET_COMPONENT_ID);
export const setBillKey = createAction(SET_BILL_KEY);
export const setPayPending = createAction(SET_PAY_PENDING);

const EMAIL = OrderHistoryText.submitReceiptEmail;
const PHONE = OrderHistoryText.submitReceiptMessage;

export const setToastDeliveryFail = toggle => (dispatch, getState) => {
  dispatch(createAction(SET_TOAST_DELIVERY_FAIL)(toggle));
};

export const setIsRefundCompletion = isOpen => (dispatch, getState) => {
  dispatch(
    createAction(SET_IS_REFUND_COMPLETION)({ isRefundCompletion: isOpen }),
  );
};

export const showOrderHistoryDetailScreen = ({
  componentId,
  orderId,
  status,
  finishedAction,
}) => async (dispatch, getState) => {
  const orderIdForOpenCheck = await $_storage.get(
    KeyUtils.ORDER_HISTROTY_DETAIL_ORDERID,
  );
  if (orderIdForOpenCheck) {
    // 열려있는 상태 > 주문 갱신
    if (orderId) {
      dispatch(getOrderDetail(orderId));
    }
  } else {
    if (status && status === 'over') {
      finishedAction();
      return;
    }
    // 닫혀있는 상태 > showModal 호출
    CommonUtils.navPush({
      componentId,
      name: 'OrderHistoryScreen',
      passProps: {
        orderId,
      },
    });
    finishedAction();
  }
};

export const actionRefund = ({
  type,
  refundPrice,
  toggleRefundModal,
  componentId,
}) => async (dispatch, getState) => {
  const {
    orderItem: { _id, orderId },
  } = getState().OrderHistoryModule;

  if (type === 'point') {
    WashAlert.showConfirm(
      OrderHistoryText.refundToPoint,
      Favorite.yes,
      Favorite.no,
      async () => {
        dispatch(setHttpPending({ isPending: true }));
        await $_axios
          .post(
            ServerUtils.ACTION_REFUND,
            {},
            { objectId: _id, refundType: type, price: refundPrice },
          )
          .then(response => {
            dispatch(setHttpPending({ isPending: false }));
            const { code } = response.data;
            if (code === 200) {
              WashAlert.showAlertWithCallback(
                OSDPaymentString.refundOver,
                Favorite.ok,
                () => {
                  toggleRefundModal(0);
                  dispatch(getOrderHistory());
                  CommonUtils.navPush({
                    componentId,
                    name: 'PointHistoryScreen',
                  });
                },
              );
            } else {
              WashAlert.showAlertWithCallback(
                Favorite.fail,
                Favorite.ok,
                () => {
                  toggleRefundModal(0);
                },
              );
            }
          });
      },
    );
  } else {
    WashAlert.showConfirm(
      OrderHistoryText.refundModal,
      Favorite.yes,
      Favorite.no,
      async () => {
        dispatch(setHttpPending({ isPending: true }));
        await $_axios
          .post(ServerUtils.ACTION_REFUND_NOTICE, {}, { objectId: _id })
          .then(response => {
            dispatch(setHttpPending({ isPending: false }));
            const { code } = response.data;
            if (code === 200) {
              toggleRefundModal(0);
              dispatch(getOrderDetail(orderId));
              // dispatch(getAvailable());
              dispatch(setIsRefundCompletion(true));

              // WashAlert.showAlertWithCallback(OSDPaymentString.refundNoticeOver, Favorite.ok, () => {
              //   toggleRefundModal(0);
              //   dispatch(getAvailable());
              // });
            } else {
              WashAlert.showAlertWithCallback(
                Favorite.fail,
                Favorite.ok,
                () => {
                  toggleRefundModal(0);
                },
              );
            }
          });
      },
    );
  }
};

const wait = timeout => {
  return new Promise(resolve => {
    setTimeout(resolve, timeout);
  });
};

export const onRefreshInProgress = () => (dispatch, getState) => {
  dispatch(setHttpPending({ refreshingInProgress: true }));
  wait(2000).then(() => {
    dispatch(setHttpPending({ refreshingInProgress: false }));
    dispatch(getOrderHistory());
  });
};

export const setReceipt = (data, componentId) => async (dispatch, getState) => {
  const {
    orderItem: { _id },
  } = getState().OrderHistoryModule;
  dispatch(sendReceit({ row: data, objectId: _id, componentId }));
};

export const sendReceit = ({ row, objectId, componentId }) => async (
  dispatch,
  getState,
) => {
  const { tId, payType, refundType } = row;
  if (payType === 'naverpay' || refundType === 'naverpay') {
    CommonUtils.navShowModalWebView({
      url: 'https://new-m.pay.naver.com/historybenefit/paymenthistory',
    });
  } else {
    const options = [EMAIL, PHONE];
    options.push(OrderHistoryText.cancel);
    let phone = await CommonUtils.getValue(KeyUtils.PHONE_NUMBER);
    BottomSheet.showBottomSheetWithOptions(
      {
        options,
        title: OrderHistoryText.submitReceipt,
        dark: false,
        cancelButtonIndex: options.length,
      },
      value => {
        const title = options[value];
        if (title === EMAIL) {
          CommonUtils.navPush({
            componentId,
            name: 'TextInputScreen',
            passProps: {
              pageName: PageName.EMAIL_RECEIPT,
              finishedAction: email => {
                dispatch(
                  sendReceitAction({
                    objectId,
                    type: 'email',
                    tId,
                    value: email,
                    componentId,
                  }),
                );
              },
            },
          });
        } else if (title === PHONE) {
          dispatch(
            sendReceitAction({
              objectId,
              type: 'sms',
              tId,
              value: phone,
              componentId,
            }),
          );
        }
      },
    );
  }
};
const sendReceitAction = ({
  objectId,
  type,
  tId,
  value,
  componentId,
}) => async (dispatch, getState) => {
  dispatch(setHttpPending({ isPending: true }));
  await $_axios
    .post(ServerUtils.SEND_RECEIPT, {}, { objectId, type, tId, value })
    .then(response => {
      dispatch(setHttpPending({ isPending: false }));
      const { code, message } = response.data;
      if (code === 200) {
        if (type === 'sms') {
          // CommonUtils.navPush({
          //   componentId,
          //   name: 'CSPopupScreen'
          // });
          ChannelIO.showMessenger();
        } else {
          WashAlert.showAlert(OSDPaymentString.receiptOver, Favorite.ok);
        }
      } else {
        // WashAlert.showAlert(Favorite.fail,Favorite.ok);
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    });
};

export const init = status => async (dispatch, getState) => {
  if (status) {
    dispatch(getAvailable());
  }
};

export const setOrder = orderItem => async dispatch => {
  dispatch(createAction(SET_ORDER)(orderItem));
};

export const setPoint = (point, callback) => async (dispatch, getState) => {
  dispatch(setHttpPending({ isPending: true }));
  let uid = await CommonUtils.getValue(KeyUtils.USER_ID);
  const {
    orderItem: { _id },
    available: {
      order: { useCoupon, usedCouponList },
    },
  } = getState().OrderHistoryModule;
  $_axios
    .post(
      ServerUtils.AVAILABLE_VALUE_IN_ORDER,
      {},
      { objectId: _id, uid, coupon: usedCouponList, point },
    )
    .then(response => {
      dispatch(createAction(GET_AVAILABLE)(response.data));
      if (callback) {
        callback();
      }
    });
};

export const addCoupon = coupon => async (dispatch, getState) => {
  dispatch(setHttpPending({ isPending: true }));

  let uid = $_status.state.user.uid;
  const {
    orderItem: { _id },
    available: {
      order: { usePoint },
    },
  } = getState().OrderHistoryModule;

  await $_axios
    .post(
      ServerUtils.AVAILABLE_VALUE_IN_ORDER,
      {},
      { objectId: _id, uid, coupon, point: usePoint },
    )
    .then(response => {
      dispatch(createAction(GET_AVAILABLE)(response.data));
    });
};

export const getAvailable = finishedAction => async (dispatch, getState) => {
  dispatch(setHttpPending({ isPending: true }));

  let uid = $_status.state.user.uid;
  const {
    orderItem: { _id },
  } = getState().OrderHistoryModule;
  await $_axios
    .post(ServerUtils.AVAILABLE_VALUE_IN_ORDER, {}, { objectId: _id, uid })
    .then(response => {
      dispatch(createAction(GET_AVAILABLE)(response.data));
      if (finishedAction) {
        finishedAction();
      }
    })
    .catch(error => {
      WashAlert.showAlert(message ? message : Favorite.fail, Favorite.ok);
      dispatch(setHttpPending({ isPending: false }));
    });
};

export const togglePayType = ({ payType, finalPrice, componentId }) => async (
  dispatch,
  getState,
) => {
  dispatch(createAction(TOGGLE_PAY_TYPE)(payType));

  if (payType === 'account') {
    const uid = await $_storage.get(KeyUtils.USER_ID);
    const { orderItem, available } = getState().OrderHistoryModule;

    async.waterfall(
      [
        callback => {
          dispatch(
            showBankList({
              uid,
              name: orderItem.userInfo.name,
              orderId: orderItem.orderId,
              finalPrice: available.order.finalPrice,
              usePoint: available.order.usePoint,
              usedCouponList: available.order.usedCouponList,
              componentId,
              phone: orderItem.phone,
            }),
          );
          callback();
        },
        callback => {
          Navigation.pop(componentId);
          callback();
        },
      ],
      err => {},
    );
  } else if (payType !== '') {
    async.waterfall([
      callback => {
        Navigation.pop(componentId);
        callback();
      },
    ]);
  }
};

// 결제모달 띄워진 상태로 해당사항 체크하고 결제하기 버튼 눌렀을 경우
export const pressPay = () => async (dispatch, getState) => {
  const {
    payment,
    available: {
      availableCoin,
      availablePoint,
      cardList,
      coupon,
      order: { usePoint, usedCouponList, totalPrice, finalPrice },
      hash,
    },
    orderItem: {
      _id,
      orderId,
      userInfo: { uid, name },
    },
    selectedPaymentType,
    componentId,
  } = getState().OrderHistoryModule;

  // const uid = await CommonUtils.getValue(KeyUtils.USER_ID);

  const _storage = await $_storage.get();

  const phone = _storage[KeyUtils.PHONE_NUMBER];

  const af_address = _storage[KeyUtils.USER_ADDRESS];
  const af_road_address = _storage[KeyUtils.USER_ROAD_ADDRESS];
  const af_detail_address = _storage[KeyUtils.USER_ADDRESS_OTHERS];
  const af_user_type = _storage[KeyUtils.USER_TYPE];

  switch (selectedPaymentType) {
    // 등록된 카드결제의 경우, android에서 blur처리가 안되는 문제로 인해 모달을 먼저 내리고 이후 결제동작 실행
    case 'bill':
      dispatch(setModalOn(false));
      await dispatch(
        actionPaymentRequest(
          {
            uid,
            name,
            orderId,
            objectId: _id,
            finalPrice,
            usePoint,
            usedCouponList,
            payType: 'bill',
          },
          () => {
            WashAlert.showAlertWithCallback(
              OSDPaymentString.payOver,
              Favorite.ok,
              () => {
                dispatch(getOrderHistory());
                dispatch(setBillKey(''));
                Navigation.pop(componentId);
                // this.handlePressGoBack();
              },
            );
          },
        ),
      );
      break;
    case 'regist':
      dispatch(
        requestRegistCard(
          {
            componentId,
          },
          () => {
            WashAlert.showAlertWithCallback(
              OSDPaymentString.addCardComplete,
              Favorite.ok,
              () => {
                dispatch(setModalOn(false));
                dispatch(getAvailable());
              },
            );
          },
        ),
      );
      // dispatch(showRegistCard());
      break;
    case 'coin':
      if (!availableCoin) {
        WashAlert.showConfirm(
          OrderHistoryPaymentString.goBulletPageModal,
          Favorite.ok,
          Favorite.no,
          () => {
            dispatch(goToCoin(componentId));
          },
        );
      } else {
        dispatch(
          actionPaymentRequest(
            {
              uid,
              name,
              orderId,
              objectId: _id,
              finalPrice,
              usePoint,
              usedCouponList,
              payType: 'coin',
            },
            () => {
              WashAlert.showAlertWithCallback(
                OSDPaymentString.payOver,
                Favorite.ok,
                () => {
                  dispatch(getOrderHistory());
                  dispatch(setModalOn(false));
                  Navigation.pop(componentId);
                },
              );
            },
          ),
        );
      }
      break;
    case 'card':
      dispatch(
        showInicisCard(
          {
            uid,
            name,
            objectId: _id,
            finalPrice,
            orderId,
            usePoint,
            phone,
            usedCouponList,
          },
          () => {
            WashAlert.showAlertWithCallback(
              OSDPaymentString.payOver,
              Favorite.ok,
              () => {
                dispatch(setModalOn(false));
                Navigation.pop(componentId);
                setTimeout(() => {
                  dispatch(getOrderHistory());
                }, 200);
              },
            );
            /** 여기가 성공 **/
          },
          () => {
            /** 실패 **/
            dispatch(setModalOn(false));
          },
        ),
      );
      break;
    case 'naverpay':
      showNaverPay({
        data: {
          callType: 'naverpay',
          url: ServerUtils.URL_NAVERPAY,
          uid,
          name,
          objectId: _id,
          totalPrice,
          finalPrice,
          orderId,
          usePoint,
          phone,
          usedCouponList,
          hash,
        },
        finishedAction: json => {
          const { code, message } = json;
          if (code === 200) {
            WashAlert.showAlertWithCallback(
              OSDPaymentString.payOver,
              Favorite.ok,
              () => {
                Navigation.pop(componentId);
                dispatch(setModalOn(false));
                setTimeout(() => {
                  dispatch(getOrderHistory());
                }, 200);
              },
            );
          } else {
            dispatch(setModalOn(false));

            if (message) {
              WashAlert.showAlert(message, Favorite.ok);
            } else {
              /** 디폴트 메시지 **/
              WashAlert.showAlert(Favorite.fail, Favorite.ok);
            }
          }
        },
      });
      break;
  }
  setTimeout(() => {
    dispatch(setPayPending(false));
  }, 3000);
};

// 카드 등록
// const showRegistCard = () => async (dispatch, getState) => {
//   const { orderItem : { userInfo : { uid , name }} } = getState().OrderHistoryModule;

//   WashPayment.show({ callType : 'bill', uid, name } , (json) => {
//     const { code, message } = json;

//     if (code == 200) {
//       // cardList 업데이트 했으니 다시 orderItem? api 호출

//     } else if (code == 300) {
//       /** 그냥 화면 닫은 경우 **/
//     } else {
//       if (message) {
//         WashAlert.showAlert(message, Favorite.ok);
//         /** 서버에서 돌려주는 메시지 **/
//       } else {
//         WashAlert.showAlert(Favorite.fail, Favorite.ok);
//       }
//     }
//   })
// }

// 총알 구매 화면
const goToCoin = componentId => async (dispatch, getState) => {
  /** 총알 없음 총알 살까요? 물어보고 총알 페이지 이동 **/
  CommonUtils.navPush({
    componentId,
    name: 'BuyBulletScreen',
  });
};

export const joinMembership = componentId => async (dispatch, getState) => {
  const {
    orderItem: { orderId },
  } = getState().OrderHistoryModule;

  dispatch(
    MyPageAction.checkMember({
      finishedAction: () =>
        CommonUtils.navShowModal({
          name: 'JoinMember',
          passProps: {
            finishedAction: () => {
              dispatch(getOrderHistoryDetail(orderId));
              CommonUtils.navPush({
                componentId,
                name: 'CouponMain',
              });
            },
          },
        }),
    }),
  );
  $_status.actions.globalPendingHandler(false);
};

export const goToPreCouponMain = (componentId, status) => async (
  dispatch,
  getState,
) => {
  const {
    orderItem: {
      _id,
      preOptions: {
        payment: {
          discount: { coupon },
        },
      },
    },
  } = getState().OrderHistoryModule;

  CommonUtils.navPush({
    componentId,
    name: 'CouponMain',
    passProps: {
      status,
      objectId: _id,
      finishedAction: coupon => dispatch(setPreCoupon(coupon)),
      seletedCoupon: coupon || [],
    },
  });
};

export const goToCouponMain = componentId => async (dispatch, getState) => {
  const {
    available: {
      order: { usedCouponList },
    },
    orderItem: { _id },
  } = getState().OrderHistoryModule;

  CommonUtils.navPush({
    componentId,
    name: 'CouponMain',
    passProps: {
      objectId: _id,
      finishedAction: coupon => dispatch(addCoupon(coupon)),
      seletedCoupon: usedCouponList || [],
    },
  });
};

export const goToPointMain = componentId => async (dispatch, getState) => {
  const {
    available: { availablePoint },
  } = getState().OrderHistoryModule;

  dispatch(OrderAction.selectPoint(0));

  CommonUtils.navPush({
    componentId,
    name: 'TextInputScreen',
    passProps: {
      pageName: PageName.USE_POINT,
      maximum: availablePoint,
      keyboardType: 'number-pad',
      finishedAction: point => dispatch(setPoint(point)),
    },
  });
};

export const goToSetPickupTime = componentId => async (dispatch, getState) => {
  const {
    orderItem: { _id, orderId },
  } = getState().OrderHistoryModule;

  CommonUtils.navShowModalPageSheet({
    componentId: componentId,
    name: 'OrderPickupScreen',
    passProps: {
      orderId,
      componentId,
      timeSelectCallback: pickup => {
        dispatch(
          OrderAction.updatePickupTime({
            pickup,
            objectId: _id,
            callback: () => {
              dispatch(getOrderHistoryDetail(orderId));
            },
          }),
        );
      },
    },
  });
};

export const goToSetDeliveryTime = componentId => async (
  dispatch,
  getState,
) => {
  const {
    orderItem: { _id, orderId, deliveryTime },
  } = getState().OrderHistoryModule;
  CommonUtils.navShowModalPageSheet({
    componentId,
    name: 'OrderDeliveryScreen',
    passProps: {
      orderId,
      parentComponentId: componentId,
      mainDataDeliveryTime: deliveryTime,
      timeSelectCallback: (delivery, componentId) => {
        dispatch(
          OrderAction.updateDeliveryTime({
            delivery,
            objectId: _id,
            callback: () => {
              dispatch(setOrderInProgress());
              dispatch(getOrderHistoryDetail(orderId));
            },
            failCallback: () => {
              Navigation.dismissModal(componentId);
            },
          }),
        );
      },
    },
  });
};

export const setPreCoupon = selectedCoupon => async (dispatch, getState) => {
  const {
    orderItem: { orderId },
  } = getState().OrderHistoryModule;

  dispatch(setHttpPending({ isPending: true }));

  await $_axios
    .post(
      ServerUtils.SET_PRE_COUPON,
      {},
      {
        orderId,
        key: 'payment',
        data: {
          discount: {
            coupon: selectedCoupon,
          },
        },
      },
    )
    .then(res => {
      dispatch(setHttpPending({ isPending: false }));
      const { code } = res.data;
      if (code === 200) {
        dispatch(getOrderHistoryDetail(orderId));
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    })
    .catch(err => {
      dispatch(setHttpPending({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

// middle ware
export const getOrderHistory = () => async (dispatch, getStore) => {
  dispatch(setOrderInProgress());
  dispatch(setOrderOver());
};

export const getOrderHistoryDetail = orderId => async dispatch => {
  dispatch(setHttpPending({ isPending: true }));

  let userId = $_status.state.user.uid;
  const _url = `${ServerUtils.GET_HISTORY_DETAIL}/${orderId}`;

  return await $_axios
    .get(_url, {})
    .then(res => {
      dispatch(setHttpPending({ isPending: false }));

      const { order } = res.data;

      if (!order || order === {}) {
        // Navigation.dismissModal(componentId);
        WashAlert.showAlert(OrderHistoryText.notFoundOrder, Favorite.ok);
        return;
      }
      const {
        status,
        userInfo: { uid },
      } = order;
      if (parseInt(userId) === parseInt(uid)) {
        dispatch(setOrder(order));
        dispatch(init(status));
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(setHttpPending({ isPending: false }));
    });
};

/** OrderComplete에서 호출 **/
export const getOrderDetail = (orderId, componentId) => async (
  dispatch,
  getState,
) => {
  dispatch(setHttpPending({ isPending: true }));

  let userId = $_status.state.user.uid;

  return await $_axios
    .post(ServerUtils.GET_ORDER_DETAIL, {}, { orderId })
    .then(res => {
      dispatch(setHttpPending({ isPending: false }));
      if (res.data.code === 200) {
        const { order } = res.data;
        if (!order || order === {}) {
          // Navigation.dismissModal(componentId);
          WashAlert.showAlert(OrderHistoryText.notFoundOrder, Favorite.ok);
          return;
        }
        const {
          status,
          userInfo: { uid },
        } = order;
        if (parseInt(userId) === parseInt(uid)) {
          dispatch(setOrder(order));
          dispatch(init(status));
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(setHttpPending({ isPending: false }));
    });
};

export const getDiscountPriceForBasicUser = orderId => async (
  dispatch,
  getState,
) => {
  if (!orderId) {
    return;
  }
  const _url = ServerUtils.GET_DISCOUNT_PRICE_FOR_BASIC_USER.replace(
    ':orderId',
    orderId,
  );
  return await $_axios
    .get(_url, {})
    .then(res => {
      const { amount } = res.data.data;
      dispatch(
        createAction(SET_DISCOUNT_PRICE_FOR_BASIC_USER)({
          discountPriceForBasicUser: amount,
        }),
      );
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const setOrderInProgress = () => async (dispatch, getState) => {
  dispatch(setHttpPending({ isPending: true }));
  // dispatch(globalPendingHandler(true));
  // const { orderItem } = getState().OrderHistoryModule;
  return await $_axios
    .get(ServerUtils.ORDER_SEARCH_IN_PROGRESS, {})
    .then(res => {
      const { data } = res;
      const { list, GLOBAL_STATUS_LIST } = data;
      const orderListData = {
        GLOBAL_STATUS_LIST,
        orderItemList: list,
        isPending: false,
      };
      //ispatch(globalPendingHandler(false));
      dispatch(setOrderListData(orderListData));
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(setHttpPending({ isPending: false }));
      // dispatch(globalPendingHandler(false));
    });
};

export const setOrderOver = () => async (dispatch, getState) => {
  dispatch(setHttpPending({ isPending: true }));
  return await $_axios
    .get(ServerUtils.ORDER_SEARCH_OVER, {})
    .then(res => {
      const { data } = res;
      const { list, GLOBAL_STATUS_LIST } = data;
      const orderListData = {
        GLOBAL_STATUS_LIST,
        lastOrders: list.slice(0, 2),
        originalLastOrders: list,
        isPending: false,
      };
      dispatch(setOrderListData(orderListData));
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(setHttpPending({ isPending: false }));
    });
};

// reducer
const initialState = {
  payment: {
    payType: ``,
  },
  available: {
    availableCoin: 0,
    availablePoint: 0,
    cardList: [],
    coupon: [],
    order: {
      usedCouponList: [],
      usePoint: 0,
      finalPrice: 0,
    },
  },

  prevOrderItemList: [],
  receiptList: [],
  refundPrice: 0,
  isRefundCompletion: false,
  refundSuccess: false,
  discountPriceForBasicUser: 0,

  // new
  tab: 'progress',
  GLOBAL_STATUS_LIST: [],
  orderItemList: [],
  isPayPending: false,
  orderItem: {
    _id: '',
    regdate: '',
    orderId: '',
    dailyOrderId: 0,
    userInfo: {
      userType: '',
      centerId: '',
      isTemp: 0,
      uid: 0,
      address: '',
      addressOthers: '',
      doorCode: '',
      dong: '',
      postCode: '',
      lat: '',
      lon: '',
      name: '',
      thumbPicture: '',
      picture: '',
      comment: '',
      sector: '',
      connectMemberBenefit: '',
      orderIndex: 0,
    },
    status: '',
    memo: '',
    phone: '',
    alert: '',
    payment: {
      hasCard: '',
      history: [],
    },
    mission: {
      pickup: {
        pickupTime: '',
        endTime: '',
        type: '',
        where: {
          door: '',
          location: '',
        },
      },
      delivery: {
        deliveryTime: '',
        endTime: '',
        type: '',
        where: {
          door: '',
          location: '',
        },
        fixDeliveryTime: '',
      },
    },
    issue: '',
    preOptions: {
      payment: {
        discount: {
          coupon: [],
          point: 0,
        },
        payType: '',
      },
      care: {
        regdate: '',
        options: [],
      },
    },
    pickup: {
      bagNumber: '',
      item: [],
      payType: '',
      usePoint: 0,
      discountRate: 0,
      eventDiscount: 0,
      finalPrice: 0,
      totalPrice: 0,
      deliveryFee: 0,
      swatId: '',
      regdate: '',
      priceVersion: '',
      nextItemId: 0,
      itemExtra: 0,
      couponDiscount: 0,
      details: {
        finalPrice: 0,
        sumOfItemPrice: 0,
        itemExtra: 0,
        deliveryFee: 0,
        pointDiscount: 0,
        couponDiscount: 0,
        protegeDiscountForMember: 0,
        protegeDiscountForNormal: 0,
      },
      savingPoint: 0,
    },
    isPostPickup: '',
    media: [],
    analysisCheck: '',
  },
  lastOrders: [],
  originalLastOrders: [],
  isPending: false,
  refreshingInProgress: false,
  isModalOn: false,
  isToastOn: true,
  selectedPaymentType: undefined,
  modalCardStructure: {
    cards: [
      {
        title: '신용/체크카드 등록',
        registedTitle: '새로운 신용/체크카드 등록',
        key: 'regist',
        ment: '등록하기',
        // event: '배달 전 자동결제!'
      },
      {
        title: '총알캐시 충전',
        key: 'coin',
        ment: '충전하기',
        // event: '최대 50,000원 더!'
      },
      {
        title: 'PG결제 (신용/체크카드/PAYCO/카카오페이)',
        key: 'card',
        ment: '결제하기',
      },
      {
        title: '네이버페이',
        key: 'naverpay',
        ment: '결제하기',
      },
    ],
  },
  componentId: undefined,
  billKey: '',
  toastDeliveryFail: false,
};

export default handleActions(
  {
    [SET_ORDER_LIST]: (state, action) => {
      return {
        ...state,
        ..._.cloneDeep(action.payload),
      };
    },
    [HTTP_PENDING]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SET_RECEIPT_LIST]: (state, action) => {
      const { receiptList } = action.payload;
      return {
        ...state,
        receiptList,
      };
    },
    [SET_REFUND_PRICE]: (state, action) => {
      const { refundPrice } = action.payload;
      return {
        ...state,
        refundPrice,
      };
    },
    [SET_IS_REFUND_COMPLETION]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [GET_AVAILABLE]: (state, action) => {
      return {
        ...state,
        available: _.cloneDeep(action.payload),
        isPending: false,
      };
    },
    [TOGGLE_PAY_TYPE]: (state, action) => {
      var { payment } = state;
      payment.payType = action.payload;
      return {
        ...state,
        payment: _.cloneDeep(payment),
        isPending: false,
      };
    },
    [SET_ORDER]: (state, action) => {
      return {
        ...state,
        orderItem: _.cloneDeep(action.payload),
        isPending: false,
      };
    },
    [SET_MODAL_ON]: (state, action) => {
      return {
        ...state,
        isModalOn: action.payload,
        isPayPending: false,
      };
    },
    [SET_TOAST_ON]: (state, action) => {
      return {
        ...state,
        isToastOn: action.payload,
      };
    },
    [SET_CARD_CHECKED]: (state, action) => {
      return {
        ...state,
        selectedPaymentType: action.payload,
        isPayPending: false,
      };
    },
    [SET_COMPONENT_ID]: (state, action) => {
      return {
        ...state,
        componentId: action.payload,
      };
    },
    [SET_BILL_KEY]: (state, action) => {
      return {
        ...state,
        billKey: action.payload,
        isPayPending: false,
      };
    },
    [SET_PAY_PENDING]: (state, action) => {
      return {
        ...state,
        isPayPending: action.payload,
      };
    },
    [SET_TAB]: (state, action) => {
      return {
        ...state,
        tab: action.payload,
      };
    },
    [SET_TOAST_DELIVERY_FAIL]: (state, action) => {
      return {
        ...state,
        toastDeliveryFail: action.payload,
      };
    },
  },
  initialState,
);
