import { Platform, Vibration } from 'react-native';

import { createAction, handleActions } from 'redux-actions';

import * as CommonUtils from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import * as KeyUtils from '../utils/type/key';
import WashAlert from '../utils/alert';
import AnalyticsManager from '../utils/tagging/analytics';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import { Favorite, OrderChatString } from '../utils/common/strings';

import moment from 'moment';

import { _ } from '../plugins';

// action constructor
const SET_INIT = 'OrderChatModule/SET_INIT';
const HTTP_PENDING = 'OrderChatModule/HTTP_PENDING';
const SET_CHAT_LIST = 'OrderChatModule/SET_CHAT_LIST';
const SET_INITCHAT = 'OrderChatModule/SET_INITCHAT';
const SET_MODAL_DATA = 'OrderChatModule/SET_MODAL_DATA';
const ORDER_COMPLETE = 'OrderChatModule/ORDER_COMPLETE';
const RESET = 'OrderChatModule/RESET';
const BACK_PRESS_OPEN = 'OrderChatModule/BACK_PRESS_OPEN';
const SET_FROM_TYPE = 'OrderChatModule/SET_FROM_TYPE';

moment.locale('ko');
const setHttpPending = createAction(HTTP_PENDING);

export const init = () => async (dispatch, getState) => {
  dispatch(setHttpPending({ isPending: true }));

  const uid = await $_storage.get(KeyUtils.USER_ID);

  const { pickup } = getState().MainScreenModule;

  await $_axios
    .post(ServerUtils.ORDER_CHAT, {}, { uid })
    .then(response => {
      const {
        data: { blockList, message },
      } = response;
      dispatch(
        setPickupTime({
          pickup,
          blockList,
          dataList: [
            { key: 'uid', value: parseInt(uid) },
            { key: 'pickupTime', value: pickup },
            { key: 'version', value: KeyUtils.CHAT_VERSION },
          ],
        }),
      );
    })
    .catch(error => {
      if (error && error.response && error.response.data) {
        WashAlert.showAlert(
          error.response.data.title || Favorite.fail,
          Favorite.ok,
        );
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    });
};

const getInitBlock = pickup => {
  const { pickupTime, endTime } = pickup;

  const now = moment();
  const pt = moment(new Date(pickupTime));
  const et = moment(new Date(endTime));

  let titleText = ``;
  let subText = ``;

  let isToday =
    now.format('YYYYMMDD') === moment(new Date(pickupTime)).format('YYYYMMDD');
  const nightPickup = moment(new Date(pickupTime)).hour() === 0;
  const diffDaysFromNow = moment(new Date(pickupTime))
    .startOf('day')
    .diff(moment(now).startOf('day'), 'day');
  if (
    nightPickup &&
    now.hour() > 6 &&
    now.hour() <= 23 &&
    diffDaysFromNow === 1
  ) {
    /** 오늘 새벽 수거 **/
    isToday = true;
  }

  if (isToday) {
    // titleText ex. 내일 금요일 2/12 오전 7시 전까지 세탁물을 수거합니다.
    titleText += `${Favorite.tomorrow} ${pt.format(
      OrderChatString.initMsgDateFormat,
    )} ${Favorite.am} ${et.format(OrderChatString.initMsgHour)} ${
      OrderChatString.initMsgTitle
    }`;
    // subText ex. 오늘 목요일 2/11 자정까지 세탁물을 문 앞에 준비해주세요.
    subText += `${Favorite.today} ${now.format(
      OrderChatString.initMsgDateFormat,
    )} ${Favorite.midnight}${OrderChatString.initMsgSub}`;
  } else {
    // titleText ex. 금요일 2/12 오전 7시 전까지 세탁물을 수거합니다.
    titleText += `${pt.format(OrderChatString.initMsgDateFormat)} ${
      Favorite.am
    } ${et.format(OrderChatString.initMsgHour)} ${
      OrderChatString.initMsgTitle
    }`;
    // subText ex. 목요일 2/11 자정까지 세탁물을 문 앞에 준비해주세요.
    subText += `${moment(new Date(pickupTime))
      .subtract(1, 'days')
      .format(OrderChatString.initMsgDateFormat)} ${Favorite.midnight}${
      OrderChatString.initMsgSub
    }`;
  }

  /** 서버 호출 필요 **/
  return {
    blockId: 1,
    owner: 'swat', // user, swat
    text: `${titleText}\n\ngg${subText}gg`,
    // nextBlockId : 2,
    buttons: [
      {
        text: '일정변경',
        openPage: 'pickupTime',
      },
      {
        text: '네, 계속 주문할게요',
        nextBlockId: 'N200',
      },
    ],
  };
};

export const nextActionText = (currentBlockId, nextBlock) => (
  dispatch,
  getState,
) => {
  setTimeout(() => {
    dispatch(nextAction(null, currentBlockId, nextBlock.nextBlockId));
  }, 300);
};

export const nextAction = (text, blockId, nextBlockId) => (
  dispatch,
  getState,
) => {
  const list = [];
  if (text) {
    /** text 넣고 다음 발화를 찾는다 **/
    /** 이 경우는 버튼으로 들어오는 경우 + 무조건 유저 메시지다 **/
    list.push({ owner: 'user', text });
  }

  const { chatList, BLOCK_LIST, dataList } = getState().OrderChatModule;
  const currentBlock = _.find(BLOCK_LIST, { blockId });
  /** 서버 통신할지 결정 **/
  const nextBlock = _.find(BLOCK_LIST, { blockId: nextBlockId });
  if (nextBlock) {
    list.push(nextBlock);
    if (nextBlock.keyboard && !nextBlock.keyboard.text) {
      /** 이 경우는 keyboard에서 input을 받야야 한다 **/
    } else if (nextBlock.post) {
      if (nextBlock.post.path || nextBlock.post.url) {
        /** 서버 통신이 필요한 경우 **/
        dispatch(serverConnect(nextBlock));
      } else if (nextBlock.post.page) {
        /**  페이지를 팝업으로 띄운다 **/
      }
    } else {
      if (nextBlock.nextBlockId) {
        /** 이 경우는 text의 경우. trigger가 없기 때문에 여기서 만들어줘야 한다 **/
        dispatch(nextActionText(blockId, nextBlock));
      }
    }
  } else {
    /** 블록의 끝! 액션을 기다린다 **/
  }
  dispatch(createAction(SET_CHAT_LIST)(_.concat(chatList, list)));
};

const serverConnect = trigger => async (dispatch, getState) => {
  const {
    post: { path, url },
  } = trigger;
  const { dataList, BLOCK_LIST } = getState().OrderChatModule;

  const _url = url
    ? `${ServerUtils.ORDER_CHAT}${url}`
    : `${ServerUtils.ORDER_CHAT}${path}`;

  await $_axios
    .post(_url, {}, { dataList })
    .then(response => {
      const {
        data: { data, block },
      } = response;
      if (data && data.key) {
        dispatch(addDataListViaObject(data));
      }
      if (block) {
        const { blockId, text, nextBlockId, owner } = block;
        const index = _.findIndex(BLOCK_LIST, { blockId });

        if (index > -1) {
          BLOCK_LIST[index] = block;
        } else {
          BLOCK_LIST.push(block);
        }
        dispatch(nextAction(null, trigger.blockId, blockId));
      }
    })
    .catch(error => {
      if (error && error.response && error.response.data) {
        WashAlert.showAlert(
          error.response.data.title || Favorite.fail,
          Favorite.ok,
        );
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    });
};
export const onChangeInputText = text => (dispatch, getState) => {
  const { chatList } = getState().OrderChatModule;
  chatList[chatList.length - 1].keyboard.text = text;
  dispatch(createAction(SET_CHAT_LIST)(chatList));
};

export const orderAction = () => async (dispatch, getState) => {
  // const uid = await CommonUtils.getValue(KeyUtils.USER_ID);

  // const orderId = '20191211-293';
  //
  dispatch(setHttpPending({ isPending: true }));

  const storage = await $_storage.getArray([
    KeyUtils.USER_ID,
    KeyUtils.USER_ADDRESS,
    KeyUtils.USER_ROAD_ADDRESS,
    KeyUtils.USER_ADDRESS_OTHERS,
    KeyUtils.USER_TYPE,
  ]);

  const { dataList, chatList } = getState().OrderChatModule;
  const { fromTypeOfOrder } = getState().OrderChatModule;

  const _url = `${ServerUtils.ORDER_CHAT}/order`;

  if (fromTypeOfOrder) {
    dataList.push({
      key: 'from',
      value: {
        type: fromTypeOfOrder,
        processed: 'in-app',
      },
    });
  }
  await $_axios
    .post(_url, {}, { dataList })
    .then(response => {
      const {
        data: { orderId },
      } = response;

      Vibration.vibrate([100]);

      const door = _.find(dataList, { key: 'door' });

      if (door && door.value) {
        $_storage.set(KeyUtils.DOOR_CODE, door.value || '');
      }
      setAppsFlyerTrackEvent(orderId, storage);

      dispatch(createAction(ORDER_COMPLETE)(orderId));
    })
    .catch(error => {
      dispatch(setHttpPending({ isPending: false }));

      if (error && error.response && error.response.data) {
        WashAlert.showAlert(
          error.response.data.title || Favorite.fail,
          Favorite.ok,
        );
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    });
};

const setAppsFlyerTrackEvent = (orderId, storage) => {
  let af_uid, af_address, af_road_address, af_detail_address, af_user_type;

  _.map(storage, l => {
    const key = l[0];
    const value = l[1];
    if (key === KeyUtils.USER_ID) {
      af_uid = value;
    } else if (key === KeyUtils.USER_ADDRESS) {
      af_address = value;
    } else if (key === KeyUtils.USER_ROAD_ADDRESS) {
      af_road_address = value;
    } else if (key === KeyUtils.USER_ADDRESS_OTHERS) {
      af_detail_address = value;
    } else if (key === KeyUtils.USER_TYPE) {
      af_user_type = value;
    }
  });

  AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_COMPLETE_ORDER, {
    af_order_id: orderId,
    af_uid,
    af_address,
    af_road_address,
    af_detail_address,
    af_user_type,
    af_payment_method: '',
    af_coupon_name: '',
  });
  AnalyticsManager.setAirbridgeTrackEvent(
    AnalyticsKey.NAME_COMPLETE_ORDER,
    Platform.OS,
    af_uid,
  );
};

export const inputAction = images => (dispatch, getState) => {
  const { chatList } = getState().OrderChatModule;
  const {
    keyboard: { text },
    nextBlockId,
    blockId,
    data,
  } = chatList[chatList.length - 1];

  if (data) {
    dispatch(addDataList(data, text, images));
  }
  dispatch(nextAction(text, blockId, nextBlockId));
};

export const nextButtonAction = (button, blockId) => (dispatch, getState) => {
  const { chatList, dataList } = getState().OrderChatModule;

  if (chatList[chatList.length - 1].blockId === blockId) {
    /** 마지막 블록만 허용 **/
    const { data, text, nextBlockId, lastAction, openPage } = button;
    if (data) {
      _.map(chatList, r => {
        if (r.blockId === blockId) {
          dispatch(addDataList(data, text));
        }
      });
    }
    if (lastAction) {
      dispatch(orderAction());
    } else if (openPage) {
      /** 페이지를 띄우자 **/

      if (openPage === 'deliveryTime') {
        const pickupTime = _.find(dataList, { key: 'pickupTime' });
        const repair = _.find(dataList, { key: 'repair' });
        if (pickupTime) {
          CommonUtils.navShowModalPageSheet({
            name: 'OrderDeliveryScreen',
            passProps: {
              pickupTime: pickupTime.value,
              midnight: repair ? true : false,
              timeSelectCallback: delivery => {
                dispatch(
                  addDataListViaObject({
                    key: 'deliveryTime',
                    value: delivery,
                  }),
                );
                /** 서버에서 포맷만 바꿔올 수 있도록 해줘야 하기 떄문에 임시로 활용함. 아무곳에서도 사용하지 않음 **/
                dispatch(
                  addDataListViaObject({
                    key: 'localDeliveryTime',
                    value: delivery,
                  }),
                );

                /** 여기서 블록을 바꿔치기 해야한다 **/
                _.pullAt(chatList, chatList.length - 1);
                dispatch(createAction(SET_CHAT_LIST)(chatList));
                setTimeout(() => {
                  dispatch(serverConnect({ post: { path: '/deliveryTime' } }));
                }, 500);
              },
            },
          });
        }
      } else if (openPage === 'policy') {
        CommonUtils.navShowModalWebView({ url: ServerUtils.URL_POLICY });
      } else if (openPage === 'pickupTime') {
        CommonUtils.navShowModalPageSheet({
          name: 'OrderPickupScreen',
          passProps: {
            timeSelectCallback: pickup => {
              /** 시작이니까 바꿔버리면 될듯 **/
              dispatch(setPickupTime({ pickup }));
              dispatch(
                addDataListViaObject({ key: 'pickupTime', value: pickup }),
              );
            },
          },
        });
      }
    } else {
      dispatch(nextAction(text, blockId, nextBlockId));
    }
  }
};

/**
 * Modal을 띄운다
 * @description db.getCollection('appBot').find({blockId : "F103"}) 참고
 */
export const showModal = (blockId, button) => (dispatch, getState) => {
  /** Modal에 필요한 정보를 등록 **/
  const dataSet = {
    blockId,
    button,
  };
  dispatch(createAction(SET_MODAL_DATA)(dataSet));
};
/**
 * Modal을 종료
 */
export const dismissModal = () => (dispatch, getState) => {
  dispatch(createAction(SET_MODAL_DATA)());
};
/**
 * Modal 데이터 수정
 */
export const handleModalData = (blockId, button) => (dispatch, getState) => {
  const { chatList } = getState().OrderChatModule;
  const index = _.findIndex(chatList, { blockId });
  if (index > -1) {
    const { data } = button;
    if (data.key && data.value) {
      const block = _.cloneDeep(chatList[index]);
      const buttonIndex = _.findIndex(block.buttons || [], o => {
        return o && o.data && o.data.key === data.key;
      });

      console.log('buttonIndex', buttonIndex);
      console.log('block', block);

      if (buttonIndex > -1) {
        block.buttons[buttonIndex] = button;
      }
      chatList[index] = block;
      dispatch(createAction(SET_CHAT_LIST)(chatList));
      dispatch(addDataListViaObject(data));
    }
  }
};

export const pressNotice = action => (dispatch, getState) => {
  /** 2020. 02. 20 현재 버전에서는 아래 내용 밖에 없음
  {
    "action" : {
      "type" : "web",
      "webURL" : "https://www.notion.so/washswat/a709235273a74851bb0a01b71c3b1650"
    }
  }
   **/
  const { type, openPage, webURL } = action;
  if (type === 'web') {
    CommonUtils.navShowModalWebView({ url: webURL });
  } else if (type === 'modal') {
    /** We can call inneer components here **/
  }
};

export const setPickupTime = ({ pickup, blockList, dataList }) => (
  dispatch,
  getState,
) => {
  const initBlock = getInitBlock(pickup);
  dispatch(
    createAction(SET_INITCHAT)({
      initBlock,
      blockList,
      dataList,
    }),
  );
  dispatch(nextActionText(initBlock.blockId, initBlock));
};

export const addDataList = (data, text, images) => (dispatch, getState) => {
  const { chatList, dataList } = getState().OrderChatModule;
  const findIndex = _.findIndex(dataList, { key: data.key });
  if (findIndex > -1) {
    dataList[findIndex].value = text;
    if (images && images.length > 0) {
      dataList[findIndex].images = images;
      dataList[findIndex].wiredComponentIndex = chatList.length;
    }
  } else {
    const d = _.cloneDeep(data);
    d.value = text;
    if (images && images.length > 0) {
      d.images = images;
      d.wiredComponentIndex = chatList.length;
    }
    dataList.push(d);
  }
};

export const addDataListViaObject = data => (dispatch, getState) => {
  const { dataList } = getState().OrderChatModule;
  const findIndex = _.findIndex(dataList, { key: data.key });
  if (findIndex > -1) {
    dataList[findIndex] = data;
  } else {
    dataList.push(data);
  }
};

export const reset = () => (dispatch, getState) => {
  dispatch(createAction(RESET)());
};

export const backPressToggle = toggle => (dispatch, getState) => {
  dispatch(createAction(BACK_PRESS_OPEN)(toggle));
};

export const setFromTypeOfOrder = fromTypeOfOrder => (dispatch, getState) => {
  dispatch(createAction(SET_FROM_TYPE)({ fromTypeOfOrder }));
};

// reducer
const initialState = {
  isPending: false,
  chatList: [],
  dataList: [],
  BLOCK_LIST: [],
  backPressPopupOpen: false,
  orderId: undefined, // 여기 orderId가 있다는것은 주문이 완료됨. container didupdate에서 화면 전환 예정
  fromTypeOfOrder: '', // 주문 API 호출할 때, fromType으로 넣어줌
  dataSetForModal: null, // Modal 을 호출하는 데이터
};

export default handleActions(
  {
    [SET_MODAL_DATA]: (state, action) => {
      return {
        ...state,
        dataSetForModal: action.payload ? _.cloneDeep(action.payload) : null,
      };
    },
    [SET_CHAT_LIST]: (state, action) => {
      return {
        ...state,
        isPending: false,
        chatList: _.cloneDeep(action.payload),
      };
    },
    [SET_INITCHAT]: (state, action) => {
      const { initBlock, blockList, dataList } = action.payload;
      const nState = {
        ...state,
        isPending: false,
        chatList: [initBlock],
      };
      if (blockList && blockList.length > 0) {
        nState.BLOCK_LIST = blockList;
      }
      if (dataList && dataList.length > 0) {
        nState.dataList = dataList;
      }
      return nState;
    },
    [ORDER_COMPLETE]: (state, action) => {
      return {
        ...state,
        isPending: false,
        orderId: action.payload,
      };
    },
    [RESET]: (state, action) => {
      return _.cloneDeep(initialState);
    },
    [BACK_PRESS_OPEN]: (state, action) => {
      return {
        ...state,
        isPending: false,
        backPressPopupOpen: action.payload,
      };
    },
    [SET_FROM_TYPE]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },

    [HTTP_PENDING]: (state, action) => {
      const { isPending } = action.payload;
      return {
        ...state,
        isPending,
      };
    },
  },
  _.cloneDeep(initialState),
);
