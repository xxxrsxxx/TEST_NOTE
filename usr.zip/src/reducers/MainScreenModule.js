import { Platform } from 'react-native';
import appsFlyer from 'react-native-appsflyer';
import { ChannelIO } from 'react-native-channel-plugin';

import { createAction, handleActions } from 'redux-actions';
import { showOrderHistoryDetailScreen } from './OrderHistoryModule';
import { setFromTypeOfOrder } from './OrderChatModule';

import axios from 'axios';
import moment from 'moment';
import Url from 'url-parse';
import queryString from 'query-string';
import CryptoJS from 'crypto-js';

import { Favorite, MainScreenString } from '../utils/common/strings';
import WashAlert from '../utils/alert';
import {
  MAIN_API,
  COUPON_REGIST,
  GET_DELIVERY_DATETIME,
  GET_MAIN_V6,
  GET_MAIN_CONTENTS,
} from '../utils/type/server';
import * as CommonUtils from '../utils/common/index';
import * as Keys from '../utils/type/key';

import { _ } from '../plugins';

const SET_HTTP_PENDING = 'MainScreenModule/SET_HTTP_PENDING';
const SET_ORDER_PENDING = 'MainScreenModule/SET_ORDER_PENDING';
const GET_ASSET_PENDING = 'MainScreenModule/GET_ASSET_PENDING';
const GET_ASSET_SUCCESS = 'MainScreenModule/GET_ASSET_SUCCESS';
const GET_ASSET_FAILURE = 'MainScreenModule/GET_ASSET_FAILURE';
const POPUP_CLOSE = 'MainScreenModule/POPUP_CLOSE';
const SET_PICKUP = 'MainScreenModule/SET_PICKUP';
const SET_DELIVERY = 'MainScreenModule/SET_DELIVERY';
const ANY_ACIONS = 'MainScreenModule/ANY_ACIONS';
const INIT_MAIN = 'MainScreenModule/INIT_MAIN';
const SET_CONFIRM_DATA = 'MainScreenModule/SET_CONFIRM_DATA';
const ON_SCROLL_TOP_EVENT = 'MainScreenModule/ON_SCROLL_TOP_EVENT';
const OFF_SCROLL_TOP_EVENT = 'MainScreenModule/OFF_SCROLL_TOP_EVENT';
const SET_SUB_SCREEN_STATE = 'MainScreenModule/SET_SUB_SCREEN_STATE';
const SET_CONTENTS = 'MainScreenModule/SET_CONTENTS';
const ON_SCROLL_TOP_VISIBLE = 'MainScreenModule/ON_SCROLL_TOP_VISIBLE';
const OFF_SCROLL_TOP_VISIBLE = 'MainScreenModule/OFF_SCROLL_TOP_VISIBLE';

const setHttpPending = createAction(SET_HTTP_PENDING);
export const setOrderPending = createAction(SET_ORDER_PENDING);
const getAssetPending = createAction(GET_ASSET_PENDING);
const getAssetSuccess = createAction(GET_ASSET_SUCCESS);
const getAssetFailure = createAction(GET_ASSET_FAILURE);
const initMain = createAction(INIT_MAIN);
export const onScrollTopEvent = createAction(ON_SCROLL_TOP_EVENT);
export const offScrollTopEvent = createAction(OFF_SCROLL_TOP_EVENT);
export const setSubScreenState = createAction(SET_SUB_SCREEN_STATE);
const setContents = createAction(SET_CONTENTS);
export const onScrollTopVisible = createAction(ON_SCROLL_TOP_VISIBLE);
export const offScrollTopVisible = createAction(OFF_SCROLL_TOP_VISIBLE);

const secret_otu = 'WASHSECRET!!DEVIL##!(&*';

const getDecOTO = (enc, all = false) => {
  try {
    const n = new Date().getTime();

    // const decipher = crypto.createDecipher('aes-256-cbc', secret_otu);
    // let result = decipher.update(enc, 'base64', 'utf8'); // 암호화할문 (base64, utf8이 위의 cipher과 반대 순서입니다.)
    // result += decipher.final('utf8'); // 암호화할문장 (여기도 base64대신 utf8)

    let result = CryptoJS.AES.decrypt(decodeURI(enc), secret_otu).toString(
      CryptoJS.enc.Utf8,
    );
    // let result = CryptoJS.AES.decrypt(qs.unescape(enc), secret_otu).toString(CryptoJS.enc.Utf8);
    let data = JSON.parse(result) || {};

    if (all) {
      return data;
    }

    if (data && data.exp && data.orderId) {
      if (Number.parseInt(data.exp) < n) {
        return 0;
      }

      return data.orderId;
    }
  } catch (e) {
    return 0;
  }
};

// const setFromTypeOfOrder = (fromTypeOfOrder) => (dispatch, getState) => {
//   dispatch(createAction(ANY_ACIONS)({ fromTypeOfOrder }));
// };

/**
 * @description
 * 메인 컨펌창을 띄울때 사용. 모든 prop가 갖춰 졌을때 컨펌창을 띄우고, 아니면 컨펌을 닫는 액션
 * @param componentId
 * @param height {integer}
 * @param contentView {View}
 * @param leftButtonText {string}
 * @param rightButtonText {string}
 * @param onLeftButtonClicked {function}
 * @param onRightButtonClicked {function}
 * @param onClosed {function} 팝업이 닫혔을때
 * @return {function(...[*]=)}
 */
export const toggleConfirmDialog = (
  componentId,
  height,
  contentView,
  leftButtonText,
  rightButtonText,
  onLeftButtonClicked,
  onRightButtonClicked,
  onClosed,
) => async (dispatch, getState) => {
  if (componentId && height && contentView && onClosed) {
    dispatch(
      createAction(SET_CONFIRM_DATA)({
        componentId,
        height,
        contentView,
        leftButtonText,
        rightButtonText,
        onLeftButtonClicked,
        onRightButtonClicked,
        onClosed,
      }),
    );
  } else {
    dispatch(createAction(SET_CONFIRM_DATA)());
  }
};

export const handleDeepLinkUrl = ({ componentId, url }) => async (
  dispatch,
  getState,
) => {
  if (url) {
    const { protocol, host, query, pathname } = new Url(url);
    if (protocol) {
      if (Platform.OS === 'android') {
        appsFlyer.sendDeepLinkData(url);
      }
      if (protocol.indexOf('http') > -1) {
        switch (pathname) {
          case '/detail':
          case '/applink/delivery':
          case '/applink/receipt':
          case '/applink/app':
            const { orderId } = queryString.parse(query);
            const decOrderId = getDecOTO(orderId);
            if (decOrderId) {
              showDetailPage({ componentId, orderId: decOrderId, dispatch });
            }
            break;
          case '/order':
          case '/order/':
            const { web } = queryString.parse(query);
            if (web) {
              dispatch(setFromTypeOfOrder(web));
              const { pickup } = getState().MainScreenModule;
              showOrderPage({ componentId, pickup });
            }
            break;
        }
      } else if (
        protocol.indexOf('kakao') > -1 ||
        protocol.indexOf('washios') > -1
      ) {
        console.log('handle', host, query);
        if (host && query) {
          const { inviteCode, invitecode, orderId } = queryString.parse(query);
          if (
            host.indexOf(Keys.KAKAO_LINK) > -1 &&
            (inviteCode || invitecode)
          ) {
            dispatch(
              setInviteAction({
                componentId,
                inviteCode: inviteCode || invitecode,
              }),
            );
          } else if (host === 'detail' && orderId) {
            showDetailPage({ componentId, orderId, dispatch });
          }
        }
      }
    }
    CommonUtils.deleteValue(Keys.DEEP_LINK_URL);
  }
};

const showOrderPage = ({ componentId, pickup }) => {
  if (pickup !== null) {
    CommonUtils.navPush({
      componentId,
      name: 'OrderChatScreen',
      gestures: null,
    });
  } else {
    return false;
  }
};

const showDetailPage = ({ componentId, orderId, dispatch }) => {
  dispatch(
    showOrderHistoryDetailScreen({
      componentId,
      orderId,
    }),
  );
};

export const setBadge = badge => (dispatch, getState) => {
  dispatch(createAction(ANY_ACIONS)({ badge: badge || 0 }));
};

const setInviteAction = ({ componentId, inviteCode }) => async (
  dispatch,
  getState,
) => {
  const uid = $_status.state.user.uid;
  dispatch(createAction(ANY_ACIONS)({ isPending: true }));

  return await $_axios
    .post(
      COUPON_REGIST,
      {},
      {
        uid,
        code: inviteCode,
        issueType: 'auto',
      },
    )
    .then(response => {
      dispatch(createAction(ANY_ACIONS)({ isPending: false }));
      const { code, message } = response.data;
      if (code == 200) {
        WashAlert.showAlertWithCallback(
          MainString.inviteOver,
          Favorite.ok,
          () => {
            CommonUtils.navPush({
              componentId,
              name: 'CouponMain',
            });
          },
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

const showChannelOfGetMainAPI = ({ callPlace, badge }) => {
  if (callPlace === 'PreviewContainer' || callPlace === 'MainScreen') {
    if (badge > 0) {
      ChannelIO.showMessenger();
    }
  }
};

export const getNewMainAPI = () => async (dispatch, getState) => {
  const _storage = await $_storage.get();

  const appsFlyer = _storage[Keys.APPS_FLYER_ID];
  let {
    uid,
    sector,
    accessToken,
    roadAddress,
    addressOthers,
    addressTitle,
  } = getState().StatusModule.user;
  const { nextPage, pageLimit } = getState().MainScreenModule.contentsData;

  if (!addressTitle || addressTitle === 'null') {
    addressTitle = 'HOME';
  }

  let isService = _storage[Keys.IS_SERVICE_CHECK];
  if (isNaN(parseInt(isService))) {
    isService = 0;
  } else {
    isService = 1;
  }
  const mainApi = $_axios.post(
    GET_MAIN_V6,
    {},
    { uid, sector, appsFlyer, os: Platform.OS },
  );
  const mainContentsApi = $_axios.get(GET_MAIN_CONTENTS, {
    page: 1,
    limit: pageLimit,
  });
  try {
    dispatch(getAssetPending());

    const mainResponse = await mainApi;
    const contentsResponse = await mainContentsApi;
    const fullAddress = `${roadAddress} ${addressOthers}`;
    const mainData = mainResponse.data;

    /** 1주일은 이 팝업을 안볼게요~ **/
    if (mainData && mainData.popup && mainData.popup.length) {
      let skipIndexList = [];
      for (let i = 0; i < mainData.popup.length; i++) {
        let popup = mainData.popup[i];
        if (popup._id) {
          let lastSeenDate = await CommonUtils.getValue(popup._id);
          // let lastSeenDate = null;
          // CommonUtils.deleteValue(popup._id);
          if (lastSeenDate) {
            let days = moment().diff(new Date(lastSeenDate), 'days');
            if (7 > days) {
              skipIndexList.push(i);
            }
          }
        }
      }
      let data = [];
      _.map(mainData.popup, (v, i) => {
        const pass = _.findIndex(skipIndexList, index => index === i);
        if (pass == -1) {
          data.push(v);
        }
      });
      mainData.popup = data;
    }
    if (mainResponse && mainResponse.data) {
      mainResponse.data.isService = isService;
      dispatch(
        initMain({
          mainData,
          contentsBoard: contentsResponse.data.contentsBoard,
          fullAddress,
          accessToken,
        }),
      );
      // mainResponse.data.popup = null;
      // dispatch(getAssetSuccess(mainResponse));
    }
  } catch (e) {
    console.log('Network error', e);
    dispatch(getAssetFailure());
  }
};

export const getContentsAPI = () => async (dispatch, getState) => {
  const { nextPage, pageLimit } = getState().MainScreenModule.contentsData;

  try {
    const contentsResponse = await $_axios.get(GET_MAIN_CONTENTS, {
      page: nextPage,
      limit: pageLimit,
    });
    const { contentsBoard } = contentsResponse.data;
    if (contentsBoard) {
      dispatch(
        setContents({
          nextPage,
          contentsBoard,
        }),
      );
    }
    // dispatch(setHttpPending({ isPending: false }));
  } catch (e) {
    console.log('Network error', e);
    dispatch(getAssetFailure());
  }
};

export const refreshPickup = () => async (dispatch, getState) => {
  dispatch(getAssetPending());
  const _storage = await $_storage.get();
  const uid = _storage[Keys.USER_ID];
  const sector = _storage[Keys.SECTOR];
  const appsFlyer = _storage[Keys.APPS_FLYER_ID];
  await $_axios
    .post(MAIN_API, {}, { uid, sector, appsFlyer, os: Platform.OS })
    .then(response => {
      const { pickupTime } = response.data;
      dispatch(createAction(SET_PICKUP)({ pickupTime }));
    })
    .catch(error => {
      if (error && error.response && error.response.data) {
        WashAlert.showAlert(
          error.response.data.title || Favorite.fail,
          Favorite.ok,
        );
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    });
};

export const goOrderChatScreen = componentId => async (dispatch, getState) => {
  dispatch(setOrderPending({ isOrderPending: true }));
  const { pickup } = getState().MainScreenModule;

  showOrderPage({ componentId, pickup });
  setTimeout(() => dispatch(setOrderPending({ isOrderPending: false })), 300);
};

export const setPopupDisable = popup => async (dispatch, getState) => {
  if (popup && popup.length) {
    _.map(popup, o => {
      const { _id } = o;
      $_storage.set(_id, new Date().toString());
    });
  }
  dispatch(popupClose());
};

export const popupClose = () => (dispatch, getState) => {
  dispatch(createAction(POPUP_CLOSE)());
};

export const setDeliveryDateTimeAPI = ({ pickup, midnight, orderId }) => async (
  dispatch,
  getState,
) => {
  let data;
  // console.log('setDeliveryDateTimeAPI', pickup, midnight, orderId);
  // const _storage = await $_storage.get();
  // const uid = _storage[Keys.USER_ID];
  // const centerId = _storage[Keys.CENTER_ID];
  const { uid, centerId } = $_status.state.user;
  let pickupTime = pickup && pickup.pickupTime ? pickup.pickupTime : null;
  data = {
    uid,
    centerId,
    orderId,
    pickupTime: pickupTime
      ? moment(new Date( pickupTime )).format('YYYY-MM-DD')
      : 'NoServiceArea',
    basic: true,
    midnight: midnight ? midnight : moment(new Date(pickupTime)).hour() === 0,
  };

  await $_axios
    .post(GET_DELIVERY_DATETIME, {}, data)
    .then(res => {
      const { code, message } = res.data;
      if (code === 200) {
        const { array } = res.data;
        if (array && array.length > 0) {
          dispatch(
            createAction(SET_DELIVERY)({
              deliveryTime: array && array.length ? array[0] : null,
            }),
          );
        }
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
        throw 'API response code no 200';
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

const initialState = {
  error: false,
  pending: false,
  isPending: false,
  isOrderPending: false,
  point: {},
  pickup: null,
  delivery: null,
  deliveryDay: '',
  popup: null,
  badge: 0,
  banner: [],
  FAQs: null,
  isService: 1,
  lat: null,
  lon: null,
  fullAddress: '',
  addressTitle: '',
  fromTypeOfOrder: '', // 주문 API 호출할 때, fromType으로 넣어줌
  mainData: {
    pickupTime: {},
    currentOrder: [],
    appMenuConfig: {
      main: [],
      sub: [],
    },
    appReview: [],
    isOrderDeadline: false,
  },
  contentsData: {
    contentsBoard: [],
    nextPage: 1,
    pageLimit: 5,
  },
  confirmDialogData: null,
  isComplete: false,
  isScrollTopEvent: false,
  subScreenState: null, // popup, tooltip
  scrollTopVisible: false,
};

export default handleActions(
  {
    [SET_HTTP_PENDING]: (state, action) => {
      const { isPending } = action.payload;

      return {
        ...state,
        isPending,
      };
    },
    [SET_ORDER_PENDING]: (state, action) => {
      const { isOrderPending } = action.payload;
      return {
        ...state,
        isOrderPending,
      };
    },
    [GET_ASSET_PENDING]: (state, action) => {
      return {
        ...state,
        pending: true,
        error: false,
      };
    },
    [SET_CONFIRM_DATA]: (state, action) => {
      const { payload } = action;
      let confirmDialogData = null;
      if (payload) {
        confirmDialogData = _.cloneDeep(payload);
      }
      return {
        ...state,
        confirmDialogData,
      };
    },

    [GET_ASSET_SUCCESS]: (state, action) => {
      const {
        assets,
        pickupTime,
        popup,
        banner,
        FAQs,
        addressTitle,
        lat,
        lon,
        isService,
      } = action.payload.data;
      /** 배달지역이 아닌 경우 => pickupTime = null  */
      let pickup = null;

      if (pickupTime !== null) {
        pickup = {
          pickupTime: null,
          endTime: null,
        };

        if (pickupTime && pickupTime.slots && pickupTime.slots.length > 0) {
          const { day, slots } = pickupTime;
          const { start, end } = slots[0];
          pickup.pickupTime = moment(new Date(day))
            .hour(start)
            .toDate();
          pickup.endTime = moment(new Date(day))
            .hour(end)
            .toDate();
        }
      }

      return {
        ...state,
        pickup: _.cloneDeep(pickup || {}),
        pending: false,
        error: false,
        popup: popup ? _.cloneDeep(popup) : null,
        banner,
        FAQs,
        isService,
      };
    },
    [GET_ASSET_FAILURE]: (state, action) => {
      const { title } = action.payload.data;
      return {
        ...state,
        pending: false,
        error: true,
        errorMessage: title,
      };
    },
    [Keys.GLOBAL_KEY_SET_PICKUP_TIME]: (state, action) => {
      const { pickup } = action.payload;
      return {
        ...state,
        pending: false,
        pickup: _.cloneDeep(pickup),
      };
    },
    [ANY_ACIONS]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [POPUP_CLOSE]: (state, action) => {
      const { mainData } = state;
      mainData.popup = null;
      return {
        ...state,
        mainData: {
          ...state.mainData,
          popup: null,
        },
        // mainData: _.cloneDeep(mainData),
      };
    },
    [SET_PICKUP]: (state, action) => {
      const { pickupTime } = action.payload;
      let time = null;
      if (pickupTime !== null) {
        time = {
          pickupTime: null,
          endTime: null,
        };
        if (pickupTime && pickupTime.slots && pickupTime.slots.length > 0) {
          const { day, slots } = pickupTime;
          const { start, end } = slots[0];
          time.pickupTime = moment(new Date(day))
            .hour(start)
            .toDate();
          time.endTime = moment(new Date(day))
            .hour(end)
            .toDate();
        }
      }

      return {
        ...state,
        pickup: time,
        pending: false,
        error: false,
      };
    },
    [SET_DELIVERY]: (state, action) => {
      const { deliveryTime } = action.payload;
      let time = null;
      if (deliveryTime !== null) {
        time = {
          deliveryTime: null,
          endTime: null,
        };
        if (
          deliveryTime &&
          deliveryTime.slots &&
          deliveryTime.slots.length > 0
        ) {
          const { day, slots } = deliveryTime;
          const { start, end } = slots[0];
          time.deliveryTime = moment(new Date(day))
            .hour(start)
            .toDate();
          time.endTime = moment(new Date(day))
            .hour(end)
            .toDate();
        }
      }
      return {
        ...state,
        delivery: time,
        deliveryDay: `${moment(time.endTime).format('ddd')}`,
        pending: false,
        error: false,
      };
    },
    [INIT_MAIN]: (state, action) => {
      const {
        fullAddress,
        accessToken,
        mainData,
        isService,
        popup,
      } = action.payload;
      const { pickupTime } = mainData;
      let pickup = null;

      if (pickupTime !== null) {
        pickup = {
          pickupTime: null,
          endTime: null,
        };

        if (pickupTime && pickupTime.slots && pickupTime.slots.length > 0) {
          const { day, slots } = pickupTime;
          const { start, end } = slots[0];
          pickup.pickupTime = moment(new Date(day))
            .hour(start)
            .toDate();
          pickup.endTime = moment(new Date(day))
            .hour(end)
            .toDate();
        }
      }

      const isEqual = _.isEqual(state.mainData.appReview, mainData.appReview);
      if (isEqual) delete mainData.appReview;

      return {
        ...state,
        fullAddress,
        accessToken,
        mainData: {
          ...state.mainData,
          ...mainData,
        },
        contentsData: {
          ...state.contentsData,
          nextPage: 2,
          contentsBoard: action.payload.contentsBoard,
        },
        pickup: _.cloneDeep(pickup || {}),
        popup: popup ? _.cloneDeep(popup) : null,
        isService,
        error: false,
        pending: false,
      };
    },
    [ON_SCROLL_TOP_EVENT]: (state, action) => {
      return {
        ...state,
        isScrollTopEvent: true,
      };
    },
    [OFF_SCROLL_TOP_EVENT]: (state, action) => {
      return {
        ...state,
        isScrollTopEvent: false,
      };
    },
    [SET_SUB_SCREEN_STATE]: (state, action) => {
      return {
        ...state,
        subScreenState: action.payload,
      };
    },
    [SET_CONTENTS]: (state, action) => {
      const { contentsBoard, nextPage } = action.payload;
      return {
        ...state,
        contentsData: {
          ...state.contentsData,
          nextPage: nextPage + 1,
          contentsBoard: state.contentsData.contentsBoard.concat(contentsBoard),
        },
      };
    },
    [ON_SCROLL_TOP_VISIBLE]: (state, action) => {
      return {
        ...state,
        scrollTopVisible: true,
      };
    },
    [OFF_SCROLL_TOP_VISIBLE]: (state, action) => {
      return {
        ...state,
        scrollTopVisible: false,
      };
    },
  },
  initialState,
);
