import { handleActions, createAction } from 'redux-actions';

import { Navigation } from 'react-native-navigation';
import DeviceInfo from 'react-native-device-info';

import axios from 'axios';
import async from 'async';

import { getGlobalData } from './LoginModule';
import { getNewMainAPI } from './MainScreenModule';

import {
  mapString,
  Favorite,
  ChangeAddressStructure,
  AddressChangeString,
} from '../utils/common/strings';
import { globalDataSplit, navPush } from '../utils/common/index';
import * as ServerUtils from '../utils/type/server';
import * as Keys from '../utils/type/key';
import WashAlert from '../utils/alert';

import { _ } from '../plugins';

const SERVICE_PENDING = 'changeAddress/SERVICE_PENDING';
const SERVICE_ERROR = 'changeAddress/SERVICE_ERROR';

const INIT_ADDRESS = 'changeAddress/INIT_ADDRESS';
const INIT_CHAT = 'changeAddress/INIT_CHAT';
const SEARCH_LOCATION = 'changeAddress/SEARCH_LOCATION';
const HANDLE_INPUT_TEXT = 'changeAddress/HANDLE_INPUT_TEXT';
const SEND_PRESS = 'changeAddress/SEND_PRESS';
const FINISH_UPDATE = 'changeAddress/FINISH_UPDATE';
const BACK_PRESS = 'changeAddress/BACK_PRESS';

export const backPrsess = createAction(BACK_PRESS);
export const handleInputText = createAction(HANDLE_INPUT_TEXT);

//주소 리스트 불러오기
export const getLocation = ({ q }) => async dispatch => {
  if (!q) return;
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  return await $_axios
    .post(ServerUtils.LOCATION_SEARCH, {}, { q })
    .then(response => {
      const { code, count, result, data } = response.data;
      if (code == 200) {
        if (count) {
          dispatch(createAction(SEARCH_LOCATION)({ resultList: data }));
        } else {
          WashAlert.showAlert(mapString.noResult, Favorite.ok);
        }
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const addMyAddress = ({
  roadAddress,
  latitude,
  longitude,
  componentId,
}) => async (dispatch, getStore) => {
  dispatch(
    createAction(INIT_CHAT)({ roadAddress, latitude, longitude, componentId }),
  );
  const _storage = await $_storage.get();
  let name = _storage[Keys.USER_NAME];
  let phone = _storage[Keys.PHONE_NUMBER];

  const store = getStore();

  /** 하드코딩 **/
  var startIndex = 0;
  const chatStructure = ChangeAddressStructure;

  finalChatList({
    dispatch,
    chatArray: [],
    nextIndex: startIndex,
    store,
    chatStructure,
  });
  navPush({
    componentId,
    name: 'AddressChangeChat',
  });
};

export const changeMyAddress = (type, idx, componentId) => async (
  dispatch,
  getState,
) => {
  const uid = $_status.state.user.uid;
  const _url = ServerUtils.USER_ADDRESS_UPDATE.replace(':type', type);
  return await $_axios
    .post(_url, {}, { uid, idx })
    .then(response => {
      const { code, address, message } = response.data;
      if (code == 200) {
        const finded = _.find(address, { valid: 1 });
        if (finded && finded.title) {
          const { isService, doorCode } = finded;
          let copyAddress = address.filter(item => {
            return item.roadAddress != null;
          });
          if (doorCode) {
            $_storage.set(Keys.DOOR_CODE, doorCode);
          }

          async.waterfall(
            [
              callback => {
                console.log(
                  'Keys.IS_SERVICE_CHECK, String(isService)',
                  Keys.IS_SERVICE_CHECK,
                  String(isService),
                );
                $_storage.set(Keys.IS_SERVICE_CHECK, String(isService));
                dispatch(
                  createAction(Keys.ADDRESS_TITLE)({
                    addressTitle: finded.title,
                    userAddressList: copyAddress,
                    updating: true,
                  }),
                );
                if (type === 'delete') {
                  return;
                }
                callback();
              },
              callback => {
                const versionCode = DeviceInfo.getBuildNumber();
                dispatch(
                  getGlobalData({
                    uid,
                    versionCode,
                    callback: err => {
                      callback();
                    },
                  }),
                );
              },
              // callback => {
              //   dispatch(getPriceList());
              //   callback();
              // },
              callback => {
                dispatch(
                  getNewMainAPI(),
                  console.log('getNewMainAPI'),
                  // getMainAPI({ componentId, callPlace: 'ChangeAddressModule' }),
                );
                callback();
              },
              callback => {
                Navigation.popToRoot(componentId);
                callback();
              },
            ],
            err => {},
          );
        }
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const init = () => async (dispatch, getState) => {
  const uid = $_status.state.user.uid;
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

  return await $_axios
    .post(ServerUtils.USER_ADDRESS_LIST, {}, { uid })
    .then(response => {
      const { code, address } = response.data;
      if (code == 200) {
        let copyAddress = address.filter(item => {
          return item.roadAddress != null;
        });
        dispatch(createAction(INIT_ADDRESS)(copyAddress));
      } else {
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const sendPress = ({ key, nextIndex }) => async (dispatch, getStore) => {
  const store = getStore();

  var {
    chatParams,
    inputTextValueForConfirmScreen,
    chatArray,
  } = store.ChangeAddressModule;

  if (!inputTextValueForConfirmScreen) {
    if (
      chatArray[chatArray.length - 1] &&
      chatArray[chatArray.length - 1].placeholder
    ) {
      WashAlert.showAlert(
        `${chatArray[chatArray.length - 1].placeholder}를 입력해주세요!`,
        Favorite.ok,
      );
      return;
    }
  }
  if (inputTextValueForConfirmScreen) {
    const regex = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]{1,4}(도|시|구)\s[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]{1,4}(동|면|리|로)/;
    if (regex.test(inputTextValueForConfirmScreen)) {
      // this.setState({ inputValue: '' });
      showAlert(AddressChangeString.unexpectedOtherAddress);
      return;
    }
  }

  if (!chatParams) {
    chatParams = {};
  }
  /** 나중에 서버 보낼 키 담고 **/
  chatParams[key] = inputTextValueForConfirmScreen;
  /** 답변이 끝났기 때문에 채팅에 있는 input은 빼버린다 **/

  const findIndex = _.findIndex(chatArray, { key });

  chatArray.splice(findIndex, 1);
  /** 답변한 메시지를 채팅에 넣는다 **/
  chatArray.push({
    type: 'right',
    array: [{ key, value: inputTextValueForConfirmScreen, background: true }],
  });
  finalChatList({ dispatch, chatArray, chatParams, nextIndex, store });
};

const finalChatList = async ({
  dispatch,
  chatArray,
  chatParams,
  nextIndex,
  store,
  chatStructure,
}) => {
  // const address = await getValue(Keys.ROADADDRESS);
  // const addressOthers = await getValue(Keys.ADDDRESSOTHERS);

  var permission = true;
  var { roadAddress } = store.ChangeAddressModule;

  if (!chatStructure) {
    chatStructure = store.ChangeAddressModule.chatStructure;
  }
  for (var i = nextIndex; i < chatStructure.length; i++) {
    const { type, logic } = chatStructure[i];
    if (type === 'left') {
      var row = chatStructure[i];

      _.map(row.array || [], o => {
        if (/\{roadAddress\}/.test(o.text)) {
          o.text = o.text.replace(/\{roadAddress\}/, roadAddress);
        }
        if (/\{addressOthers\}/.test(o.text)) {
          const { addressOthers } = chatParams;
          o.text = o.text.replace(/\{addressOthers\}/, addressOthers);
        }
      });
      chatArray.push(row);
    } else {
      if (permission) {
        /** 질문은 한개씩! 그니까 그냥 permission 만들고 질문 한개주면 닫는다 **/
        chatArray.push(chatStructure[i]);
        permission = false;
        break;
      }
    }
  }

  dispatch(
    createAction(SEND_PRESS)({
      chatArray,
      chatParams,
      chatStructure,
    }),
  );
};
export const buttonPress = ({ key, value, nextIndex }) => async (
  dispatch,
  getStore,
) => {
  const store = getStore();
  var { chatParams, chatArray, componentId } = store.ChangeAddressModule;

  if (key === 'final') {
    /** 마지막 접수 **/

    const { addressOthers, title } = chatParams;
    const { roadAddress, latitude, longitude } = store.ChangeAddressModule;
    const uid = $_status.state.user.uid;

    dispatch(createAction(SERVICE_PENDING)({ isPending: true }));

    await $_axios
      .post(
        ServerUtils.USER_ADDRESS_ADD,
        {},
        {
          uid,
          roadAddress,
          addressOthers,
          lat: latitude,
          lon: longitude,
          addressTitle: title,
        },
      )
      .then(response => {
        const { code, message, user } = response.data;
        if (code == 200) {
          async.waterfall(
            [
              callback => {
                $_storage.set(globalDataSplit(user));
                callback();
              },
              callback => {
                dispatch(
                  createAction(Keys.ADDRESS_TITLE)({ addressTitle: title }),
                );
                callback();
              },
              callback => {
                dispatch(
                  getNewMainAPI(),
                  // getMainAPI({ componentId, callPlace: 'ChangeAddressModule' }),
                );
                setTimeout(() => {
                  callback();
                }, 500);
              },
              callback => {
                setTimeout(() => {
                  Navigation.popToRoot(componentId);
                  callback();
                }, 100);
              },
            ],
            err => {
              dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
            },
          );

          // dispatch(createAction(Keys.ADDRESS_TITLE)({ addressTitle: title }));
        } else {
          dispatch(createAction(SERVICE_PENDING)({ isPending: false }));

          if (message) {
            WashAlert.showAlert(message, Favorite.ok);
          } else {
            WashAlert.showAlert(Favorite.fail, Favorite.ok);
          }
        }
      })
      .catch(err => {
        dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
        WashAlert.showAlert(Favorite.fail, Favorite.ok);
      });
  } else {
    /** 나중에 서버 보낼 키 담고 **/
    chatParams[key] = value;
    /** 버튼뷰를 빼버리고 파란뷰를 담는다 **/
    chatArray.splice(chatArray.length - 1, 1);
    /** 답변한 메시지를 채팅에 넣는다 **/
    chatArray.push({
      type: 'right',
      array: [{ key, value: value, background: true }],
    });
    finalChatList({ dispatch, chatArray, chatParams, nextIndex, store });
  }
};

const global = ({ uid, callback }) => dispatch => {
  dispatch(createAction(SERVICE_PENDING)({ isPending: true }));
  axios
    .post(ServerUtils.PATH_GLOBALDATA, { uid })
    .then(response => {
      const { code, user } = response.data;
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
      if (code == 200) {
        $_storage.set(globalDataSplit(user));
        if (callback) {
          callback();
        }
      }
    })
    .catch(err => {
      dispatch(createAction(SERVICE_PENDING)({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

const initialState = {
  userAddressList: [],
  resultList: [],
  chatArray: [],
  chatParams: {},
  inputTextValueForConfirmScreen: undefined,
  chatStructure: [], // chat 구조체
  roadAddress: undefined,
  latitude: undefined,
  longitude: undefined,
  isPending: false,
};

export default handleActions(
  {
    [INIT_ADDRESS]: (state, action) => {
      return {
        ...state,
        userAddressList: _.cloneDeep(action.payload),
        isPending: false,
      };
    },
    [Keys.ADDRESS_TITLE]: (state, action) => {
      const { userAddressList } = action.payload;
      if (userAddressList) {
        const { roadAddress, addressOthers } = _.find(userAddressList, {
          valid: 1,
        });
        return {
          ...state,
          userAddressList: _.cloneDeep(userAddressList),
          isPending: false,
        };
      }
    },

    [SERVICE_PENDING]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    [SEARCH_LOCATION]: (state, action) => {
      return {
        ...state,
        resultList: _.cloneDeep(action.payload.resultList),
        isPending: false,
      };
    },
    [INIT_CHAT]: (state, action) => {
      const { roadAddress, latitude, longitude, componentId } = action.payload;
      return {
        ...state,
        roadAddress,
        latitude,
        longitude,
        componentId,
        finished: false,
      };
    },

    [HANDLE_INPUT_TEXT]: (state, action) => {
      return {
        ...state,
        inputTextValueForConfirmScreen: action.payload,
      };
    },

    [SEND_PRESS]: (state, action) => {
      const { chatArray, chatParams, chatStructure } = action.payload;

      var params = {
        ...state,
        chatArray: _.cloneDeep(chatArray),
        chatParams: _.cloneDeep(chatParams),
        inputTextValueForConfirmScreen: ``,
      };
      if (chatStructure && chatStructure.length > 0) {
        params.chatStructure = _.cloneDeep(chatStructure);
      }
      return params;
    },
    [FINISH_UPDATE]: (state, action) => {
      const ss = _.cloneDeep(initialState);

      return ss;
    },
    [BACK_PRESS]: (state, action) => {
      return initialState;
    },
  },
  _.cloneDeep(initialState),
);
