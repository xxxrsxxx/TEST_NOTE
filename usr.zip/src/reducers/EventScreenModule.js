import { createAction, handleActions } from 'redux-actions';

import axios from 'axios';

import { GET_EVENT_PAGE } from '../utils/type/server';
import * as CommonUtils from '../utils/common/index';

import { _ } from '../plugins';

// action type
const GET_LOAD_BNR_API = 'EventScreenModule/GET_LOAD_BNR_API';
const DESTROY_BNR = 'EventScreenModule/DESTROY_BNR';
const SET_PENDING = 'EventScreenModule/SET_PENDING';

// crete action
const getLoadBnr = createAction(GET_LOAD_BNR_API);
const destroyBnr = createAction(DESTROY_BNR);
const setPending = createAction(SET_PENDING);

// dispatch function
export const getLoadBnrApi = () => async (dispatch, getState) => {
  let { bannerList } = getState().EventScreenModule;

  try {
    dispatch(pendingHandler(true));
    const result = await $_axios.get(GET_EVENT_PAGE, {
      page: bannerList.page + 1,
      limit: bannerList.limit,
    });

    const _data = result.data;
    const value = {
      ...bannerList,
      page: bannerList.page + 1,
      items:
        _data && _data.eventBoard
          ? bannerList.items.concat(_data.eventBoard)
          : bannerList.items,
    };
    if (!_data) {
      dispatch(pendingHandler(false));
      return; // 리스트 페이징 했을시 확인 필요
    }
    dispatch(
      getLoadBnr({
        value,
      }),
    );
    dispatch(pendingHandler(false));
  } catch (e) {
    dispatch(pendingHandler(false));
    throw e;
  }
};

export const destroyBnrData = () => async (dispatch, getState) => {
  const { bannerList } = initialState;
  dispatch(
    destroyBnr({
      bannerList,
    }),
  );
};

export const pendingHandler = value => async (dispatch, getState) => {
  dispatch(setPending({ isPending: value }));
};

const initialState = {
  isPending: false,
  bannerList: {
    page: 0,
    limit: 5,
    items: [],
  },
};
export default handleActions(
  {
    [GET_LOAD_BNR_API]: (state, action) => {
      const { payload } = action;
      return {
        ...state,
        bannerList: { ...payload.value },
      };
    },
    [DESTROY_BNR]: (state, action) => {
      const { payload } = action;
      return {
        ...state,
        bannerList: { ...payload.bannerList },
      };
    },
    [SET_PENDING]: (state, action) => {
      const { isPending } = action.payload;
      return {
        ...state,
        isPending,
      };
    },
  },
  initialState,
);
