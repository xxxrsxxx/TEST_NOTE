import { combineReducers } from 'redux';
import LoginModule from './LoginModule';
import StartOrderModule from './StartOrderModule';
import OrderRequestModule from './OrderRequestModule';
import OrderModule from './OrderModule';
import OrderHistoryModule from './OrderHistoryModule';
import MyPageModule from './MyPageModule';
import PriceListModule from './PriceListModule';
import RegularOrderModule from './RegularOrderModule';
import FeedbackModule from './FeedbackModule';
import PaymentModule from './PaymentModule';
import CoinModule from './CoinModule';
import SpecialCareModule from './SpecialCareModule';
import ChangeAddressModule from './ChangeAddressModule';
import OrderChatModule from './OrderChatModule';
import MainScreenModule from './MainScreenModule';
import DoorModule from './DoorModule';
import StatusModule from './StatusModule';
import PaymentViaCardModule from './PaymentViaCardModule';
import BuyBulletModule from './BuyBulletModule';
import AlbumModule from './AlbumModule';
import LoginQuestionModule from './LoginQuestionModule';
import EventScreenModule from './EventScreenModule';
import BottomTabModule from './BottomTabModule';
import WebviewModule from './WebviewModule';

const appReducers = combineReducers({
  LoginModule,
  StartOrderModule,
  OrderRequestModule,
  OrderModule,
  OrderHistoryModule,
  MyPageModule,
  PriceListModule,
  RegularOrderModule,
  FeedbackModule,
  PaymentModule,
  CoinModule,
  SpecialCareModule,
  ChangeAddressModule,
  OrderChatModule,
  MainScreenModule,
  DoorModule,
  StatusModule,
  PaymentViaCardModule,
  BuyBulletModule,
  AlbumModule,
  LoginQuestionModule,
  EventScreenModule,
  BottomTabModule,
  WebviewModule,
});

const reducers = (state, action) => {
  if (action.type === 'myPage/LOGOUT') {
    state = undefined;
  }

  return appReducers(state, action);
};

export default reducers;
