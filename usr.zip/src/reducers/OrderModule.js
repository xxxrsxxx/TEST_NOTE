import { Platform, Vibration } from 'react-native';
import { Navigation } from 'react-native-navigation';

import { createAction, handleActions } from 'redux-actions';

import moment from 'moment';

import * as ServerUtils from '../utils/type/server';
import * as KeyUtils from '../utils/type/key';
import {
  ConfirmOrderCompleteText,
  ConfirmOrderCompleteTextExpress,
  ConfirmOrderCompleteTextWeekly,
  Favorite,
  OrderChatText,
  OrderModuleString,
} from '../utils/common/strings';
import WashAlert from '../utils/alert';
import * as AnalyticsKey from '../utils/tagging/analytics/key';
import AnalyticsManager from '../utils/tagging/analytics';

import { onRefresh } from './OrderHistoryModule';

import { _ } from '../plugins';

moment.locale('ko');

// action constructor

const SET_PICKUP_DATETIME_LIST = 'order/SET_PICKUP_DATETIME_LIST';
const SELECT_PICKUP_DATE_TIME = 'order/SELECT_PICKUP_DATE_TIME';
const SET_PICKUP_LOCATE = 'order/SET_PICKUP_LOCATE';
const SET_DELIVERY_DATETIME_LIST = 'order/SET_DELIVERY_DATETIME_LIST';
const SELECT_DELIVERY_DATE_TIME = 'order/SELECT_DELIVERY_DATE_TIME';
const TOGGLE_PAY_TYPE = 'order/TOGGLE_PAY_TYPE';
const BACK_PRESS = 'order/BACK_PRESS';

const SET_ASSETS = 'order/SET_ASSETS';
const SELECT_COUPON = 'order/SELECT_COUPON';
const SELECT_POINT = 'order/SELECT_POINT';

const SET_WHERE_PICKUP = 'order/SET_WHERE_PICKUP';
const SET_OTHER_REQUEST_COMMENT = 'order/SET_OTHER_REQUEST_COMMENT';
const RESET_CHAT_STATUS = 'order/RESET_CHAT_STATUS';
const HTTP_PENDING = 'order/HTTP_PENDING';
const PURCHASE_COIN = 'order/PURCHASE_COIN';
const ORDER_CONFIRM_INPUT_CHAT = 'order/ORDER_CONFIRM_INPUT_CHAT';
// const CONFIRM_CHANGE_INPUT_TYPE = 'order/CONFIRM_CHANGE_INPUT_TYPE';
const COMMON_ENTRANCE_INFO = 'order/COMMON_ENTRANCE_INFO';
const INPUT_COMMON_ENTRANCE = 'order/INPUT_COMMON_ENTRANCE';
const HANDLE_INPUT_TEXT = 'order/HANDLE_INPUT_TEXT';
const SEND_PRESS = 'order/SEND_PRESS';
const ORDER_FINISH = 'order/ORDER_FINISH';
const UPDATE_TIME = 'order/UPDATE_TIME';

export const setPickupDateTime = createAction(SELECT_PICKUP_DATE_TIME);
export const setDeliveryType = createAction(SET_PICKUP_LOCATE);
export const setDeliveryDateTime = createAction(SELECT_DELIVERY_DATE_TIME);
export const setPickupStatusAndChatList = createAction(SET_WHERE_PICKUP);
export const purchasedCoin = createAction(PURCHASE_COIN);
export const setOtherRequestCommentAndChatList = createAction(
  SET_OTHER_REQUEST_COMMENT,
);
export const resetChatStatus = createAction(RESET_CHAT_STATUS);
export const backPrsess = createAction(BACK_PRESS);

export const setHttpPending = createAction(HTTP_PENDING);
export const togglePayType = createAction(TOGGLE_PAY_TYPE);
export const selectCoupon = createAction(SELECT_COUPON);
export const selectPoint = createAction(SELECT_POINT);

const setPickupDateTimeList = createAction(SET_PICKUP_DATETIME_LIST);
const setDeliveryDateTimeList = createAction(SET_DELIVERY_DATETIME_LIST);
const setAssets = createAction(SET_ASSETS);

// export const orderConfirmInputChat = createAction(ORDER_CONFIRM_INPUT_CHAT);
// export const changeComfirmInputType = createAction(CONFIRM_CHANGE_INPUT_TYPE);
// export const commonEntranceInfo = createAction(COMMON_ENTRANCE_INFO);
// export const inputCommonEntrance = createAction(INPUT_COMMON_ENTRANCE);
export const handleInputText = createAction(HANDLE_INPUT_TEXT);

const IS_TEST = true; // false 일 경우, globalData 사용
// const convertSelectDelType = {
//   'door' : '문 앞',
//   'box' : '무인택배함',
//   'security' : '경비실·택배실'
// }

export const changeTime = () => async (dispatch, getStore) => {
  const store = getStore();

  const { pickup, delivery } = store.OrderModule;
  var objectId;
  if (
    store.OrderHistoryModule.orderItem &&
    store.OrderHistoryModule.orderItem._id
  ) {
    objectId = store.OrderHistoryModule.orderItem._id;
  }
  var message;

  if (pickup.day && delivery.day) {
    /** 수거 배달시간 변경 **/
    const { pickupTime } = pickup;
    const { deliveryTime } = delivery;
    message = `
수거시간 ${moment(new Date(pickupTime)).format('MM/DD (ddd) HH:mm')}-${moment(
      new Date(pickup.endTime),
    ).format('HH:mm')}
배달시간 ${moment(new Date(deliveryTime)).format('MM/DD (ddd) HH:mm')}-${moment(
      new Date(delivery.endTime),
    ).format('HH:mm')}

시간을 변경할까요?`;
  } else if (delivery.day) {
    /** 배달시간 변경 **/
    const { deliveryTime } = delivery;
    message = `배달시간을 ${moment(new Date(deliveryTime)).format(
      'MM-DD (ddd) HH:mm',
    )}-${moment(new Date(delivery.endTime)).format('HH:mm')}
변경할까요?`;
  }
  if (objectId && message) {
    WashAlert.showConfirm(message, Favorite.yes, Favorite.no, () => {
      if (pickup.day) {
        dispatch(updateBoth({ pickup, delivery, objectId }));
      } else {
        /** 배달시간만 변경 **/
        dispatch(updateDeliveryTime({ delivery, objectId }));
      }
    });
  }
};
export const updateBoth = ({ pickup, delivery, objectId, callback }) => async (
  dispatch,
  getStore,
) => {
  dispatch(setHttpPending({ isPending: true }));
  await $_axios
    .post(
      ServerUtils.UPDATE_TIME_BOTH,
      {},
      {
        objectId,
        pickup: {
          type: 'ninja',
          pickupTime: new Date(pickup.pickupTime),
          endTime: new Date(pickup.endTime),
        },
        delivery: {
          type: 'ninja',
          deliveryTime: new Date(delivery.deliveryTime),
          endTime: new Date(delivery.endTime),
        },
      },
    )
    .then(res => {
      const { code, message } = res.data;
      if (code === 200) {
        if (callback) {
          callback();
        } else {
          dispatch(
            createAction(UPDATE_TIME)({
              finishUpdatePickupTime: true,
              isPending: false,
            }),
          );
        }
      } else {
        WashAlert.showAlert(message, Favorite.ok);
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const updatePickupTime = ({ pickup, objectId, callback }) => async (
  dispatch,
  getStore,
) => {
  dispatch(setHttpPending({ isPending: true }));
  await $_axios
    .post(
      ServerUtils.UPDATE_TIME_PICKUP,
      {},
      {
        objectId,
        pickup: {
          type: 'ninja',
          pickupTime: new Date(pickup.pickupTime),
          endTime: new Date(pickup.endTime),
        },
      },
    )
    .then(res => {
      const { code, message } = res.data;
      if (code === 200) {
        callback();
      } else {
        dispatch(setHttpPending({ isPending: false }));
        WashAlert.showAlert(message, Favorite.ok);
      }
    })
    .catch(err => {
      dispatch(setHttpPending({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const updateDeliveryTime = ({
  delivery,
  objectId,
  callback,
  failCallback,
}) => async (dispatch, getStore) => {
  dispatch(setHttpPending({ isPending: true }));
  await $_axios
    .post(
      ServerUtils.UPDATE_TIME_DELIVERY,
      {},
      {
        objectId,
        delivery: {
          type: 'ninja',
          deliveryTime: new Date(delivery.deliveryTime),
          endTime: new Date(delivery.endTime),
        },
      },
    )
    .then(res => {
      const { code, message } = res.data;
      if (code === 200) {
        callback();
      } else {
        dispatch(setHttpPending({ isPending: false }));
        failCallback();
        WashAlert.showAlert(message, Favorite.ok);
      }
    })
    .catch(err => {
      dispatch(setHttpPending({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

export const sendPress = ({ key, nextIndex }) => async (dispatch, getStore) => {
  const store = getStore();
  var {
    orderParams,
    inputTextValueForConfirmScreen,
    orderConfirmChatArr,
  } = store.OrderModule;

  if (!inputTextValueForConfirmScreen) {
    if (
      orderConfirmChatArr[orderConfirmChatArr.length - 1] &&
      orderConfirmChatArr[orderConfirmChatArr.length - 1].placeholder
    ) {
      WashAlert.showAlert(
        `${
          orderConfirmChatArr[orderConfirmChatArr.length - 1].placeholder
        }를 입력해주세요!`,
        Favorite.ok,
      );
      return;
    }
  }

  /** 나중에 서버 보낼 키 담고 **/
  orderParams[key] = inputTextValueForConfirmScreen;
  /** 답변이 끝났기 때문에 채팅에 있는 input은 빼버린다 **/
  const findIndex = _.findIndex(orderConfirmChatArr, { key });
  orderConfirmChatArr.splice(findIndex, 1);
  /** 답변한 메시지를 채팅에 넣는다 **/
  orderConfirmChatArr.push({
    type: 'right',
    array: [{ key, value: inputTextValueForConfirmScreen, background: true }],
  });
  finalChatList({
    dispatch,
    orderConfirmChatArr,
    orderParams,
    nextIndex,
    store,
  });
};
export const buttonPress = ({ key, value, nextIndex }) => async (
  dispatch,
  getStore,
) => {
  const store = getStore();
  if (key === 'final') {
    /** 마지막 접수 **/
    const { orderType } = store.OrderModule;
    if (orderType === 'weekly') {
      actionWeeklyOrder({ dispatch, store });
    } else if (orderType === 'classic') {
      actionClassicOrder({ dispatch, store });
    }
  } else {
    var { orderParams, orderConfirmChatArr } = store.OrderModule;
    /** 나중에 서버 보낼 키 담고 **/
    if (key === 'door' && value === '공동현관 출입정보 입력') {
      orderParams[key] = 'null';
    } else {
      orderParams[key] = value;
    }
    /** 버튼뷰를 빼버리고 파란뷰를 담는다 **/
    orderConfirmChatArr.splice(orderConfirmChatArr.length - 1, 1);
    /** 답변한 메시지를 채팅에 넣는다 **/
    orderConfirmChatArr.push({
      type: 'right',
      array: [{ key, value: value, background: true }],
    });
    finalChatList({
      dispatch,
      orderConfirmChatArr,
      orderParams,
      nextIndex,
      store,
    });
  }
};

const finalChatList = async ({
  dispatch,
  orderConfirmChatArr,
  orderParams,
  nextIndex,
  store,
  chatStructure,
  weekly,
}) => {
  const _storage = await $_storage.get();
  const address = _storage[KeyUtils.ROADADDRESS];
  const addressOthers = _storage[KeyUtils.ADDDRESSOTHERS];
  const userName = _storage[KeyUtils.USER_NAME];

  var permission = true;
  const {
    deliveryOptionArray,
    pickup: { pickupTime, endTime, where },
    delivery,
    orderParams: { door, startDateForWeekly },
  } = store.OrderModule;

  if (!chatStructure) {
    chatStructure = store.OrderModule.chatStructure;
  }
  for (var i = nextIndex; i < chatStructure.length; i++) {
    const { type, logic } = chatStructure[i];
    if (type === 'left') {
      var row = chatStructure[i];

      _.map(row.array || [], o => {
        if (/\{userName\}/.test(o.text)) {
          o.text = o.text.replace(/\{userName\}/, userName);
        }
        if (/\{pickupLocation\}/.test(o.text)) {
          const locate = where.locate || 'door';
          o.text = o.text.replace(
            /\{pickupLocation\}/,
            `${_.find(deliveryOptionArray, { key: locate }).text}`,
          );
        }
        if (/\{pickupTime\}/.test(o.text)) {
          o.text = o.text.replace(
            /\{pickupTime\}/,
            `수거 ${moment(new Date(pickupTime)).format(
              'M월 D일 (ddd) HH',
            )}-${moment(new Date(endTime)).format('HH')}시`,
          );
        }
        if (/\{deliveryTime\}/.test(o.text)) {
          o.text = o.text.replace(
            /\{deliveryTime\}/,
            `배달 ${moment(new Date(delivery.deliveryTime)).format(
              'M월 D일 (ddd) HH',
            )}-${moment(new Date(delivery.endTime)).format('HH')}시`,
          );
        }
        if (/\{address\}/.test(o.text)) {
          o.text = o.text.replace(/\{address\}/, `${address} ${addressOthers}`);
        }
        if (/\{door\}/.test(o.text)) {
          o.text = o.text.replace(/\{door\}/, door);
        }
        /** 정기주문 관련 **/
        if (/\{weeklyOption\}/.test(o.text)) {
          const {
            weekModalData,
            periodIndex,
            day,
            hour: { start, end },
            delivery,
          } = store.RegularOrderModule;
          const option = `${weekModalData[periodIndex].ko} ${moment()
            .weekday(day)
            .format('dddd')} ${start}-${end}시`;
          o.text = o.text.replace(/\{weeklyOption\}/, option);
        }

        if (/\{startDateForWeekly\}/.test(o.text)) {
          const m = moment(new Date(startDateForWeekly)).format(
            'YYYY-MM-DD (ddd)',
          );
          o.text = o.text.replace(/\{startDateForWeekly\}/, m);
        }
      });
      orderConfirmChatArr.push(row);
    } else {
      if (permission) {
        /** 질문은 한개씩! 그니까 그냥 permission 만들고 질문 한개주면 닫는다 **/
        if (logic) {
          // 채팅 데이터가 prigramically 하게 생겨야 할 경우 **/

          const { day, hour } = store.RegularOrderModule;
          if (logic === 'possibleWeeklyOrderDays') {
            /** 정기주문 날짜필요 **/
            var copy = _.cloneDeep(chatStructure[i]);
            const pickupStartTime = hour.start;
            copy.array = getSchedule(day, pickupStartTime);
            orderConfirmChatArr.push(copy);
          }
        } else {
          orderConfirmChatArr.push(chatStructure[i]);
        }
        permission = false;
        break;
      }
    }
  }

  dispatch(
    createAction(SEND_PRESS)({
      orderConfirmChatArr,
      orderParams,
      chatStructure,
      weekly,
    }),
  );
};

const actionClassicOrder = async ({ dispatch, store }) => {
  const _storage = await $_storage.get();
  const {
    orderParams: { door, name, bedding },
    pickup,
    delivery,
    paymentOption,
  } = store.OrderModule;

  let uid = _storage[KeyUtils.USER_ID];

  const body = {
    uid,
    pickup: {
      type: 'ninja',
      pickupTime: new Date(pickup.pickupTime),
      endTime: new Date(pickup.endTime),
      where: pickup.where,
    },
    delivery: {
      type: 'ninja',
      deliveryTime: new Date(delivery.deliveryTime),
      endTime: new Date(delivery.endTime),
      where: delivery.where,
    },
    preOptions: {
      payment: paymentOption,
    },
    bedding,
  };

  if (door && door != OrderModuleString.defaultDoorCode) {
    /** 기본이 아니라면 **/
    body.door = door;
  }
  if (name) {
    body.name = name;
  }

  const af_address = _storage[KeyUtils.USER_ADDRESS];
  const af_road_address = _storage[KeyUtils.USER_ROAD_ADDRESS];
  const af_detail_address = _storage[KeyUtils.USER_ADDRESS_OTHERS];
  const af_user_type = _storage[KeyUtils.USER_TYPE];

  dispatch(setHttpPending({ isPending: true }));
  await $_axios
    .post(ServerUtils.POST_CLASSIC_ORDER, {}, { body })
    .then(res => {
      const { code, orderId, message } = res.data;
      if (code === 200) {
        Vibration.vibrate([100]);
        dispatch(createAction(ORDER_FINISH)({ orderId, isPending: false }));
        setTimeout(() => {
          const payType = getPayType(paymentOption);
          const couponName = getCouponName(paymentOption);
          setAppsFlyerTrackEvent(
            orderId,
            uid,
            af_address,
            af_road_address,
            af_detail_address,
            af_user_type,
            payType,
            couponName,
          );
        }, 500);
      } else {
        dispatch(setHttpPending({ isPending: false }));
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }
      }
    })
    .catch(err => {
      dispatch(setHttpPending({ isPending: false }));
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
    });
};

const setAppsFlyerTrackEvent = (
  orderId,
  uid,
  af_address,
  af_road_address,
  af_detail_address,
  af_user_type,
  payType,
  couponName,
) => {
  AnalyticsManager.setAppsFlyerTrackEvent(AnalyticsKey.NAME_COMPLETE_ORDER, {
    af_order_id: orderId,
    af_uid: uid,
    af_address,
    af_road_address,
    af_detail_address,
    af_user_type,
    af_payment_method: payType,
    af_coupon_name: couponName,
  });
  AnalyticsManager.setAirbridgeTrackEvent(
    AnalyticsKey.NAME_COMPLETE_ORDER,
    Platform.OS,
    uid,
  );
};

const getPayType = paymentOption => {
  if (paymentOption !== undefined) {
    const payType = paymentOption.payType;
    if (payType !== undefined) {
      return payType;
    }
  }
};

const getCouponName = paymentOption => {
  if (paymentOption !== undefined) {
    const discount = paymentOption.discount;
    if (discount !== undefined) {
      const coupon = discount.coupon;
      if (coupon !== undefined && coupon.length > 0) {
        return coupon[0].name;
      }
    }
  }
  return '';
};

const actionWeeklyOrder = async ({ dispatch, store }) => {
  const { orderParams, paymentOption } = store.OrderModule;
  const {
    day,
    weekModalData,
    periodIndex,
    hour,
    delivery,
  } = store.RegularOrderModule;
  const period = weekModalData[periodIndex].key;
  const _storage = await $_storage.get();
  let uid = await _storage[KeyUtils.USER_ID];
  const { door, startDateForWeekly } = orderParams;
  if (startDateForWeekly) {
    const start = moment(new Date(startDateForWeekly)).format('YYYY-MM-DD');
    const af_address = await _storage[KeyUtils.USER_ADDRESS];
    const af_road_address = await _storage[KeyUtils.USER_ROAD_ADDRESS];
    const af_detail_address = await _storage[KeyUtils.USER_ADDRESS_OTHERS];
    const af_user_type = await _storage[KeyUtils.USER_TYPE];

    dispatch(setHttpPending({ isPending: true }));
    await $_axios
      .post(
        ServerUtils.POST_WEEKLY_ORDER,
        {},
        {
          period,
          start,
          pay: 'skip',
          delivery,
          day,
          uid,
          hour,
          startDateForWeekly,
          door: door === OrderModuleString.defaultDoorCode ? `` : door,
        },
      )
      .then(res => {
        const { code, message } = res.data;
        Vibration.vibrate([100]);

        if (code === 200) {
          dispatch(
            createAction(ORDER_FINISH)({ orderId: 'weekly', isPending: false }),
          );
          const payType = getPayType(paymentOption);
          const couponName = getCouponName(paymentOption);
          setAppsFlyerTrackEvent(
            orderId,
            uid,
            af_address,
            af_road_address,
            af_detail_address,
            af_user_type,
            payType,
            couponName,
          );
        } else {
          dispatch(createAction(PENDDING)({ isPending: false }));

          if (message) {
            WashAlert.showAlert(message, Favorite.ok);
            /** 서버에서 돌려주는 메시지 **/
          } else {
            WashAlert.showAlert(Favorite.fail, Favorite.ok);
          }
        }
      })
      .catch(err => {});
  }
};

export const initChat = weekly => async (dispatch, getStore) => {
  const _storage = await $_storage.get();
  let name = _storage[KeyUtils.USER_NAME];
  let phone = _storage[KeyUtils.PHONE_NUMBER];

  const store = getStore();
  const { orderParams, express } = store.OrderModule;
  const { door } = orderParams;

  /** 하드코딩 **/
  var startIndex = 2;
  if (!name || name === phone.slice(phone.length - 4, phone.length)) {
    startIndex = 0;
  } else {
    if (door && door != 'null') {
      startIndex = 5;
    } else {
      startIndex = 2;
    }
  }
  var chatStructure;
  if (weekly) {
    chatStructure = ConfirmOrderCompleteTextWeekly;
  } else {
    if (express) {
      chatStructure = ConfirmOrderCompleteTextExpress;
    } else {
      chatStructure = ConfirmOrderCompleteText;
    }
  }

  finalChatList({
    dispatch,
    orderConfirmChatArr: [],
    nextIndex: startIndex,
    store,
    chatStructure,
    weekly,
    orderParams,
  });
};

export const cancelOrder = ({
  objectId,
  reason,
  callback,
  componentId,
}) => async (dispatch, getState) => {
  const uid = await $_storage.get(KeyUtils.USER_ID);
  const refreshOrderHistory = () => {
    dispatch(onRefresh()); // OrderModule <=> OrderHistoryodule 순환참조. 리펙토링 필요. by charles
    Navigation.popToRoot(componentId);
  };
  if (reason) {
    dispatch(setHttpPending({ isPending: true }));

    await $_axios
      .post(ServerUtils.CANCEL_ORDER, {}, { objectId, reason })
      .then(res => {
        const { code, data, message } = res.data;
        Vibration.vibrate([100]);
        if (code === 200) {
          callback();
          AnalyticsManager.setAppsFlyerTrackEvent(
            AnalyticsKey.NAME_CANCEL_ORDER,
            {
              af_cancel_date: new Date(),
              af_cancel_reason: reason,
            },
          );
          AnalyticsManager.setAirbridgeTrackEvent(
            AnalyticsKey.NAME_CANCEL_ORDER,
            Platform.OS,
            uid,
          );
        } else {
          if (message) {
            WashAlert.showAlertWithCallback(
              message,
              Favorite.ok,
              refreshOrderHistory,
            );
            /** 서버에서 돌려주는 메시지 **/
          } else {
            WashAlert.showAlertWithCallback(
              Favorite.fail,
              Favorite.ok,
              refreshOrderHistory,
            );
          }
        }
        dispatch(setHttpPending({ isPending: false }));
      })
      .catch(err => {
        console.warn(err);
        dispatch(setHttpPending({ isPending: false }));
      });
  } else {
    WashAlert.showAlert(OrderModuleString.orderCancelError, Favorite.ok);
  }
};

// middleware
export const getPickupDateTimeAPI = ({
  basic,
  objectId,
  finishedActionWhenOrderComplete,
}) => async (dispatch, getStore) => {
  dispatch(setHttpPending({ isPending: true }));
  const _storage = await $_storage.get();
  let uid = _storage[KeyUtils.USER_ID];
  let centerId = _storage[KeyUtils.CENTER_ID];
  const userType = _storage[KeyUtils.USER_TYPE];
  const doorCode = _storage[KeyUtils.DOOR_CODE];
  let { pickup, orderParams } = getStore().OrderModule;
  await $_axios
    .post(ServerUtils.GET_PICKUP_DATETIME, {}, { uid, centerId, basic })
    .then(res => {
      const { code, message } = res.data;
      if (code === 200) {
        const pickupDateTimeItemList = res.data.array;
        const { day } = pickupDateTimeItemList[0];
        pickup.day = day;
        if (doorCode) {
          orderParams.door = doorCode;
        }
        dispatch(
          setPickupDateTimeList({
            isPending: false,
            pickupDateTimeItemList,
            pickup,
            basic,
            orderParams,
            objectId,
            finishedActionWhenOrderComplete,
            userType,
          }),
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }

        throw 'API response code no 200';
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(setHttpPending({ isPending: false }));
    });
};

export const getDeliveryDateTimeAPI = ({
  objectId,
  orderId,
  finishedActionWhenOrderComplete,
}) => async (dispatch, getStore) => {
  dispatch(setHttpPending({ isPending: true }));
  // const day = '2019-03-02'
  const {
    pickup: { day, pickupTime },
    // basic
  } = getStore().OrderModule;
  const basic = true;
  const _storage = await $_storage.get();
  let uid = _storage[KeyUtils.USER_ID];
  let centerId = _storage[KeyUtils.CENTER_ID];
  const userType = _storage[KeyUtils.USER_TYPE];

  let _data = {};

  if (orderId) {
    _data = { orderId };
  } else {
    _data = {
      uid,
      centerId,
      pickupTime: day,
      basic,
      midnight: moment(new Date(pickupTime)).hour() === 0 ? true : false,
    };
  }

  await $_axios
    .post(ServerUtils.GET_DELIVERY_DATETIME, {}, _data)
    .then(res => {
      const { code, message } = res.data;
      if (code === 200) {
        const { array } = res.data;

        dispatch(
          setDeliveryDateTimeList({
            isPending: false,
            deliveryArray: array,
            objectId,
            finishedActionWhenOrderComplete,
            userType,
          }),
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }

        throw 'API response code no 200';
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(setHttpPending({ isPending: false }));
    });
};

export const getAssetAPI = () => async dispatch => {
  dispatch(setHttpPending({ isPending: true }));

  let userId = await $_storage.get(KeyUtils.USER_ID);

  await $_axios
    .post(
      ServerUtils.GET_ASSETS,
      {},
      {
        uid: userId,
        point: true,
        coin: true,
        bill: true,
        coupon: true,
      },
    )
    .then(res => {
      const { code, message } = res.data;
      if (code === 200) {
        let assets = res.data.data;

        if (_.isEmpty(assets)) {
          assets = '';
          throw 'assets in null';
        }

        let couponAssetsItem = '';
        let pointAssetsItem = '';
        let coinAssetsItem = '';
        let cardAssetsItem = '';

        _.forEach(assets, (value, key) => {
          if (key === 'coupon') {
            couponAssetsItem = {
              couponList: value,
            };
          } else if (key === 'point') {
            pointAssetsItem = value;
          } else if (key === 'coin') {
            coinAssetsItem = value;
          } else if (key === 'bill') {
            cardAssetsItem = {
              cardList: value,
            };
          }
        });

        dispatch(
          setAssets({
            couponAssetsItem,
            pointAssetsItem,
            coinAssetsItem,
            cardAssetsItem,
            isSuccessAssetsAPI: true,
            isPending: false,
          }),
        );
      } else {
        if (message) {
          WashAlert.showAlert(message, Favorite.ok);
          /** 서버에서 돌려주는 메시지 **/
        } else {
          WashAlert.showAlert(Favorite.fail, Favorite.ok);
        }

        throw 'API response code no 200';
      }
    })
    .catch(err => {
      WashAlert.showAlert(Favorite.fail, Favorite.ok);
      dispatch(setHttpPending({ isPending: false }));
    });
};

// reducer
const initialState = {
  express: false,
  basic: false,
  pickupDateTimeItemList: [], // 수거시간 목록
  deliveryArray: [], // 배달시간 목록
  pickup: {
    // 수거 object
    day: null,
    pickupTime: null,
    endTime: null,
    where: { door: '', locate: '' },
  },
  delivery: {
    // 배달 object
    day: null,
    deliveryTime: null,
    endTime: null,
    where: { door: '', locate: '' },
  },
  couponAssetsItem: '', // 내가 가지고 있는 자신
  pointAssetsItem: '', // 내가 가지고 있는 자신
  coinAssetsItem: '', // 내가 가지고 있는 자신
  cardAssetsItem: '', // 내가 가지고 있는 자신
  paymentOption: {
    // 서버에 보내는 이번주문에 사용할 할인들
    discount: {
      coupon: [],
      point: 0,
    },
    payType: ``,
  },

  orderLastChatList: [
    OrderChatText.whereIsPickupChat,
    OrderChatText.whereIsPickupChoiceChat,
  ],
  // whereIsPickup: '', // status: direct | door
  // requestComment: '', // status: none | direct
  isPending: false,

  isSuccessAssetsAPI: false /** 쓰는지 확인 필요 **/,

  //@Edwin
  orderConfirmChatArr: [],
  orderParams: {},

  deliveryOptionArray: [
    {
      key: 'door',
      text: '문 앞',
      // alert: '모든 세탁이 완료되면 당일 저녁 20-24시에 문 앞에 배달'
    },
    {
      key: 'box',
      text: '무인택배함',
      // alert: '모든 세탁이 완료되면 알림을 받고 배달시간 예약'
    },
    {
      key: 'security',
      text: '경비실∙택배실',
      // alert: '예약시간까지 되는 것만 받고 남은 세탁물은 완성시 배달예약 (배달비 3,000원 추가)'
    },
    {
      key: 'meet',
      text: '직접 만나서',
      // alert: '예약시간까지 되는 것만 받고 남은 세탁물은 완성시 배달예약 (배달비 3,000원 추가)'
    },
  ],
  chatStructure: [], // chat 구조체
  orderType: 'classic', // 주문타입 classic || weekly,
  orderId: null,
  objectId: null, // objectId가 있는 경우는 시간 변경
  finishedActionWhenOrderComplete: null, // 주문이 끝나고 부르는 함수. 지금까지 나온 방법에서는 이게 최선인듯. 주문 끝나면 이함수를 부른다.
  finishUpdatePickupTime: false,
  finishUpdateDeliveryTime: false,
  userType: null,
};

export default handleActions(
  {
    [SELECT_PICKUP_DATE_TIME]: (state, action) => {
      // key: pickupDate | pickupTime
      const { day, start, end, key, express } = action.payload;

      var target = state[key];
      target.day = day;
      target[`${key}Time`] = moment(new Date(day))
        .hour(start)
        .toDate();
      target.endTime = moment(new Date(day))
        .hour(end)
        .toDate();
      let send = {
        ...state,
        [key]: _.cloneDeep(target),
      };
      if (start != 0 && express) {
        send.express = express;
      } else {
        send.express = false;
      }
      return send;
    },
    [SET_PICKUP_LOCATE]: (state, action) => {
      var { pickup } = state;
      pickup.where.locate = action.payload.value;
      return {
        ...state,
        pickup: _.cloneDeep(pickup),
      };
    },
    [SELECT_DELIVERY_DATE_TIME]: (state, action) => {
      // key: deliveryDate | deliveryTime
      return {
        ...state,
        [action.payload.key]: action.payload.value,
      };
    },
    [SET_ASSETS]: (state, action) => {
      const { paymentOption } = state;
      let send = {
        ...state,
        couponAssetsItem: action.payload.couponAssetsItem,
        pointAssetsItem: action.payload.pointAssetsItem,
        coinAssetsItem: action.payload.coinAssetsItem,
        cardAssetsItem: action.payload.cardAssetsItem,
        isSuccessAssetsAPI: action.payload.isSuccessAssetsAPI
          ? new Boolean(action.payload.isSuccessAssetsAPI)
          : false,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
      };
      var payType = '';
      if (action.payload.coinAssetsItem && action.payload.coinAssetsItem.coin) {
        payType = 'coin';
      } else if (
        action.payload.cardAssetsItem &&
        action.payload.cardAssetsItem.cardList &&
        action.payload.cardAssetsItem.cardList.length > 0
      ) {
        payType = 'bill';
      }
      if (payType) {
        paymentOption.payType = payType;
        send.paymentOption = _.cloneDeep(paymentOption);
      }
      return send;
    },
    [PURCHASE_COIN]: (state, action) => {
      const coin = action.payload;
      var { paymentOption, coinAssetsItem } = state;
      paymentOption.payType = 'coin';
      coinAssetsItem.coin = coin;
      return {
        ...state,
        paymentOption: _.cloneDeep(paymentOption),
        coinAssetsItem: _.cloneDeep(coinAssetsItem),
      };
    },
    [SELECT_COUPON]: (state, action) => {
      const coupon = action.payload;
      var { paymentOption, coinAssetsItem } = state;
      paymentOption.discount.coupon = coupon;
      return {
        ...state,
        paymentOption: _.cloneDeep(paymentOption),
      };
    },
    [SELECT_POINT]: (state, action) => {
      const point = action.payload;
      var { paymentOption, coinAssetsItem } = state;
      paymentOption.discount.point = point;
      return {
        ...state,
        paymentOption: _.cloneDeep(paymentOption),
      };
    },

    [TOGGLE_PAY_TYPE]: (state, action) => {
      //
      const { seg, key, value } = action.payload;
      var { paymentOption } = state;
      if (key && value) {
        paymentOption[seg][key] = value;
      } else if (!key && value) {
        paymentOption[seg] = value;
      }
      return {
        ...state,
        paymentOption: _.cloneDeep(paymentOption),
      };
    },

    [SET_WHERE_PICKUP]: (state, action) => {
      return {
        ...state,
        whereIsPickup: action.payload.pickupValue,
        orderLastChatList: action.payload.chatList,
      };
    },
    [SET_OTHER_REQUEST_COMMENT]: (state, action) => {
      return {
        ...state,
        requestComment: action.payload.requestCommentValue,
        orderLastChatList: action.payload.chatList,
      };
    },
    [RESET_CHAT_STATUS]: (state, action) => {
      return {
        ...state,
        whereIsPickup: '',
        requestComment: '',
        orderLastChatList: action.payload.chatList,
      };
    },
    [SET_PICKUP_DATETIME_LIST]: (state, action) => {
      return {
        ...state,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
        pickup: _.cloneDeep(action.payload.pickup),
        orderParams: _.cloneDeep(action.payload.orderParams),
        pickupDateTimeItemList: _.cloneDeep(
          action.payload.pickupDateTimeItemList,
        ),
        basic: action.payload.basic ? new Boolean(action.payload.basic) : false,
        objectId: action.payload.objectId,
        finishedActionWhenOrderComplete:
          action.payload.finishedActionWhenOrderComplete,
        userType: action.payload.userType,
      };
    },
    [SET_DELIVERY_DATETIME_LIST]: (state, action) => {
      const {
        objectId,
        finishedActionWhenOrderComplete,
        userType,
      } = action.payload;
      var { delivery } = state;

      const send = {
        ...state,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
        delivery: _.cloneDeep(delivery),
        deliveryArray: _.cloneDeep(action.payload.deliveryArray),
        userType,
      };
      if (state.objectId === undefined && objectId) {
        send.objectId = objectId;
      }

      if (finishedActionWhenOrderComplete) {
        send.finishedActionWhenOrderComplete = finishedActionWhenOrderComplete;
      }
      return send;
    },

    [HTTP_PENDING]: (state, action) => {
      return {
        ...state,
        isPending: action.payload.isPending
          ? new Boolean(action.payload.isPending)
          : false,
      };
    },

    [SEND_PRESS]: (state, action) => {
      const {
        orderConfirmChatArr,
        orderParams,
        chatStructure,
        weekly,
      } = action.payload;

      var params = {
        ...state,
        orderConfirmChatArr: _.cloneDeep(orderConfirmChatArr),
        orderParams: _.cloneDeep(orderParams),
        inputTextValueForConfirmScreen: ``,
      };
      if (chatStructure && chatStructure.length > 0) {
        params.chatStructure = _.cloneDeep(chatStructure);
      }
      if (weekly != undefined && weekly === true) {
        params.orderType = 'weekly';
      }
      return params;
    },

    [HANDLE_INPUT_TEXT]: (state, action) => {
      return {
        ...state,
        inputTextValueForConfirmScreen: action.payload,
      };
    },
    [BACK_PRESS]: (state, action) => {
      return initialState;
    },
    [ORDER_FINISH]: (state, action) => {
      const { orderId } = action.payload;
      return {
        ...state,
        orderId,
        isPending: false,
      };
    },
    [UPDATE_TIME]: (state, action) => {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
  _.cloneDeep(initialState),
);

function getSchedule(weekday, pickupStartTime) {
  var timeArray = [];
  var now = moment();
  if (now.weekday() > weekday) {
    var add = weekday - now.weekday() + 7;
  } else if (now.weekday() === weekday) {
    if (now.hour() >= 15) {
      /** 오늘 마감은 15시 **/
      var add = 7;
    } else {
      // 현재시간이 수거시간보다 2시간정도 여유가 있을 때, 당일 수거가능
      if (now.hour() + 2 < pickupStartTime) {
        var add = 0;
      } else {
        var add = 7;
      }
    }
  } else {
    var add = weekday - now.weekday();
  }
  now = now.add(add, 'day');
  for (var i = 0; i < 3; i++) {
    var a = 7;
    if (i === 0) {
      a = 0;
    }
    timeArray.push({
      key: 'startDateForWeekly',
      value: now.format('YYYY-MM-DD (ddd)'),
      nextIndex: 7,
    });
    now.add(1, 'week');
  }
  return timeArray;
}
