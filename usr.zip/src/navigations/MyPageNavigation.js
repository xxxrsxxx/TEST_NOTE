import CouponMain from '../screens/mypage/CouponMain.js';
import Announcement from '../screens/cs/Announcement.js';
import Settings from '../screens/setting/Settings.js';
import PaymentMethod from '../screens/payment/PaymentMethod.js';
import Faq from '../screens/cs/Faq.js';
import PhoneNumChange from '../screens/setting/PhoneNumChange.js';
import MembershipCancelReason from '../screens/membership/MembershipCancelReason.js';

import PaymentHistory from '../screens/membership/PaymentHistory.js';
import UserWithdrawal from '../screens/setting/UserWithdrawal.js';
import InviteScreen from '../screens/mypage/InviteScreen';
import { Navigation } from 'react-native-navigation';
import React from 'react';

export default function MyPageNavigation(Navigation, store, Provider) {
  Navigation.registerComponent(
    'CouponMain',
    () => props => (
      <Provider store={store}>
        <CouponMain {...props} />
      </Provider>
    ),
    () => CouponMain,
  );
  Navigation.registerComponent(
    'Announcement',
    () => props => (
      <Provider store={store}>
        <Announcement {...props} />
      </Provider>
    ),
    () => Announcement,
  );
  Navigation.registerComponent(
    'Settings',
    () => props => (
      <Provider store={store}>
        <Settings {...props} />
      </Provider>
    ),
    () => Settings,
  );
  Navigation.registerComponent(
    'PaymentMethod',
    () => props => (
      <Provider store={store}>
        <PaymentMethod {...props} />
      </Provider>
    ),
    () => PaymentMethod,
  );
  Navigation.registerComponent(
    'PhoneNumChange',
    () => props => (
      <Provider store={store}>
        <PhoneNumChange {...props} />
      </Provider>
    ),
    () => PhoneNumChange,
  );
  Navigation.registerComponent(
    'MembershipCancelReason',
    () => props => (
      <Provider store={store}>
        <MembershipCancelReason {...props} />
      </Provider>
    ),
    () => MembershipCancelReason,
  );

  Navigation.registerComponent(
    'Faq',
    () => props => (
      <Provider store={store}>
        <Faq {...props} />
      </Provider>
    ),
    () => Faq,
  );

  Navigation.registerComponent(
    'UserWithdrawal',
    () => props => (
      <Provider store={store}>
        <UserWithdrawal {...props} />
      </Provider>
    ),
    () => UserWithdrawal,
  );
  Navigation.registerComponent(
    'PaymentHistory',
    () => props => (
      <Provider store={store}>
        <PaymentHistory {...props} />
      </Provider>
    ),
    () => PaymentHistory,
  );
  Navigation.registerComponent(
    'InviteScreen',
    () => props => (
      <Provider store={store}>
        <InviteScreen {...props} />
      </Provider>
    ),
    () => InviteScreen,
  );
}
