import { Navigation } from 'react-native-navigation';
import { Provider } from 'react-redux';
import React from 'react';
import OrderHistoryScreen from '../screens/order/OrderHistoryScreen';
import OrderDetailScreen from '../screens/order/OrderDetailScreen';
import OrderCompleteScreen from '../screens/order/OrderCompleteScreen';
import PaymentViaCardScreen from '../screens/order/PaymentViaCardScreen';
import PointHistoryScreen from '../screens/mypage/PointHistoryScreen';
import BuyBulletScreen from '../screens/coin/BuyBulletScreen';
import BulletHistoryScreen from '../screens/coin/BulletHistoryScreen';
import AlbumScreen from '../screens/order/orderDetail/AlbumScreen';
import AlbumSwiperScreen from '../screens/order/orderDetail/AlbumSwiperScreen';

// 개편 버전
// MyPage MyPageScreen
import MyPageScreen from '../screens/mypage/MyPageScreen';
// WebViewScreen
import WebViewScreen from '../screens/webView/WebViewScreen';
// EventScreen
import EventPageScreen from '../screens/event/EventPageScreen';
// HomeScreen
import HomeScreen from '../screens/home/HomeScreen';
// MainScreen
import MainScreen from '../screens/main/MainScreen';

export default function ScreenNavigation(store, Provider) {
  Navigation.registerComponent(
    'MainScreen',
    () => props => (
      <Provider store={store}>
        <MainScreen {...props} />
      </Provider>
    ),
    () => MainScreen,
  );

  Navigation.registerComponent(
    'HomeScreen',
    () => props => (
      <Provider store={store}>
        <HomeScreen {...props} />
      </Provider>
    ),
    () => HomeScreen,
  );

  Navigation.registerComponent(
    'PaymentViaCardScreen',
    () => props => (
      <Provider store={store}>
        <PaymentViaCardScreen {...props} />
      </Provider>
    ),
    () => PaymentViaCardScreen,
  );

  Navigation.registerComponent(
    'OrderHistoryScreen',
    () => props => (
      <Provider store={store}>
        <OrderHistoryScreen {...props} />
      </Provider>
    ),
    () => OrderHistoryScreen,
  );

  Navigation.registerComponent(
    'OrderDetailScreen',
    () => props => (
      <Provider store={store}>
        <OrderDetailScreen {...props} />
      </Provider>
    ),
    () => OrderDetailScreen,
  );

  Navigation.registerComponent(
    'OrderCompleteScreen',
    () => props => (
      <Provider store={store}>
        <OrderCompleteScreen {...props} />
      </Provider>
    ),
    () => OrderCompleteScreen,
  );

  Navigation.registerComponent(
    'OrderCompleteScreen',
    () => props => (
      <Provider store={store}>
        <OrderCompleteScreen {...props} />
      </Provider>
    ),
    () => OrderCompleteScreen,
  );

  Navigation.registerComponent(
    'PointHistoryScreen',
    () => props => (
      <Provider store={store}>
        <PointHistoryScreen {...props} />
      </Provider>
    ),
    () => PointHistoryScreen,
  );

  Navigation.registerComponent(
    'BuyBulletScreen',
    () => props => (
      <Provider store={store}>
        <BuyBulletScreen {...props} />
      </Provider>
    ),
    () => BuyBulletScreen,
  );

  Navigation.registerComponent(
    'BulletHistoryScreen',
    () => props => (
      <Provider store={store}>
        <BulletHistoryScreen {...props} />
      </Provider>
    ),
    () => BulletHistoryScreen,
  );

  Navigation.registerComponent(
    'AlbumScreen',
    () => props => (
      <Provider store={store}>
        <AlbumScreen {...props} />
      </Provider>
    ),
    () => AlbumScreen,
  );

  Navigation.registerComponent(
    'AlbumSwiperScreen',
    () => props => (
      <Provider store={store}>
        <AlbumSwiperScreen {...props} />
      </Provider>
    ),
    () => AlbumSwiperScreen,
  );
  Navigation.registerComponent(
    'MyPageScreen',
    () => props => (
      <Provider store={store}>
        <MyPageScreen {...props} />
      </Provider>
    ),
    () => MyPageScreen,
  );
  Navigation.registerComponent(
    'WebViewScreen',
    () => props => (
      <Provider store={store}>
        <WebViewScreen {...props} />
      </Provider>
    ),
    () => WebViewScreen,
  );
  Navigation.registerComponent(
    'EventPageScreen',
    () => props => (
      <Provider store={store}>
        <EventPageScreen {...props} />
      </Provider>
    ),
    () => EventPageScreen,
  );
}
