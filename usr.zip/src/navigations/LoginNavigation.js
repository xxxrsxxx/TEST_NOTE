import { Navigation } from 'react-native-navigation';

import LoginChat from '../screens/login/LoginChat';
import SignTerms from '../screens/login/SignTerms';
import AddressChat from '../screens/login/AddressChat';
import MapView from '../screens/login/MapView';
import Login from '../screens/login/Login';
import MissionComplete from '../screens/login/MissionComplete';
import SignUpComplete from '../screens/login/SignUpComplete';
import LoginQuestion from '../screens/login/LoginQuestion';
import LoginLastQuestion from '../screens/login/LoginLastQuestion';
import React from 'react';

export default function LoginNavigation(store, Provider) {
  Navigation.registerComponent(
    'Login',
    () => props => (
      <Provider store={store}>
        <Login {...props} />
      </Provider>
    ),
    () => Login,
  );
  Navigation.registerComponent(
    'MapView',
    () => props => (
      <Provider store={store}>
        <MapView {...props} />
      </Provider>
    ),
    () => MapView,
  );
  Navigation.registerComponent(
    'SignTerms',
    () => props => (
      <Provider store={store}>
        <SignTerms {...props} />
      </Provider>
    ),
    () => SignTerms,
  );
  Navigation.registerComponent(
    'AddressChat',
    () => props => (
      <Provider store={store}>
        <AddressChat {...props} />
      </Provider>
    ),
    () => AddressChat,
  );
  Navigation.registerComponent(
    'LoginChat',
    () => props => (
      <Provider store={store}>
        <LoginChat {...props} />
      </Provider>
    ),
    () => LoginChat,
  );
  Navigation.registerComponent(
    'MissionComplete',
    () => props => (
      <Provider store={store}>
        <MissionComplete {...props} />
      </Provider>
    ),
    () => MissionComplete,
  );
  Navigation.registerComponent(
    'SignUpComplete',
    () => props => (
      <Provider store={store}>
        <SignUpComplete {...props} />
      </Provider>
    ),
    () => SignUpComplete,
  );
  Navigation.registerComponent(
    'LoginQuestion',
    () => props => (
      <Provider store={store}>
        <LoginQuestion {...props} />
      </Provider>
    ),
    () => LoginQuestion,
  );
  Navigation.registerComponent(
    'LoginLastQuestion',
    () => props => (
      <Provider store={store}>
        <LoginLastQuestion {...props} />
      </Provider>
    ),
    () => LoginLastQuestion,
  );
}
