import { Navigation } from 'react-native-navigation';
import OrderHistoryPaymentContainer from '../containers/order/OrderHistoryPaymentContainer';
import WashPlanAfterOrder from '../containers/order/WashPlanAfterOrder';
import OrderInfoContainer from '../containers/order/OrderInfoContainer';
import PaymentRegistrationContainer from '../containers/order/PaymentRegistrationContainer';
import ImageMarkerContainer from '../containers/common/ImageMarkerContainer';
import AlbumContainer from '../containers/AlbumContainer';
import React from 'react';

export default function ContainerNavigation(store, Provider) {
  Navigation.registerComponent(
    'OrderHistoryPaymentContainer',
    () => (props) => (
      <Provider store={store}>
        <OrderHistoryPaymentContainer {...props} />
      </Provider>
    ),
    () => OrderHistoryPaymentContainer,
  );

  Navigation.registerComponent(
    'WashPlanAfterOrder',
    () => (props) => (
      <Provider store={store}>
        <WashPlanAfterOrder {...props} />
      </Provider>
    ),
    () => WashPlanAfterOrder,
  );
  Navigation.registerComponent(
    'OrderInfoContainer',
    () => (props) => (
      <Provider store={store}>
        <OrderInfoContainer {...props} />
      </Provider>
    ),
    () => OrderInfoContainer,
  );
  Navigation.registerComponent(
    'PaymentRegistrationContainer',
    () => (props) => (
      <Provider store={store}>
        <PaymentRegistrationContainer {...props} />
      </Provider>
    ),
    () => PaymentRegistrationContainer,
  );
  Navigation.registerComponent(
    'ImageMarkerContainer',
    () => (props) => (
      <Provider store={store}>
        <ImageMarkerContainer {...props} />
      </Provider>
    ),
    () => ImageMarkerContainer,
  );
  Navigation.registerComponent(
    'AlbumContainer',
    () => (props) => (
      <Provider store={store}>
        <AlbumContainer {...props} />
      </Provider>
    ),
    () => AlbumContainer,
  );
}
