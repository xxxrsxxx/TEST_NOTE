import { Navigation } from 'react-native-navigation';
import OrderChatScreen from '../screens/order/OrderChatScreen';
import OrderPickupScreen from '../screens/order/OrderPickupScreen';
import OrderDeliveryScreen from '../screens/order/OrderDeliveryScreen';
import OrderConfirmScreen from '../screens/order/OrderConfirmScreen';
import OrderPaymentScreen from '../screens/order/OrderPaymentScreen';
import React from 'react';

export default function OrderNavigation(store, Provider) {
  Navigation.registerComponent(
    'OrderChatScreen',
    () => props => (
      <Provider store={store}>
        <OrderChatScreen {...props} />
      </Provider>
    ),
    () => OrderChatScreen,
  );

  Navigation.registerComponent(
    'OrderPickupScreen',
    () => props => (
      <Provider store={store}>
        <OrderPickupScreen {...props} />
      </Provider>
    ),
    () => OrderPickupScreen,
  );

  Navigation.registerComponent(
    'OrderDeliveryScreen',
    () => props => (
      <Provider store={store}>
        <OrderDeliveryScreen {...props} />
      </Provider>
    ),
    () => OrderDeliveryScreen,
  );

  Navigation.registerComponent(
    'OrderConfirmScreen',
    () => props => (
      <Provider store={store}>
        <OrderConfirmScreen {...props} />
      </Provider>
    ),
    () => OrderConfirmScreen,
  );

  Navigation.registerComponent(
    'OrderPaymentScreen',
    () => props => (
      <Provider store={store}>
        <OrderPaymentScreen {...props} />
      </Provider>
    ),
    () => OrderPaymentScreen,
  );
}
