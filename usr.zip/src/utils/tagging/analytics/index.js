import appsFlyer from 'react-native-appsflyer';
import Mixpanel from 'react-native-mixpanel';
import AsyncStorage from '@react-native-community/async-storage';

import * as Keys from '../../type/key';

import * as AnalyticsKey from './key';

const APP_OPEN_COUNT = 'AppOpenCount';
const APP_ORDER_COUNT = 'OrderCount';

class AnalyticsManager {
  constructor() {
    this.initAppsFlyer();
  }

  /**
   * 초기화
   */
  initAppsFlyer = () => {
    let MIXPANEL_TOKEN = '338bdd07ced8c02d9409dcd99858e291';
    let GOOGLE_SENDER_ID = '1085975131826';
    let APPS_FLYER_DEV_KEY = 'aHdXswC7ZFZNHajhK28XZL';
    let AIR_BRIDGE_TOKEN = '648e5c7ab4e14c13bc2e508866c122e3';
    if (__DEV__) {
      MIXPANEL_TOKEN = '0000000000d8c02d9409dcd99858e291';
      GOOGLE_SENDER_ID = '000000000000';
      APPS_FLYER_DEV_KEY = '0000007ZFZNHajhK28XZL';
      AIR_BRIDGE_TOKEN = '648e5c7ab4e14c13bc2e508866c122e3';
    }
    // appsFlyer
    const options = {
      devKey: APPS_FLYER_DEV_KEY,
      isDebug: false,
      appId: '1049236217',
      onInstallConversionDataListener: true, //Optional
      onDeepLinkListener: true, //Optional
    };

    appsFlyer.initSdk(
      options,
      result => {
        appsFlyer.getAppsFlyerUID((error, appsFlyerUID) => {
          if (error) {
            console.error('appsFlyer.initSdk() - error:', error);
          } else {
            if (appsFlyerUID) {
              AsyncStorage.setItem(Keys.APPS_FLYER_ID, appsFlyerUID);
            }
          }
        });
      },
      error => {
        console.error(`appsFlyer initAppsFlyer() error: ${error}`);
      },
    );
    // mixpanel
    this.mixpanel = callback =>
      Mixpanel.sharedInstanceWithToken(MIXPANEL_TOKEN)
        .then(() => {
          callback();
        })
        .catch(error => {
          // ('Failed to initialize Mixpanel: ', error)
        });
    // airbridge
    // Airbridge.init('washswat', AIR_BRIDGE_TOKEN);
  };

  /**
   * 트래킹이벤트를 설정
   * @param {String} eventName
   * @param {Object} eventValues
   */
  setAppsFlyerTrackEvent = async (eventName, eventValues) => {
    // appsFlyer
    let trackFunc;
    if (appsFlyer) {
      if (appsFlyer.logEvent) {
        trackFunc = appsFlyer.logEvent;
      } else if (appsFlyer.trackEvent) {
        trackFunc = appsFlyer.trackEvent;
      }
    }
    if (!trackFunc) {
      return;
    }
    console.log('trackFunc', trackFunc);
    await trackFunc(
      eventName,
      eventValues,
      result => {},
      error => {},
    );
    // mixpanel
    this.mixpanel(() => {
      Mixpanel.track(eventName, eventValues);
      if (eventName === AnalyticsKey.NAME_COMPLETE_ORDER) {
        Mixpanel.increment(APP_ORDER_COUNT, 1);
      }
      if (eventName === AnalyticsKey.NAME_CANCEL_ORDER) {
        Mixpanel.increment(APP_ORDER_COUNT, -1);
      }
    });
  };

  setAirbridgeTrackEvent = (
    category,
    action,
    label,
    integerValue,
    eventObject,
  ) => {
    // if (category && action && label && integerValue && eventObject) {
    //   Airbridge.goal(category, action, label, integerValue, eventObject);
    // } else if (category && action && label && integerValue) {
    //   Airbridge.goal(category, action, label, integerValue, {});
    // } else if (category && action && label) {
    //   Airbridge.goal(category, action, label);
    // } else if (category && action) {
    //   Airbridge.goal(category, action);
    // }
  };

  setAlias = async (uid, created, callback) => {
    this.mixpanel(() => {
      Mixpanel.createAlias(uid + '');
      if (created) {
        Mixpanel.increment(APP_OPEN_COUNT, 1);
        Mixpanel.set({ $created: new Date().toISOString() });
      }
      setTimeout(() => {
        Mixpanel.flush();
        callback();
      }, 2000);
    });
    // Airbridge.signUp(Airbridge.makeUserObject({ userId: uid + '', userEmail: '' }));
  };

  /**
   *
   * @param {Object} user globaldata
   */
  setGlobal = async user => {
    this.mixpanel(() => {
      const { name, phone, userType, dong, isService, appPush, uid } = user;
      Mixpanel.identify(uid + '');
      Mixpanel.increment(APP_OPEN_COUNT, 1);
      const value = {
        $name: name,
        $phone: phone,
        userType,
        dong,
        isService,
        uid: uid + '',
        appPush: appPush ? true : false,
      };
      Mixpanel.set(value);
      // appsFlyer
      setTimeout(() => {
        appsFlyer.setCustomerUserId(uid + '', response => {});
      }, 1000);

      // Airbridge.signIn(Airbridge.makeUserObject({ userId: uid + '', userEmail: '' }));
    });
  };
}

export default new AnalyticsManager();
