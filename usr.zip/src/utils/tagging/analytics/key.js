// eventName - start
// export const AF_APP_OPEN = ''; // 앱오픈
// export const AF_APP_OPEN_DEEPLINK = ''; // 앱오픈 - 딥링크
export const NAME_COMPLETE_REGISTRATION = 'af_complete_registration'; // 회원가입
export const NAME_COMPLETE_ORDER = 'af_complete_order'; // 주문신청
export const NAME_CANCEL_ORDER = 'af_cancel_order'; // 주문취소
export const NAME_ADD_PAYMENT_INFO = 'af_add_payment_info'; // 결제수단추가
export const NAME_SEARCH = 'af_search'; // 품목 검색
export const NAME_PRICE_DETAIL = 'af_price_detail'; // 품목설명보기
export const NAME_PRICE = 'af_price'; // 가격표
export const NAME_VIEW_PROMOTION = 'af_view_promotion'; // 프로모션 보기
export const NAME_SIGN_UP_MEMBERSHIP = 'af_sign_up_membership'; // 멤버십 가입
export const NAME_SIGN_OUT_MEMBERSHIP = 'af_sign_out_membership'; // 멥버십 탈퇴
export const NAME_INVITE = 'af_invite'; // 친구초대 시도
export const NAME_REQUEST = 'af_request'; // 요청사항
export const NAME_ORDER_DETAIL = 'af_order_detail'; // 주문상세
export const NAME_ORDER_STATUS = 'af_order_status'; // 주문현황
export const NAME_FEEDBACK = 'af_feedback'; // 평점등록
export const NAME_REVIEW = 'af_review'; // 앱리뷰남기기
export const NAME_REGISTRATION_COUPON = 'af_registration_coupon'; // 쿠폰코드 등록
export const NAME_PUSH_SETTING = 'af_push_setting'; // 푸시알림 받기
export const NAME_SIGN_OUT = 'af_sign_out'; // 회원탈퇴
export const NAME_HOME_BANNER = 'af_home_banner'; // 배너 클릭
export const NAME_SIGN_UP_PHONE = 'af_sign_up_phone'; // 회원가입 번호인증
export const NAME_SIGN_UP_ADDRESS = 'af_sign_up_address'; // 회원가입 주소입력
export const NAME_START_SING_UP = 'af_start_sign_up'; // 회원가입 시작
export const NAME_BUY_FREE_TICKET = 'af_buy_free_ticket'; // 자유이용권
// eventName - end
