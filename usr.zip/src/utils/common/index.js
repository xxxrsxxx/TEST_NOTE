import React from 'react';
import { Linking, Platform, Text } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { Navigation } from 'react-native-navigation';
import { RNNDrawer } from 'react-native-navigation-drawer-extension';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import codePush from 'react-native-code-push';
import DeviceInfo from 'react-native-device-info';

// utils plugin
import { _, moment } from '../../plugins';
// utils styles
import { Font, Styles } from '../style';
const { washswatColor } = Font;

import { Favorite } from './strings';

// type import
import * as Keys from '../type/key';
import * as ServerUtils from '../type/server';

import WashAlert from '../alert';
import AnalyticsManager from '../../utils/tagging/analytics';

export async function setValue(key, value) {
  await AsyncStorage.setItem(key, value);
  $_debug.storageLog('SET');
  return true;
}

export async function getValue(key) {
  let result = await AsyncStorage.getItem(key);
  $_debug.storageLog('GET');
  return result;
}

export function getValueWithCallback(key, callback) {
  AsyncStorage.getItem(key, callback);
}

export function deleteValue(key) {
  AsyncStorage.removeItem(key);
}

export function multiSetValue(array) {
  AsyncStorage.multiSet(array);
}

export function multiGetValue(array) {
  return AsyncStorage.multiGet(array);
}

export const commentToSpan = comment => {
  var array = comment.split(`\n`);
  const views = [];
  for (var idx = 0; idx < array.length; idx++) {
    const elem = array[idx];
    if (idx === 0) {
      views.push(<Text style={{ overflowWrap: 'break-word' }}>{elem}</Text>);
    } else {
      if (elem === ``) {
        views.push(
          <Text style={{ padding: 1, overflowWrap: 'break-word' }}>{` `}</Text>,
        );
      } else {
        views.push(
          <Text style={{ marginTop: -3, overflowWrap: 'break-word' }}>
            {elem}
          </Text>,
        );
      }
    }
  }
  return views;
};

export async function allClear() {
  try {
    const keys = await AsyncStorage.getAllKeys();
    await AsyncStorage.multiRemove(keys);
  } catch (e) {
    console.log('allClear', e);
  }
  window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ && showAsyncStorageContentInDev();
}

export function globalDataSplit(gData) {
  /** 여러 데이터가 다들어오기 때문에 global데이터인지 확인한다 **/
  if (gData && gData.phone && gData.address) {
    /** 이정도면 globaldata가 맞다.**/
    AnalyticsManager.setGlobal(gData);
  }

  const gMap = new Map();
  const globalDataArr = [];

  Object.keys(gData).map((keyName, i) => {
    if (gData[keyName] === null || gData[keyName] === undefined) {
      gData[keyName] = 'null';
    }
    gMap.set(keyName, gData[keyName].toString());
  });

  for (let item of gMap) {
    globalDataArr.push(item);
  }
  return globalDataArr;
}

export const counter = joinTimer => {
  let remainTime = 300;
  setInterval(function() {
    let miniutes = Math.floor(remainTime / 60);
    let seconds = Math.floor(remainTime % 60);
    let timer = moment()
      .set('minute', miniutes)
      .set('second', seconds)
      .format('mm:ss');

    if (remainTime < 0) {
      clearInterval(tid);
    } else {
      remainTime -= 1;
      joinTimer({ timerCounter: timer });
    }
  }, 1000);
};

export const goLoginChat = componentId => {
  Navigation.push(componentId, {
    component: {
      name: 'LoginChat',
      options: {
        animations: {
          push: {
            ...Platform.select({
              android: {
                content: {
                  x: {
                    from: 0,
                    to: 0,
                    duration: 400,
                    interpolation: 'accelerate',
                  },
                  alpha: {
                    from: 0,
                    to: 1,
                    duration: 400,
                    interpolation: 'accelerate',
                  },
                },
              },
            }),
          },
        },
      },
    },
  });
};

export const setNavigationRoot = props => {
  let notification, coupon;
  if (props) {
    if (props.notification) {
      notification = props.notification;
    }
    if (props.coupon) {
      notification = props.coupon;
    }
  }

  Navigation.setDefaultOptions({
    statusBar: {
      visible: true,
      backgroundColor: washswatColor.white,
      style: 'dark',
    },
    topBar: {
      visible: false,
      drawBehind: true,
      animate: false,
    },
    layout: {
      backgroundColor: 'white',
      textColor: 'black',
    },
    bottomTabs: {
      visible: false,
      animate: false, // Controls whether BottomTabs visibility changes should be animated
      drawBehind: true,
      backgroundColor: 'white',
      barStyle: 'black',
    },
    animations: {
      setRoot: {
        enabled: 'true',
        alpha: {
          from: 0,
          to: 1,
          duration: 400,
          startDelay: 100,
          interpolation: 'accelerate',
        },
      },
      bottomTabs: {
        alpha: {
          from: 0,
          to: 1,
        },
      },

      push: {
        ...Platform.select({
          android: {
            content: {
              x: {
                from: 1000,
                to: 0,
                duration: 400,
                interpolation: 'accelerate',
              },
              alpha: {
                from: 0,
                to: 1,
                duration: 400,
                interpolation: 'accelerate',
              },
            },
          },
        }),
      },
      pop: {
        ...Platform.select({
          android: {
            content: {
              x: {
                from: 0,
                to: 1000,
                duration: 200,
                interpolation: 'accelerate',
              },
              alpha: {
                from: 1,
                to: 0,
                duration: 200,
                interpolation: 'accelerate',
              },
            },
          },
        }),
      },
    },
  });

  Navigation.setRoot({
    root: {
      stack: {
        children: [
          {
            component: {
              name: 'MainScreen', // MainScreen
              passProps: { notification },
            },
          },
        ],
      },
    },
  });
  /** 첫 가입시 **/
  if (coupon) {
    // if(true){
    setTimeout(() => {
      Navigation.showModal({
        stack: {
          children: [
            {
              component: {
                name: 'SignUpComplete',
                passProps: { coupon },
              },
            },
          ],
        },
      });
    }, 500);
  }
  /** OrderHistoryDetailScreen 중복 방지 **/
  deleteValue(Keys.ORDER_HISTROTY_DETAIL_ORDERID);
};

export const setRootLogin = () => {
  Navigation.setRoot({
    root: {
      id: 'Login',
      stack: {
        children: [
          {
            component: { name: 'Login' },
          },
        ],
      },
    },
  });
};

export function numberWithCommas(x) {
  if (x === undefined) {
    return;
  }
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * beforeHour 미만이면 true
 * @param {number} beforeHour
 */
export const isAutoPaymentTime = (deliveryTime, beforeHour) => {
  return (
    moment(new Date(deliveryTime)).startOf('day') > moment().startOf('day') ||
    (moment(new Date(deliveryTime))
      .startOf('day')
      .format('YYYYMMDD') ===
      moment()
        .startOf('day')
        .format('YYYYMMDD') &&
      moment().hour() < beforeHour)
  );
};

/**
 * http를 https로 변경한 url을 반환
 * @param {String} url
 */
export const replaceHttpToHttps = url => {
  if (!url.includes('http://')) {
    return url;
  }
  return url.replace('http://', 'https://');
};

export const goAppStore = () => {
  if (Platform.OS === 'ios') {
    Linking.openURL(
      'itms-apps://itunes.apple.com/us/app/itunes-u/id1049236217',
    );
  } else {
    Linking.openURL('market://details?id=com.washswat.android');
  }
};

export const getDaysDiffByYMD = ({ pickupYMD, deliveryYMD }) => {
  const p = moment(pickupYMD).startOf('day');
  const d = moment(deliveryYMD).startOf('day');
  return d.diff(p, 'days');
};

export const switchBottomTab = index => {
  Navigation.mergeOptions('BottomTabsId', {
    bottomTabs: {
      currentTabIndex: index,
    },
  });
};

// NaverPay전용
export const navShowModalWebViewNP = (data, finishedAction) => {
  Navigation.showModal({
    stack: {
      children: [
        {
          component: {
            name: 'PaymentViaCardScreen',
            passProps: {
              data,
              finishedAction: json => {
                const { code, message } = json;
                if (code === 200) {
                  finishedAction();
                } else {
                  if (message) {
                    WashAlert.showAlert(message, Favorite.ok);
                  } else {
                    /** 디폴트 메시지 **/
                    WashAlert.showAlert(Favorite.fail, Favorite.ok);
                  }
                }
              },
            },
          },
        },
      ],
    },
  });
};

export const navShowModalWebView = ({ url, video, data, finishedAction }) => {
  if (!url) {
    return;
  }
  Navigation.showModal({
    stack: {
      children: [
        {
          component: {
            name: 'WView',
            passProps: {
              url,
              video,
              finishedAction: json => {
                const { code, message } = json;
                if (code === 200) {
                  finishedAction();
                } else {
                  if (message) {
                    WashAlert.showAlert(message, Favorite.ok);
                  } else {
                    /** 디폴트 메시지 **/
                    WashAlert.showAlert(Favorite.fail, Favorite.ok);
                  }
                }
              },
            },
          },
        },
      ],
    },
  });
};

export const navShowModal = ({ name, passProps }) => {
  if (!name) {
    return;
  }
  Navigation.showModal({
    stack: {
      children: [
        {
          component: {
            name,
            passProps,
          },
        },
      ],
    },
  });
};
export const dismissModal = componentId => {
  if (!componentId) {
    return;
  }
  Navigation.dismissModal(componentId);
};

export const navShowModalPageSheet = async ({ name, passProps }) => {
  if (!name) {
    return;
  }
  Navigation.showModal({
    stack: {
      children: [
        {
          component: {
            name,
            passProps,
            options: {
              modalPresentationStyle: 'pageSheet',
              screenBackgroundColor: 'transparent',
            },
          },
        },
      ],
    },
  });
};

export const navPush = ({ componentId, name, passProps }) => {
  console.log('componentId : ', componentId);
  console.log('name : ', name);
  if (!componentId && !name) {
    return;
  }
  Navigation.push(componentId, {
    component: {
      name,
      passProps,
    },
  });
};

export const pop = componentId => {
  if (!componentId) {
    return;
  }

  Navigation.pop(componentId);
};

export const navStackRoot = ({ componentId, name, passProps }) => {
  Navigation.setStackRoot(componentId, [
    {
      component: {
        name,
        passProps,
        options: {
          animations: {
            setStackRoot: {
              enabled: true,
            },
          },
        },
      },
    },
  ]);
};

export const convertDayOfWeekForKorean = ({ number, dayOfWeeks }) => {
  let dayOfWeek = '';
  if (dayOfWeeks && dayOfWeeks.length > 0) {
    for (let i = 0; i < dayOfWeeks.length; i++) {
      if (i === number) {
        dayOfWeek = dayOfWeeks[i];
        break;
      }
    }
  }
  return dayOfWeek;
};

/*
sideMenu Control
*/

export const showSideMenu = componentId => {
  return RNNDrawer.showDrawer({
    component: {
      name: 'SideMenuScreen',
      passProps: {
        animationOpenTime: 400,
        animationCloseTime: Keys.DrawerAnimationCloseTime,
        direction: 'left',
        dismissWhenTouchOutside: true,
        fadeOpacity: 0.6,
        drawerScreenWidth: '73%',
        drawerScreenHeight: '100%',
        parentComponentId: componentId,
      },
      options: {
        layout: {
          backgroundColor: 'transparent',
        },
      },
    },
  });
};

export const closeSideMenu = () => {
  return RNNDrawer.dismissDrawer();
};

export const showAlert = message => {
  const content = message ? message : Favorite.fail;
  WashAlert.showAlert(content, Favorite.ok);
};

export const getKeyboardTopSpacing = () => {
  if (Platform.OS === 'android') {
    const devices = [
      'SM-G970', // 갤럭시 s10e
      'SM-G973', // 갤럭시 s10
      'SM-G975', // 갤럭시 s10+
      'SM-G977', // 갤럭시 s10 5g
      'SM-G981', // 갤럭시 s20
      'SM-G986', // 갤럭시 s20+
      'SM-G988', // 갤럭시 s20u
      'SM-N971', // 노트10
      'SM-N976', // 노트10+
    ];
    const found = devices.find(device =>
      DeviceInfo.getModel().startsWith(device),
    );

    if (found) {
      return getStatusBarHeight();
    }
  }
  return 0;
};
