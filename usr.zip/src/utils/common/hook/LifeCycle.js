import React, { useEffect, useState } from 'react';

function LifeCycle(props) {
  /**
   * @dsc 장착 됐을시 이벤트 처리를 위한 사용
   * @param cb:function
   */
  const mounted = cb => {
    useEffect(() => {
      cb();
    }, []);
  };
  /**
   * @dsc 장착 해제 됐을시 이벤트 처리를 위한 사용
   * @param cb:function
   */
  const unMounted = cb => {
    useEffect(() => {
      return () => {
        cb();
      };
    }, []);
  };

  return {
    mounted,
    unMounted,
  };
}

export default LifeCycle;
