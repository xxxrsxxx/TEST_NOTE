import { URL_USER_GUIDE } from '../../type/server';
import * as PageName from '../../../vo/PageName';

export const OnBoarding = {
  initialStart: '시작하기',
  videoComment: `세탁이 필요한\n모든 때`,
  skipText: '건너뛰기',
};

export const Favorite = {
  afternoon: '오후',
  cancel: '취소',
  close: '닫기',
  fail: '문제가 있어요! 다시 시도해주시겠어요?',
  blank: '내용을 채워주세요!',
  requiredImages: '완벽한 처리를 위해 사진을 보내주세요',
  morning: '오전',
  no: '아뇨',
  ok: '확인',
  won: '원',
  yes: '네!',
  completion: '완료',
  fee: '요금',
  yesterday: '어제',
  today: '오늘',
  tomorrow: '내일',
  am: '오전',
  pm: '오후',
  noon: '정오',
  midnight: '자정',
  dawn: '새벽',
  hour: '시',
  minute: '분',
  between: '사이',
  card: '카드',
  bullet: '총알',
  month: '월',
  day: '일',
};

export const EmojiText = {
  card: '💳',
};

export const UpdatePopupString = {
  updateHard:
    '앱의 안정성을 높인 새로운 버전이 출시되었습니다.\n업데이트 후 이용해주세요!',
  updateSelect:
    '앱의 안정성을 높인 최신 업데이트가 있습니다.\n스토어로 이동할까요?',
};
export const LoginString = {
  networkErrorModal:
    '서버와 연결할 수 없습니다.\n 네트워크 상태를 확인해주세요',
  networkErrorModalButton: '다시시도',
  codeErrorModal: '죄송합니다. 잠시 후에 다시시도 해주세요.',
  codeErrorModalButton: '다시시도',
};
export const mapString = {
  noResult: `주소가 이상해요! 정확한 주소로 검색해주시겠어요?`,
  validationAddress:
    '도로명 주소로 검색하거나 정확한 지번 주소를 입력해주세요.',
  inputPlaceholder: '지번, 도로명, 건물명 검색',
};

export const StartOrderShared = {
  stage: '단계',
  selection: '선택',
  charge: '충전',
  change: '변경',
  memberOnly: 'member only',
  dayOfWeekArray: [
    '일요일',
    '월요일',
    '화요일',
    '수요일',
    '목요일',
    '금요일',
    '토요일',
  ],
  eventEn: 'event',
  addCard: '카드 추가하기',
  close: '닫기',
};

export const OrderText = {
  order: '주문하기',
  pickup: '수거',
  receiptPublish: '인수증 발행',
  delivery: '배송',
  complete: '배송 완료',
  expected: '예정',
};

export const OrderCompleteText = {
  emoji: '🙌',
  title: '주문성공!',
};

export const DoorPassText = {
  title: '⚠️ 공동현관 출입정보가 정확한가요?',
  content:
    '을 선택하셨어요. 출입이 불가하거나 경비원 부재시 부득이하게 경비실에 배송하거나 이조차 여의치 않으면 철수합니다. 재배송시 배송비 3천원이 발생하는 점 참고 부탁드립니다.',
  button: '출입정보 변경하기',
};

export const OrderHistoryText = {
  progressOrder: '진행중인 주문',
  lastOrder: '지난 주문',
  deliverySearch: '배송조회',
  payment: '결제하기',
  paymentCompletion: '결제완료',
  writeReview: '💰 리뷰쓰기',
  emptyEmoji: '⚠️',
  emptyProgressOrder: '🤧\n빨래, 쌓아두지 말고\n오늘 세특을 불러보세요',
  emptyLastOrder: '지난 주문이 없습니다.',
  order: '세탁신청',
  emoji: '🗂',
  title: '주문목록',
  dayOfWeeks: ['일', '월', '화', '수', '목', '금', '토'],
  receiptTitle: '🧾 인수증 도착',
  receiptContent:
    '의류 5벌, 침구류 2개, 신발 1켤레 (이)가 있습니다. 결제하실 금액은 54,500원 입니다.',
  receiptButtonBeforePay: '결제하기 (할인수단 적용)',
  receiptButtonAfterPay: '인수증 보기',
  receiptExpectedTime: '오후 4시 전',
  payStatusLater: '결제대기중',
  payStatusAuto: '자동결제',
  payStatusFail: '결제실패',
  payStatusAdd: '추가금결제',
  payStatusRefund: '환불금',
  washStatusPickup: '수거중',
  washStatusWait: '검수중',
  washStatusIng: '세탁중',
  washStatusDelivery: '배송중',
  washStatusFail: '결제실패',
  washStatusOver: '배송완료',
  count: '개',
  orderCancel: '주문취소',
  deliveryReservation: '배송일을 예약해주세요',
  payPlz: '인수증에서 결제를 진행해주세요',
  notFoundOrder: '주문정보가 없습니다',
  submitReceiptEmail: '이메일 전송',
  submitReceiptMessage: '문자메시지 전송',
  submitReceipt: '영수증 전송',
  cancel: '취소',
  refundToPoint: '포인트로 환불할까요?',
  refundModal: '결제 내역에서 환불할까요? 영업일 기준 2-3일 소요될 수 있습니닷',
};

export const OrderHistoryProgressText = {
  orderDetail: '주문상세',
  pickupStatus: '주문완료',
  waitStatus: '검수중',
  overStatus: '배송완료',
  swat: '요원',
  pickupBag: '수거가방',
  washBeforePickup: '세탁물 수거전',
  washBeforeWait: '세탁물 검수중',
  scheduleChange: '일정변경',
  orderCancel: '주문취소',
  requestModification: '요청사항 수정',
  paymentFail:
    '⚠️ 결제 실패로 배송이 취소되었습니다.\n결제 후 배송일을 다시 예약해주세요.',
};

export const OrderHistoryStatusItemText = {
  pickupSchedule: '시 전 수거 예정',
  arriveSchedule: '시 전 배송 예정',
  overSchedule: '새벽 도착',
  undecidedTime: '배송일 재예약 필요',
};

export const StainCareText = {
  success: '얼룩케어 완료',
  fail: '얼룩케어 불가',
  refundExpect: '원 환불 예정',
  showVideo: '영상보기',
};

export const OrderInfoText = {
  title: '📋 주문정보',
  pickup: '**수거**',
  delivery: '**배송**',
  requestMatter: '**요청사항**',
};

export const PaymentRegistrationText = {
  title: '⚠️ 결제수단을 등록하세요',
  contentReady:
    '지금 선불총알을 구입하거나 카드를 등록하시면 더욱 편리하게 이용하실 수 있어요.',
  contentCheck: '배송일 오전까지 결제수단이 등록되지 않으면 배송이 취소됩니다.',
  contentRegistered:
    '해당 결제수단으로 배송일 오전에 결제될 예정입니다. 결제수단을 변경하시겠어요?',
  buttonRegistration: '결제수단 등록',
  buttonChange: '결제수단 변경',
  actionPay: '결제하기',
};

export const OrderHistoryPaymentText = {
  title: '💳 결제금액',
  washAmount: '세탁요금',
  itemExtra: '추가요금',
  totalPrice: '총 주문금액',
  couponDiscount: '쿠폰 할인',
  usePoint: '포인트 할인',
  membershipDiscount: '멤버십 할인',
  itemExtraExplain: '자세한 내용은 품목 아래의 🏷 설명을 참고해주세요',
  deliveryFee: '배송비',
  finalPaymentAmount: '최종 결제금액',
  actionPayment: '결제하기 (할인수단 적용)',
  actionSendReceipt: '영수증 전송 (카드결제내역)',
  paymentMethod: '결제수단',
  payAccount: '계좌이체',
  payBill: '카드',
  payCoin: '총알결제',
  payNaverPay: '네이버페이',
  refundAccount: '계좌 환불',
  refundBill: '카드 환불',
  refundCoin: '총알 환불',
  refundPoint: '포인트 환불',
  refundNaverPay: '네이버페이 환불',
  addPrice: '추가요금',
  refundPrice: '환불금액',
  refundReceiveCompletion: '환불 접수 완료',
  membershipBenefit: '멤버십 혜택 알아보기',
};

export const StartOrderPickup = {
  title: '언제 수거할까요?',
  modalContent:
    '고객님의 사생활 보호를 위해 문 앞에 수거배달합니다. 수거시 문 앞에 세탁물이 없으면 도어벨을 눌러 도착을 알립니다. 배달시 문고리에 걸고 즉시 사진을 보내드립니다.',
  eventTitle: '타임세일 이벤트',
  eventMessage: '반포자이 타임세일! 이불 전품목 1천원!',
  eventShow: '이벤트 보기',
};

export const StartOrderDelivery = {
  title: '언제 배달할까요?',
  modalExpressContent:
    '생활빨래, 기본 상·하의, 원피스, 가벼운 아우터 종류에 한해 익일배달이 가능합니다. 기타 품목이 있다면 완성시 연락드립니다. (세탁비 4만원 이상 추가배달비 무료)',
  modalContent:
    '**신발, 패딩, 수선은 3일이 소요됩니다.**이 다음날을 선택해주십시오. 세탁기간은 제품 종류와 상태에 따라 달라질 수 있습니다. 안전하고 꼼꼼하게 세탁하겠습니다.',
  modalExpressContent1: '급행비가 있습니다.',
  modalExpressContent2:
    '익일배달은 세탁비의 20% 할증요금 및 배달비 3천원이 추가됩니다. 멤버십 회원이라면 배달비는 무료입니다.',
  modalExpressContent3: 'event.',
  modalExpressContent4: '생활빨래 익일배달 무료',
  modalOk: 'ok',
  modalCancel: 'cancel',
};

export const OrderChat = {
  openCamera: '사진 촬영',
  openGallary: '앨범 선택',
  modalCancel: '닫기',
  permissionTitle: '권한이 필요해요',
  permission_android:
    '사진 촬영을 위해 카메라 권한을 허용해주세요\n\n어플리케이션 설정 > 권한 > 카메라/저장공간 권한 필요',
  permission_ios: '사진 촬영을 위해 카메라 권한을 허용해주세요!',
  inputPlaceHolder: '직접입력',
};

export const StartOrderConfirm = {
  title: '마지막 확인',
  orderInfoConfirm: '주문정보 확인',
  serviceItemTitle: '서비스 종류 선택',
  serviceItemSubTitle: '필요한 서비스를 모두 선택해주십시오.',
  serviceItemArray: [
    {
      key: 'dry',
      title: '드라이클리닝',
      subTitle: 'dry / wet cleaning',
      content:
        '제품의 종류와 상태에 따라 사전에 안내된 금액과 세탁기간이 상이해질 수 있습니다.',
      selected: false,
    },
    {
      key: 'washAndFold',
      title: '생활빨래',
      subTitle: 'wash & fold',
      content:
        '반드시 다른 세탁물과 분리하고 밀봉해 주십시오. 개봉 즉시 물세탁 · 열풍건조가 진행되오니 세탁법에 주의해 주십시오.',
      selected: false,
    },
    {
      key: 'bedding',
      title: '침구류',
      subTitle: 'bedding',
      content:
        '얼룩케어가 필요 없는 일반 침구류는 생활빨래로도 가능합니다. 생활빨래가 아닌 경우에만 선택해주세요.',
      selected: false,
    },
    {
      key: 'shoes',
      title: '신발',
      subTitle: 'shoes',
      content: '',
      selected: false,
    },
    {
      key: 'repair',
      title: '수선',
      subTitle: 'repair',
      content:
        '수선은 단독 서비스가 불가합니다. 수선 후 드라이클리닝이 진행되며 최소 3일이 소요됩니다.',
      selected: false,
    },
    {
      key: 'etc',
      title: '기타',
      subTitle: 'living, carpet, etc',
      content: '',
      selected: false,
    },
  ],
  washAndFoldHelp: {
    content:
      '생활빨래는 봉지에 담은 그대로 물세탁 · 열풍건조하는 물빨래 서비스입니다. 40L당 15,000원입니다.\n\n✔︎. 규격봉투가 없을 경우 일반 봉투에 담아주십시오. 요청사항에 설명을 작성해주시면 불필요한 연락을 줄일 수 있습니다.\n\n✔︎. 1봉지 1드럼으로 단독세탁합니다. 컬러를 구분해 세탁하기 원하시면 2개 봉지에 나누어 담아주십시오.\n\n✔︎. 얼룩제거와 다림질 작업은 포함되지 않습니다.\n\n✔︎.  물세탁/기계건조 불가 제품이나 오리/거위털 이불, 토퍼, 쿠션, 발매트, 패딩은 드라이클리닝으로 맡겨주십시오.',
    close: 'close',
  },
  doorTitle: '공동현관 출입정보',
  doorYes: '공동현관 출입가능',
  doorNo: '공동현관 출입불가',
  doorContent:
    '이 건물은 공동현관 출입제한이 없거나 경비원이 24시간 상주합니다. 출입 제한시 임의로 경비실에 배달할 수 있습니다.',
  doorPlaceholder: '출입 방법 입력 (예. #1234*)',
  doorInputPlz: '공동현관 출입정보를 입력해주세요.',
  paymentInfo: '결제정보',
  paymentTitle: '결제수단',
  // paymentSubTitle: '선불결제, 카드결제, 계좌이체',
  couponTitle: '쿠폰 적용',
  noCoupon: '쿠폰이 없어요!',
  pointTitle: '포인트 적용',
  noPoint: '포인트가 없어요!',
  // discountTitle: '할인수단 선택',
  // discountSubTitle: '쿠폰과 포인트',
  precautions: '주의사항',
  precautionsContent1:
    '최소주문금액은 14900원입니다. 세탁비가 14900원 미만이라도 14900원이 청구됩니다.\n\n',
  precautionsContent2:
    '예약시간 1시간 전까지 취소·변경이 가능합니다. 이후에는 취소 수수료 3천원이 발생합니다.\n\n',
  precautionsContent3:
    '케어라벨이 없거나, 세탁표기법상 드라이클리닝 및 물세탁이 모두 금지된 제품은 전문가가 소재와 상태를 확인 후 세탁합니다. 다만, 이때 세탁 결과에 대해서는 책임을 지지 않으니 유의해 주십시오.\n\n',
  precautionsContent4_1:
    '계속 진행하시면 유실물 처리방침, 세탁정책, 보상정책 등',
  precautionsContent4_2: '서비스 운영정책',
  precautionsContent4_3: '에 동의하시게 됩니다.',
  order: '주문하기',
};

export const StartOrderPayment = {
  title: '결제수단',
  bulletCharge: '총알 충전',
  bulletChargeExplain: '최대 7% 할인가로 선불권 구입',
  bulletPercent: 'up to 7%',
  bullet: '총알',
  balance: '잔액',
  simplePayment: '간편결제',
  simplePaymentExplain: '카드 등록하고 배달일 오전에 자동결제',
  card: '카드',
  cardExplain: '배달일 오전에 자동결제',
  accountTransfer: '계좌이체',
  accountTransferSub: '인수증 발급시 가상계좌로 직접 송금',
  singleCardPayment: '1회성 카드결제',
  singleCardPaymentSub: '인수증 발급시 카드번호 직접 입력',
  // virtualAccountTransfer: '가상계좌번호로 직접 송금',
  // cardRegist: '카드 등록하기',
  notice: 'notice.',
  noticeContent:
    '지금 결제가 진행되는 것이 아닙니다. 세탁물 수거 후 검수실에서 영상촬영을 마치면 결제금액이 확정됩니다. 이때 인수증을 보내드립니다.\n\n총알은 세탁특공대 전용 선불권입니다. 최대 7% 할인된 가격으로 구입하실 수 있습니다.\n\n카드를 등록하시면 배달일 오전에 자동으로 결제되어 편리합니다.\n\n익일배달은 총알 또는 등록된 카드로만 결제가 가능합니다.',
};

export const OrderAdvertise = {
  content: '생활빨래\n익일배달 무료',
};

export const OrderRequest = {
  requestSave: '요청사항을 저장할까요?',
  requestSuccess: '접수완료! 꼼꼼히 체크하겠습니닷',
  requests: [
    {
      type: 'pickup',
      title: '수거/배달에 관한 요청',
      secondTitle: '수거/배달 요청',
      placeholder: '배송요원에게 전달됩니다',
      content:
        '-. 배송요원은 택배처럼 정해진 동선에 따라 움직입니다. ‘9시까지’, ‘9시 쯤’ 과 같은 특정 시간을 맞추기 어렵습니다. 다음 고객님들을 위해 양해해 주시면 고맙겠습니다.',
      isRequest: false,
      detailRequests: [
        { type: 'bell', title: '도착하시면 벨을 눌러주세요', selected: false },
        { type: 'security', title: '경비실에 배달해주세요', selected: false },
        { type: 'message', title: '직접 작성하기', selected: false },
      ],
      message: '',
    },
    {
      type: 'premium',
      title: '프리미엄 요청 (명품세탁)',
      secondTitle: '프리미엄 요청',
      placeholder:
        '어떤 제품을 어떻게 도와드릴까요?\n(예. 굽찌 무늬가 없는 흰색 와이셔츠입니다.)',
      content:
        '-. 세심한 주의가 필요한 고가의 제품을 위한 명품세탁 서비스입니다. 프리미엄 가격이 적용됩니다.\n-. 구입가 100만원 이상, 구입시기 3년 미만의 제품은 프리미엄을 신청해주십시오.',
      isRequest: false,
      message: '',
      images: [],
    },
    {
      type: 'repair',
      title: '수선 요청',
      secondTitle: '수선 요청',
      placeholder:
        '어떤 제품을 어떻게 도와드릴까요?\n(예. 굽찌 무늬가 없는 흰색 와이셔츠입니다. 중앙 맨 밑 단추를 두번째 위치에 달아주세요.)',
      content:
        '-. 현재 단추달기, 바지 기장수선, 터진 라인을 따라 재박음질 같은 간단한 수선만 가능합니다.\n-. 단추나 후크 등 작은 부속품은 분실될 우려가 높습니다. 옷핀으로 해당 의류에 단단히 고정해 보내주십시오.\n-. 기장수선은 옷핀으로 정확하게 길이를 표시하거나 견본의류를 보내주시면 참고하여 작업합니다.',
      isRequest: false,
      message: '',
      images: [],
    },
    {
      type: 'etc',
      title: '기타 요청',
      secondTitle: '기타 요청',
      placeholder:
        '어떤 제품을 어떻게 도와드릴까요?\n(예. 굽찌 무늬가 없는 흰색 와이셔츠입니다.)',
      content: '',
      isRequest: false,
      message: '',
      images: [],
    },
  ],
};

export const CancelReasonString = {
  reason: '해지사유',
  notOften: '자주 맡기는 편이 아니라서',
  notBenefit: '내가 원하는 혜택이 없어서',
  tooExpensive: '멤버십 회원료가 비싸서',
  directInput: '직접 입력',
  complete: '완료',
};

export const MembershipInfoString = {
  monthBenefit: '이달의 혜택',
  payHistory: '결제내역',
  cancelMembership: '멤버십 해지',
  exitMembership: '멤버십 해지완료!\n멤버십은 언제든 다시 가입할 수 있습니닷:)',
  cancel: '해지하기',
  cancelMembershipModal:
    '정말로 멤버십을 해지하시겠어요?\n환불정책은 내프로필-> 자주묻는 질문에서 확인하실수 있습니닷',
  close: '닫기',
};

export const PresentFriendString = {
  presentForFriend: '초대쿠폰 선물하기',
};

export const MyPageString = {
  benefit: '혜택보기',
  benefitForCitizon: '멤버십 혜택보기',
  info: '멤버십 관리',
  couponBox: '쿠폰함',
  join: '멤버십 가입하기',
  freeTicket: '이용권 구매하기',
  memberUserFlag: '멤버십 이용중',
  basicUserFlag: 'Basic',
  myPoint: '포인트',
  notice: '공지사항',
  cardManage: '결제수단 관리',
  faq: ' FAQ 자주묻는질문',
  directAdvice: '1:1상담하기',
  setting: '설정',
  joinMember: '멤버십을 가입할까요?',
  joinMemberComplete: '멤버십 가입 완료.',
  buyCoin: '총알 구입하기',

  joinFreeTicket:
    '여름 한정 선착순 기획상품으로 환불이 어렵습니다.\n이용기간은 구입일로부터 30일까지입니다.\n\n초특가 자유이용권을 구매할까요?',
  joinFreeTicketComplete: '구매 완료.\n쿠폰함에서 등록된 쿠폰을 확인하세요!',

  mySwatMembershipNormal: { name: '멤버십 혜택보기', key: 'JoinMember' },
  mySwatMembershipMember: { name: '멤버십 관리', key: 'MembershipInfo' },
  deleteCard: '이 카드를 삭제할까요?',
  defaultCard: '이 카드를 대표카드로 등록할까요?',
};

export const PageTitles = {
  coin: '총알',
  point: '포인트',
  setMyInfo: '내 정보 설정',
  invite: '친구초대',
  coupon: '쿠폰',
  membership: '멤버십',
};

export const Member1949 = {
  start: '30일 무료체험 시작하기',
  title: '추천인 아이디 있으세요?',
  content: '추천인 아이디를 입력하시면\n무료체험 기간이 60일로 연장됩니다',
  recmdId: '추천인 아이디는?',
  recmdTitle: '30일 무료체험 시작하기',
  recmdContent:
    '멤버십1949 회원이 되시면 친구에게 선물할 수 있는 추천인 아이디가 생성됩니다.',
  oneMonthFree: '없어요, 30일 무료체험 시작하기',
  twoMonthFree: '있어요, 60일 무료체험 시작하기',
  clauseContent1:
    '무료체험 후 월 4900원 / 언제든 해지 가능 / 무료체험을 시작하시면 ',
  clauseContent2: '멤버십1949 운영정책',
  clauseContent3: '에 동의하시게 됩니다',
  freeComplete: `이미 무료체험을 이용하셨습니다. 계속 진행하시면 멤버십 회원료 4900원이 결제됩니다.`,
  joinMembership: '멤버십 가입하기',
};

export const MyPointString = {
  accumulationCodeRegistration: '적립코드 등록',
  history: 'History',
  seeMoreList: '더보기',
};

export const CouponMainString = {
  myCoupon: 'my coupons',
  myCouponContent: '주문당 최대 1장 사용가능\n현금 교환 및 잔액 환불 불가',
  noCoupon: '쿠폰이 없습니다.',
  set: '적용하기',
};

export const AnnouncementString = {
  notice: 'Notice',
};

export const CouponTopString = {
  hint: '쿠폰코드 입력하기',
};

export const CouponString = {
  membershipCoupon: '멤버십쿠폰',
  chainCoupon: '연쇄쿠폰',
};

export const CouponCodeInput = {
  inputCode: '쿠폰등록',
  regist: '등록하기',
  couponNumber: '쿠폰번호 입력',
};

export const TextInputScreenString = {
  accumulationCodeInput: '적립코드 입력',
  couponCodeInput: '쿠폰코드 입력',
  enter10Characters: '10자 내로 입력',
  usePoint: '사용할 포인트 입력',
  allUse: '모두사용',
  doNotUse: '사용안함',
  email: '이메일 주소 입력',
  orderCancel: '더 좋은 서비스가 될 수 있도록 취소 사유를 알려주세요',
  recmdIdInput: '추천인 아이디 입력',
  doorCodeInput: '공동현관 출입정보 입력',
  usePointExplain:
    '포인트는 쿠폰 적용 후 남은 결제금액의 50%, 최대 1만원까지 사용 가능합니다. 단, 멤버십 회원에 한해 사용 제한이 없습니다.',
  done: 'DONE',
  maximum: '최대',
  canPoint: 'P 사용 가능',
};

export const OSDPaymentString = {
  paymentHistory: '결제내역',
  addCardComplete: '카드가 추가되었습니다.',
  won: '원',
  receiptOver: '영수증이 전송되었습니닷',
  refundOver: '환불처리 됐습니닷',
  refundNoticeOver:
    '환불 신청 했습니닷. 영업일 기준 2-3일 소요될 수 있으니 잠시만 기다려주세요!',
  payOver: '결제성공!',
};

export const OrderHistoryDetailString = {
  orderDetail: '주문상세',
  address: '주소',
  dawn: '새벽',
  pickupDate: '수거일정',
  deliveryDate: '배송일정',
  pickupDetail: '수거요청사항',
  deliveryDetail: '배송요청사항',
  washDetail: '세탁요청사항',
  washPayment: '세탁요금',
  addedPayment: '추가요금',
  won: '원',
  frontDoor: '공동현관',
  remain: '잔여',
  totalOrderPayment: '총 주문금액',
  couponDiscount: '쿠폰 할인',
  pointDiscount: '포인트 할인',
  membershipDiscount: '멤버십 할인',
  totalPayment: '총 결제금액',
  accounting: '책정중',
  canApplyAfterCheck: '검수 후 적용 가능',
  membershipDiscountDefault: '7% 할인',
  change: '변경',
  refund: '환불',
  refundExpectPrice: '환불(예정)금액',
  save: '적립',
  receipt: '영수증',
  deliveryFee: '배송요금',
  scheduleChange: '일정변경',
  closeModal: '닫기',
  registCard: '등록하기',
  chargeBullet: '충전하기',
  makePayment: '결제하기',
  paymentComplete: '결제완료',
  membershipToast: '💁포인트는 배송완료 후 자동으로 적립됩니다.',
  toastEmoji: '💁',
  normalToast: '시까지 결제되지 않으면 배송이 취소됩니다. 지금 결제해주세요.',
  membershipMeritTitle: '👑멤버십 가입 혜택',
  membershipMerit: `월 2회 무료배송, 프리미엄 세탁 10% 할인`,
  joinMembership: '더 알아보기',
  noCareOption: '없음',
  payType: {
    card: 'PG결제',
    bill: '카드결제',
    coin: '총알캐시',
    point: '포인트',
    account: '계좌이체',
    naverpay: '네이버페이',
    later: '후불',
  },
  careOptions: {
    repair: '수선요청',
    etc: '기타',
    premium: '프리미엄 요청',
    laundry: '세탁요청',
    premiumWashAndFold: '생활빨래 프리미엄 요청',
  },
  myWashItem: '나의 세탁물',
};

export const OrderHistoryPaymentString = {
  goBulletPageModal: '총알이 모자라요! 총알을 충전할까요?',
};

export const SignTermsText = {
  bottomTextArr: [
    {
      key: 'privacy',
      text: '[필수] 개인정보 처리방침',
      isRequire: true,
      isChecked: false,
    },
    {
      key: 'clause',
      text: '[필수] 세탁특공대 서비스 이용약관',
      isRequire: true,
      isChecked: false,
    },
    {
      key: 'location',
      text: '[필수] 위치기반서비스 이용약관',
      isRequire: true,
      isChecked: false,
    },
    {
      key: 'push',
      text: '[선택] 혜택 정보 앱 푸시 알림 수신',
      isRequire: false,
      isChecked: false,
      type: 'push',
    },
  ],
  headTitle: `서비스 이용을 위한\n동의 안내`,
  subTitle: `서비스 이용에 꼭 필요한 사항입니다. 정책 및 약관을 클릭해 모든 내용을 확인해주세요.`,
  termsTitle: '전체 동의',
  next: '다음',
};

export const LoginQuestionText = {
  headTitle: `인증 해주세요!`,
  subTitle: `등록된 휴대전화 번호로 가입된 사용자가 있어요. `,
  subTitleBold: `로그인 하시려면 기존에 등록하신 주소를 인증 해주세요. `,
  subTitleLast: `아래 주소 중 이전에 등록한 내 주소는 어디인가요?`,

  goSignUp: '신규 가입',
  check_first: '기존에 등록된 주소가 맞나요?',
};

export const LoginLastQuestionText = {
  headTitle: `인증 해주세요!`,
  subTitle: `상세 주소를 인증해 주세요. 아래 상세 주소의 네모에 해당하는 글자를 채워주세요`,
  goSignUp: '신규 가입',
  fail:
    '답변이 일치하지 않아요! 다시하기 또는 우측 상단의 신규회원 가입을 진행 해주세요!',
  retry: '다시하기',
};

export const LoginChatText = {
  placeholderText: {
    phone: '010-1234-5678',
    certificateNumber: '0000',
  },
  firstChat: {
    textArr: [
      {
        text:
          '안녕하세요. 세탁특공대입니다.\n서비스 이용을 위해 휴대폰번호를 입력해 주세요.\n\n신규회원이라면 니트 드라이클리닝 990원 쿠폰을 즉시 발급해 드려요!',
      },
    ],
    type: 'left',
    flexWrap: true,
  },
  reEnterPhoneNum: {
    textArr: [
      {
        text: '전화번호 재입력',
        background: false,
        onPress: true,
        btnKey: 'reEnterPhone',
      },
    ],
    type: 'flex-end',
  },
  notMatchCertificate: {
    textArr: [
      {
        text:
          '인증번호가 일치하지 않습니다. 새로운 인증번호를 보내드리니 다시 시도해주세요.',
      },
    ],
    type: 'left',
    flexWrap: true,
  },
  certificate: {
    textArr: [
      { text: '문자로 인증번호를 보냈습니다. 4자리 숫자를 입력해주세요.' },
    ],
    type: 'left',
    flexWrap: true,
  },
  inputDemoText: {
    textArr: [{ text: null, background: true }],
    type: 'flex-end',
  },
  certificateNumberCheck: '인증번호를 확인해주세요.',
};

export const AddressChatText = {
  placeholderText: {
    remaining_address: '나머지 주소 입력(예: 102동 123호)',
    save_address_name: '10자 내로 직접입력(예: 우리집)',
  },
  firstChat: {
    textArr: [
      {
        text: '선택하신 주소는 ',
        textMiddle: '서울 강남구 삼성동 157-29 [도로명] 테헤란로 501',
        textEnd: '입니다.\n나머지 동/호수를 정확하게 입력해주세요.',
      },
    ],
    type: 'left',
    flexWrap: true,
  },

  saveName: {
    textArr: [{ text: '어떤 이름으로 저장할까요?' }],
    type: 'left',
  },
  saveBtn: {
    textArr: [
      { text: 'HOME', background: false, onPress: true, btnKey: 'home' },
      { text: 'OFFICE', background: false, onPress: true, btnKey: 'office' },
      {
        text: '직접입력',
        background: false,
        onPress: true,
        btnKey: 'directInput',
      },
    ],
    type: 'flex-end',
    flexWrap: true,
    answerChatType: 'save_address_name',
  },
  directInput: {
    textArr: [{ text: '', background: true }],
    type: 'flex-end',
  },
  warningText: {
    textArr: [
      {
        text: '',
        textMiddle: 'HOME',
        textEnd:
          '에 공동현관 출입제한이 있습니까? 출입방법을 기재해주시면 문 앞까지 안전하게 수거배달하겠습니다.',
        background: false,
      },
      {
        text:
          '출입이 제한되면 임의로 경비실이나 택배함에 배달할 수 있습니다. 경비원 부재 등으로 이 조차 어렵다면 철수하고, 재배달비가 발생할 수 있습니다.',
      },
    ],
    type: 'left',
    flexWrap: true,
  },
  commonPorch: {
    textArr: [
      {
        text: '제한없음 또는 경비실 호출',
        background: false,
        onPress: true,
        btnKey: 'securityCall',
      },
      {
        text: '직접입력',
        background: false,
        onPress: true,
        btnKey: 'directInput',
      },
    ],
    type: 'flex-end',
    answerChatType: 'commonPorchInput',
  },
  sendButton: 'SEND',
  inputAddressOthers: '상세주소를 입력해주세요',
  unexpectedOtherAddress: '주소를 검색하고 다시 해주세요',
};

export const CardRegistString = {
  titleLabel: '카드등록',
  content: '신용,체크,법인카드 등록 가능',
};

export const SwatBulletString = {
  titleLabel: '세특총알',
  content: '15만원,30만원,50만원 선불권 할인',
};

export const MainString = {
  home: 'HOME',
  order: '주문하기',
  singleOrder: '1회주문',
  regularOrder: '정기주문',
  expressOrder: '급행주문',
  expressFee5000: '익일배달비 5,000원',
  inviteOver: '초대장 접수완료!\n쿠폰을 확인해보세요!',
  neverToSeeAgain: '다시보지않기',
};

export const NewMainString = {
  mainTitle1: '오늘 신청하면',
  mainTitle2: '요일 새벽 배송',
  noServiceAreaTitle_: '아쉽게도,',
  noServiceAreaTitle_2: '아직 세특권이 아니에요',
  subTitle: '이런 서비스는 어때요?',
  reviewBoardTitle: '실제 고객들의 칭찬후기',
  contentsTitle: '세특발견',
  orderIndexFront: '세특 ',
  orderIndexRear: '회차 ・ ',
  pickup: '수거',
  delivery: '배송',
  wash: '세탁',
};

export const HomeScreenString = {
  order: '세탁신청하기',
  exit: '한번 더 누르시면 종료됩니다',
};

export const BottomTabString = {
  home: '홈',
  membership: '멤버십',
  order: '세탁신청',
  orderHistory: '이용내역',
  mypage: '마이세특',
};

export const InviteTypes = [
  { type: 'kakao', message: '카톡 친구에게 선물하기' },
  // { type : 'sms', 'message' : '문자메시지로 선물하기' },
  { type: 'copy', message: '선물코드 복사하기' },
];

export const InviteMessage = {
  text: `{name}님이 세탁지원금 5,000원을 선물했어요.\n\n1등 모바일 세탁소, 세탁특공대 앱을 다운받고 바로 5,000원을 받아보세요.\n① [쿠폰함] > [쿠폰코드 입력하기]\n② [{myCode}] 입력\n\n이미 누적 매출 100억원을 돌파한 세탁특공대 바로가기\nhttps://go.onelink.me/E5Lh/fdd98913`,
  // text: `{name}님이 한큐에\n집 앞으로 세탁배달!\n일요일에도 밤 12시까지\n출동하는 모바일 세탁소\n세탁특공대 앱으로 초대했습니다.\n\n[쿠폰함]에서 [{myCode}] 입력하고 첫주문을 마치면 1만원 할인쿠폰을 드립니닷!`,
  over: '메시지가 클립보드에 저장됐습니닷',
  topTitle: '5,000원 선물하고\n10,000원 받기',
};

export const MainInviteFriendString = {
  sectionTitle: '첫단추가 중헌디,\n첫주문50% 할인쿠폰',
  sectionContent:
    '첫 주문에 멤버십 회원이면 50% 할인!\n 제한시간 안에 멤버십에 가입하고 첫 주문을 파\n격 할인가에 이용해보십쇼.',
  presentMethod: [
    {
      title: '❶  초대쿠폰 선물하기',
      message: '초대할 친구를 선택해 쿠폰 보내기',
    },
    {
      title: '❷  친구가 신규회원으로 가입',
      message: '친구가 회원가입 후 쿠폰함에서\n내가 보내준 초대쿠폰을 등록',
    },
    {
      title: '❸  첫주문 완료하면 나에게 1만원 지급',
      message:
        '친구의 첫주문이 완료되면 내 쿠폰함에\n10,000원 할인쿠폰 지급\n(배송완료시 지급)',
    },
  ],
  present: [
    {
      title: '5천원 선물하고 1만원 받기',
      message:
        '친구가 회원님의 초대쿠폰을 통해 신규회원으로 가입하면 5천원 할인쿠폰을 받습니다.\n\n가입한 친구가 첫주문을 완료하면 회원님에게 1만원 할인쿠폰이 지급됩니다.',
    },
  ],
};

export const PaymentBuyBulletString = {
  title: '얼마나 충전할까요?',
  noticeTitle: '총알 구입시 유의사항',
  noticeContents: [
    '총알은 세탁특공대 전용 결제수단으로 선불권을 의미하며',
    '선불금액에 따라 보너스 총알을 추가로 제공합니다.',
    '총알의 환불은 아래와 같이 구분됩니다.',
    '1) 구입한 날로부터 1개월 이내: 잔액의 100% 환불',
    '2) 구입한 날로부터 1개월 이후: 잔액의 90% 환불',
    '단, 잔액이 1만원 미만인 경우 1천원의 환불수수료가 공제되며,',
    '잔액이 1천원 이하인 경우 환불되지 않습니다.',
    '무료로 제공되는 보너스 총알은 구매 취소 및 환불대상이 아닙니다.',
    '총알의 유효기간은 구입한 날로부터 5년입니다.',
  ],
  membershipBonus: '멤버십회원 보너스',
  normalBonus: '일반회원 보너스',
  unit: '만원',
  won: '원',
  registerCardModalTitle: '등록된 대표카드로 총알을 구입할까요?',
  registerCardModalOK: '네!',
  registerCardModalNO: '아니요',
  easyPayment: '간편결제',
  easyPaymentExplain: '등록된 대표카드로 결제',
  cardPayment: '카드결제',
  cardPaymentExplain: 'PAYCO, SSGPAY, 카카오페이 및 해외카드도 결제가능',
  confirm:
    '앗, 총알이 없네요.\n총알은 세탁특공대에서 사용할 수 있는 선불권이에요.\n지금 충전하시면 보너스 총알을 선물로 드려요.',
  confirmPoint: `아직 보유한 포인트가 없어요.\n포인트는 주문 후 적립됩니다.`,
  confirmOK: '총알 구입하기',
};

export const PaymentBuyBulletItemString = {
  tenThousandWon: '만원',
};

export const ModalString = {
  confirm: '요청사항을 저장할까요?',
};

export const PaymentMethodString = {
  paymentMethod: '결제수단',
};

export const PriceListString = {
  basicFee: '기본요금',
  specialFee: '스페셜요금',
  premiumFee: '프리미엄요금',
  smallFee: '소형요금',
  mediumFee: '중형요금',
  largeFee: '대형요금',
  singleFee: '싱글요금',
  doubleFee: '더블요금',
  queenKingFee: '퀸·킹요금',
};

export const PriceString = {
  detailModalDesc:
    '세심한 주의가 필요한 명품과 세탁표기법 상 단독세탁을 요하는 제품에 적용됩니다.',
  detailModalDescBottom:
    '자세한 내용은 주문과정의 🔍 **프리미엄 세탁이란?** 에서 확인해주세요.\n\n주문 시 프리미엄 세탁을 신청하지 않으셨더라도 고가 제품의 안전을 위해 프리미엄 세탁을 요하는 제품은 프리미엄 가격으로 우선 안내해드리고 있습니다. 일반 세탁으로 변경하기 원하시면 고객센터로 문의해주세요.',
};

export const FaqString = {
  chat: '1:1 상담',
};

export const OrderChatText = {
  whereIsPickupChat: {
    textArr: [
      {
        text:
          '요원이 세탁물을 어디서 수거할까요?\n바쁘시거나 사생활 보호를 원하시면 문 앞에 두세요. 도착 30분 전 알림을 보내드립니다.',
      },
    ],
    type: 'left',
    flexWrap: true,
  },
  whereIsPickupChoiceChat: {
    textArr: [
      {
        text: '요원에게 직접 전해줄게요',
        background: false,
        btnKey: 'direct',
        isUsedOnPress: true,
      },
      {
        text: '문 앞에 둘게요',
        background: false,
        btnKey: 'door',
        isUsedOnPress: true,
      },
    ],
    customSectionKey: 'whereIsPickupChoiceChat',
  },
};

export const ErrorMessage = {
  pickupDateTimeAPI: '픽업날짜 조회에 실패하였습니다.',
  deliveryDateTimeAPI: '배달날짜 조회에 실패하였습니다.',
  assetsAPI: '결제정보 조회에 실패하였습니다.',
  orderHistoryAPI: '주문내역 조회에 실패하였습니다.',
  awsS3UploadAPI: '사진 업로드에 실패하였습니다.',
  stillUploading: '사진 업로드중! 잠시만 기다려주세요',
};

export const AlertMessage = {
  membershipOnlyTime: '멤버십 회원만 이용이 가능 합니다.',
  breakTime: '해당 시간은 이용이 불가능 합니다.',
};

export const ImageMarkerGuide = {
  addMarker: '요청부위에 마크를 표시하려면\n사진을 톡 눌러주십쇼.',
  deleteMarker:
    '마크를 추가하려면 사진을 눌러주십쇼.\n마크를 다시 눌러 삭제할 수 있습니다.',
  title: '사진을 톡 눌러\n요청 부위를 마킹해주세요.',
  subtitle: '삭제하려면 요청 부위를 다시 터치하세요.',
  next: '다음',
};

// Feedback
export const FeedbackAfterOrderString = {
  feedback_posivtive: '리뷰 남기기',
  feedback_negative: '다음에요',
  pickupService: '수거서비스',
  pickupPoint: 'Pickup',
  deliveryService: '배달서비스',
  deliveryPoint: 'Delivery',
  washQuality: '세탁품질',
  washPoint: 'Cleaning',
  completion: '완료',
  feedbackUpated: '소중한 의견 감사합니다.',
  feedbackUpated_ios:
    '🎁세특 1만 원 할인쿠폰 받으세요! \n\n' +
    '소중한 의견을 남겨주셔서 감사해요.\n지금 앱스토어에 앱리뷰를 남겨주시면 100%\n1만 원 할인쿠폰 드려요.\n\n' +
    '*[1:1 문의하기]에 리뷰를 캡처해 보내주세요.',
  feedbackUpated_android:
    '🎁세특 1만 원 할인쿠폰 받으세요! \n\n' +
    '소중한 의견을 남겨주셔서 감사해요.\n지금 앱스토어에 앱리뷰를 남겨주시면 100%\n1만 원 할인쿠폰 드려요.\n\n' +
    '*[1:1 문의하기]에 리뷰를 캡처해 보내주세요.',
};

// Feedback 주문 경험 좋음 선택
export const FeedbackGoodExperienceSelectionString = {
  question: {
    textArr: [
      {
        text: '이번 주문은 어떠셨나요?\n소중한 의견을 들려주세요.\n(50P 적립)',
      },
    ],
    type: 'left',
  },
  placeholderText:
    '칭찬 한마디는 영하의 날씨도 잊게하고, 개선 한마디는 세상을 바꾸지 말입니다. 마음의 소리 부탁드립니다!',
};

// Feedback 주문 경험 나쁨 선택
export const FeedbackBadExperienceSelectionString = {
  question: {
    textArr: [{ text: '앗, 어떤 점이 가장 실망스러우셨나요?' }],
    type: 'left',
  },
  answer: {
    textArr: [
      {
        text: '수거 요원 또는 수거 서비스',
        background: false,
        onPress: true,
        btnKey: 'pickup',
      },
      {
        text: '배달 요원 또는 배달 서비스',
        background: false,
        onPress: true,
        btnKey: 'delivery',
      },
      { text: '세탁품질', background: false, onPress: true, btnKey: 'wash' },
      { text: '기타', background: false, onPress: true, btnKey: 'etc' },
    ],
    type: 'flex-end',
    flexWrap: true,
    answerChatType: '',
  },
  placeholderText:
    '실망시켜 죄송합니다! 문제를 바로 잡고 개선할 수 있도록 자세한 이야기를 들려주십시오.',
  transmissionText: '이 내용을 고객센터에도 전송합니다',
};

export const MissionCompleteString = {
  loaded: `철컥!\n첫주문 {price}원\n할인쿠폰 장전!`,
  shot: `5분 미션에 성공했습니다.\n쿠폰은 유효기간 안에 쏘셔야함다!`,
};

export const OrderModuleString = {
  defaultDoorCode: '출입제한 없음 또는 경비실 호출',
  orderCancelError: '취소 사유를 알려주세요!',
};
export const WashPlanAfterOrderText = {
  title: '주문 이후 세탁 일정',
  schedules: [
    {
      title: '세탁물 담기',
      content:
        '세특의 포장봉투나 쇼핑백에 생활빨래와 개별클리닝을 구분해 담아주세요.',
    },
    {
      title: '문 앞에 내놓기',
      content:
        '일정에 맞게 밤 12시까지 세탁물을 내놓으면 새벽 7시 전에 비대면으로 수거합니다.',
    },
    {
      title: '인수증 받고 결제하기',
      content:
        '수거 당일 오후에 인수증 알림이 오면 세탁물 내역과 금액을 확인하고 결제해주세요.',
    },
    {
      title: '깨끗한 세탁물 새벽배송 받기',
      content:
        '5단계 공정을 거쳐 꼼꼼하게 세탁해 48시간 안에 문 앞까지 새벽 배송합니다.',
    },
  ],
};

export const ConfirmOrderCompleteText = [
  // 0
  {
    type: 'left',
    array: [
      {
        text: `**성함**이 어떻게 되십니까? 본명 대신 개성있는 닉네임을 정하실 수 있습니다.`,
      },
    ],
  },
  // 1
  {
    type: 'input',
    nextIndex: 2,
    placeholder: '닉네임 입력',
    key: `name`,
    value: null,
  },
  // 2
  {
    type: 'left',
    array: [
      {
        text: `{pickupLocation}까지 안전하게 수거배달하기 위해 **공동현관 출입정보**를 정확하게 기재해 주십시오.`,
      },
      {
        text: `출입이 제한되면 임의로 무인택배함이나 경비실에 배달할 수 있습니다. 경비원 부재 등으로 이 조차 어렵다면 철수하고, 취소 수수료가 발생할 수 있습니다.`,
      },
    ],
  },
  // 3
  {
    type: 'button',
    array: [
      { key: 'door', value: OrderModuleString.defaultDoorCode, nextIndex: 5 },
      { key: 'door', value: '공동현관 출입정보 입력', nextIndex: 4 },
    ],
  },
  // 4
  {
    type: 'input',
    nextIndex: 5,
    placeholder: '공동현관 출입번호',
    key: `door`,
    value: null,
  },
  // 5
  {
    type: 'left',
    array: [{ text: `이 주문에 이불, 패드 등 침구류가 있습니까?` }],
  },
  // 6
  {
    type: 'button',
    array: [
      { key: 'button', value: '네! 침구를 맡길 예정입니닷', nextIndex: 7 },
      { key: 'button', value: '아니오, 없습니다', nextIndex: 9 },
    ],
  },
  // 7
  {
    type: 'left',
    array: [
      {
        text: `**생활빨래는 봉투에 담아주시는 그대로 물세탁하고 열풍건조하며, 봉투 당 가격**입니다. 이불과 함께 빨래를 한 봉지에 담으셔도 됩니다.

**생활빨래가 아니라면 케어라벨에 따라 세탁하고, 종류와 사이즈에 따라 가격이 책정됩니다.** 얼룩제거가 필요하거나 고가의 제품, 구스이불 등은 꼭 개별 품목으로 맡겨주세요.`,
      },
    ],
  },
  // 8
  {
    type: 'button',
    array: [
      { key: 'bedding', value: '생활빨래', nextIndex: 9 },
      { key: 'bedding', value: '개별품목', nextIndex: 9 },
    ],
  },
  // 9
  {
    type: 'left',
    removeAutoScrolling: true,
    array: [
      {
        text:
          '{userName}님, 이제 마지막으로 주문정보를 확인하겠습니다.\n\n' +
          '**주소**\n{address}\n{door}\n\n' +
          '**예약일시**\n\u2714{pickupTime}\n\u2714{deliveryTime}\n\u2714{pickupLocation}\n\n' +
          '요청사항은 주문이 끝나면 주문내역에서 작성하실 수 있습니다.',
        // `**PICKUP**\n{pickupTime}\n{pickupLocation}\n\n**ADDRESS**\n{address}\n{door}`
      },
      {
        text:
          '**주의사항**\n\n' +
          '최소 주문금액은 2만원입니다. 2만원 미만이라도 2만원이 청구됩니다. (첫주문은 해당되지 않습니다.)\n\n' +
          '익일배달은 급행비가 추가됩니다.\n\n' +
          '예약시간 1시간 전까지 취소·변경이 가능합니다. 이후에는 취소 수수료로 3천원이 부과됩니다.\n\n' +
          '주문하시면 서비스 운영정책 및 주의사항에 동의하시게 됩니다. 환불, 세탁불가 사유, 보상정책 등 중요한 내용이 많으니 꼭 확인해주십시오.',
        // '최소 주문금액은 2만원으로 2만원 미만이라도 2만원이 청구됩니다.' +
        // '\n\n예약시간 1시간 전까지 취소·변경이 가능합니다. 이후에는 취소 수수료로 3천원이 부과됩니다.' +
        // '\n\n선택하신 배달시간은 픽업 후 품질관리팀의 검수가 끝나면 세탁비와 함께 확정됩니다.' +
        // '\n\n주문정보와 서비스 필독사항을 확인하고 내용에 동의하시면 주문됩니다.'
      },
    ],
  },
  // 10
  {
    type: 'left',
    webView: 'https://www.washswat.com/washswat_service_policy',
    array: [{ text: `서비스 필독사항` }],
  },
  // 11
  {
    type: 'button',
    array: [{ key: 'final', value: '주문하기' }],
    // array: [{ key: 'final', value: '네, 모두 동의하고 주문할게요!' }]
  },
];

export const ConfirmOrderCompleteTextExpress = [
  // 0
  {
    type: 'left',
    array: [
      {
        text: `**성함**이 어떻게 되십니까? 본명 대신 개성있는 닉네임을 정하실 수 있습니다.`,
      },
    ],
  },
  // 1
  {
    type: 'input',
    nextIndex: 2,
    placeholder: '닉네임 입력',
    key: `name`,
    value: null,
  },
  // 2
  {
    type: 'left',
    array: [
      {
        text: `**{pickupLocation}**까지 안전하게 수거배달하기 위해 공동현관 출입정보를 정확하게 기재해 주십시오.`,
      },
      {
        text: `출입이 제한되면 임의로 무인택배함이나 경비실에 배달할 수 있습니다. 경비원 부재 등으로 이 조차 어렵다면 철수하고, 취소 수수료가 발생할 수 있습니다.`,
      },
    ],
  },
  // 3
  {
    type: 'button',
    array: [
      { key: 'door', value: OrderModuleString.defaultDoorCode, nextIndex: 5 },
      { key: 'door', value: '공동현관 출입정보 입력', nextIndex: 4 },
    ],
  },
  // 4
  {
    type: 'input',
    nextIndex: 5,
    placeholder: '공동현관 출입번호',
    key: `door`,
    value: null,
  },
  // 5
  {
    type: 'left',
    array: [{ text: `이 주문에 이불, 패드 등 침구류가 있습니까?` }],
  },
  // 6
  {
    type: 'button',
    array: [
      { key: 'button', value: '네! 침구를 맡길 예정입니닷', nextIndex: 7 },
      { key: 'button', value: '아니오, 없습니다', nextIndex: 9 },
    ],
  },
  // 7
  {
    type: 'left',
    array: [
      {
        text: `**생활빨래는 봉투에 담아주시는 그대로 물세탁하고 열풍건조하며, 봉투 당 가격**입니다. 이불과 함께 빨래를 한 봉지에 담으셔도 됩니다. 현재 최대 34% 할인 이벤트중입니다!

**생활빨래가 아니라면 케어라벨에 따라 세탁하고, 종류와 사이즈에 따라 가격이 책정됩니다.** 얼룩제거가 필요하거나 고가의 제품, 구스이불 등은 꼭 개별 품목으로 맡겨주세요.`,
      },
    ],
  },
  // 8
  {
    type: 'button',
    array: [
      { key: 'bedding', value: '생활빨래', nextIndex: 9 },
      { key: 'bedding', value: '개별품목', nextIndex: 9 },
    ],
  },
  // 9
  {
    type: 'left',
    removeAutoScrolling: true,
    array: [
      {
        text:
          '{userName}님, 이제 마지막으로 주문정보를 확인하겠습니다.\n\n' +
          '**주소**\n{address}\n{door}\n\n' +
          '**예약일시**\n\u2714{pickupTime}\n\u2714{deliveryTime}\n\u2714{pickupLocation}\n\n' +
          '요청사항은 주문이 끝나면 주문내역에서 작성하실 수 있습니다.',
        // `**PICKUP**\n{pickupTime}\n{pickupLocation}\n\n**ADDRESS**\n{address}\n{door}`
      },
      {
        text:
          '**주의사항**\n\n' +
          '최소 주문금액은 2만원입니다. 2만원 미만이라도 2만원이 청구됩니다. (첫주문은 해당되지 않습니다.)\n\n' +
          '익일배달은 급행비가 추가됩니다.\n\n' +
          '예약시간 1시간 전까지 취소·변경이 가능합니다. 이후에는 취소 수수료로 3천원이 부과됩니다.\n\n' +
          '주문하시면 서비스 운영정책 및 주의사항에 동의하시게 됩니다. 환불, 세탁불가 사유, 보상정책 등 중요한 내용이 많으니 꼭 확인해주십시오.',
        // '최소 주문금액은 2만원으로 2만원 미만이라도 2만원이 청구됩니다.' +
        // '\n\n예약시간 1시간 전까지 취소·변경이 가능합니다. 이후에는 취소 수수료로 3천원이 부과됩니다.' +
        // '\n\n선택하신 배달시간은 픽업 후 품질관리팀의 검수가 끝나면 세탁비와 함께 확정됩니다.' +
        // '\n\n주문정보와 서비스 필독사항을 확인하고 내용에 동의하시면 주문됩니다.'
      },
      {
        text: `⚠️ 익일배달은 급행비가 있습니다. 익일세탁비(세탁비의 20%)와 익일배달비(3천원)가 급행비로 과금됩니다.

멤버십 회원은 익일배달비가 무료입니다.`,
      },
    ],
  },
  // 10
  {
    type: 'left',
    webView: 'https://www.washswat.com/washswat_service_policy',
    array: [{ text: `서비스 필독사항` }],
  },
  // 11
  {
    type: 'button',
    array: [{ key: 'final', value: '네, 모두 동의하고 주문할게요!' }],
  },
];

export const ConfirmOrderCompleteTextWeekly = [
  // 0
  {
    type: 'left',
    array: [
      {
        text: `**성함**이 어떻게 되십니까? 본명 대신 개성있는 닉네임을 정하실 수 있습니다.`,
      },
    ],
  },
  // 1
  {
    type: 'input',
    nextIndex: 2,
    placeholder: '닉네임 입력',
    key: `name`,
    value: null,
  },
  // 2
  {
    type: 'left',
    array: [
      {
        text: `**{pickupLocation}**까지 안전하게 수거배달하기 위해 공동현관 출입정보를 정확하게 기재해 주십시오`,
      },
      {
        text: `출입이 제한되면 임의로 무인택배함이나 경비실에 배달할 수 있습니다. 경비원 부재 등으로 이 조차 어렵다면 철수하고, 취소 수수료가 발생할 수 있습니다.`,
      },
    ],
  },
  // 3
  {
    type: 'button',
    array: [
      { key: 'door', value: OrderModuleString.defaultDoorCode, nextIndex: 5 },
      { key: 'door', value: '공동현관 출입정보 입력', nextIndex: 4 },
    ],
  },
  // 4
  {
    type: 'input',
    nextIndex: 5,
    placeholder: '공동현관 출입번호',
    key: `door`,
    value: null,
  },
  // 5
  {
    type: 'left',
    array: [{ text: `정기주문을 언제부터 시작할까요?` }],
  },
  // 6
  {
    type: 'button',
    logic: 'possibleWeeklyOrderDays',
    array: [],
  },
  // 7
  {
    type: 'left',
    array: [
      {
        text:
          // '{userName}님, 이제 마지막으로 주문정보를 확인하겠습니다.\n\n' +
          // '**주소**\n{address}\n{door}\n\n' +
          // '**예약일시**\n\u2714{pickupTime}\n\u2714{deliveryTime}\n\u2714{pickupLocation}\n\n' +
          // '요청사항은 주문이 끝나면 주문내역에서 작성하실 수 있습니다.'
          `**PICKUP**\n{weeklyOption}\n{pickupLocation}\n{startDateForWeekly}부터\n\n**ADDRESS**\n{address}\n{door}`,
      },
      {
        text:
          '최소 주문금액은 2만원으로 2만원 미만이라도 2만원이 청구됩니다. (급행비는 최소 주문금액에서 제외)' +
          '\n\n예약시간 1시간 전까지 취소·변경이 가능합니다. 이후에는 취소 수수료로 3천원이 부과됩니다.' +
          '\n\n선택하신 배달시간은 픽업 후 품질관리팀의 검수가 끝나면 세탁비와 함께 확정됩니다.' +
          '\n\n주문정보와 서비스 필독사항을 확인하고 내용에 동의하시면 주문됩니다.',
      },
    ],
  },
  // 8
  {
    type: 'left',
    webView: 'https://www.washswat.com/washswat_service_policy',
    array: [{ text: `서비스 필독사항` }],
  },
  // 9
  {
    type: 'button',
    array: [{ key: 'final', value: '네, 모두 동의합니다' }],
  },
];

export const ChangeAddressStructure = [
  {
    type: 'left',
    array: [
      {
        text: `안녕하세요!\n변경할 주소의 **동/호수**를 알려주시면 신속하게 주소를 변경해드릴게요!`,
      },
    ],
  },

  {
    type: 'input',
    nextIndex: 2,
    placeholder: '나머지 주소 입력(예: 102동 123호)',
    key: `addressOthers`,
    value: null,
  },
  {
    type: 'left',
    array: [{ text: `이 주소를 뭐라고 저장할까요?` }],
  },
  {
    type: 'button',
    array: [
      { key: 'title', value: 'HOME', nextIndex: 5 },
      { key: 'title', value: 'OFFICE', nextIndex: 5 },
      { key: 'title', value: '직접입력', nextIndex: 4 },
    ],
  },
  {
    type: 'input',
    nextIndex: 5,
    placeholder: '예를들어 우리집',
    key: `title`,
    value: null,
  },
  {
    type: 'left',
    array: [{ text: `**{roadAddress} {addressOthers}**로 주소를 변경합니다` }],
  },
  {
    type: 'button',
    array: [{ key: 'final', value: '네, 변경해주세요' }],
  },
];

export const PhoneNumChangeChat = {
  directInput: {
    textArr: [{ text: '', background: true }],
    type: 'right',
  },
  userCheck: {
    textArr: [
      {
        text: '전화번호를 입력하시면 인증번호를 발송해드립니다!',
      },
    ],
    type: 'left',
    flexWrap: true,
  },
  reEnterPhoneNum: {
    textArr: [
      {
        text: '전화번호 재입력',
        background: false,
        onPress: true,
        btnKey: 'reEnterPhone',
      },
    ],
    type: 'flex-end',
    buttonPress: true,
  },
  notMatchCertificate: {
    textArr: [
      { text: '인증번호가 일치하지 않습니다. 새로운 인증번호를 발송합니닷' },
    ],
    type: 'left',
    flexWrap: true,
  },
  certificate: {
    textArr: [
      { text: '문자로 인증번호를 보냈습니다. 4자리 숫자를 입력해주세요.' },
    ],
    type: 'left',
    flexWrap: true,
  },
  changePhoneNum: {
    textArr: [
      { text: '인증이 완료되었습니다! 변경할 전화번호를 입력해주세요.' },
    ],
    type: 'left',
    flexWrap: true,
  },
};

export const SettingsString = {
  setting: '설정',
  sir: '님',
  nickname: '닉네임 변경',
  address: '주소 변경',
  phoneChangeComplete: '전화번호가 변경되었습니다',
  nicknameChangeComplete: '닉네임이 변경되었습니다',
  events: '달달한 할인, 이벤트 정보를 받습니다',
  appReview: '앱 리뷰 남기기',
  servicePolicy: '서비스 정책 보기',
  noti: '혜택 알림 받기',
  notiOn: '가뭄의 단비같은 할인, 이벤트 정보를 받습니다.',
  notiOff: '가뭄의 단비같은 할인, 이벤트 정보를 받지 않습니다.',
  logout: '로그아웃',
  logoutAlertContent: '로그아웃하시겠습니까?',
  withdrawal: '회원탈퇴',
  withdrawalQuestion:
    '탈퇴 시 회원님의 정보를 비롯한 모든 주문기록이 삭제됩니다. 때문에 이전 주문에 대한 어떠한 사후처리도 도와드릴 수 없게 됩니다.\n계속 진행하시겠습니까?',
  withdrawalQuestionYes: '탈퇴 신청하기',
  withdrawalQuestionNo: '취소',
  washswatInc: 'WashSwat Inc.',
};

export const AddressChangeString = {
  placeholderText: '지번, 도로명, 건물명 검색',
  unexpectedOtherAddress: '주소를 검색하고 다시 해주세요',
};

export const UserWithdrawalString = {
  withdrawal: '탈퇴하기',
  placeholderText:
    '혹시 불편하신 점이 있으셨나요? 소중한 의견 귀담아 듣겠습니다',
  tagNotServiceArea: '#서비스 지역이 아닙니다',
  alertContent: '정말 세탁특공대를 탈퇴하시겠어요?!',
  withdrawalAlertContent:
    '탈퇴 신청이 접수되었습니다.\n다시 만나뵙길 희망합니다.',
};

export const MainScreenString = {
  welcomeText: '안녕하세요,',
  userTitle: '님!',
  mainDescription:
    '가장 빠른 수거시간이 설정되었어요.\n지정된 시간에 세탁물을 문 앞에 두세요.',
  dawnDeliveryDescription:
    '새벽에 쓰르륵 수거합니다.\n자정까지 세탁물을 문 앞에 두세요.',
  disableMainDescription:
    '서비스 지역이 아닙니다.\n세특권을 오픈하면 가장 먼저 알려드리겠습니다.',
  alreadyReceivedOrder: '이미 접수된 주문이 있어요! 주문 내역을 확인해주세요~',
};

export const SideMenuString = {
  sideMenuArray: [
    { menuName: '📋 주문목록', pushName: 'OrderHistoryScreen' },
    { menuName: '🏷 가격표', pushName: 'PriceList' },
    { menuName: '💳 결제수단 관리', pushName: 'PaymentMethod' },
    { menuName: '👑 멤버십 혜택', pushName: 'membership' },
    { menuName: '📢 공지사항', pushName: 'Announcement' },
    { menuName: '🎧 고객센터', pushName: 'Faq' },
    { menuName: '🎁 친구초대', pushName: 'PresentFriend' },
    { menuName: '📖 세특 사용법', pushName: 'Web', url: URL_USER_GUIDE },
  ],
  pointText: '포인트',
  couponText: '쿠폰함',
};

export const Event = {
  finished: '종료',
};

export const CommonString = {
  asyncError: 'Sorry',
};

export const OrderChatBackPressPopupString = {
  title: '아직 주문이 접수되지 않았습니다.\n주문을 취소할까요?',
  cancel: '네, 취소할게요',
  keepGoing: '아니요, 계속 할게요',
  guideText: '세특 사용법',
};

export const previewString = {
  nextText: '다음',
  firstText: '앱을 열자마자\n가장 빠른 수거 시간을\n보여드립니다!',
  secondText: '물론, 다른날로\n변경할 수 있죠',
  thirdText: '주소 변경은 여기!',
  fourthText1: '가격표, 쿠폰함,\n주문내역, 고객센터 등',
  fourthText2: '궁금한 내용은\n모두 여기 있어요',
  closeText: '닫기',
  firstPreviewText: '12/31 (화)\n오후 8시 - 자정',
  previewEmoji: '🗓',
};

export const SelectPaymentString = {
  modal_title: '카드를 선택해주세요',
  bullet_modal_cardAdd: '+ 대표카드 등록하고 충전하기',
};

export const PointHistoryScreenString = {
  history: '🔖 History',
  unit: 'p',
  more_text: '더보기,',
  coin_unit: '원',
};

export const BuyBulletString = {
  buyBulletFail: '총알구입 실패! 다시 한번 시도해주시겠어요?',
  buyBulletSuccess: '총알구입에 성공하셨습니다',
  selectPayCard: '대표카드가 없습니다.\n 대표카드를 등록해주세요.',
};

export const CoinString = {
  failBuyCoinModal: '총알구입 실패! 다시 한번 시도해주시겠어요?',
};

export const OrderChatString = {
  today: '오늘',
  todayNight: '오늘 새벽',
  tmrNight: '내일 새벽',
  tmrAfterNight: '모레 새벽',
  comeInMidNight: '자정',
  initMsgTitle: '전까지 세탁물을 수거합니다.',
  initMsgDateFormat: 'ddd요일 M/D',
  initMsgHour: 'h시',
  initMsgSub: '까지 세탁물을 문 앞에 준비해주세요.',
};

export const settingTextArray = {
  setting: [
    { name: '닉네임 변경', page: 'TextInputScreen', key: PageName.CHANGE_NAME },
    { name: '주소 변경', page: 'AddressChange' },
    {
      name: '전화번호 변경',
      page: 'PhoneNumChange',
      key: PageName.CHANGE_PHONE,
    },
    // { name: '앱 리뷰 남기기', page: 'Linking' },
    { name: '서비스 정책보기', page: 'ServicePolicy' },
  ],
  appexit: [
    { name: '로그아웃', functionName: 'onPressLogout' },
    { name: '회원탈퇴', functionName: 'onPressWithdrawal' },
  ],
  companyInfo: [
    '주식회사 워시스왓',
    '사업자등록번호 865-88-00031',
    '통신판매업신고번호 제2020-서울금천-1744호',
    '이메일 cs@washswat.com',
    '대표자 예상욱, 남궁진아',
  ],
};

export const serviceOptionArray = {
  termsOfService: '서비스 이용약관',
  privacyPolicy: '개인정보 처리방침',
  locationTermOfService: '위치 기반 서비스 약관',
  cancel: '취소',
};

export const AlbumText = {
  basicFee: '기본요금',
  addFee: '추가요금',
  checkNote: '검수노트',
  receiptTitle: '📷 앨범',
  receiptButton: '전체 보기',
  title: '앨범',
  expireDate: '💁미디어 파일의 저장 기간은 최대 30일 입니다',
};

export const FAQText = {
  faq: '자주 묻는 질문',
  titles: {
    pickup: '수거',
    wait: '검수',
    ing: '세탁',
    delivery: '배달',
    over: '완료',
  },
  etc: '기타',
};

export const WebViewText = {
  appUpdate: '앱을 최신버전으로 업데이트하거나 종료 후 재시작해주세요.',
};
