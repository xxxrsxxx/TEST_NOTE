import { NativeModules, Platform } from 'react-native';
import { Navigation } from 'react-native-navigation';

import WashAlert from '../../alert';
import * as CommonUtils from '../../common';
import { Favorite } from '../strings';

export function show(send, finishedAction) {
  const { OS } = Platform;
  if (OS === 'ios') {
    CommonUtils.navShowModal({
      name: 'PaymentViaCardScreen',
      passProps: {
        data: send,
        finishedAction: json => {
          const { code, message } = json;
          if (code === 200) {
            finishedAction(json);
          } else {
            if (message) {
              WashAlert.showAlert(message, Favorite.ok);
            } else {
              /** 디폴트 메시지 **/
              WashAlert.showAlert(Favorite.fail, Favorite.ok);
            }
          }
        },
      },
    });
  } else {
    const { Payment } = NativeModules;
    Payment.show(JSON.stringify(send), (err, obj) => {
      if (obj) {
        if (typeof obj === 'string') {
          obj = JSON.parse(obj);
        }
        const { code, message, data } = obj;
        if (code == 200) {
          finishedAction({ code, message });
        } else if (code == 300) {
          /** 그냥 화면 닫은 경우 **/
        } else {
          if (message) {
            WashAlert.showAlert(message, Favorite.ok);
            /** 서버에서 돌려주는 메시지 **/
          } else {
            WashAlert.showAlert(Favorite.fail, Favorite.ok);
          }
        }
      }
    });
  }
}

export function showNaverPay({ data, finishedAction }) {
  const { OS } = Platform;
  if (OS === 'ios') {
    Navigation.showModal({
      stack: {
        children: [
          {
            component: {
              name: 'PaymentViaCardScreen',
              passProps: {
                data,
                finishedAction,
              },
            },
          },
        ],
      },
    });
  } else {
    const { Payment } = NativeModules;
    Payment.show(JSON.stringify(data), (err, obj) => {
      if (obj) {
        if (typeof obj === 'string') {
          obj = JSON.parse(obj);
        }
        const { code, message, data } = obj;
        if (code === 200) {
          finishedAction({ code, message });
        } else if (code === 300) {
          /** 그냥 화면 닫은 경우 **/
        } else {
          if (message) {
            WashAlert.showAlert(message, Favorite.ok);
            /** 서버에서 돌려주는 메시지 **/
          } else {
            WashAlert.showAlert(Favorite.fail, Favorite.ok);
          }
        }
      }
    });
  }
}

/**

 WashAlert.showConfirm(
 "test", "positive","negative",
 () => {
    // 'positive'
  },
 )

 WashAlert.showAlert(
 "content", "button"
 )
 WashAlert.showAlertWithCallback(
 "content", "button" , () => {

  }
 )
 **/
