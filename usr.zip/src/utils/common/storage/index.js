import { AsyncStorage, _ } from '../../../plugins';

export default function() {
  /**
   * @Dsc storage set fnc
   * type 1: 단수형 $storage.set('string',value);
   * type 2: 복수형 $storage.set([['string', 'value:string']])
   */
  this.set = (key, value) => {
    if (typeof key === 'string') {
      AsyncStorage.setItem(key, value);
    }
    if (Array.isArray(key)) {
      AsyncStorage.multiSet(key);
    }
    $_debug.storageLog('SET');
  };
  /**
   * @Dsc async storage get fnc
   * type 1: 단수형 $storage.get('string');
   * type 2: 복수형 $storage.get();
   */
  this.get = async key => {
    if (key) return AsyncStorage.getItem(key);

    if (key === undefined) {
      const keys = await AsyncStorage.getAllKeys();
      const data = await AsyncStorage.multiGet(keys);
      let result = {};
      _.forEach(data, (e, i) => {
        result[e[0]] = e[1];
      });
      return result;
    }
    $_debug.storageLog('GET');
  };

  this.getArray = array => {
    return AsyncStorage.multiGet(array);
  };

  this.delete = key => {
    AsyncStorage.removeItem(key);
  };

  this.allClear = async () => {
    try {
      const keys = await AsyncStorage.getAllKeys();
      await AsyncStorage.multiRemove(keys);
    } catch (e) {
      console.log('allClear', e);
    }
    //devStorage('CLEAR');
  };
}
