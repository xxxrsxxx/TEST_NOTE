// utils plugin
import { _ } from '../../../plugins';

/**
 * @dsc debugger inject code
 *
 * function devHandler() {
 *  const _debug = $_debug;
 *  const _status = $_status; //리덕스 status module 연동
 *  const _debugStart = function () {$_status.actions.statusHandler("debug:true")}
 *  return {
 *    _debug,
 *    _status,
 *    _debugStart
 *  };
 * }
 * const $devTool = devHandler();
 * const $log = devLog();
 * @url https://www.notion.so/washswat/DEBUG-DETIAL-36a4f6b7b90a4e55b2af6cf010b1d39a
 */

export default function() {
  const styles = [
    'background: #fff',
    'border: 1px solid #3E0E02',
    'color: red',
    'display: block',
    'line-height: 40px',
    'text-align: center',
    'font-weight: bold',
    'font-size: 20px',
  ].join(';');

  this.storageLog = _.debounce(type => {
    const comment = `%c ============Show Storage ${type}============= `;
    console.log(comment, styles);
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ &&
      showAsyncStorageContentInDev();
  }, 1000);
}
