import { navPush, navShowModal } from '../../common';
import {
  ORDER_CHAT_SCREEN_NAME,
  WEB_VIEW_SCREEN_NAME,
  ADDRESS_CHANGE_SCREEN_NAME,
  PAYMENT_METHOD_SCREEN_NAME,
  MEMBERSHIP_CANCEL_REASON_SCREEN_NAME,
  JOIN_MEMBER_SCREEN_NAME,
} from '../../../static/screen-name';

/**
 *
 * navPush utils 사용방법
 *  - 원하는 Screen 이름의 함수 호출
 *  - param으로 componentId, passProps, showModal를 객체로 감싸서 넣는다.
 *  - showModal 형태를 하고싶은 경우 param에 showModal: true를 추가해준다.
 *
 * navPush utils 만든 의도
 *  - navigation name을 호출 할 때마다 직접 입력하지 못하도록하여 human error 발생확률을 낮추기 위함
 *
 * written by Charles
 */

const selectNavType = props => {
  if (props.showModal) navShowModal(props);
  else navPush(props);
};

// WebViewScreen
export const navPushWebViewScreen = ({ componentId, passProps, showModal }) => {
  selectNavType({
    componentId,
    name: WEB_VIEW_SCREEN_NAME,
    passProps,
    showModal,
  });
};

// OrderChatScreen
export const navPushOrderChatScreen = ({
  componentId,
  passProps,
  showModal,
}) => {
  selectNavType({
    componentId,
    name: ORDER_CHAT_SCREEN_NAME,
    passProps,
    showModal,
  });
};

// AddressChange
export const navPushAddressChangeScreen = ({
  componentId,
  passProps,
  showModal,
}) => {
  selectNavType({
    componentId,
    name: ADDRESS_CHANGE_SCREEN_NAME,
    passProps,
    showModal,
  });
};

// PaymentMethod
export const navPushPaymentMethodScreen = ({
  componentId,
  passProps,
  showModal,
}) => {
  selectNavType({
    componentId,
    name: PAYMENT_METHOD_SCREEN_NAME,
    passProps,
    showModal,
  });
};

// MembershipCancelReason
export const navPushMembershipCancelReasonScreen = ({
  componentId,
  passProps,
  showModal,
}) => {
  selectNavType({
    componentId,
    name: MEMBERSHIP_CANCEL_REASON_SCREEN_NAME,
    passProps,
    showModal,
  });
};

// JoinMember
export const navPushJoinMemberScreen = ({
  componentId,
  passProps,
  showModal,
}) => {
  selectNavType({
    componentId,
    name: JOIN_MEMBER_SCREEN_NAME,
    passProps,
    showModal,
  });
};
