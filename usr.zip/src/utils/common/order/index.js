import React from 'react';
import { Text } from 'react-native';
import { Navigation } from 'react-native-navigation';
import * as CommonUtils from '../../common';
import {
  Favorite,
  OrderHistoryText,
  OrderText,
  CommonString,
} from '../strings';

import { Font } from '../../style';
const { washswatColor } = Font;
import * as PageName from '../../../vo/PageName';

export const getPayStatusObject = ({
  status,
  pickup,
  deliveryTime,
  preOptions,
  alert,
  issue,
  history,
}) => {
  /*
   * status: pickup, wait, ing:인수증도착, delivery, over
   * */
  if (status === 'pickup' || status === 'wait') return;
  if (pickup && pickup.payType && pickup.payType === 'later') {
    const deliveryCancel = $_.find(
      history,
      o => o && o.info && o.info.type && o.info.type === 'deliveryCancel',
    );
    if (
      status === 'delivery' &&
      deliveryCancel &&
      pickup &&
      pickup.payType &&
      pickup.payType === 'later'
    ) {
      return {
        payStatus: OrderHistoryText.payStatusFail,
        color: washswatColor.red,
      };
    } else {
      if (preOptions && preOptions.payment && preOptions.payment.payType) {
        if (preOptions.payment.payType === 'later') {
          return {
            payStatus: OrderHistoryText.payStatusLater,
            color: washswatColor.black,
          };
        } else {
          return {
            payStatus: OrderHistoryText.payStatusAuto,
            color: washswatColor.blue,
          };
        }
      }
      return undefined;
    }
  } else {
    if (alert && alert.length > 0 && alert[0].button) {
      const { action, name, needPayPrice, needRefundPrice } = alert[0].button;
      switch (action) {
        case 'payment':
          return {
            payStatus: OrderHistoryText.payStatusAdd,
            color: washswatColor.blue,
          };
        case 'refund':
          return {
            payStatus: OrderHistoryText.payStatusRefund,
            color: washswatColor.blue,
          };
        default:
          return undefined;
      }
    }
  }
  return undefined;
};

export const getWashStatus = ({ status, pickup, history }) => {
  switch (status) {
    case 'pickup':
      return OrderHistoryText.washStatusPickup;
    case 'wait':
      return OrderHistoryText.washStatusWait;
    case 'ing':
      return OrderHistoryText.washStatusIng;
    case 'delivery':
      const deliveryCancel = $_.find(
        history,
        o => o && o.info && o.info.type && o.info.type === 'deliveryCancel',
      );
      if (
        status === 'delivery' &&
        deliveryCancel &&
        pickup &&
        pickup.payType &&
        pickup.payType === 'later'
      ) {
        return OrderHistoryText.washStatusFail;
      } else {
        return OrderHistoryText.washStatusDelivery;
      }
    case 'over':
      return OrderHistoryText.washStatusOver;
    default:
      return undefined;
  }
};

export const getDateOfMission = ({ startTime, endTime }) => {
  const timeMoment = $_moment(startTime);
  const endTimeMoment = $_moment(endTime);
  const monthDay = timeMoment.format('M/D');
  const dayOfWeek = CommonUtils.convertDayOfWeekForKorean({
    number: timeMoment.day(),
    dayOfWeeks: OrderHistoryText.dayOfWeeks,
  });
  const amPm = timeMoment.format('a');
  let timeHour = timeMoment.format('k:mm');
  const endTimeHour = endTimeMoment.format('k:mm');
  if (timeHour === '24:00') {
    timeHour = '00:00';
  }
  return `${monthDay} (${dayOfWeek}) ${amPm} ${timeHour} - ${endTimeHour}`;
};

const convertHour = hour => {
  if (hour === 0 || hour === 24) {
    return Favorite.midnight;
  }
  if (hour === 12) {
    return Favorite.noon;
  }
  return `${hour}${Favorite.hour}`;
};

export const getDateOfPickupDelivery = ({
  status,
  mission,
  pickup,
  deliveryOver,
  issue,
  history,
}) => {
  if (!(mission && mission.pickup && mission.delivery)) {
    return '';
  }
  let date = '';
  let message = '';
  switch (status) {
    case 'pickup':
      // 수거 @11/01 (목) 오후 4:00 - 6:00
      date = getDateOfMission({
        startTime: mission.pickup.pickupTime,
        endTime: mission.pickup.endTime,
      });
      message = `${OrderText.pickup}`;
      break;
    case 'wait':
      // 인수증 발행 @11/02 (금) 오전 10:00
      // const pickup = mission.pickup;
      if (pickup) {
        const timeMoment = $_moment(pickup.regdate);
        const pickupDate = timeMoment.format('M/D');
        const dayOfWeek = CommonUtils.convertDayOfWeekForKorean({
          number: timeMoment.day(),
          dayOfWeeks: OrderHistoryText.dayOfWeeks,
        });
        date = `${pickupDate} (${dayOfWeek}) ${OrderHistoryText.receiptExpectedTime}`;
        message = `${OrderText.receiptPublish}`;
      }
      break;
    case 'ing':
    case 'delivery':
      // 배송 @11/03 (토) 오후 4:00 - 24:00
      const undecidedTime = $_.find(
        issue || [],
        o => o && o.isIssue && o.code === 'undecidedTime',
      );
      const deliveryCancel = $_.find(
        history,
        o => o && o.info && o.info.type && o.info.type === 'deliveryCancel',
      );
      if (
        status === 'delivery' &&
        deliveryCancel &&
        pickup &&
        pickup.payType &&
        pickup.payType === 'later'
      ) {
        date = OrderHistoryText.payPlz;
      } else {
        if (
          undecidedTime ||
          $_moment() >
            $_moment(new Date(mission.delivery.endTime)).add(12, 'hour')
        ) {
          // 배송일을 예약해주세요
          date = OrderHistoryText.deliveryReservation;
          message = '';
        } else {
          date = getDateOfMission({
            startTime: mission.delivery.deliveryTime,
            endTime: mission.delivery.endTime,
          });
          message = `${OrderText.delivery}`;
        }
      }
      break;
    case 'over':
    case 'complete':
      // 배송 완료 @11/3 (토) 오후 8:45
      let result = '이번 주문경험은 어떠셨나요?';
      if (deliveryOver) {
        const { regdate } = deliveryOver;
        const deliveryOverMoment = $_moment(regdate);
        const dayOfWeek = CommonUtils.convertDayOfWeekForKorean({
          number: deliveryOverMoment.day(),
          dayOfWeeks: OrderHistoryText.dayOfWeeks,
        });
        result = `${OrderText.complete} @${deliveryOverMoment.format(
          'M/D',
        )} (${dayOfWeek}) ${deliveryOverMoment.format(
          'a',
        )} ${deliveryOverMoment.format('k:mm')}`;
      }
      return result;
    default:
      return undefined;
  }
  return `${message && `${message} `}${date && `@${date}`}`;
};

export const convertTextWithRegex = ({ text, font, color }) => {
  const regexGlobal = /\*\*(.+?)\*\*/g;
  if (regexGlobal.test(text)) {
    const matches = text.match(regexGlobal);
    const splits = text.split(regexGlobal);
    const views = [];
    let check = false;
    $_.map(splits, (splitText, index) => {
      if (!$_.isEmpty(splitText)) {
        const finded = $_.find(
          matches,
          matchText => matchText.indexOf(splitText) > -1,
        );
        views.push(
          <Text
            key={index}
            style={{
              ...font,
              color,
              lineHeight: 22,
              fontWeight: finded ? 'bold' : 'normal',
            }}
          >
            {splitText}
          </Text>,
        );
      }
    });
    return <Text>{views}</Text>;
  } else {
    return <Text style={{ ...font, color, lineHeight: 22 }}>{text}</Text>;
  }
};

export const cancelOrder = ({
  _id,
  OrderAction,
  componentId,
  OrderHistoryAction,
  OrderHistoryState,
  passScreen,
}) => {
  // const { orderItem } = OrderHistoryState;
  // const { _id } = orderItem;
  CommonUtils.navPush({
    componentId,
    name: 'TextInputScreen',
    passProps: {
      pageName: PageName.ORDER_CANCEL,
      multiLine: true,
      finishedAction: reason => {
        OrderAction.cancelOrder({
          objectId: _id,
          reason,
          callback: () => {
            OrderHistoryAction.setOrderInProgress();
            if (passScreen !== 'OrderHistoryListContainer') {
              Navigation.dismissModal(componentId);
            }
          },
          componentId,
        });
      },
    },
  });
};

export const getCircleText = ({ pickup }) => {
  if (pickup && pickup.pickupTime && pickup.endTime) {
    let result = '';
    if ($_moment(pickup.pickupTime).hour() === 0) {
      const dawnMoment = $_moment(pickup.pickupTime).subtract(10, 'minutes');
      result +=
        dawnMoment.format(`MM/DD (ddd)`) + '\n' + dawnMoment.format(`H시 m분`);
    } else {
      result +=
        $_moment(pickup.pickupTime).format(`MM/DD (ddd)`) +
        '\n' +
        $_moment(pickup.pickupTime).format(`A h시`);
    }
    if ($_moment(pickup.endTime).hour() === 0) {
      result += ` - 자정`;
    } else {
      result += ` - ${$_moment(pickup.endTime).format('h시')}`;
    }
    return result;
  } else {
    return CommonString.asyncError;
  }
};
