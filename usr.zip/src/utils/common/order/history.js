export const isDeliveryFail = ({ order }) => {
  if (!order) {
    return false;
  }
  const { history, status, pickup } = order;
  if (!history || !status || !pickup) {
    return false;
  }
  const deliveryCancel = $_.find(
    history,
    o => o && o.info && o.info.type && o.info.type === 'deliveryCancel',
  );
  return (
    status === 'delivery' &&
    deliveryCancel &&
    pickup &&
    pickup.payType &&
    pickup.payType === 'later'
  );
};
