import React from 'react';
import myPageScreen from '../../../static/json/mypage/screen.json';

//console.log('combine', myPage);
const MyPageContext = React.createContext({
  loadData: myPageScreen,
});

export default MyPageContext;
