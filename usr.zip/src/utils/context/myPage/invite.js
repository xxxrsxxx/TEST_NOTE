import React from 'react';
import inviteContext from '../../../static/json/mypage/invite.json';

const InviteContext = React.createContext({
  loadData: inviteContext,
});

export default InviteContext;
