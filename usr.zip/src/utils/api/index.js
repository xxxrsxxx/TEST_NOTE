import axios from 'axios';
import DeviceInfo from 'react-native-device-info';
import * as Keys from '../type/key';
import { globalDataSplit } from '../common';
import WashAlert from '../alert';
import { Favorite } from '../common/strings';

function axiosInstance(storage, update) {
  const init = async () => {
    /**
     * @name _debugCheck
     * @dsc 어드민 테스트 API 등록 체크
     * @returns {Promise<void>}
     * @private
     */
    const _debugCheck = async () => {
      const svcShard = storage[Keys.SVC_SHARD];
      const NODE_ENV = storage[Keys.NODE_ENV];
      const baseURL_WashAPI = storage[Keys.BASE_URL_WASH_API];
      const baseURL_WWWAPI = storage[Keys.BASE_URL_WWW_API];

      const apiConfig = {
        api: {
          debug: true,
          debugUrl: {
            DEFAULT_URL: '',
            DEFAULT_URL_WEB: '',
          },
        },
      };

      if (baseURL_WashAPI || baseURL_WWWAPI) {
        if (baseURL_WashAPI)
          apiConfig.api.debugUrl.DEFAULT_URL = baseURL_WashAPI;

        if (baseURL_WWWAPI)
          apiConfig.api.debugUrl.DEFAULT_URL_WEB = baseURL_WWWAPI;

        await $_status.actions.statusHandler(apiConfig);
      }
      if (svcShard && NODE_ENV === 'production') {
        const { api, web } = JSON.parse(svcShard);
        if (api || web) {
          /** 데이터 전부 지워서 로그아웃 되도록 **/
          await $_storage.allClear();
          if (api) $_storage.set(Keys.BASE_URL_WASH_API, api);
          if (web) $_storage.set(Keys.BASE_URL_WWW_API, web);
          WashAlert.showAlert(
            '개발 계정으로 로그인! 앱을 종료 후 다시 실행 해주세요',
            Favorite.ok,
          );
          return;
        }
      }
    };
    await _debugCheck();
  };

  /**
   * @dsc setting aixos instance
   * @param params:object
   * @returns {AxiosInstance}
   */
  function createInstance(params) {
    const _storage = storage;
    let headers = {};
    let accessToken = _storage[Keys.ACCESS_TOKEN] || null;
    let _appVersion = '';
    let _codePushLabel = '';

    if (params && params.userAccessToken) accessToken = params.userAccessToken;
    if (params && params.headers) headers = { ...params.headers };

    headers['x-access-token'] = accessToken;
    const _codePush = () => {
      const _update = update;

      _appVersion = DeviceInfo.getVersion();

      function getAppInfo() {
        const { appVersion, label } = _update;
        if (appVersion) {
          _appVersion = appVersion;
          _codePushLabel = label;
        } else {
          _appVersion = DeviceInfo.getVersion();
        }
      }

      if (_update) getAppInfo();
      headers[
        'user-agent'
      ] = `washswat/${_appVersion}-${_codePushLabel} (+Application)`;

      $_storage.set(
        globalDataSplit({
          [Keys.CODE_PUSH_VERSION]: _appVersion,
          [Keys.CODE_PUSH_LABEL]: _codePushLabel,
        }),
      );
    };
    _codePush();

    const instance = axios.create({
      headers,
      timeout: 5000,
    });
    return instance;
  }
  /**
   * @dsc 어드민 디버깅 설정시 유알엘 교체
   * @param url:string
   * @returns {string}
   */
  function changeUrl(url) {
    const splitUrl = url.split('.com/');
    const _deg = $_status.state.api.debugUrl;
    let result = '';
    for (let e in _deg) {
      const value = _deg[e];
      const confirm = value.indexOf(splitUrl[0]) > -1;
      if (confirm) result = `${value}${splitUrl[1]}`;
    }
    return result;
  }

  let instance = createInstance();

  /**
   * @param url
   * @param params
   * @param data
   * @returns {Promise<AxiosResponse<any>>}
   */

  async function post(url, params, data) {
    let _url = url;
    try {
      const { debug } = $_status.state.api;

      if (params && params.userAccessToken) instance = createInstance(params);
      if (debug) _url = changeUrl(url);
      const res = await instance.post(_url, data, { params });
      return res;
    } catch (e) {
      console.log(
        '%c ====================postAxios error====================',
        styles.console,
        '\n URL',
        _url,
        '\n PARAMS:',
        params,
        '\n DATA:',
        data,
        '\n ERROR:',
        e,
      );
    }
  }

  /**
   *
   * @param url
   * @param params
   * @returns {Promise<AxiosResponse<any>>}
   */
  async function get(url, params) {
    let _url = url;
    try {
      const { debug } = $_status.state.api;

      if (params && params.userAccessToken) instance = createInstance(params);
      if (debug) _url = changeUrl(url);

      const res = await instance.get(_url, { params });
      return res;
    } catch (e) {
      console.log(
        '%c ====================getAxios error====================',
        styles.console,
        '\n URL:',
        _url,
        '\n PARAMS:',
        params,
        '\n ERROR:',
        e,
      );
    }
  }

  async function patch(url, params, data) {
    let _url = url;
    try {
      const { debug } = $_status.state.api;
      const isParams = params && params.headers;
      if (isParams) instance = createInstance(params);
      if (debug) _url = changeUrl(url);
      const res = await instance.patch(_url, data, { params });
      return res;
    } catch (e) {
      console.log(
        '%c ====================patchAxios error====================',
        styles.console,
        '\n URL',
        _url,
        '\n PARAMS:',
        params,
        '\n DATA:',
        data,
        '\n ERROR:',
        e,
      );
    }
  }

  /**
   * @param url
   * @param params
   * @param data
   * @returns {Promise<AxiosResponse<any>>}
   */

  async function put(url, params, data) {
    let _url = url;
    try {
      const { debug } = $_status.state.api;
      if (debug) _url = changeUrl(url);
      const res = await instance.put(_url, data, { params });
      return res;
    } catch (e) {
      console.log(
        '%c ====================putAxios error====================',
        styles.console,
        '\n URL',
        _url,
        '\n PARAMS:',
        params,
        '\n DATA:',
        data,
        '\n ERROR:',
        e,
      );
    }
  }

  return {
    init,
    post,
    get,
    patch,
    put,
  };
}
const styles = {
  console: [
    'background: yellow',
    'border: 1px solid #3E0E02',
    'color: red',
    'display: block',
    'line-height: 40px',
    'text-align: center',
    'font-weight: bold',
    'font-size: 20px',
  ].join(';'),
};

export default axiosInstance;
