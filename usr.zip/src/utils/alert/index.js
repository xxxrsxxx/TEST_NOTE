import { NativeModules } from 'react-native';

const Module = {
  showConfirm: (text, positive, negative, callback) => {
    NativeModules.WashAlert.showConfirm(text, positive, negative, result => {
      if (callback) {
        callback(result);
      }
    });
  },

  showToast: content => {
    NativeModules.WashAlert.showToast(content);
  },

  showAlert: (content, button, callback) => {
    if (callback) {
      NativeModules.WashAlert.showAlertWithCallback(content, button, result => {
        callback(result);
      });
    } else {
      NativeModules.WashAlert.showAlert(content, button);
    }
  },
  showAlertWithCallback: (content, button, callback) => {
    Module.showAlert(content, button, callback);
  },
  showConfirmPromise: async (text, positive, negative) => {
    try {
      const result = await new Promise((resolve, reject) => {
        Module.showConfirm(text, positive, negative, result => {
          resolve(result);
        });
      });
      return result;
    } catch (e) {
      throw e;
    }
  },
  showAlertPromise: async (content, button) => {
    try {
      const result = await new Promise((resolve, reject) => {
        Module.showAlert(content, button, result => {
          resolve(result);
        });
      });
      return result;
    } catch (e) {
      throw e;
    }
  },
};

module.exports = Module;

/**

 WashAlert.showConfirm(
 "test", "positive","negative",
 () => {
    // ('positive')
  },
 )

 WashAlert.showAlert(
 "content", "button"
 )
 WashAlert.showAlertWithCallback(
 "content", "button" , () => {

  }
 )
 **/
