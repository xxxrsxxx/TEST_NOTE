import { Alert, Platform } from 'react-native';
import Mixpanel from 'react-native-mixpanel';
import { ChannelIO } from 'react-native-channel-plugin';
import messaging from '@react-native-firebase/messaging';
import PushNotificationIOS from '@react-native-community/push-notification-ios';
import * as CommonUtils from '../common/index';
import * as Keys from '../type/key';
import * as ServerUtils from '../type/server';

const iOS_NOTIFICATION_TYPES = [
  { type: 'notification', opened: false },
  { type: 'localNotification', opened: false },
  { type: 'register', opened: false },
  { type: 'registrationError', opened: false },
];
const FirebaseMount = async (getPermission, notificationDataFromSplash) => {
  if (getPermission && !__DEV__) {
    await checkPermission();
    const existsToken = await $_storage.get(Keys.TOKEN);
    if (existsToken) {
      saveThirdParty(existsToken);
    }
  }
  let treadId = null;
  if (Platform.OS === 'ios') {
    const notificationHandler = async notification => {
      try {
        notification.finish(PushNotificationIOS.FetchResult.NoData);
        let data = notification.getData();
        let random = Math.random() * (1000 - 100) + 100;
        await new Promise(resolve =>
          setTimeout(() => {
            resolve();
          }, random),
        );
        if (data && data.aps && data.aps['thread-id']) {
          if (treadId === data.aps['thread-id']) {
            return;
          }
          treadId = data.aps['thread-id'];
        }
        await onMessage(data);
      } catch (e) {}
    };
    PushNotificationIOS.setApplicationIconBadgeNumber(0);
    let initData = await PushNotificationIOS.getInitialNotification();
    if (initData && initData.getData()) {
      await notificationHandler(initData);
      let alert = initData.getAlert();
      if (alert && alert.action) {
        await onMessage({ aps: { alert } });
      } else {
        await notificationHandler(initData);
      }
      // Alert.alert(JSON.stringify(initData))
      //
    }
    PushNotificationIOS.addEventListener('notification', notificationHandler);
    PushNotificationIOS.addEventListener(
      'localNotification',
      notificationHandler,
    );

    // PushNotificationIOS.getDeliveredNotifications((data) => {
    //   Alert.alert('getDeliveredNotifications')
    //
    // })
    // PushNotificationIOS.getScheduledLocalNotifications((data) => {
    //   Alert.alert('getScheduledLocalNotifications')
    // })

    let index = $_.findIndex(iOS_NOTIFICATION_TYPES, { type: 'notification' });
    if (index > -1) {
      iOS_NOTIFICATION_TYPES[index].opened = true;
    }
  } else {
    console.log(' notificationDataFromSplash', notificationDataFromSplash);

    if (notificationDataFromSplash) {
      /** 스플레시에서 타고 들어온 경우 **/
      try {
        await onMessage(notificationDataFromSplash);
      } catch (e) {}
    }
    /**
     * Foreground :
     When the application is open and in view.
     * Background	:
     When the application is open, however in the background (minimised).
     This typically occurs when the user has pressed the "home" button on the device or has switched to another app via the app switcher.
     *  Quit	:
     When the device is locked or application is not active or running. The user can quit an app by "swiping it away" via the app switcher UI on the device.
     */

    /** Foreground **/
    messaging().onMessage(async remoteMessage => {
      console.log('Foreground', remoteMessage.notification);
      await onMessage(remoteMessage, true);
    });
    /** Background ||  Quit **/
    messaging().setBackgroundMessageHandler(async remoteMessage => {
      console.log('Background', remoteMessage.notification);
      await onMessage(remoteMessage, true);
    });

    /**
     * Assume a message-notification contains a "type" property in the data payload of the screen to open
     */

    messaging().onNotificationOpenedApp(async remoteMessage => {
      console.log(
        'Washswat-Firebase',
        'Notification caused app to open from background state:',
        remoteMessage.notification,
      );
      await onMessage(remoteMessage);
    });

    try {
      /**
       * Check whether an initial notification is available
       */
      let rm = messaging().getInitialNotification();
      if (rm) {
        console.log('Washswat-Firebase', 'available', rm.notification);
        await onMessage(rm);
      }
    } catch (e) {}
  }
};

const onMessage = async (remoteMessage, bypass) => {
  try {
    let data;
    console.log('Washswat-Firebase', 'onMessage - init', remoteMessage);
    if (Platform.OS === 'ios') {
      if (remoteMessage && remoteMessage.data) {
        data = remoteMessage.data;
      } else if (remoteMessage && remoteMessage.aps) {
        data = remoteMessage;
      }
    } else {
      if (bypass) {
        return;
      }
      if (!remoteMessage || !remoteMessage.notification) {
        return;
      }
      data = remoteMessage;
    }
    console.log('Washswat-Firebase', 'onMessage - onMessage', remoteMessage);
    if (!data) {
      return;
    }
    /** WASHSWAT 처리 사항 **/
    if (Platform.OS == 'ios') {
      const {
        aps: {
          alert: { action },
        },
      } = data;
      if (action) {
        const { transactionId, screen, passProps } = action;
        let stop = await handlePushAction(transactionId, screen, passProps);
        if (stop) {
          return;
        }
      }
    } else {
      let {
        data: { transactionId, screen, passProps },
      } = data;
      if (
        passProps &&
        typeof passProps === 'string' &&
        passProps.indexOf('{') > -1
      ) {
        passProps = JSON.parse(passProps);
      }
      let stop = await handlePushAction(transactionId, screen, passProps);
      console.log(
        'transactionId , screen , passProps',
        transactionId,
        screen,
        passProps,
        stop,
      );
      if (stop) {
        return;
      }
    }
  } catch (e) {
    console.log('Washswat-Firebase', 'onMessage - error', e);
  }

  try {
    let isChannelPush = await ChannelIO.isChannelPushNotification(
      remoteMessage,
    );
    if (isChannelPush) {
      await ChannelIO.receivePushNotification(remoteMessage);
    }
  } catch (e) {}
};

const handlePushAction = async (transactionId, screen, passProps) => {
  let isAppPush = transactionId ? true : false;
  try {
    const _storage = await $_storage.get();
    const existsCheck = _storage[transactionId];
    if (!existsCheck) {
      await $_storage.set(transactionId, transactionId);
      /**
       * Update TO SERVER
       */

      console.log(' Update TO SERVER');

      try {
        await $_axios.put(ServerUtils.NOTIFICATION, {}, { transactionId });
      } catch (e) {
        console.log('notification', e);
      }
      if (screen) {
        CommonUtils.navShowModal({ name: screen, passProps });
      }
    }
  } catch (e) {}
  return isAppPush;
};

const checkPermission = async () => {
  try {
    if (Platform.OS === 'ios') {
      console.log('checkPermission');
      await PushNotificationIOS.requestPermissions();

      PushNotificationIOS.addEventListener('register', token => {
        console.log('APP_TOKEN', token);
        if (token) {
          saveToken(token);
        }
      });
      PushNotificationIOS.addEventListener('registrationError', token => {
        console.log('APP_TOKEN - registrationError ', token);
        // if (token) {
        //   saveToken(token);
        // }
      });

      let index = $_.findIndex(iOS_NOTIFICATION_TYPES, { type: 'register' });
      if (index > -1) {
        iOS_NOTIFICATION_TYPES[index].opened = true;
      }
    } else {
      let token = await messaging().getToken();
      if (token) {
        await saveToken(token);
      }
      messaging().onTokenRefresh(async token => {
        await saveToken(token);
      });
    }
  } catch (e) {
    console.log('error', e);
  }
};

const saveToken = async token => {
  try {
    const _storage = await $_storage.get();
    const existsToken = _storage[Keys.TOKEN];
    const uid = _storage[Keys.USER_ID];
    // showAlert(`${token === existsToken} | ${token}`, IN_DEBUG_MODE, 'ok');
    // !IN_DEBUG_MODE &&
    if (existsToken != token) {
      // if(true){
      await $_storage.set(Keys.TOKEN, token);
      saveThirdParty(token);
      await $_axios.post(
        ServerUtils.SET_TOKEN,
        {},
        {
          uid,
          token,
          deviceType: Platform.OS,
        },
      );
    }
  } catch (e) {}
};

const saveThirdParty = token => {
  if (Platform.OS === 'ios') {
    // Mixpanel.clearPushRegistrationId();
    Mixpanel.addPushDeviceToken(token);
  } else {
    Mixpanel.setPushRegistrationId(token);
  }
  ChannelIO.initPushToken(token);
};

const FirebaseUnMount = async () => {
  console.log('Washswat-Firebase', 'unmount');
  // for (let row of iOS_NOTIFICATION_TYPES) {
  //   if (row.opened) {
  //     PushNotificationIOS.removeEventListener(row.type);
  //   }
  // }
};

module.exports = {
  FirebaseMount,
  FirebaseUnMount,
};
