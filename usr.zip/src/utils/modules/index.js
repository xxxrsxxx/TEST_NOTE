import { NativeModules } from 'react-native';
module.exports = NativeModules.Invite;

/**

 Invite.sendKakao(
 name, myCode,
 (err,result) => {
    const {code} = result;
    // ('positive')
  },
 )

 **/
