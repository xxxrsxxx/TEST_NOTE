export const GLOBAL_DATA = 'globalData';
export const CERTIFICATE_NUMBER = 'certificateNumber';
export const PHONE_NUMBER = 'phone';
export const REMAINING_ADDRESS = 'remaining_address';
export const SAVE_ADDRESS_NAME = 'save_address_name';
export const COMMON_PORCH_INPUT = 'commonPorchInput';
export const USE_POINT = 'usePoint';
export const SECURITY_CALL = 'securityCall';
export const AWS_S3_ACCESS_KEY = 'AKIAJLI57WNA74JLYHSA';
export const AWS_S3_SECRET_ACCESS_KEY =
  '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';
export const CONFIRM_NAME = 'orderConfirmName';
export const COMMON_ENTRANCE = 'commonEntrance';
export const REGIST_COMMON_ENTRANCE = 'registCommonEntrance';
export const ROADADDRESS = 'roadAddress';
export const ADDDRESSOTHERS = 'addressOthers';
export const ADDRESS_TITLE = 'addressTitle';
export const APP_PUSH = 'appPush';
export const VERSION_CODE = 'versionCode';
export const MY_CODE = 'myCode';
export const LAT = 'lat';
export const LON = 'lon';
export const IS_ORDER_WHEN_DELIVERY_GUIDE = 'isOrderWhenDeliveryGuide';
export const POINT = 'point';
export const COUPON = 'coupon';
export const PICKUP_TIME = 'pickupTime';

export const DOOR_CODE = 'doorCode';
export const DEEP_LINK_URL = 'DEEP_LINK_URL';
export const APP_SCHEME = 'APP_SCHEME';
export const KAKAO_LINK = 'kakaolink';
export const APNS_TOKEN = 'APNS_TOKEN';
export const APPS_FLYER_ID = 'APPS_FLYER_ID';

export const SCENARIO_ORDER_COMPLETE = 'SCENARIO_ORDER_COMPLETE';
export const INDEX_ORDER_HISTORY = 2;
export const KAKAO_INVITE_ID = '14737';
export const SENDERID = '1085975131826';

export const FEEDBACK_IS_REGIST = 'feedback_is_regist';
export const MAIN_POPUP_NEVER_OPEN = 'mainPopupNeverOpen'; // 메인 팝업 다시보지않기
export const POPUP_ID = 'popupId';
export const DISABLED_POPUP_DATE = 'disabledPopupDate';
export const POPUP_CLOSE = 'popupClose';
export const IS_PREVIEW = 'isPreview';
export const ORDER_HISTROTY_DETAIL_ORDERID = 'OrderHistoryDetailOrderId';

export const PROGRESS = 'progress';
export const LAST = 'last';

/*
Globaldata 따로 작성
 */
export const CODE_PUSH_LABEL = 'codePushLabel';
export const CODE_PUSH_VERSION = 'codePushVesion';
export const USER_ID = 'uid';
export const USER_PHONE = 'phone';
export const USER_TYPE = 'userType';
export const USER_TYPE_MEMBER = 'member';
export const USER_TYPE_NORMAL = 'normal';
export const USER_NAME = 'name';
export const CENTER_ID = 'centerId';
export const RESTORE_ID = 'RESTORE_ID';
export const FRESH_CHAT_USER_ID = 'FRESH_CHAT_USER_ID';
export const USER_ROAD_ADDRESS = 'roadAddress';
export const USER_ADDRESS = 'address';
export const USER_ADDRESS_OTHERS = 'addressOthers';
export const TOKEN = 'token';
export const IS_SERVICE_CHECK = 'isService';
export const ACCESS_TOKEN = 'accessToken'; // API 호출시 header에 전달할 때 사용
export const KEY_CHANNEL = 'ee01b6fb-0906-442a-97c3-89e744c3618b';
export const SECTOR = 'sector';
export const SVC_SHARD = 'svcShard';
export const BASE_URL_WASH_API = 'BASE_URL_WASH_API';
export const BASE_URL_WWW_API = 'BASE_URL_WWW_API';
export const NODE_ENV = 'NODE_ENV';

export const CONNECT_MEMBER_BENEFIT = 'connectMemberBenefit';

export const DrawerAnimationCloseTime = 400;
export const CHAT_VERSION = 2;
/*
reducer
 */
export const GLOBAL_KEY_SET_PICKUP_TIME = 'GLOBAL_KEY_SET_PICKUP_TIME';
