import { rootConfig } from '../../../config';

const styles = [
  'background: yellow',
  'border: 1px solid #3E0E02',
  'color: black',
  'display: block',
  'line-height: 40px',
  'text-align: center',
  'font-weight: bold',
  'font-size: 20px',
].join(';');

console.log(
  '%c ====================rootConfig====================',
  styles,
  '\n',
  rootConfig,
);
window.$_ENVMODE = rootConfig.ENVMODE;

export const DEFAULT_URL = rootConfig.API_URL;
export const DEFAULT_URL_WEB = rootConfig.API_URL_WEB;
export const NAVERPAY_URL = rootConfig.NAVERPAY_URL;

export const URL_CLAUSE =
  'https://www.notion.so/washswat/2534d982aea14101afc9a5d4b0d75542'; // 서비스 이용약관
export const URL_PRIVACY =
  'https://www.notion.so/washswat/865b051adf9b4b4aa2327fedaae96fa9'; // 개인정보 처리방침
export const URL_LOCATION_CLAUSE =
  'https://www.notion.so/washswat/c483e219dd9d4cc89d602fe6265f4d30'; // 위치기반서비스 약관
export const URL_SERVICE_POLICY =
  'https://www.notion.so/washswat/a709235273a74851bb0a01b71c3b1650'; // 서비스 정책
export const CHECK_OFFLINE = `${DEFAULT_URL}health_check`;
export const PATH_GLOBALDATA = `${DEFAULT_URL}user/global`;
export const SET_TOKEN = `${DEFAULT_URL}user/token`;
export const NOTIFICATION = `${DEFAULT_URL}notification`;
export const MAIN_API = `${DEFAULT_URL}screen/v5/main`;

export const GET_ADDRESS = DEFAULT_URL + 'address/coord2address';
export const LOCATION_SEARCH = DEFAULT_URL + 'location/search';
export const GET_CERTIFICATE_NUMBER = DEFAULT_URL + 'user/certification';
export const POST_CERTIFICATE_CHECK = DEFAULT_URL + 'user/v4/login/check';

export const GET_CERTIFICATION_CODE = `${DEFAULT_URL}user/v5/certifications`; // 임시 인증용 코드를 생성한다 (발신)
export const GET_CERTIFICATION_TOKEN = `${DEFAULT_URL}user/v5/certifications/-/tokens`; // 임시 인증용 토큰을 생성한다
export const UPDATE_PHONE_NUMBER = `${DEFAULT_URL}user/v5/updatePhoneNumber`; // 핸드폰 번호 변경

export const GET_ASSETS = DEFAULT_URL + 'user/assets';
export const ACCUMULATIONCODE_REGIST = DEFAULT_URL + 'user/promotion';
export const GET_QNA = DEFAULT_URL + 'info/QnA';
export const GET_COUPON_LIST = DEFAULT_URL + 'coupon/list';
export const CHANGE_NAME = DEFAULT_URL + 'user/update/name';
export const USER_LOGIN = DEFAULT_URL + 'user/v4/login';
export const COUPON_REGIST = DEFAULT_URL + 'coupon/issue/code';
export const MAIN = `${DEFAULT_URL}screen/v4/main`;

export const CHECK_MEMBER = DEFAULT_URL + 'membership/checkMember';
export const MEMBERSHIPCANCEL = DEFAULT_URL + 'membership/delete';
export const MEMBERSHIPINFO = DEFAULT_URL + 'membership/info';
export const JOIN_MEMBER = DEFAULT_URL + 'membership/regist';

export const WITHDRAWAL = DEFAULT_URL + 'user/delete';

export const ORDER_SEARCH_IN_PROGRESS = `${DEFAULT_URL}screen/v5/order/search/inProgress`;
export const ORDER_SEARCH_OVER = `${DEFAULT_URL}screen/v5/order/search/over`;
export const ORDER_SEARCH_BY_ORDER_ID = `${DEFAULT_URL}screen/v5/order/search/orderId/:orderId`;
export const GET_ORDER_LIST = DEFAULT_URL + 'order/v4/list';
export const GET_ORDER_DETAIL = DEFAULT_URL + 'order/v4/detail';
export const GET_DISCOUNT_PRICE_FOR_BASIC_USER = `${DEFAULT_URL}payment/calculate/-/discounts/:orderId`;
export const GET_STATUS = `${DEFAULT_URL}status`;

export const GET_ANNOUNCEMENT = DEFAULT_URL + 'info/announce';

export const GET_PRICE_LIST = DEFAULT_URL + 'item';
export const SEND_RECEIPT = `${DEFAULT_URL_WEB}admin/client/sendReceipt`;

export const USER_ADDRESS_LIST = `${DEFAULT_URL}user/v4/address/list`;
export const USER_ADDRESS_UPDATE = `${DEFAULT_URL}user/v4/address/update/:type`;
export const USER_ADDRESS_ADD = `${DEFAULT_URL}user/v4/update/address`;

export const APP_PUSH = `${DEFAULT_URL}user/appPush`;
export const URL_USER_GUIDE = `${DEFAULT_URL_WEB}app/guide`;

/** PAYMENT **/
export const SNED_ACCOUNT_MESSAGE = `${DEFAULT_URL}payment/action/pay/account`;
export const PAY_ACTION = `${DEFAULT_URL}payment/action/pay/`;
export const BUY_COIN = `${DEFAULT_URL}user/assets/buy/coin`;
export const ACTION_REFUND = `${DEFAULT_URL}payment/refund`;

export const ACTION_REFUND_NOTICE = `${DEFAULT_URL}payment/refundNotice`;
export const DELETE_CARD = `${DEFAULT_URL}payment/updateCard/delete`;
export const GENERATE_ACCOUNT = `${DEFAULT_URL}payment/action/pay/inicisAccount/generate`;
export const SET_DEFAULT_CARD = `${DEFAULT_URL}payment/updateCard/default`;

export const AVAILABLE_VALUE_IN_ORDER = `${DEFAULT_URL}payment/calculate`;

/** ORDER **/
export const GET_PICKUP_DATETIME = DEFAULT_URL + 'order/v4/time/pickup';
export const GET_DELIVERY_DATETIME = DEFAULT_URL + 'order/v4/time/delivery';
export const POST_WEEKLY_ORDER = `${DEFAULT_URL_WEB}v3/weekly/regist`;
export const POST_CLASSIC_ORDER = `${DEFAULT_URL}order/apply`;
export const CANCEL_ORDER = `${DEFAULT_URL}order/update/cancel`;
export const UPDATE_TIME_BOTH = `${DEFAULT_URL}order/update/both`;
export const UPDATE_TIME_PICKUP = `${DEFAULT_URL}order/update/pickupTime`;
export const UPDATE_TIME_DELIVERY = `${DEFAULT_URL}order/update/deliveryTime`;
export const SET_PRE_OPTIONS = `${DEFAULT_URL}order/v4/preOptions/list`;
export const SET_PRE_COUPON = `${DEFAULT_URL}order/v4/preOptions`;

export const UPDATE_FEEDBACK = `${DEFAULT_URL}order/v4/feedback`;
export const IS_CS_ACTIVE = `${DEFAULT_URL}freshdesk/conversation/getConversation`;

export const GET_HISTORY_DETAIL = `${DEFAULT_URL}screen/v5/order/search/orderId`;
export const URL_NAVERPAY = `${NAVERPAY_URL}order/naverpay/prepare`;

/** OrderChat **/
export const ORDER_CHAT = `${DEFAULT_URL}screen/v5/chatbot`;
export const UPDATE_DOOR_CODE = `${DEFAULT_URL}address/update/doorCode/set`;

/** LoginQuestion **/
export const GET_LOGIN_QUESTION = `${DEFAULT_URL}screen/v5/login/question`;
export const POST_LOGIN_QUESTION_CHECK_FIRST_QUESTION = `${DEFAULT_URL}screen/v5/login/question/check/first`;

export const MEMBER_VALUE = `${DEFAULT_URL_WEB}v3/:uid/memberValue/`;
export const FREE_TICKET_VALUE = `${DEFAULT_URL_WEB}v3/:uid/freeTicketValue/`;

// 이니시스
export const URL_INICIS_INIBILL_CARD = rootConfig.URL_INICIS_INIBILL_CARD;
export const URL_INICIS_SMART_WCARD = rootConfig.URL_INICIS_SMART_WCARD;
export const URL_POLICY =
  'https://www.notion.so/washswat/2021-fc51b6b86bb04dd1b69d3972763964b8';

// 개편 메인 API URL
export const GET_MAIN_V6 = `${DEFAULT_URL}screen/v6/main`;
export const GET_MAIN_CONTENTS = `${DEFAULT_URL}screen/v6/main/contents`;
export const GET_EVENT_PAGE = `${DEFAULT_URL}board/event`; // 수정 필요
export const ORDER_CHECK_URL = `${DEFAULT_URL}screen/v6/order/valid`;
