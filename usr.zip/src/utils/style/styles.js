import { Dimensions, Platform, StatusBar, StyleSheet } from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import { washswatColor } from './font';

export const { height } = Dimensions.get('window');

export const commonStyles = StyleSheet.create({
  cardBackground: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    shadowColor: washswatColor.black,
    shadowOffset: {
      width: 0,
      height: -8,
    },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 16,
  },
});

export const diameter = height * 0.3;
export const androidStatusBar = StatusBar.currentHeight;
export const STATUSBAR_HEIGHT =
  Platform.OS === 'ios' ? getStatusBarHeight() : 0;
export const GET_STATUSBAR_HEIGHT = getStatusBarHeight();
export const BOTTOM_TAB_HEIGHT = 85;
export const BOTTOM_TAB_BORDER_AREA_HEIGHT = 20;
export const ORDER_BUTTON_MARGIN_BOTTOM_DEFAULT = 16;
export const ORDER_BUTTON_MARGIN_BOTTOM_DISABLE = -16;
export const ORDER_BUTTON_ANI_DURATION = 200;
export const HOME_SCROLL_TOP_BTN_THRESHOLD = 100;

// export const diameter = PixelRatio.roundToNearestPixel(196);
