import { StyleSheet, PixelRatio, Dimensions } from 'react-native';

const { height, width } = Dimensions.get('window');

export const washswatColor = {
  blue: '#0064FF',
  blue_01: '#2d4aff',
  blue_03: '#E1EDFF',
  blue_04: '#0852D2',
  blueOpacity45: '#0064FF73',
  blueOpacity14: '#0064FF24',
  blueOpacity12: '#0064FF1F',
  blueOpacity_01: '#2D4AFF14',
  lightBlue: '#0076ff',
  black: '#000000',
  blackOpacity12: '#0000001F',
  bottomTabText: '#646464',
  darkGrey: '#585858',
  grey: '#808080',
  grey_01: '#787878',
  grey_02: '#B4B4B4',
  grey_03: '#E1E1E1',
  grey_04: '#EBEBEB',
  grey_05: '#F7F7F7',
  grey_06: '#FAFAFA',
  grey_07: '#F6F6F6',
  grey_08: '#C3C4C7',
  grey_09: '#E2E2E2', // 비활성화 버튼에 사용
  grey_10: '#E6E6E6',
  grey_11: '#CACACA',
  grey_12: '#F3F3F3',
  grey_13: '#969696',
  grey_14: '#C3C3C3',
  grey_15: '#EAEAEA',
  grey_16: '#F1F2F4',
  orange: '#FEA946',
  orangeOpacity16: '#FEA94629',
  red: '#FF0032',
  red_01: '#FC564F',
  transparent: 'transparent',
  white: '#FFFFFF',
  whiteOpacity24: '#FFFFFF3D',
  whiteOpacity45: '#FFFFFF73',
  whiteOpacity65: '#FFFFFFA6',
  pink: '#ff3950',
  pinkOpacity: '#FFEBEE',
  f5: '#F5F5F5', // 추후 수정해야함
  b19: '#181818', // 추후 수정해야함,

  // Blue 계열
  blue_10: '#2d4aff',
  blue_20: '#0064FF',
  blue_30: '#0076ff',
  blue_40: '#98C0FF',
  blue_50: '#DBE9FF',
  blue_60: '#F1F7FF',
  // Black 계열
  black_10: '#000000',
  black_20: '#555555',
  black_30: '#7B7B7B',
  black_40: '#9D9D9D',
  black_50: '#C4C4C4',
  black_60: '#D9D9D9',
  black_70: '#E9E9E9',
  black_80: '#F6F6F6',
  // Red 계열
  red_10: '#E00025',
  red_20: '#FF0032',
  red_30: '#FF3F50',
  red_40: '#FF7A83',
  red_50: '#FFD1D4',
  red_60: '#FFCCD4',
  // Yellow 계열
  yellow_10: '#FFBF1C',
  yellow_20: '#FFC831',
  yellow_30: '#FFD353',
  yellow_40: '#FFDF84',
  yellow_50: '#FFEBB4',
  yellow_60: '#FFF6E0',
};

export const themeColorSelector = ({ theme = 'primary', opacity = 10 }) => {
  let color;

  switch (theme) {
    case 'primary':
      color = 'black';
      break;
    case 'point':
      color = 'blue';
      break;
    case 'negative':
      color = 'red';
      break;
    case 'warning':
      color = 'yellow';
      break;
  }
  return washswatColor[`${color}_${opacity}`];
};

const guidelineBaseWidth = 360;
// const guidelineBaseWidth = Platform.OS === 'ios' ? 375 : 360;
export const guidelineBaseHeight = 640;
// export const guidelineBaseHeight = Platform.OS === 'ios' ? 812 : 640;

export const verticalScale = size => {
  return Math.round((height / guidelineBaseHeight) * size);
};

export const horizonScale = size =>
  Math.round((width / guidelineBaseWidth) * size);

export const responseFont = size => {
  return StyleSheet.create({
    bold: {
      fontFamily: 'SpoqaHanSansNeo-Bold',
      fontSize: PixelRatio.roundToNearestPixel(size),
    },
    regular: {
      fontFamily: 'SpoqaHanSansNeo-Regular',
      fontSize: PixelRatio.roundToNearestPixel(size),
    },
  });
};
