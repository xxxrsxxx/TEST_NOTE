import lodash from 'lodash';
import Moment from 'moment';
import clipboard from '@react-native-community/clipboard';
import modal from 'react-native-modalbox';
import asyncStorage from '@react-native-community/async-storage';

export const _ = lodash;
export const moment = Moment;
export const Clipboard = clipboard;
export const Modal = modal;
export const AsyncStorage = asyncStorage;
