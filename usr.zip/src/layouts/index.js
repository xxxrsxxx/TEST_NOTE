import BottomTabLayout from './BottomTabLayout';

export { BottomTabLayout };
