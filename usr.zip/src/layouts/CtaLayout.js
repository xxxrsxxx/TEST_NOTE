import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import * as CommonUtils from '../utils/common/index';
import { TouchableOpacityActiveOne } from '../components/common';
// component import
// style import
import { Font } from '../utils/style';
import { BasicHeader } from '../components/common/layout';
const { responseFont, washswatColor } = Font;

function CtaLayout(Props, ContentComponent) {
  const SpecificComponent = props => {
    const { title, url, cta } = props.option;
    const { anchor, anchorScreen, cbAction } = cta ? cta : {};

    const pressHandler = e => {
      if (cbAction !== undefined) cbAction(props.componentId);
      else {
        CommonUtils.navPush({
          componentId: props.componentId,
          name: anchorScreen,
        });
      }
    };

    return (
      <>
        <BasicHeader title={title} componentId={props.componentId} />
        <ContentComponent {...props} />
        {cta !== undefined && (
          <TouchableOpacityActiveOne
            style={styles.ctaBar}
            onPress={pressHandler}
          >
            <Text style={styles.ctaAnchor}>{anchor}</Text>
          </TouchableOpacityActiveOne>
        )}
      </>
    );
  };
  return <View style={styles.container}>{SpecificComponent(Props)}</View>;
}

const styles = StyleSheet.create({
  container: { flex: 1, position: 'relative' },
  ctaBar: {
    position: 'absolute',
    bottom: 34,
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    width: 326,
    height: 54,
    borderRadius: 5,
    backgroundColor: washswatColor.blue,
  },
  ctaAnchor: {
    ...responseFont(15).bold,
    color: washswatColor.white,
  },
});
export default CtaLayout;
