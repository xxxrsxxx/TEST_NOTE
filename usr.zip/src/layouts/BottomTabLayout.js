import React from 'react';
import { StyleSheet, View } from 'react-native';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
// modules import
import * as BottomTabModule from '../reducers/BottomTabModule';
// components import
import { BottomTab } from '../components/common';
import { NoticeModal } from '../components/common/modal';
// styles import
import { Styles } from '../utils/style';
const { BOTTOM_TAB_HEIGHT, BOTTOM_TAB_BORDER_AREA_HEIGHT } = Styles;

function BottomTabLayout({ children, componentId, onPressTab }) {
  const dispatch = useDispatch();
  const BottomTabState = useSelector(state => state.BottomTabModule);
  const toggleOrderButton = () => dispatch(BottomTabModule.toggleOrderButton());

  return (
    <View style={styles.container}>
      <View style={styles.childrenContainer}>{children}</View>
      <View style={styles.bottomTab}>
        <BottomTab onPressTab={onPressTab} BottomTabState={BottomTabState} />
      </View>
      <NoticeModal
        componentId={componentId}
        BottomTabState={BottomTabState}
        toggleOrderButton={toggleOrderButton}
      />
    </View>
  );
}

BottomTabLayout.defaultProps = {
  componentId: '0',
  children: null,
  onPressTab: () => {},
};

BottomTabLayout.propTypes = {
  componentId: PropTypes.string.isRequired,
  children: PropTypes.oneOfType([PropTypes.array, PropTypes.element]),
  onPressTab: PropTypes.func.isRequired,
};

const styles = StyleSheet.create({
  childrenContainer: {
    flex: 1,
    paddingBottom: BOTTOM_TAB_HEIGHT - BOTTOM_TAB_BORDER_AREA_HEIGHT,
  },
  container: {
    flex: 1,
  },
  bottomTab: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    zIndex: 150,
  },
});

export default BottomTabLayout;
