import axios from "axios";
import { alertHandler } from "../common";
const Module = {
  call: async ({ url, method, data }) => {
    console.log("process.env.port in axios", process.env.PORT);
    try {
      const dataSet = {
        // baseURL: DEFAULT_URL,
        url,
        method: method || "get",
      };

      switch (dataSet.method) {
        // case "get":
        //   dataSet.params = data;
        //   break;
        case "post":
          dataSet.data = data;
          break;
        default:
          break;
      }

      const response = await axios(dataSet);

      return response.data;
    } catch (error) {
      // console.log("error", error);
      alertHandler.errorAlert(error);
    }
  },
};

export default Module;
