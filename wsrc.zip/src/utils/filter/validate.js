class validate {
	email = value => {
		let result = false;
		const reg = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
		if (reg.test(value)) result = true;
		return result;
	};
}

export default new validate();
