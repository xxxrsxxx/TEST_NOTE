import axios from 'axios';
function axiosInstance() {
	let instance = null;
	const init = async () => {
		instance = createInstance();
	};

	/**
	 * @dsc setting aixos instance
	 * @param params:object
	 * @returns {AxiosInstance}
	 */
	function createInstance(params) {
		const _instance = axios.create({
			//baseURL: 'http://localhost:3000/',
			headers: {},
			timeout: 5000,
		});
		return _instance;
	}

	init();

	/**
	 * @param url
	 * @param params
	 * @param data
	 * @returns {Promise<AxiosResponse<any>>}
	 */

	async function post(url, params, data) {
		try {
			const res = await instance.post(url, data, { params });
			return res;
		} catch (e) {
			console.log(
				'%c ====================postAxios error====================',
				styles.console,
				'\n URL',
				url,
				'\n PARAMS:',
				params,
				'\n DATA:',
				data,
				'\n ERROR:',
				e,
			);
		}
	}

	/**
	 *
	 * @param url
	 * @param params
	 * @returns {Promise<AxiosResponse<any>>}
	 */
	async function get(url, params) {
		try {
			const res = await instance.get(url, { params });
			return res;
		} catch (e) {
			console.log(
				'%c ====================getAxios error====================',
				styles.console,
				'\n URL:',
				url,
				'\n PARAMS:',
				params,
				'\n ERROR:',
				e,
			);
		}
	}

	async function patch(url, params, data) {
		let _url = url;
		try {
			const res = await instance.patch(url, data, { params });
			return res;
		} catch (e) {
			console.log(
				'%c ====================patchAxios error====================',
				styles.console,
				'\n URL',
				url,
				'\n PARAMS:',
				params,
				'\n DATA:',
				data,
				'\n ERROR:',
				e,
			);
		}
	}

	/**
	 * @param url
	 * @param params
	 * @param data
	 * @returns {Promise<AxiosResponse<any>>}
	 */

	async function put(url, params, data) {
		try {
			const res = await instance.put(url, data, { params });
			return res;
		} catch (e) {
			console.log(
				'%c ====================putAxios error====================',
				styles.console,
				'\n URL',
				url,
				'\n PARAMS:',
				params,
				'\n DATA:',
				data,
				'\n ERROR:',
				e,
			);
		}
	}

	return {
		init,
		post,
		get,
		patch,
		put,
	};
}
const styles = {
	console: [
		'background: yellow',
		'border: 1px solid #3E0E02',
		'color: red',
		'display: block',
		'line-height: 40px',
		'text-align: center',
		'font-weight: bold',
		'font-size: 20px',
	].join(';'),
};

export default axiosInstance;
