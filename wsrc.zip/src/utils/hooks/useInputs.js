import { useState, useCallback, useReducer } from "react";

export default function useInputs(defaultValue) {}
