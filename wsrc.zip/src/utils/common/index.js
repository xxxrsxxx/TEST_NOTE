import { toast } from "react-toastify";

const alertHandler = {
  showAlert: ({ message, event }) => {
    if (!event)
      return toast.success(message, {
        position: toast.POSITION.BOTTOM_CENTER,
        autoClose: 1000,
      });

    toast.success(message, {
      position: toast.POSITION.BOTTOM_CENTER,
      autoClose: 1000,
      onClose: event,
    });
  },
  errorAlert: (error) => {
    let message = "이슈 상황! 개발팀에 문의주세요";
    if (error && error.response && error.response.data) {
      message = error.response.data.message;
    }
    toast.error(message, {
      position: toast.POSITION.BOTTOM_CENTER,
    });

    throw error;
  },
};
export { alertHandler };
