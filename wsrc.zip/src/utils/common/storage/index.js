function storageController() {
  function setData(key, value, type, action) {
    try {
      if (type == "json") {
        value = JSON.stringify(value);
      }
      if (action === "setSession") sessionStorage.setItem(key, value);
      if (action === "setLocal") localStorage.setItem(key, value);
    } catch (e) {}
  }

  function getData(key, type, action) {
    let value = null;
    try {
      if (action === "getSession") value = sessionStorage.getItem(key);
      if (action === "getLocal") value = localStorage.getItem(key);

      if (type == "json") {
        value = JSON.parse(value);
      }
    } catch (e) {
      value = -1;
    }

    return value;
  }

  const setSession = (key, value, type) => {
    setData(key, value, type, "setSession");
  };
  const setLocal = (key, value, type) => {
    setData(key, value, type, "setLocal");
  };

  const getSession = (key, type) => {
    return getData(key, type, "getSession");
  };
  const getLocal = (key, type) => {
    return getData(key, type, "getLocal");
  };

  const removeSession = (key) => {
    try {
      sessionStorage.removeItem(key);
    } catch (e) {}
  };
  const clearSession = () => {
    try {
      sessionStorage.clear();
    } catch (e) {}
  };
  const removeLocal = (key) => {
    try {
      localStorage.removeItem(key);
    } catch (e) {}
  };
  const clearLocal = () => {
    try {
      localStorage.clear();
    } catch (e) {}
  };

  return {
    setSession,
    getSession,
    removeSession,
    clearSession,
    setLocal,
    getLocal,
    removeLocal,
    clearLocal,
  };
}

function cookieHandler() {
  const getData = (key) => {
    if (!key) return null;

    let decodedCookie = decodeURIComponent(document.cookie).split("; ");

    const findedData = decodedCookie.find(
      (data) => data.indexOf(`${key}=`) > -1
    );

    return findedData ? findedData.split("=")[1] : null;
  };
  const deleteData = () => {
    window.location = "/";
    let savedCookies = document.cookie.split(";");

    savedCookies.forEach(
      (cookie) =>
        (document.cookie = cookie + "=;expires=" + new Date(0).toUTCString())
    );
  };

  return {
    getData,
    deleteData,
  };
}

export const storage = storageController();
export const cookie = cookieHandler();
