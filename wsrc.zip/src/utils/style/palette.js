import oc from "open-color";

/**
 * @description open-color에 있는 색상을 return 해주는 colorpicker
 * @param {color} 선택하려고 하는 색상
 * @param {opacity} 색상의 명암 (0~9)
 */
export default function palette({ color, opacity }) {
  // if(!color || !opacity)

  return `${oc[color][opacity]}`;
}
