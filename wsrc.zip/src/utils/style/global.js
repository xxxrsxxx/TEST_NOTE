import { createGlobalStyle } from "styled-components";

const GlobalStyle = createGlobalStyle`
  body {
    background-color: #F8F9FA;
  }
`;

export default GlobalStyle;
