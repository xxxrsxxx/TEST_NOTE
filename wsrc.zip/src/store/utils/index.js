import { keysIn } from "../../utils/lodash";

function setActions({ normal, thunk }) {
  let normalConfig = {};

  const op = {
    init: () => {
      op.normalActions(normal);
    },
    normalActions: (value) => {
      const key = keysIn(value);
      key.forEach((e) => {
        normalConfig = { ...normalConfig, ...value[e] };
      });
    },
  };
  op.init();
  return {
    normal: normalConfig,
  };
}

export { setActions };
