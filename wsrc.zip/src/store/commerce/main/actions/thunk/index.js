import { Common, Server } from "../../../../../utils";
const { alertHandler } = Common;
import moment from "moment";
moment.locale("ko");

const reloadWithAlert = (message) => {
  alertHandler.showAlert({
    message,
    event: () => window.location.reload(),
  });
};

function _thunkActions() {
  this.contents = {
    init: ({ setContentsList, setContentsTotalCount, setTagList }) => async (
      dispatch,
      getState
    ) => {
      // 병렬처리 고려

      let contentListResult = await Server.call({
        url: `/api/main/contents?page=1&limit=10`,
        method: "get",
      });

      let tagListResult = await Server.call({
        url: `/api/main/tag`,
        method: "get",
      });

      const { contentList, totalCount } = contentListResult;
      const { tagList } = tagListResult;

      dispatch(setContentsList(contentList));
      dispatch(setContentsTotalCount(totalCount));
      dispatch(setTagList(tagList));
    },
    loadTargetPage: ({ page }, { setContentsList }) => async (
      dispatch,
      getState
    ) => {
      let result = await Server.call({
        url: `/api/main/contents?page=${page}&limit=10`,
        method: "get",
      });

      const { contentList } = result;

      dispatch(setContentsList(contentList));
    },
    makeContentsAction: ({ title, subTitle, url, image, seq, tags }) => async (
      dispatch,
      getState
    ) => {
      let data = {
        content: { title, subTitle, url, image, seq },
        tags,
      };

      let result = await Server.call({
        url: `/api/main/contents`,
        method: "post",
        data,
      });

      if (result) reloadWithAlert("컨텐츠 생성이 완료되었습니다.");
    },
    editContentsAction: ({
      index,
      title,
      subTitle,
      image,
      tags,
      url,
      seq,
    }) => async (dispatch, getState) => {
      const data = {
        content: { index, title, subTitle, image, url, seq },
        tags,
      };

      let result = await Server.call({
        url: `/api/main/contents/edit`,
        method: "post",
        data,
      });

      if (result) reloadWithAlert("컨텐츠 수정이 완료되었습니다.");
    },
    activateContentsAction: ({
      index,
      title,
      subTitle,
      image,
      url,
      seq,
      isValid,
    }) => async (dispatch, getState) => {
      const data = {
        content: { index, title, subTitle, image, url, seq, isValid },
      };

      let result = await Server.call({
        url: `/api/main/contents/activate`,
        method: "post",
        data,
      });

      if (result) reloadWithAlert("컨텐츠 변경이 완료되었습니다.");
    },
    makeTagAction: ({ keyword, seq }, { setTagList }) => async (
      dispatch,
      getState
    ) => {
      const data = {
        tag: { keyword, seq },
      };

      let newTagResult = await Server.call({
        url: `/api/main/tag`,
        method: "post",
        data,
      });

      let tagListResult = await Server.call({
        url: `/api/main/tag`,
        method: "get",
      });

      const { tagList } = tagListResult;

      dispatch(setTagList(tagList));

      if (result) reloadWithAlert("태그 추가가 완료되었습니다.");
    },
  };
  this.event = {
    init: ({ setEventTotalCount, setEventList }) => async (
      dispatch,
      getState
    ) => {
      let eventListResult = await Server.call({
        url: `/api/main/event?page=1&limit=10`,
        method: "get",
      });

      const { eventList, totalCount } = eventListResult;
      dispatch(setEventTotalCount(totalCount));
      dispatch(setEventList(eventList));
    },
    loadTargetPage: ({ page }, { setEventList }) => async (
      dispatch,
      getState
    ) => {
      let result = await Server.call({
        url: `/api/main/event?page=${page}&limit=10`,
        method: "get",
      });

      const { eventList } = result;

      dispatch(setEventList(eventList));
    },
    makeEventAction: ({
      title,
      subTitle,
      url,
      imageUrl,
      startdate,
      enddate,
      seq,
    }) => async (dispatch, getState) => {
      let data = {
        event: {
          title,
          subTitle,
          url,
          imageUrl,
          startdate: startdate
            ? startdate
            : moment(new Date()).format("YYYY/MM/DD"),
          enddate,
          seq,
        },
      };

      let result = await Server.call({
        url: `/api/main/event`,
        method: "post",
        data,
      });

      if (result) reloadWithAlert("이벤트 생성이 완료되었습니다.");
    },
    editEventAction: ({
      index,
      title,
      subTitle,
      url,
      imageUrl,
      startdate,
      enddate,
      seq,
    }) => async (dispatch, getState) => {
      const data = {
        event: {
          index,
          title,
          subTitle,
          url,
          imageUrl,
          startdate,
          enddate,
          seq,
        },
      };

      let result = await Server.call({
        url: `/api/main/event/edit`,
        method: "post",
        data,
      });

      if (result) reloadWithAlert("수정이 완료되었습니다.");
    },
    activateEventAction: ({
      index,
      title,
      subTitle,
      image,
      url,
      seq,
      isValid,
    }) => async (dispatch, getState) => {
      const data = {
        event: { index, title, subTitle, image, url, seq, isValid },
      };

      let result = await Server.call({
        url: `/api/main/event/activate`,
        method: "post",
        data,
      });

      if (result) reloadWithAlert("변경이 완료되었습니다.");
    },
  };

  this.tag = {
    init: ({ setTagTotalCount, setList }) => async (dispatch, getState) => {
      let tagListResult = await Server.call({
        url: `/api/main/tag?page=0&limit=10`,
        method: "get",
      });

      const { tagList, totalCount } = tagListResult;

      dispatch(setTagTotalCount(totalCount));
      dispatch(setList(tagList));
    },
    loadTargetPage: (page) => async (dispatch, getState) => {
      let result = await Server.call({
        url: `/api/main/tag?page=${page - 1}&limit=10`,
        method: "get",
      });

      const { tagList } = result;

      console.log("tagList", tagList);

      dispatch(setList(tagList));
    },
    makeTagAction: ({ keyword, seq }) => async (dispatch, getState) => {
      let data = {
        tag: { keyword, seq },
      };

      let result = await Server.call({
        url: `/api/main/tag`,
        method: "post",
        data,
      });

      if (result) reloadWithAlert("태그 생성이 완료되었습니다.");
    },
    editTagAction: ({ index, keyword, seq }) => async (dispatch, getState) => {
      const data = {
        tag: { index, keyword, seq },
      };

      let result = await Server.call({
        url: `/api/main/tag/edit`,
        method: "post",
        data,
      });

      if (result) reloadWithAlert("태그 수정이 완료되었습니다.");
    },
    activateTagAction: ({ index, keyword, seq, isValid }) => async (
      dispatch,
      getState
    ) => {
      const data = {
        tag: { index, keyword, seq, isValid },
      };

      let result = await Server.call({
        url: `/api/main/tag/activate`,
        method: "post",
        data,
      });

      if (result) reloadWithAlert("태그 변경이 완료되었습니다.");
    },
  };

  this.dashBoard = {
    init: ({ keyInit }) => async (dispatch, getState) => {
      let start = moment().format("YYYY-MM-DD");
      let end = moment().add(1, "day").format("YYYY-MM-DD");

      let result = await Server.call({
        url: `/api/dashboard/${start}/${end}`,
        method: "get",
      });
      dispatch(keyInit(result));
    },
  };
}
const thunk = new _thunkActions();
export default thunk;
