import normalActions from "./normal";
import thunkActions from "./thunk";

export { normalActions, thunkActions };
