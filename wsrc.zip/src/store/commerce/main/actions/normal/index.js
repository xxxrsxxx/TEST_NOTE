import initialState from '../../initialState';

// utils
import { setActions } from '../../../../utils';

function _actions() {
	this.dashBoard = {
		keyInit(state, action) {
			// 불변성 지키지 않고 사용 가능
			state.dashBoard.dataSet = action.payload;
		},
	};

	this.popUp = {
		setPopup: (state, action) => {
			state.popup = action.payload;
		},
		resetPopup: (state, action) => {
			state.popup = initialState.popup;
		},
	};

	this.event = {
		setEventList(state, action) {
			state.event.eventList = action.payload;
		},
		setEventTotalCount(state, action) {
			state.event.eventTotalCount = action.payload;
		},
		setTargetEvent(state, action) {
			state.event.targetEvent = action.payload;
		},
	};

	this.contents = {
		setContentsList(state, action) {
			state.contents.contentList = action.payload;
		},
		setContentsTotalCount(state, action) {
			state.contents.contentsTotalCount = action.payload;
		},
		setTargetContent(state, action) {
			state.contents.targetContent = action.payload;
		},
		setTagList(state, action) {
			state.contents.tagList = action.payload;
		},
	};

	this.tag = {
		setList(state, action) {
			state.tag.tagList = action.payload;
		},
		setTagTotalCount(state, action) {
			state.tag.tagTotalCount = action.payload;
		},
		setTargetTag(state, action) {
			state.tag.targetTag = action.payload;
		},
	};
}

const _act = new _actions();

const result = setActions({
	normal: _act,
});

const normalActions = result.normal;

export default normalActions;
