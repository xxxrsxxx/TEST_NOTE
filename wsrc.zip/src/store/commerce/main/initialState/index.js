function _state() {
  let config = {};

  const popup = {
    visible: false,
    title: "",
    content: "",
    onConfirm: "",
    onCancel: "",
  };

  const contents = {
    contentList: [], // 세특발견 컨텐츠 List
    contentsTotalCount: 0, // 전체 컨텐츠 수
    targetContent: [], // 현재 수정하려고 하는 target 컨텐츠
    tagList: [], // 현재 존재하는 전체 태그들의 리스트
  };

  const event = {
    eventList: [], // 이벤트 List
    eventTotalCount: 0, // 전체 이벤트 수
    targetEvent: [], // 현재 수정하려고 하는 target Event
  };

  const tag = {
    tagList: [], // 현재 존재하는 전체 태그들의 리스트
    tagTotalCount: 0, // 전체 태그 수
    targetTag: [], // 현재 변경하려는 태그
  };

  const dashBoard = { dataSet: {} };

  config = { ...{ popup, contents, event, tag, dashBoard } };

  return config;
}

export default _state();
