import { createSlice } from "@reduxjs/toolkit";

import initialState from "./initialState";

import { normalActions, thunkActions } from "./actions";

const main = createSlice({
  name: "main",
  initialState,
  reducers: normalActions,
});
// 일반 action
export const eventActions = main.actions;
export const eventThunkActions = thunkActions;

export default main.reducer;
