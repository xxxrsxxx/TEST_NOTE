import main from "./main";

export const reducers = {
  main,
};
