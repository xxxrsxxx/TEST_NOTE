import { combineReducers, configureStore } from "@reduxjs/toolkit";

import { reducers } from "./commerce";
import { createWrapper } from "next-redux-wrapper";
import thunk, { ThunkAction } from "redux-thunk";

const commerceRoot = combineReducers(reducers);

const _env = process.env.NODE_ENV !== "production";
const makeStore = (context) =>
  configureStore({
    reducer: {
      commerce: commerceRoot,
    },
    devTools: _env,
    middleware: [thunk],
  });

export const wrapper = createWrapper(makeStore, {
  debug: _env,
});
