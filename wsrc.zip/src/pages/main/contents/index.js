import React, { useState, useEffect } from 'react';

// css
import styled from 'styled-components';
import palette from '../../../utils/style/palette';

// redux
import { useSelector, useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../../store/commerce/main';
const { setContentsList, setContentsTotalCount, setTagList } = eventActions;
const { contents } = eventThunkActions;
//import { contentsThunkActions } from "../../../modules/contents";
// components
import { Table, TableBody, TableRow, TableCell, TableContainer, TableHead, Paper, Pagination } from '../../../utils/material';
import { MainLayout } from '../../../components/layout';
import { CustomTableRow, ContentDialog } from '../../../components/main/contents';
import { CustomButton } from '../../../components/common';

// static data
import { contentsData } from '../../../static/main';

// styled components
const HeaderWrapper = styled.div`
	display: flex;
	justify-content: flex-end;
	margin-bottom: 2rem;
`;

const CustomTableCell = styled(TableCell)`
	border-bottom: 1px solid black;
	padding: 1rem;
	text-align: center;
	font-size: 18px;
	font-weight: 600;
`;

const PaginationWrapper = styled.div`
	display: flex;
	justify-content: center;
	margin-top: 2rem;
`;

const Contents = () => {
	const [toggleContentDialog, setToggleContentDialog] = useState(false);

	const { contentList, contentsTotalCount } = useSelector(state => state.commerce.main.contents);
	const dispatch = useDispatch();

	useEffect(() => {
		dispatch(contents.init({ setContentsList, setContentsTotalCount, setTagList }));
	}, []);

	const toggleDialog = () => setToggleContentDialog(!toggleContentDialog);

	const renderTableHeader = () => {
		const { contentsTableHeader } = contentsData;

		return contentsTableHeader.map(content => <CustomTableCell key={content}>{content}</CustomTableCell>);
	};

	const renderContentsTable = () => {
		return contentList.map(content => <CustomTableRow key={content.title} dataRow={content} toggleDialog={toggleDialog} />);
	};

	const makeContent = ({ title, subTitle, image, url, seq }) => {
		dispatch(contents.makeContent({ title, subTitle, image, url, seq }));
	};

	const handlePagination = (_, page) => {
		dispatch(contents.loadTargetPage({ page }, { setContentsList }));
	};

	return (
		<MainLayout title="세특발견 컨텐츠 만들기">
			<HeaderWrapper>
				<CustomButton size={'medium'} color={palette({ color: 'indigo', opacity: 6 })} onClick={() => setToggleContentDialog(true)}>
					컨텐츠 생성
				</CustomButton>
			</HeaderWrapper>

			<TableContainer component={Paper}>
				<Table>
					<TableHead>
						<TableRow>{renderTableHeader()}</TableRow>
					</TableHead>
					<TableBody>{renderContentsTable()}</TableBody>
				</Table>
			</TableContainer>

			<PaginationWrapper>
				<Pagination count={Math.ceil(contentsTotalCount / 10)} defaultPage={1} color="primary" onChange={handlePagination} />
			</PaginationWrapper>

			<ContentDialog open={toggleContentDialog} handleClose={toggleDialog} makeContent={makeContent} />
		</MainLayout>
	);
};

export default Contents;
