import React, { useEffect } from 'react';

import styled from 'styled-components';

// redux
import { useSelector, useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../store/commerce/main';
const { keyInit } = eventActions;
const { dashBoard } = eventThunkActions;
import axios from 'axios';
// utils
import { size, map, countBy } from '../../utils/lodash';

// ui components
import { Grid, Container, Android, Apple, CheckBox, ShoppingCartIcon, RemoveShoppingCart, RateReview } from '../../utils/material';
import { MainLayout } from '../../components/layout';
import { GridCard, ReviewCardWrapper, ReviewCard, CancelReviewCard } from '../../components/main';
import { wrapper } from '../../store';

// styled components
const MainContainer = styled.div`
	display: flex;
	flex-direction: column;
`;

const TopMargin = styled.div`
	margin-top: 4rem;
`;

const Main = () => {
	const dataSet = useSelector(state => state.commerce.main.dashBoard.dataSet);
	const dispatch = useDispatch();

	useEffect(() => {
		dispatch(dashBoard.init({ keyInit }));
	}, []);

	const renderDashBoard = () => {
		return [
			{
				title: 'Android 다운로드 수',
				content: countBy(dataSet.download, 'platform').android || 0,
				subContent: '실시간 금일 누적 Play Store 다운로드 수',
				icon: Android,
				color: 'lime',
			},
			{
				title: 'iOS 다운로드 수',
				content: countBy(dataSet.download, 'platform').ios || 0,
				subContent: '실시간 금일 누적 App Store 다운로드 수',
				icon: Apple,
				color: 'pink',
			},
			{
				title: '가입자 수',
				content: dataSet.newUsers.length || 0,
				subContent: '실시간 금일 누적 가입자 수',
				icon: CheckBox,
				color: 'blue',
			},
			{
				title: '주문 수',
				content: dataSet.orders || 0,
				subContent: '실시간 금일 누적 주문 수',
				icon: ShoppingCartIcon,
				color: 'indigo',
			},
			{
				title: '취소 주문 수',
				content: dataSet.cancel.length || 0,
				subContent: '실시간 금일 누적 취소 주문 수',
				icon: RemoveShoppingCart,
				color: 'cyan',
			},
			{
				title: '취소 주문율',
				content: `${((dataSet.cancel.length / (dataSet.orders + dataSet.cancel.length)) * 100).toFixed(1) || 0}%`,
				subContent: '실시간 금일 누적 취소 주문율',
				icon: RateReview,
				color: 'yellow',
			},
		].map(data => {
			return (
				<Grid key={data.title} style={{ marginTop: 20 }} item xs={4} md={4}>
					<GridCard data={data} />
				</Grid>
			);
		});
	};

	return (
		<MainContainer>
			<MainLayout>
				<TopMargin />
				{dataSet && size(dataSet) > 0 && (
					<Container component="main">
						<Grid direction="row" container spacing={3}>
							{renderDashBoard()}
						</Grid>
					</Container>
				)}

				{dataSet && size(dataSet) > 0 && (
					<Container style={{ marginTop: 30 }} component="main">
						<Grid direction="row" container spacing={2}>
							<ReviewCardWrapper title={'취소 주문 사유'}>
								{map(dataSet.cancel, order => (
									<CancelReviewCard key={order.orderId} order={order} />
								))}
							</ReviewCardWrapper>

							<ReviewCardWrapper title={'Android 리뷰'}>
								{map(dataSet.androidReviews.data, review => (
									<ReviewCard key={review.text} review={review} />
								))}
							</ReviewCardWrapper>

							<ReviewCardWrapper title={'iOS 리뷰'}>
								{map(dataSet.iosReviews, review => (
									<ReviewCard key={review.text} review={review} />
								))}
							</ReviewCardWrapper>
						</Grid>
					</Container>
				)}
			</MainLayout>
		</MainContainer>
	);
};
export const getServerSideProps = wrapper.getServerSideProps(async ({ context, store }) => {
	/**
	 * @dsc 서버 라이프 훅 에서 상태와 액션 사용법
	 * 랜더링 퍼포먼스를 위해 서버 랜더링 과정에서 디스 패치 가능
	 */
	const state = store.getState();
	// 통신 작업후 액션 할당
	//await store.dispatch(keyInit("server"));
	//console.log("?????!!!2222!!", global.config);
	//let res = await axios.get(`http://localhost:3000/api/main/tag`, {});
	console.log('??22', process.env.NEXT_PUBLIC_TEST);
});
export default Main;
