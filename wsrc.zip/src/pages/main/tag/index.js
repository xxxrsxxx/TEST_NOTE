import React, { useState, useEffect } from 'react';

// css
import styled from 'styled-components';
import palette from '../../../utils/style/palette';

// redux
import { useSelector, useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../../store/commerce/main';
const { setContentsList, setList, setTagTotalCount } = eventActions;
const { tag } = eventThunkActions;

//import { tagThunkActions } from "../../../modules/tag";

// components
import { Table, TableBody, TableRow, TableCell, TableContainer, TableHead, Paper, Pagination } from '../../../utils/material';
import { MainLayout } from '../../../components/layout';
import { CustomTableRow, TagDialog } from '../../../components/main/tag';
import { CustomButton } from '../../../components/common';

// static data
import { tagData } from '../../../static/main';

// styled components
const HeaderWrapper = styled.div`
	display: flex;
	justify-content: flex-end;
	margin-bottom: 2rem;
`;

const CustomTableCell = styled(TableCell)`
	border-bottom: 1px solid black;
	padding: 1rem;
	text-align: center;
	font-size: 18px;
	font-weight: 600;
`;

const PaginationWrapper = styled.div`
	display: flex;
	justify-content: center;
	margin-top: 2rem;
`;

const TagTable = () => {
	const [toggleTagDialog, setToggleTagDialog] = useState(false);

	const { tagList, tagTotalCount } = useSelector(state => state.commerce.main.tag);
	const dispatch = useDispatch();

	useEffect(() => {
		dispatch(tag.init({ setTagTotalCount, setList }));
	}, []);

	const toggleDialog = () => setToggleTagDialog(!toggleTagDialog);

	const renderTableHeader = () => {
		const { tagTableHeader } = tagData;

		return tagTableHeader.map(content => <CustomTableCell key={content}>{content}</CustomTableCell>);
	};

	const renderTagTable = () =>
		tagList.map(tag => <CustomTableRow key={`${tag.keyword}-${tag.seq}`} dataRow={tag} toggleDialog={toggleDialog} />);

	const handlePagination = (_, page) => {
		dispatch(tag.loadTargetPage({ page }, { setContentsList }));
	};

	return (
		<MainLayout title="세특발견 태그 만들기">
			<HeaderWrapper>
				<CustomButton size={'medium'} color={palette({ color: 'indigo', opacity: 6 })} onClick={() => setToggleTagDialog(true)}>
					태그 생성
				</CustomButton>
			</HeaderWrapper>
			<TableContainer component={Paper}>
				<Table>
					<TableHead>
						<TableRow>{renderTableHeader()}</TableRow>
					</TableHead>
					<TableBody>{renderTagTable()}</TableBody>
				</Table>
			</TableContainer>

			<PaginationWrapper>
				<Pagination count={Math.ceil(tagTotalCount / 10)} defaultPage={1} color="primary" onChange={handlePagination} />
			</PaginationWrapper>

			<TagDialog open={toggleTagDialog} handleClose={toggleDialog} />
		</MainLayout>
	);
};

export default TagTable;
