import React, { useState, useEffect } from 'react';

// css
import styled from 'styled-components';
import palette from '../../../utils/style/palette';

// redux
import { useSelector, useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../../store/commerce/main';
const { setEventTotalCount, setEventList } = eventActions;
const { event } = eventThunkActions;
// components
import { Table, TableBody, TableRow, TableCell, TableContainer, TableHead, Paper, Pagination } from '../../../utils/material';
import { MainLayout } from '../../../components/layout';
import { CustomTableRow, EventDialog } from '../../../components/main/event';
import { CustomButton } from '../../../components/common';

// static data
import { eventData } from '../../../static/main';

// styled components
const HeaderWrapper = styled.div`
	display: flex;
	justify-content: flex-end;
	margin-bottom: 2rem;
`;

const CustomTableCell = styled(TableCell)`
	padding: 1rem;
	border-bottom: 1px solid black;
	text-align: center;
	font-size: 18px;
	font-weight: 600;
`;

const PaginationWrapper = styled.div`
	display: flex;
	justify-content: center;
	margin-top: 2rem;
`;

const Event = () => {
	const [toggleEventDialog, setToggleEventDialog] = useState(false);

	const { eventList, eventTotalCount } = useSelector(state => state.commerce.main.event);
	const dispatch = useDispatch();

	useEffect(() => {
		dispatch(event.init({ setEventTotalCount, setEventList }));
	}, []);

	const toggleDialog = () => setToggleEventDialog(!toggleEventDialog);

	const renderTableHeader = () => {
		const { eventTableHeader } = eventData;

		return eventTableHeader.map(content => <CustomTableCell key={content}>{content}</CustomTableCell>);
	};

	const renderEventTable = () => eventList.map(event => <CustomTableRow key={event.title} dataRow={event} toggleDialog={toggleDialog} />);

	const handlePagination = (_, page) => {
		dispatch(event.loadTargetPage({ page }, { setEventList }));
	};

	return (
		<MainLayout title="이벤트 만들기">
			<HeaderWrapper>
				<CustomButton size={'medium'} color={palette({ color: 'indigo', opacity: 6 })} onClick={() => setToggleEventDialog(true)}>
					이벤트 생성
				</CustomButton>
			</HeaderWrapper>
			<TableContainer component={Paper}>
				<Table>
					<TableHead>
						<TableRow>{renderTableHeader()}</TableRow>
					</TableHead>
					<TableBody>{renderEventTable()}</TableBody>
				</Table>
			</TableContainer>

			<PaginationWrapper>
				<Pagination count={Math.ceil(eventTotalCount / 10)} defaultPage={1} color="primary" onChange={handlePagination} />
			</PaginationWrapper>

			<EventDialog open={toggleEventDialog} handleClose={toggleDialog} />
		</MainLayout>
	);
};

export default Event;
