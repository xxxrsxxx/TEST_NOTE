import React, { useState } from "react";

import Image from "next/image";

// css
import styled from "styled-components";
import palette from "../../utils/style/palette";

import { Server } from "../../utils";
import { useRouter } from "next/router";

const LoginContainer = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;

const LoginWrapper = styled.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  justify-content: center;
  width: 35rem;
  height: 35rem;
  background-color: ${palette({ color: "gray", opacity: 2 })};
`;

const FormWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;

const Title = styled.div`
  margin-bottom: 3rem;
  color: white;
  font-size: 32px;
`;

const LoginForm = styled.input`
  width: 80%;
  margin-bottom: 1rem;
  outline: none;
  height: 2.5rem;
  font-size: 1rem;
`;

const ButtonWrapper = styled.div`
  width: 80%;
  margin-top: 1rem;
`;

const SubmitButton = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 2.5rem;
  margin-top: 1rem;
  border: 1px solid ${palette({ color: "gray", opacity: 7 })};
  cursor: pointer;
  color: ${palette({ color: "gray", opacity: 7 })};
  transition: 0.3s;

  :hover {
    color: white;
    background-color: ${palette({ color: "gray", opacity: 7 })};
  }
`;

function Login() {
  const [swatId, setSwatId] = useState("");
  const [password, setPassword] = useState("");

  const router = useRouter();

  const submitLoginData = async () => {
    try {
      const result = await Server.call({
        url: "/api/login",
        method: "post",
        data: { swatId, password },
      });

      console.log("result", result);
      router.replace("/main");
    } catch (e) {
      console.log("submit login data 에러 진입");
      console.log("error", e);
    }
  };

  return (
    <LoginContainer>
      <LoginWrapper>
        <FormWrapper>
          <Title>
            <Image width={100} height={100} src={"/logo.png"} />
          </Title>

          <LoginForm
            type="email"
            value={swatId}
            onChange={(e) => setSwatId(e.target.value)}
            placeholder={"계정 이메일"}
          />

          <LoginForm
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={"비밀번호"}
          />

          <ButtonWrapper>
            <SubmitButton onClick={submitLoginData}>로그인하기</SubmitButton>
            {/* <SubmitButton onClick={submitLoginData}>
              바코드로 로그인하기
            </SubmitButton> */}
          </ButtonWrapper>
        </FormWrapper>
      </LoginWrapper>
    </LoginContainer>
  );
}

export default Login;
