import React, { useEffect } from 'react';
import { Provider } from 'react-redux';

import { wrapper } from '../store';

import { Alert } from '../components/common';

import CssBaseline from '@material-ui/core/CssBaseline';
import { ToastContainer } from 'react-toastify';

import GlobalStyle from '../utils/style/global';
import 'react-toastify/dist/ReactToastify.css';

const App = ({ Component, pageProps }) => {
	useEffect(() => {}, []);
	return (
		// <Provider store={store}>
		<>
			<CssBaseline />
			<GlobalStyle />
			<Component {...pageProps} />
			<Alert />
			<ToastContainer />
		</>
		// </Provider>
	);
};
// App.getInitialProps = async appContext => {
// 	// console.log('?!!!!!', appContext);
// 	// return {
// 	// 	test: 1,
// 	// };
// };

export default wrapper.withRedux(App);
