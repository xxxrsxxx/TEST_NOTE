import React, { useEffect } from "react";
import axios from "axios";
import { useRouter } from "next/router";
import { Server } from "../utils";

function Home(props) {
  const router = useRouter();
  useEffect(() => {
    router.push(props.path);
  }, []);
  return <div>기본 페이지</div>;
}

export async function getServerSideProps(context) {
  try {
    const cookie = context.req.headers.cookie ? context.req.headers.cookie : "";

    axios.defaults.headers["cookie"] = cookie;

    const result = await Server.call({
      url: `http://localhost:${process.env.PORT || 3000}/api/login`,
      method: "get",
    });

    if (!result) {
      throw new Error("no account");
    }
    return {
      props: {
        path: "/main",
      },
    };
  } catch (e) {
    console.log("error", e);
    return {
      props: {
        path: "/login",
      },
    };
  }
}

export default Home;
