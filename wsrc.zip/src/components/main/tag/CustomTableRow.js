import React from 'react';

// css
import styled from 'styled-components';
import palette from '../../../utils/style/palette';

// redux
import { useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../../store/commerce/main';
const { setPopup, resetPopup, setTargetTag } = eventActions;
const { tag } = eventThunkActions;
// ui component
import { TableRow, TableCell } from '../../../utils/material';
import { CustomButton, Circle } from '../../common';

// styled components
const CustomTableCell = styled(TableCell)`
	font-size: 15px;
`;

const CustomTableRow = props => {
	const { dataRow, toggleDialog } = props;
	// 한줄에 대한 데이터가 들어온다.
	const { idx, keyword, isValid, seq } = dataRow;

	const dispatch = useDispatch();

	const { activateTagAction } = tag;

	const onEdit = () => {
		dispatch(setTargetTag(dataRow));
		toggleDialog();
	};

	const onActivate = () =>
		dispatch(
			setPopup({
				visible: true,
				title: '확인',
				content: parseInt(isValid) === 0 ? '정말 활성화하시겠습니까?' : '정말 비활성화하시겠습니까?',
				onConfirm: () => {
					dispatch(resetPopup());
					dispatch(
						activateTagAction({
							index: idx,
							keyword,
							seq,
							isValid,
						}),
					);
				},
			}),
		);

	return (
		<TableRow>
			<CustomTableCell>{keyword}</CustomTableCell>
			<CustomTableCell>{seq}</CustomTableCell>
			<CustomTableCell>
				<Circle color={palette({ color: isValid == 0 ? 'red' : 'green', opacity: 3 })} />
			</CustomTableCell>
			<CustomTableCell>
				<CustomButton color={palette({ color: 'blue', opacity: 5 })} onClick={onEdit}>
					수정
				</CustomButton>
			</CustomTableCell>
			<CustomTableCell>
				<CustomButton
					color={palette({
						color: parseInt(isValid) === 0 ? 'indigo' : 'red',
						opacity: 6,
					})}
					onClick={onActivate}>
					{parseInt(isValid) === 0 ? '활성' : '비활성'}
				</CustomButton>
			</CustomTableCell>
		</TableRow>
	);
};

export default CustomTableRow;
