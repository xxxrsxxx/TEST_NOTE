import React, { useState, useEffect } from 'react';

// css
import styled from 'styled-components';

// redux
import { useSelector, useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../../store/commerce/main';
const { setTargetTag } = eventActions;
const { tag } = eventThunkActions;
// ui component, layout
import { Button, DialogContent, DialogActions, TextField } from '../../../utils/material';
import { DialogLayout } from '../../layout';

// util
import moment from 'moment';
moment.locale('ko');

// styled-components
const TextInput = styled(TextField)`
	width: 300px;
`;

const RowContainer = styled.div`
	display: flex;
	width: 100%;
	margin: 1.5rem 0;
`;

const Title = styled.div`
	display: flex;
	align-items: center;
	font-size: 1.5rem;
	flex: 1;
`;

function TagDialog(props) {
	const { open, handleClose } = props;

	const [inputs, setInputs] = useState({
		index: '',
		keyword: '',
		seq: '',
	});

	const { keyword, seq } = inputs;

	const { targetTag } = useSelector(state => state.commerce.main.tag);

	const dispatch = useDispatch();
	const { makeTagAction, editTagAction } = tag;

	useEffect(() => {
		if (!targetTag) return;

		setInputs({
			index: targetTag.idx,
			...targetTag,
		});
	}, [targetTag]);

	const changeInput = e => {
		const { name, value } = e.target;

		setInputs({
			...inputs,
			[name]: value,
		});
	};

	const resetInputs = () => {
		setInputs({
			index: '',
			keyword: '',
			seq: '',
		});
	};

	const closeDialog = () => {
		handleClose();
		resetInputs();
		dispatch(setTargetTag([]));
	};

	const makeTag = () => {
		dispatch(makeTagAction(inputs));
		closeDialog();
	};

	const editTag = () => {
		dispatch(editTagAction(inputs));
		closeDialog();
	};

	const hasTargetData = targetTag && targetTag.constructor === Object;

	const renderActionButton = () => {
		const clickEvent = hasTargetData ? editTag : makeTag;
		const content = hasTargetData ? '태그 수정' : '태그 생성';

		return (
			<Button autoFocus onClick={clickEvent} color="primary">
				{content}
			</Button>
		);
	};

	return (
		<div>
			<DialogLayout size={'md'} open={open} closeDialog={closeDialog} title={hasTargetData ? '태그 수정' : '태그 생성'}>
				<DialogContent style={{ width: '500px', padding: '1rem' }} dividers>
					<RowContainer>
						<Title>내용</Title>
						<TextInput name="keyword" value={keyword} placeholder={'내용'} onChange={changeInput} />
					</RowContainer>
					<RowContainer>
						<Title>정렬순서</Title>
						<TextInput type={'number'} name="seq" value={seq} placeholder={'정렬순서'} onChange={changeInput} />
					</RowContainer>
				</DialogContent>
				<DialogActions style={{ margin: 0, padding: '0.5rem' }}>{renderActionButton()}</DialogActions>
			</DialogLayout>
		</div>
	);
}

export default TagDialog;
