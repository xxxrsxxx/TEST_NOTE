import React from 'react';

import moment from 'moment';

import { Card, CardContent, Avatar, Typography, Box, Rating } from '../../utils/material';

const ReviewCard = props => {
	const { review } = props;
	const { id, userName, userImage, date, score, title, text, replyText } = review;

	return (
		<Card style={{ marginBottom: 5 }}>
			<CardContent>
				<div
					style={{
						display: 'flex',
						flexDirection: 'row',
						alignItems: 'center',
					}}>
					<Avatar alt={userName} src={userImage} />
					<div
						style={{
							display: 'flex',
							flexDirection: 'column',
							marginLeft: 10,
						}}>
						<div
							style={{
								display: 'flex',
								flexDirection: 'row',
								alignItems: 'center',
							}}>
							<Typography component="div">
								<Box fontWeight="fontWeightBold">{`${userName}`}</Box>
							</Typography>
							<div style={{ marginLeft: 5 }}>
								<Rating size="small" value={score} readOnly />
							</div>
						</div>
						<Typography component="div">
							<Box fontSize={12} style={{ color: '#808080' }}>
								{`${moment(new Date(date)).format('YYYY-MM-DD HH:mm')}`}
							</Box>
						</Typography>
					</div>
				</div>
			</CardContent>
			<CardContent>
				<div>
					<Typography component="div">
						<Box>{title ? `${title} - ${text}` : text}</Box>
					</Typography>
				</div>
			</CardContent>

			{replyText && (
				<CardContent>
					<div>
						<Typography
							style={{
								backgroundColor: 'papayawhip',
								padding: 5,
							}}
							component="div">
							<Box fontStyle="oblique">{`${replyText}`}</Box>
						</Typography>
					</div>
				</CardContent>
			)}
		</Card>
	);
};

export default ReviewCard;
