import React from 'react';
import styled from 'styled-components';

import palette from '../../utils/style/palette';

import { Icon, Card, CardContent, Typography, Paper } from '../../utils/material';

const GridCard = props => {
	const { data } = props;
	const { title, content, subContent, icon, color = 'cyan' } = data;
	const CustomIcon = styled(icon)`
		width: 50px;
		height: 50px;
		color: white;
	`;

	return (
		<Card style={{ overflow: 'visible' }}>
			<CardContent>
				<Typography component="div">
					<div
						style={{
							position: 'relative',
							display: 'flex',
							alignItems: 'center',
						}}>
						<Paper
							style={{
								position: 'absolute',
								top: '-40px',
								display: 'flex',
								alignItems: 'center',
								justifyContent: 'center',
								width: '100px',
								height: '100px',
								backgroundColor: palette({ color, opacity: 4 }),
								border: `1px solid ${palette({ color, opacity: 4 })}`,
							}}
							elevation={3}>
							<CustomIcon />
						</Paper>
					</div>

					<div
						style={{
							display: 'flex',
							flexDirection: 'column',
							alignItems: 'flex-end',
							justifyContent: 'center',
						}}>
						<div
							style={{
								fontSize: '20px',
								color: palette({ color: 'gray', opacity: 6 }),
							}}>
							{title}
						</div>
						<div style={{ fontSize: '48px' }}>{content}</div>
					</div>
				</Typography>
			</CardContent>
			<div
				style={{
					display: 'flex',
					alignItems: 'center',
					height: '4rem',
					margin: '1rem',
					borderTop: '1px solid black',
					fontSize: '16px',
					color: palette({ color: 'gray', opacity: 6 }),
				}}>
				{subContent}
			</div>
		</Card>
	);
};

export default GridCard;
