import React from 'react';

// styles
import styled from 'styled-components';
import palette from '../../utils/style/palette';

import { Grid } from '../../utils/material';

// styled components
const CardHeader = styled.div`
	font-size: 36px;
	text-align: center;
	margin-bottom: 1rem;
	color: ${palette({ color: 'gray', opacity: 6 })};
`;

const ReviewCardWrapper = props => {
	const { title, children } = props;

	return (
		<Grid style={{ marginTop: 20 }} item xs={4} md={4}>
			<Grid direction="column" container>
				<CardHeader>{title}</CardHeader>
				{children}
			</Grid>
		</Grid>
	);
};

export default ReviewCardWrapper;
