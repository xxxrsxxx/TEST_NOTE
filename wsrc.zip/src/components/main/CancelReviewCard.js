import React from 'react';

import { Card, CardContent, Box, Typography } from '../../utils/material';

const CancelReviewCard = props => {
	const { order } = props;

	const {
		userInfo: { name },
		orderId,
		cancel: { reason },
	} = order;

	return (
		<Card style={{ marginBottom: 5 }}>
			<CardContent>
				<Typography component="div">
					<Box fontWeight="fontWeightBold">{`${name} - ${orderId}`}</Box>
				</Typography>
			</CardContent>
			<CardContent>
				<div>
					<Typography component="div">
						<Box>{reason}</Box>
					</Typography>
				</div>
			</CardContent>
		</Card>
	);
};

export default CancelReviewCard;
