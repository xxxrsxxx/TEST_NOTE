import React from 'react';
import Image from 'next/image';

import styled from 'styled-components';
import palette from '../../../utils/style/palette';

// redux
import { useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../../store/commerce/main';
const { setPopup, resetPopup, setTargetEvent } = eventActions;
const { event } = eventThunkActions;

// ui component
import { TableRow, TableCell } from '../../../utils/material';
import { CustomButton, Circle } from '../../common';

// styled components
const ImageWrapper = styled.div``;

const LinkTag = styled.a`
	text-decoration: none;
	color: blue;
`;

const CustomTableCell = styled(TableCell)`
	font-size: 15px;
`;

const CustomTableRow = props => {
	const { dataRow, toggleDialog } = props;
	// 한줄에 대한 데이터가 들어온다.
	const { idx, title, subTitle, url, imageUrl, startdate, enddate, seq, isValid } = dataRow;

	const dispatch = useDispatch();

	const { activateEventAction } = event;
	const onEdit = () => {
		dispatch(setTargetEvent(dataRow));
		toggleDialog();
	};

	const onActivate = () =>
		dispatch(
			setPopup({
				visible: true,
				title: '확인',
				content: parseInt(isValid) === 0 ? '정말 활성화하시겠습니까?' : '정말 비활성화하시겠습니까?',
				onConfirm: () => {
					dispatch(resetPopup());
					dispatch(
						activateEventAction({
							index: idx,
							title,
							subTitle,
							imageUrl,
							startdate,
							enddate,
							url,
							seq,
							isValid,
						}),
					);
				},
			}),
		);

	return (
		<TableRow>
			<CustomTableCell>{title}</CustomTableCell>s <CustomTableCell>{subTitle}</CustomTableCell>
			<CustomTableCell>{url}</CustomTableCell>
			<CustomTableCell>
				<ImageWrapper>
					<Image src={imageUrl} alt="이미지" width={200} height={200} />
					<div>
						<LinkTag target="_blank" href={imageUrl}>
							이미지 바로가기
						</LinkTag>
					</div>
				</ImageWrapper>
			</CustomTableCell>
			<CustomTableCell>{startdate}</CustomTableCell>
			<CustomTableCell>{enddate}</CustomTableCell>
			<CustomTableCell style={{ width: '4rem' }}>{seq}</CustomTableCell>
			<CustomTableCell style={{ width: '4rem' }}>
				<Circle color={palette({ color: isValid == 0 ? 'red' : 'green', opacity: 3 })} />
			</CustomTableCell>
			<CustomTableCell>
				<CustomButton color={palette({ color: 'blue', opacity: 5 })} onClick={onEdit}>
					수정
				</CustomButton>
			</CustomTableCell>
			<CustomTableCell>
				<CustomButton
					color={palette({
						color: parseInt(isValid) === 0 ? 'indigo' : 'red',
						opacity: 6,
					})}
					onClick={onActivate}>
					{parseInt(isValid) === 0 ? '활성' : '비활성'}
				</CustomButton>
			</CustomTableCell>
		</TableRow>
	);
};

export default CustomTableRow;
