import React, { useState, useEffect } from 'react';

// css
import styled from 'styled-components';

// redux
import { useSelector, useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../../store/commerce/main';
const { setTargetEvent } = eventActions;

const { event } = eventThunkActions;

// ui component
import {
	Button,
	DialogContent,
	DialogActions,
	MuiPickersUtilsProvider,
	KeyboardDatePicker,
	KeyboardTimePicker,
} from '../../../utils/material';
import DialogRow from './DialogRow';
import { DialogLayout } from '../../layout';

// util
import DateFnsUtils from '@date-io/date-fns';
import moment from 'moment';
moment.locale('ko');

const Input = styled.input`
	width: 700px;
`;

function EventDialog(props) {
	const { open, handleClose } = props;

	const [inputs, setInputs] = useState({
		index: '',
		title: '',
		subTitle: '',
		url: '',
		imageUrl: '',
		seq: 0,
	});
	const [startdate, setStartdate] = useState('');
	const [enddate, setEnddate] = useState('');

	const { index, title, subTitle, url, imageUrl, seq } = inputs;

	const { targetEvent } = useSelector(state => {
		return state.commerce.main.event;
	});
	const dispatch = useDispatch();
	const { makeEventAction, editEventAction } = event;

	useEffect(() => {
		if (!targetEvent) return;

		const { idx: index, startdate, enddate } = targetEvent;

		setInputs({
			index,
			...targetEvent,
		});

		setStartdate(startdate);
		setEnddate(enddate);
	}, [targetEvent]);

	const onChange = e => {
		const { name, value } = e.target;

		setInputs({
			...inputs,
			[name]: value,
		});
	};

	const resetInputs = () => {
		setInputs({
			index: '',
			title: '',
			subTitle: '',
			url: '',
			imageUrl: '',
			seq: 0,
		});
		setStartdate('');
		setEnddate('');
	};

	const closeDialog = () => {
		handleClose();
		resetInputs();
		dispatch(setTargetEvent([]));
	};

	const makeEvent = () => {
		dispatch(
			makeEventAction({
				...inputs,
				startdate,
				enddate,
			}),
		);
		closeDialog();
	};

	const editEvent = () => {
		dispatch(
			editEventAction({
				...inputs,
				startdate,
				enddate,
			}),
		);
		closeDialog();
	};

	const hasTargetData = targetEvent && targetEvent.constructor === Object;

	const renderActionButton = () => {
		const clickEvent = hasTargetData ? editEvent : makeEvent;
		const content = hasTargetData ? '이벤트 수정' : '이벤트 생성';

		return (
			<Button autoFocus onClick={clickEvent} color="primary">
				{content}
			</Button>
		);
	};

	return (
		<div>
			<DialogLayout open={open} closeDialog={closeDialog} title={hasTargetData ? '이벤트 컨텐츠 수정' : '이벤트 컨텐츠 생성'}>
				<DialogContent style={{ padding: '1rem' }} dividers>
					<DialogRow title={'타이틀'}>
						<Input name="title" value={title} onChange={onChange} />
					</DialogRow>
					<DialogRow title={'서브 타이틀'}>
						<Input name="subTitle" value={subTitle} onChange={onChange} />
					</DialogRow>
					<DialogRow title={'URL'}>
						<Input name="url" value={url} onChange={onChange} />
					</DialogRow>
					<DialogRow title={'이미지'}>
						<Input name="imageUrl" value={imageUrl} onChange={onChange} />
					</DialogRow>
					<DialogRow title={'시작 일자'}>
						<MuiPickersUtilsProvider utils={DateFnsUtils}>
							<KeyboardDatePicker
								disableToolbar
								variant="inline"
								format="yyyy/MM/dd"
								margin="normal"
								label="시작 일자"
								value={startdate}
								onChange={date => setStartdate(date)}
								KeyboardButtonProps={{
									'aria-label': 'change date',
								}}
							/>
							<KeyboardTimePicker
								variant="inline"
								label="시작 시간"
								margin="normal"
								value={startdate}
								onChange={date => setStartdate(date)}
								KeyboardButtonProps={{
									'aria-label': 'change time',
								}}
							/>
						</MuiPickersUtilsProvider>
					</DialogRow>
					<DialogRow title={'종료 일자'}>
						<MuiPickersUtilsProvider utils={DateFnsUtils}>
							<KeyboardDatePicker
								disableToolbar
								variant="inline"
								format="yyyy/MM/dd"
								margin="normal"
								label="종료 일자"
								value={enddate}
								onChange={date => setEnddate(date)}
								KeyboardButtonProps={{
									'aria-label': 'change date',
								}}
							/>
							<KeyboardTimePicker
								variant="inline"
								label="종료 시간"
								margin="normal"
								value={enddate}
								onChange={date => setEnddate(date)}
								KeyboardButtonProps={{
									'aria-label': 'change time',
								}}
							/>
						</MuiPickersUtilsProvider>
					</DialogRow>
					<DialogRow title={'배너 순서'}>
						<Input type={'number'} name="seq" value={seq} onChange={onChange} />
					</DialogRow>
				</DialogContent>
				<DialogActions style={{ margin: 0, padding: '0.5rem' }}>{renderActionButton()}</DialogActions>
			</DialogLayout>
		</div>
	);
}

export default EventDialog;
