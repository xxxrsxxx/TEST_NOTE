import React from "react";
import styled from "styled-components";

const RowContainer = styled.div`
  display: flex;
  width: 1000px;
  margin: 1.5rem 0;
`;

const Title = styled.div`
  font-size: 1.5rem;
  flex: 1;
`;

const DialogRow = (props) => {
  const { title, children } = props;

  return (
    <RowContainer>
      <Title>{title}</Title>
      {children}
    </RowContainer>
  );
};

export default DialogRow;
