import React, { useState, useEffect } from 'react';

// css
import styled from 'styled-components';

// redux
import { useSelector, useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../../store/commerce/main';
const { setTargetContent } = eventActions;
const { contents } = eventThunkActions;
// ui component
import {
	Button,
	DialogContent,
	DialogActions,
	MenuItem,
	Checkbox,
	ListItemText,
	FormControl,
	Select,
	InputLabel,
} from '../../../utils/material';
import DialogRow from './DialogRow';
import { DialogLayout } from '../../layout';

const Input = styled.input`
	width: 700px;
`;

function ContentDialog(props) {
	const { open, handleClose } = props;

	const [inputs, setInputs] = useState({
		index: '',
		title: '',
		subTitle: '',
		image: '',
		tags: '',
		url: '',
		seq: 0,
		tagKeyword: '',
		tagSeq: 0,
	});

	const { title, subTitle, image, tags, url, seq, tagKeyword, tagSeq } = inputs;

	// redux
	const { targetContent, tagList } = useSelector(state => state.commerce.main.contents);

	const dispatch = useDispatch();
	const { makeContentsAction, editContentsAction, makeTagAction } = contents;

	useEffect(() => {
		if (!targetContent) return;

		setInputs({
			index: targetContent.idx,
			...targetContent,
			tagKeyword: '',
			tagSeq: 0,
		});
	}, [targetContent]);

	const resetInputs = () => {
		setInputs({
			index: '',
			title: '',
			subTitle: '',
			image: '',
			tags: '',
			url: '',
			seq: 0,
			tagKeyword: '',
			tagSeq: 0,
		});
	};

	const onChange = e => {
		const { name, value } = e.target;

		setInputs({
			...inputs,
			[name]: value,
		});
	};

	const closeDialog = () => {
		handleClose();
		resetInputs();
		dispatch(setTargetContent([]));
	};

	const makeContents = () => {
		dispatch(makeContentsAction(inputs));
		closeDialog();
	};

	const editContents = () => {
		dispatch(editContentsAction(inputs));
		closeDialog();
	};

	const makeTag = () => {
		dispatch(makeTagAction({ keyword: tagKeyword, seq: tagSeq }));
		setInputs({
			...inputs,
			tagKeyword: '',
			tagSeq: '',
		});
	};

	const renderTagSelector = () => {
		return (
			<Select
				multiple
				name="tags"
				onChange={onChange}
				value={tags ? tags : []}
				renderValue={selected => {
					const result = [];
					selected.forEach(data => result.push(data.keyword));

					return result.join(', ');
				}}>
				{tagList.map(tag => {
					if (parseInt(tag.isValid) === 0) return;
					return (
						<MenuItem
							key={tag.keyword}
							value={tags && tags.find(data => data.keyword === tag.keyword) ? tags.find(data => data.keyword === tag.keyword) : tag}>
							<Checkbox checked={tags && !!tags.find(data => data.keyword === tag.keyword)} />
							<ListItemText primary={tag.keyword} />
						</MenuItem>
					);
				})}
			</Select>
		);
	};

	const hasTargetData = targetContent && targetContent.constructor === Object;

	const renderActionButton = () => {
		const clickEvent = hasTargetData ? editContents : makeContents;
		const content = hasTargetData ? '컨텐츠 수정' : '컨텐츠 생성';

		return (
			<Button autoFocus onClick={clickEvent} color="primary">
				{content}
			</Button>
		);
	};

	return (
		<div>
			<DialogLayout open={open} closeDialog={closeDialog} title={hasTargetData ? '세특발견 컨텐츠 수정' : '세특발견 컨텐츠 생성'}>
				<DialogContent style={{ padding: '1rem' }} dividers>
					<DialogRow title={'타이틀'}>
						<Input name="title" value={title} onChange={onChange} />
					</DialogRow>
					<DialogRow title={'서브 타이틀'}>
						<Input name="subTitle" value={subTitle} onChange={onChange} />
					</DialogRow>
					<DialogRow title={'URL'}>
						<Input name="url" value={url} onChange={onChange} />
					</DialogRow>
					<DialogRow title={'이미지'}>
						<Input name="image" value={image} onChange={onChange} />
					</DialogRow>
					<DialogRow title={'배너 순서'}>
						<Input name="seq" type={'number'} value={seq} onChange={onChange} />
					</DialogRow>
					<DialogRow title={'태그'}>
						<FormControl>
							<InputLabel>Tag</InputLabel>
							{renderTagSelector()}
						</FormControl>
					</DialogRow>
					<DialogRow title={'태그 생성'}>
						<input
							type={'text'}
							name="tagKeyword"
							value={tagKeyword}
							onChange={onChange}
							placeholder={'내용'}
							style={{ marginRight: '1rem' }}
						/>
						<input
							type={'number'}
							step={'100'}
							name="tagSeq"
							value={tagSeq}
							onChange={onChange}
							placeholder={'정렬 순서 (100단위 입력)'}
							style={{ marginRight: '1rem' }}
						/>
						<Button onClick={makeTag}>태그 생성</Button>
					</DialogRow>
				</DialogContent>
				<DialogActions style={{ margin: 0, padding: '0.5rem' }}>{renderActionButton()}</DialogActions>
			</DialogLayout>
		</div>
	);
}

export default ContentDialog;
