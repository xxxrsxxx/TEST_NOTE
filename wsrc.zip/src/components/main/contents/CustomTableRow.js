import React from 'react';
import Image from 'next/image';

// css
import styled, { css } from 'styled-components';
import palette from '../../../utils/style/palette';

// redux
import { useDispatch } from 'react-redux';
import { eventActions, eventThunkActions } from '../../../store/commerce/main';
const { setPopup, resetPopup } = eventActions;
const { contents } = eventThunkActions;
// ui component
import { TableRow, TableCell, Chip } from '../../../utils/material';
import { CustomButton, Circle } from '../../common';

// styled components
const ImageWrapper = styled.div``;

const LinkTag = styled.a`
	text-decoration: none;
	color: blue;
`;

const CustomTableCell = styled(TableCell)`
	font-size: 15px;
`;

const CustomTableRow = props => {
	const dispatch = useDispatch();

	const { dataRow, toggleDialog } = props;
	const { idx, title, subTitle, url, tags, image, seq, isValid } = dataRow;

	const { activateContentsAction } = contents;

	const renderTags = () => {
		if (!tags || tags.length === 0) {
			return null;
		}

		return tags.map(tag => <Chip style={{ margin: '0.3rem' }} key={tag.keyword} label={tag.keyword} />);
	};

	const onEdit = () => {
		dispatch(
			setTargetContent({
				idx,
				title,
				subTitle,
				image,
				tags,
				url,
				seq,
				isValid,
			}),
		);
		toggleDialog();
	};

	// setContentsStatus 으로 [활성/비활성]

	const onActivate = () =>
		dispatch(
			setPopup({
				visible: true,
				title: '확인',
				content: parseInt(isValid) === 0 ? '정말 활성화하시겠습니까?' : '정말 비활성화하시겠습니까?',
				onConfirm: () => {
					dispatch(resetPopup());
					dispatch(
						activateContentsAction({
							index: idx,
							title,
							subTitle,
							image,
							url,
							seq,
							isValid,
						}),
					);
				},
			}),
		);

	return (
		<TableRow>
			<CustomTableCell>{title}</CustomTableCell>
			<CustomTableCell>{subTitle}</CustomTableCell>
			<CustomTableCell>{url}</CustomTableCell>
			<CustomTableCell>
				<ImageWrapper>
					<Image src={image} alt="이미지" width={200} height={200} />
					<div>
						<LinkTag target="_blank" href={image}>
							이미지 바로가기
						</LinkTag>
					</div>
				</ImageWrapper>
			</CustomTableCell>
			<CustomTableCell>{seq}</CustomTableCell>
			<CustomTableCell>{renderTags()}</CustomTableCell>
			<CustomTableCell>
				<Circle color={palette({ color: isValid == 0 ? 'red' : 'green', opacity: 3 })} />
			</CustomTableCell>
			<CustomTableCell>
				<CustomButton color={palette({ color: 'blue', opacity: 5 })} onClick={onEdit}>
					수정
				</CustomButton>
			</CustomTableCell>
			<CustomTableCell>
				<CustomButton
					color={palette({
						color: parseInt(isValid) === 0 ? 'indigo' : 'red',
						opacity: 6,
					})}
					onClick={onActivate}>
					{parseInt(isValid) === 0 ? '활성' : '비활성'}
				</CustomButton>
			</CustomTableCell>
		</TableRow>
	);
};

export default CustomTableRow;
