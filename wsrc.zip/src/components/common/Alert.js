import React from 'react';

// redux
import { useSelector, useDispatch } from 'react-redux';
// action
import { eventActions } from '../../store/commerce/main';

// ui components
import { Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from '../../utils/material';

export default function AlertDialog() {
	const popup = useSelector(state => state.commerce.main.popup);
	const dispatch = useDispatch();

	const handleClose = () => dispatch(eventActions.resetPopup);

	const { title, content, onConfirm, onCancel } = popup;

	return (
		<div>
			<Dialog open={popup.visible} onClose={handleClose}>
				<DialogTitle>{title}</DialogTitle>
				<DialogContent style={{ width: '500px' }}>
					<DialogContentText>{content}</DialogContentText>
				</DialogContent>
				<DialogActions>
					<Button onClick={onConfirm} color="primary" autoFocus>
						확인
					</Button>
					<Button onClick={handleClose} color="secondary">
						취소
					</Button>
				</DialogActions>
			</Dialog>
		</div>
	);
}
