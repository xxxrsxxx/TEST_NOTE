import { DialogTitle, Typography, IconButton, CloseIcon } from '../../utils/material';

import palette from '../../utils/style/palette';

const CustomDialogTitle = props => {
	const { children, onClose } = props;
	return (
		<DialogTitle style={{ margin: 0, padding: '1rem' }} disableTypography>
			<Typography variant="h6">{children}</Typography>
			{onClose ? (
				<IconButton
					aria-label="close"
					style={{
						position: 'absolute',
						right: '0.5rem',
						top: '0.5rem',
						color: palette({ color: 'gray', opacity: 5 }),
					}}
					onClick={onClose}>
					<CloseIcon />
				</IconButton>
			) : null}
		</DialogTitle>
	);
};

export default CustomDialogTitle;
