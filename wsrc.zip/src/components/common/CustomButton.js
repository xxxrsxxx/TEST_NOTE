import React from "react";
import styled, { css } from "styled-components";

const sizes = {
  small: {
    fontSize: "15px",
    width: "4rem",
    padding: "0.3rem 0.5rem",
  },
  medium: {
    fontSize: "16px",
    width: "7rem",
    padding: "0.6rem 1rem",
  },
  large: {
    fontSize: "18px",
    width: "14rem",
    padding: "0.9rem 1.2rem",
  },
};

const sizeStyles = css`
  ${({ size }) => css`
    font-size: ${sizes[size].fontSize};
    width: ${sizes[size].width};
    padding: ${sizes[size].padding};
  `}
`;

const colorStyles = css`
  ${({ color }) => {
    const selectedColor = color ? color : "white";

    return css`
      border: 1px solid ${selectedColor};
      background: ${selectedColor};
      &:hover {
        opacity: 0.8;
      }
    `;
  }};
`;

const Wrapper = styled.div`
  width: 3rem;
  padding: 0.3rem 0.5rem;
  color: white;
  border-radius: 3px;
  text-align: center;
  cursor: pointer;

  transition: 0.3s;

  ${colorStyles}
  ${sizeStyles}
`;

const CustomButton = (props) => {
  const { size = "small", color, onClick, children } = props;
  return (
    <Wrapper size={size} color={color} onClick={onClick}>
      {children}
    </Wrapper>
  );
};

export default CustomButton;
