import React from "react";
import styled, { css } from "styled-components";

const CircleContainer = styled.div`
  width: 20px;
  height: 20px;
  border-radius: 10px;

  ${(props) => {
    return css`
      background: ${props.color};
    `;
  }}
`;

const Circle = (props) => {
  return <CircleContainer color={props.color} />;
};

export default Circle;
