import { Dialog } from '../../../utils/material';

import { CustomDialogTitle } from '../../common';

const DialogLayout = props => {
	const { size, open, closeDialog, title, children } = props;

	return (
		<Dialog maxWidth={size || 'lg'} onClose={closeDialog} open={open}>
			<CustomDialogTitle onClose={closeDialog}>{title}</CustomDialogTitle>
			{children}
		</Dialog>
	);
};

export default DialogLayout;
