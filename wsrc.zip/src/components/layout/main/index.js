import React, { useState, useEffect } from 'react';

import Image from 'next/image';
import { useRouter } from 'next/router';

// css
import styled from 'styled-components';

import { cookie } from '../../../utils/common/storage';

// ui component
import { DropdownContainer } from '../../common';
import { MenuItem } from '../../../utils/material';

import { globalVar } from '../../../static/setting';
const HeaderContainer = styled.div`
	display: flex;
	flex-direction: column;
`;

const HeaderWrapper = styled.div`
	height: 5rem;
	display: flex;
	align-items: center;
	background-color: #343a40;
	padding: 0 4rem;
`;

const MenuWrapper = styled.div`
	display: flex;
	flex: 1;
	align-items: center;
	color: white;
	font-size: 1.1rem;
	margin-left: 3rem;
`;

const AccountInfo = styled.div`
	padding: 0.6rem 1.2rem;
	color: white;
	border: 1px solid white;
	border-radius: 5px;
	cursor: pointer;
	font-weight: 400;

	transition: 0.3s;

	&:hover {
		opacity: 0.8;
	}
`;

const Title = styled.div`
	padding: 1.5rem;
`;

const MainLayout = props => {
	const { title, children } = props;
	const router = useRouter();

	const [swatId, setSwatId] = useState('');

	useEffect(() => {
		const swatId = cookie.getData('swatId');
		setSwatId(swatId);
	}, []);

	const goMainPage = () => {
		router.push('/');
	};

	const logout = () => {
		cookie.deleteData();
		router.push('/');
	};

	const renderTitle = () => {
		if (!title) return;

		return <div style={{ marginBottom: '1.5rem', fontSize: '2rem' }}>{title}</div>;
	};

	return (
		<div>
			{/* header */}
			<HeaderContainer>
				<HeaderWrapper>
					<div style={{ cursor: 'pointer' }}>
						<Image width={50} height={50} src={'/logo.png'} alt={'메인 로고'} onClick={goMainPage} />
					</div>
					<MenuWrapper>
						<DropdownContainer title={'앱 컨텐츠 관리'}>
							<MenuItem onClick={() => router.push('/main/contents')}>세특발견 컨텐츠</MenuItem>
							<MenuItem onClick={() => router.push('/main/event')}>이벤트</MenuItem>
							<MenuItem onClick={() => router.push('/main/tag')}>태그</MenuItem>
						</DropdownContainer>

						<DropdownContainer title={'어드민 관리'}>
							<MenuItem onClick={() => router.push('/main/contents')}>세특발견 컨텐츠</MenuItem>
							<MenuItem onClick={() => router.push('/main/event')}>이벤트</MenuItem>
							<MenuItem onClick={() => router.push('/main/tag')}>태그</MenuItem>
						</DropdownContainer>
					</MenuWrapper>
					<AccountInfo onClick={logout}>{swatId}</AccountInfo>
				</HeaderWrapper>
			</HeaderContainer>

			<Title>
				{renderTitle()}
				{children}
			</Title>
		</div>
	);
};

export default MainLayout;
