import MainLayout from "./main";
import DialogLayout from "./dialog";

export { MainLayout, DialogLayout };
