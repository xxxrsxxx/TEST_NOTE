import 'moment/locale/ko';
import axiosInstance from '../../utils/api';
import { storage, cookie } from '../../utils/common/storage';
/**
 * @name initialLayout
 * @dsc 페이지에 대해 반응형 정보 제공하기 위한 로직
 */
function initialLayout() {
	const config = {
		anchor: {
			html: document.querySelector('html'),
			body: document.querySelector('body'),
		},
		screen: {
			typeArray: [],
		},
	};
	/**
	 * @name setResScreen
	 * @dsc 반응형 대응 스크린 타입 셋업 함수
	 **/
	const setResScreen = () => {
		const { anchor, screen } = config;

		// res size info
		const standardSize = [
			{ s1: 768, s2: 960 },
			{ s1: 768, s2: 960 },
		];

		// size info
		let w = window.innerWidth;
		let selSize = standardSize[0];
		let deviceType = 'pc';

		const mobileReg = /Mobile|iP(hone|od|ad)|And roid|IEMobile/;

		if (window.navigator.userAgent.match(mobileReg)) deviceType = 'mobile';

		if (deviceType === 'mobile') {
			w = window.screen.width;
			selSize = standardSize[1];
		}

		let screenType = w < selSize['s1'] ? 1 : w < selSize['s2'] ? 2 : 3;
		let string = `${deviceType}-screen-${screenType}`;

		// anchor classList 일치 하지 않을 경우
		if (!anchor.html.classList.contains(string)) {
			//array method includes 같은 원리
			screen.typeArray.push(string);
			screen.typeArray.forEach(e => {
				anchor.html.classList.remove(e);
			});
		}
		anchor.html.classList.add(string);
		anchor.html.setAttribute('deviceType', `${deviceType}`);
		anchor.html.setAttribute('screenType', `${screenType}`);
	};
	/**
	 * @dsc window scroll event check
	 **/
	const scrollEvent = () => {
		const { anchor } = config;
		window.addEventListener('scroll', function (e) {
			anchor.body.classList.toggle('scroll_down', window.scrollY > 0);
		});
	};
	/**
	 * @dsc window resize event check
	 **/
	const resizeDom = () => {
		window.addEventListener('resize', () => {
			setResScreen();
		});
	};

	return (function () {
		scrollEvent();
		setResScreen();
		resizeDom();
	})();
}

/**
 * @name getGlobal
 * @dsc 전역 플러그인 함수
 * @return {{}}
 */
let assignGlobal = true;
let result = {};
const getGlobal = () => {
	const install = function () {
		/**
		 * @dsc set global variable
		 * @private
		 */
		const $_axios = axiosInstance();
		const $_storage = storage;
		const $_cookie = cookie;

		const _result = {};

		_result.$_axios = $_axios;
		_result.$_storage = $_storage;
		_result.$_cookie = $_cookie;

		return _result;
	};
	if (assignGlobal) {
		result = install();
		assignGlobal = false;
	}
	return result;
};
export { initialLayout, getGlobal };
