const tagData = {
  tagTableHeader: ["내용", "정렬순서", "활성 상태", "수정", "활성"],
};

export default tagData;
