const eventData = {
  eventTableHeader: [
    "타이틀",
    "서브 타이틀",
    "URL",
    "이미지 URL",
    "시작 일자",
    "종료 일자",
    "순서",
    "활성 여부",
    "수정",
    "활성",
  ],
};

export default eventData;
