import contentsData from "./contents";
import eventData from "./event";
import tagData from "./tag";

export { contentsData, eventData, tagData };
