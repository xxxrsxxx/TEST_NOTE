const contentsData = {
  contentsTableHeader: [
    "타이틀",
    "서브 타이틀",
    "URL",
    "이미지",
    "컨텐츠 순서",
    "태그",
    "활성 여부",
    "수정",
    "활성",
  ],
};

export default contentsData;
