import { createStore, applyMiddleware } from 'redux';
import ReduxThunk from 'redux-thunk';
import { createLogger } from 'redux-logger';

import module from '../store';

const logger = createLogger();
// const store = createStore(module, applyMiddleware(logger, ReduxThunk))
const store = createStore(module, applyMiddleware(ReduxThunk));
export default store;
